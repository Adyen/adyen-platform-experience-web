(function(global, factory) {
  typeof exports === "object" && typeof module !== "undefined" ? factory(exports) : typeof define === "function" && define.amd ? define(["exports"], factory) : (global = typeof globalThis !== "undefined" ? globalThis : global || self, factory(global.AdyenPlatformExperienceWeb = {}));
})(this, function(exports2) {
  "use strict";var __defProp = Object.defineProperty;
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);
var __privateWrapper = (obj, member, setter, getter) => ({
  set _(value) {
    __privateSet(obj, member, value, setter);
  },
  get _() {
    return __privateGet(obj, member, getter);
  }
});

  var _locale, _languageCode, _availableLocales, _supportedLocales, _customTranslations, _translations, _translationsLoader, _fetchTranslationFromCdnPromise, _ready, _currentRefresh, _markRefreshAsDone, _refreshWatchlist, _restamp, _Localization_instances, refreshTranslations_fn, _a, _numberOfMonths, _endTimestamp, _startTimestamp2, _endTimestampOffset, _startTimestampOffset, _DEFAULT_LOCALE, _cursorBlockIndex, _cursorBlockStartIndex, _cursorBlockEndIndex, _cursorStartIndex, _cursorEndIndex, _cursorIndex, _cursorOffset, _cursorTimestamp, _dynamicBlockHeight, _effect, _firstWeekDay, _frameBlocksCached, _locale2, _maxFrameSize, _selectionStartTimestamp, _selectionEndTimestamp, _size, __timeslice, _timeslice, _timezone, _today, _unwatchCurrentDay, _fromTimestamp, _toTimestamp, _fromBlockOffsetFromOrigin, _toBlockOffsetFromOrigin, _numberOfBlocks, _numberOfUnits, _daysOfWeek, _frameBlocks, _TimeFrame_instances, applyTimeSliceUpdate_fn, getClampedFrameOffset_fn, getContainedTimestamp_fn, getFrameBlockAtIndex_fn, shiftFrameCursorByOffset_fn, shiftOrigin_fn, shiftOriginIfNecessary_fn, _daysInWeek, _daysOfWeekCached, _daysOfWeekend, _currentDayTimestamp, _fromTimestamp2, _toTimestamp2, _numberOfBlocks2, _originMonthStartOffset, _originMonthStartTimestamp, _originYear, _selectionFromTimestamp, _selectionToTimestamp, _MonthFrame_instances, getBlockTimestampOffsetFromOrigin_fn, getDayOffsetTimestamp_fn, getStartForTimestamp_fn, updateSelectionTimestamps_fn, _b, _c, _config, _destructed, _frame, _highlightFrom, _highlightTo, _highlightInProgress, _highlightSelection, _pendingWatchNotification, _rangeOffsets, _lastHighlightRange, _cursorIndexFromEvent, _shiftFactorFromEvent, _watchCallback, _watchableEffect, _unwatch, _today2, _shiftControlsHandles, _shiftControlsList, _shiftControls, _watchlist, _lastWatchableSnapshot, _chainedNotifyEffectStack, _chainedWatchEffectStack, _grid, _d, _RANGE_OFFSETS_FORMAT_REGEX, _CURSOR_POINTER_INTERACTION_EVENTS, _DAYS_OF_WEEK_FALLBACK, _SHIFT_ACTIVATION_KEYS, _SHIFT_ALL_CONTROLS, _SHIFT_MINIMAL_CONTROLS, _Calendar_static, getOffsetsFromRange_fn, getShiftOffsetType_fn, getShiftOffsetUnit_fn, _watchableEffectCallback, withNotifyEffect_fn, _Calendar_instances, currentConfig_get, timeframe_get, canShiftInDirection_fn, configure_fn, cursorHandle_fn, destruct_fn, getShiftControlRecordAtIndex_fn, getShiftFactorFromEvent_fn, highlight_fn, clearHighlight_fn, rangeHighlight_fn, restoreHighlight_fn, reframe_fn, refreshHighlighting_fn, refreshShiftControls_fn;
  const API_ENVIRONMENTS = {
    test: "https://platform-components-external-test.adyen.com/platform-components-external/api/",
    live: "https://platform-components-external-live.adyen.com/platform-components-external/api/"
  };
  const CDN_ENVIRONMENTS = {
    test: "https://18e8543875.cdn.adyen.com/platform-components/v1-cdn-test",
    live: "https://18e8543875.cdn.adyen.com/platform-components/v1-cdn-live"
    // TODO change to right LIVE url
  };
  const FALLBACK_ENV = "test";
  const normalizeLoadingContext = (loadingContext) => {
    var _a2;
    return (_a2 = loadingContext == null ? void 0 : loadingContext.replace) == null ? void 0 : _a2.call(loadingContext, /([^/])$/, "$1/");
  };
  const normalizeUrl = (url) => url == null ? void 0 : url.replace(/^([^/])/, "/$1");
  const resolveEnvironment = /* @__PURE__ */ (() => {
    const envs = API_ENVIRONMENTS;
    const cdnEnvs = CDN_ENVIRONMENTS;
    return (env) => {
      const cdnUrl = cdnEnvs[env ?? FALLBACK_ENV] || cdnEnvs[FALLBACK_ENV];
      const apiUrl = envs[env ?? FALLBACK_ENV] || envs[FALLBACK_ENV];
      return {
        apiUrl,
        cdnTranslationsUrl: `${cdnUrl}/assets/translations`,
        cdnAssetsUrl: `${cdnUrl}/assets`
      };
    };
  })();
  const fn$1 = Function.prototype.bind.bind(Function.prototype.call);
  const asyncNoop = async () => {
  };
  const identity = (value2) => value2;
  const noop = () => {
  };
  const _toString = fn$1(Object.prototype.toString);
  const toStringTag = (value2) => _toString(value2).slice(8, -1);
  const deepFreeze = (obj) => {
    Object.keys(obj).forEach((prop) => {
      const value2 = obj[prop];
      if (value2 && typeof value2 === "object" && !Object.isFrozen(value2)) {
        deepFreeze(value2);
      }
    });
    return Object.freeze(obj);
  };
  const isBoolean = (value2) => value2 === !!value2;
  const isFunction = (value2) => typeof value2 === "function";
  const isNull = (value2) => value2 === null;
  const isNullish = (value2) => value2 == void 0;
  const isNumber = (value2) => typeof value2 === "number";
  const isPlainObject = (value2) => toStringTag(value2) === "Object";
  const isString$1 = (value2) => typeof value2 === "string";
  const isSymbol = (value2) => typeof value2 === "symbol";
  const isUndefined = (value2) => value2 === void 0;
  const ABORT_EVENT = "abort";
  const DEFAULT_ABORT_ERROR_MESSAGE = "signal is aborted without reason";
  const boolify = (value2, fallbackBoolean = value2) => isBoolean(value2) ? value2 : !!fallbackBoolean;
  const boolOrFalse = (value2) => value2 === true;
  const boolOrTrue = (value2) => value2 !== false;
  const falsify = (_2) => false;
  const truthify = (_2) => true;
  const enumerable = (value2, writable = false) => ({
    writable: boolOrFalse(writable),
    enumerable: true,
    value: value2
  });
  const getter = (get, enumerable2 = true) => ({
    enumerable: boolOrTrue(enumerable2),
    get
  });
  const hasOwnProperty = fn$1(Object.prototype.hasOwnProperty);
  const sameValue = (a2, b2) => a2 === b2 || !(a2 === a2 || b2 === b2);
  if (!hasOwnProperty(AbortSignal.prototype, "reason")) {
    try {
      Object.defineProperty(AbortSignal.prototype, "reason", {
        ...getter(function _getReason() {
          return this.aborted ? abortError() : void 0;
        }, true),
        configurable: true
      });
    } catch {
    }
  }
  if (!hasOwnProperty(AbortSignal.prototype, "throwIfAborted")) {
    AbortSignal.prototype.throwIfAborted = function _throwIfAborted() {
      if (this.aborted) throw this.reason ?? abortError();
    };
  }
  const abortError = (message = DEFAULT_ABORT_ERROR_MESSAGE) => new DOMException(message, "AbortError");
  const augmentSignalReason = (signal, reason) => {
    if (!sameValue(signal.reason, reason)) {
      try {
        Object.defineProperty(signal, "reason", enumerable(reason));
      } catch {
      }
    }
    return signal;
  };
  const abortedSignal = (reason = abortError()) => {
    if ("abort" in AbortSignal) {
      return AbortSignal.abort(reason);
    }
    const _controller = new AbortController();
    const _reason = isUndefined(reason) ? abortError() : reason;
    const { signal } = _controller;
    _controller.abort(_reason);
    augmentSignalReason(signal, _reason);
    return signal;
  };
  const abortSignalForAny = (signals) => {
    if ("any" in AbortSignal) {
      return AbortSignal.any(signals);
    }
    let _sourceSignals = /* @__PURE__ */ new Set();
    let _controller = new AbortController();
    const { signal } = _controller;
    let abort = function() {
      _sourceSignals.forEach((signal2) => signal2.removeEventListener(ABORT_EVENT, abort));
      _sourceSignals.clear();
      const reason = (this == null ? void 0 : this.reason) ?? abortError();
      _controller.abort(reason);
      augmentSignalReason(signal, reason);
      _controller = _sourceSignals = abort = void 0;
    };
    setup: {
      const NIL_EXCEPTION = Symbol("<NIL_EXCEPTION>");
      let _exception = NIL_EXCEPTION;
      filter: {
        try {
          for (const maybeSignal of signals) {
            if (!isAbortSignal(maybeSignal)) throw new TypeError(`Failed to convert value to 'AbortSignal'`);
            if (maybeSignal.aborted) break filter;
            _sourceSignals.add(maybeSignal);
          }
        } catch (ex) {
          _exception = ex;
          break filter;
        }
        _sourceSignals.forEach((signal2) => signal2.addEventListener(ABORT_EVENT, abort));
        break setup;
      }
      abort.call(signal);
      if (_exception !== NIL_EXCEPTION) throw _exception;
    }
    return signal;
  };
  const isAbortSignal = (value2) => value2 instanceof AbortSignal;
  const EMPTY_ARRAY = Object.freeze([]);
  const EMPTY_OBJECT = Object.freeze(/* @__PURE__ */ Object.create(null));
  const ALREADY_RESOLVED_PROMISE = Promise.resolve();
  Promise.race(EMPTY_ARRAY);
  const tryResolve = function(fn2, ...args) {
    return new Promise((resolve) => resolve(fn2.call(this, ...args)));
  };
  const getMappedValue = (key, map, factory2) => {
    let value2 = map.get(key);
    if (isUndefined(value2) && isFunction(factory2)) {
      if (!isUndefined(value2 = factory2(key, map))) {
        map.set(key, value2);
      }
    }
    return value2;
  };
  const listFrom = (value2, fallbackList = EMPTY_ARRAY) => {
    const stringedValue = `${value2 || ""}`.trim();
    const stringedList = stringedValue ? stringedValue.split(/(?:\s*,\s*)+/).filter(identity) : EMPTY_ARRAY;
    return stringedList.length ? stringedList : fallbackList;
  };
  const pickFrom = (list, option, defaultOption) => {
    if (list.includes(option)) return option;
    if (isNullish(option)) return list[0];
    return list.includes(defaultOption) ? defaultOption : list[0];
  };
  const some = fn$1(Array.prototype.some);
  const _uniqueFlatten = function _uniqueFlatten2(reversed, items, uniqueItems = /* @__PURE__ */ new Set()) {
    for (const item of items) {
      if (!Array.isArray(item)) {
        reversed && uniqueItems.delete(item);
        uniqueItems.add(item);
      } else _uniqueFlatten2(reversed, item, uniqueItems);
    }
    return uniqueItems;
  };
  fn$1(_uniqueFlatten, void 0, false);
  fn$1(_uniqueFlatten, void 0, true);
  const parseDate = (...args) => {
    const [value2] = args;
    const date2 = args.length >= 2 ? new Date(...args) : value2 instanceof Date ? value2 : new Date(isString$1(value2) || Number.isFinite(value2) ? value2 : void 0);
    const timestamp = date2.getTime();
    return Number.isFinite(timestamp) ? timestamp : void 0;
  };
  const clamp = (min2, value2, max2) => {
    if (Math.min(min2, max2) !== min2) [min2, max2] = [max2, min2];
    return Math.max(min2, Math.min(value2, max2));
  };
  const isBitSafeInteger = (value2) => !isSymbol(value2) && value2 === ~~value2;
  const isInfinity = (value2) => isNumber(value2) && 1 / value2 === 0;
  const mid = (low, high) => {
    if (Number.isInteger(low) && Number.isInteger(high)) {
      return low + Math.floor((high - low) / 2);
    }
    throw TypeError(`Expects 2 integer values: [${low}, ${high}]`);
  };
  const mod = (value2, modulo) => (value2 % modulo + modulo) % modulo;
  const MAX_BYTE_SCALE = 3;
  const getByteScale = (bytes) => {
    if (bytes <= 1) return 0;
    return Math.floor(Math.log(bytes) / Math.log(1024));
  };
  const getFileSize = (bytes) => {
    let scale = 0;
    let size = Math.max(0, Math.round(bytes));
    if (size > 999) {
      scale = clamp(1, getByteScale(size), MAX_BYTE_SCALE);
      size = Math.round(Number((size / 1024 ** scale).toPrecision(3)) * 10) / 10;
    }
    return { scale, size };
  };
  const getHumanReadableFileSize = (bytes) => {
    const { scale, size } = getFileSize(bytes);
    switch (scale) {
      case 0:
        return `${size} byte${size === 1 ? "" : "s"}`;
      case 1:
        return `${size} KB`;
      case 2:
        return `${size} MB`;
      case 3:
        return `${size} GB`;
    }
  };
  const getUploadedFilesFromSource = (uploadedFileSource) => {
    const uploadedFiles = /* @__PURE__ */ new Set();
    if (uploadedFileSource == null ? void 0 : uploadedFileSource.items) {
      for (const item of uploadedFileSource.items) {
        if (item.kind !== "file") continue;
        const file2 = item.getAsFile();
        if (file2) uploadedFiles.add(file2);
      }
    }
    return Array.from(
      uploadedFiles.size === 0 ? new Set((uploadedFileSource == null ? void 0 : uploadedFileSource.files) ?? uploadedFiles) : uploadedFiles
    );
  };
  const uniqueId = (() => {
    let counter = Date.now();
    return (prefix = "adyen-pe") => `${prefix}-${++counter}`;
  })();
  const uuid = /* @__PURE__ */ (() => {
    const _UUID_V4_FILLER_STRING = "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx";
    return () => _UUID_V4_FILLER_STRING.replace(/[xy]/g, (xy) => {
      const randomNibble = Math.random() * 16 | 0;
      const nibble = xy == "x" ? randomNibble : randomNibble & 3 | 8;
      return nibble.toString(16);
    });
  })();
  const asPlainObject = (value2, fallback = EMPTY_OBJECT) => isPlainObject(value2) ? value2 : asPlainObject(fallback, EMPTY_OBJECT);
  const structFrom = fn$1(Object.create, void 0);
  const struct = fn$1(structFrom, void 0, null);
  const withFreezeProxyHandlers = (handler = EMPTY_OBJECT) => {
    return Object.freeze({ ...handler, defineProperty: truthify, set: truthify });
  };
  const capitalize = (str) => str && (str == null ? void 0 : str.length) > 0 ? `${str[0].toUpperCase()}${str.slice(1)}` : str;
  const isEmptyString = (str) => isNullish(str) || isString$1(str) && /^\s*$/.test(str);
  const SETUP_ENDPOINT_PATH = "/setup";
  const AUTO_REFRESH = boolOrFalse(void 0);
  const MAX_AGE_MS = (() => {
    let maxAgeMs = 0;
    if (Number.isFinite(maxAgeMs) && (maxAgeMs = Math.max(0, ~~maxAgeMs))) {
      return maxAgeMs;
    }
  })();
  class AdyenPlatformExperienceError extends Error {
    constructor(type2, requestId, message, errorCode) {
      super(message);
      __publicField(this, "type");
      __publicField(this, "errorCode");
      __publicField(this, "requestId");
      this.type = type2;
      this.name = type2;
      this.errorCode = errorCode;
      this.requestId = requestId;
    }
  }
  const FILENAME_EXTRACTION_REGEX = /^[^]*?filename[^;\n]*=\s*(?:UTF-\d['"]*)?(?:(['"])([^]*?)\1|([^;\n]*))?[^]*?$/;
  var ErrorTypes = /* @__PURE__ */ ((ErrorTypes2) => {
    ErrorTypes2["HTTP_ERROR"] = "HTTP_ERROR";
    ErrorTypes2["NETWORK_ERROR"] = "NETWORK_ERROR";
    ErrorTypes2["CANCEL"] = "CANCEL";
    ErrorTypes2["IMPLEMENTATION_ERROR"] = "IMPLEMENTATION_ERROR";
    ErrorTypes2["ERROR"] = "ERROR";
    ErrorTypes2["EXPIRED_TOKEN"] = "EXPIRED_TOKEN";
    return ErrorTypes2;
  })(ErrorTypes || {});
  const getErrorType = (errorCode) => {
    switch (errorCode) {
      case 401:
        return "EXPIRED_TOKEN";
      default:
        return "HTTP_ERROR";
    }
  };
  const getResponseContentType = (response) => {
    var _a2;
    return (_a2 = response.headers.get("Content-Type")) == null ? void 0 : _a2.split(";", 1)[0];
  };
  const getResponseDownloadFilename = (response) => {
    const disposition = response.headers.get("Content-Disposition") ?? "";
    const filename = disposition.replace(FILENAME_EXTRACTION_REGEX, "$2$3");
    return decodeURIComponent(filename);
  };
  const getRequestBodyForContentType = (body, contentType) => {
    switch (contentType) {
      case "application/json":
        return JSON.stringify(body);
      case "multipart/form-data":
        return body instanceof FormData ? body : new FormData();
      default:
        return String(body);
    }
  };
  const getRequestObject = (options) => {
    var _a2;
    const { headers = [], method = "GET" } = options;
    const SDKVersion = !options.versionless && "1.7.1";
    const contentType = options.skipContentType ? void 0 : ((_a2 = options.contentType) == null ? void 0 : _a2.toLowerCase()) ?? "application/json";
    return {
      method,
      mode: "cors",
      cache: "default",
      credentials: "same-origin",
      headers: {
        Accept: "application/json, text/plain, */*",
        ...headers,
        // Skip Content-Type header for multipart/form-data requests
        // The browser will automatically set the content-type for such requests
        ...contentType && contentType !== "multipart/form-data" && { "Content-Type": contentType },
        ...SDKVersion && { "SDK-Version": SDKVersion }
      },
      redirect: "follow",
      signal: options.signal,
      referrerPolicy: "no-referrer-when-downgrade",
      ...method === "POST" && options.body && { body: getRequestBodyForContentType(options.body, contentType) }
    };
  };
  function handleFetchError({
    message,
    level,
    errorCode,
    type: type2 = "NETWORK_ERROR",
    requestId
  }) {
    switch (level) {
      case "silent": {
        break;
      }
      case "info":
      case "warn":
        console[level](message);
        break;
      case "error":
      default:
        throw new AdyenPlatformExperienceError(type2, requestId, message, errorCode);
    }
  }
  function isAdyenErrorResponse(data) {
    return data && data.errorCode && data.type && (data.detail || data.invalidFields) && data.status;
  }
  function parseSearchParams(parameters) {
    const params = new URLSearchParams();
    for (const param of Object.keys(parameters)) {
      const value2 = parameters[param];
      if (!isNullish(value2)) {
        if (Array.isArray(value2)) {
          value2.forEach((item) => params.append(param, item));
        } else {
          params.set(param, String(value2));
        }
      }
    }
    return params;
  }
  const createAbortable = (abortReason) => {
    let _abortController;
    let _abortSignal;
    let _abortPromise;
    const _abort = () => {
      if (isUndefined(_abortController)) return;
      const _abort2 = _abortController.abort.bind(_abortController);
      _abortController = void 0;
      _abort2();
    };
    const _getAbortPromise = () => {
      _abortPromise = new Promise((_2, reject) => {
        _abortSignal.addEventListener("abort", function _abort2() {
          _abortSignal.removeEventListener("abort", _abort2);
          reject(abortReason);
        });
        if (_abortSignal.aborted) throw abortReason;
      });
      _abortPromise.catch(noop);
      return _abortPromise;
    };
    const _refreshIfNecessary = () => {
      if (isUndefined(_abortController)) {
        _abortController = new AbortController();
        _abortSignal = _abortController.signal;
        _abortPromise = _getAbortPromise();
      }
      return abortable;
    };
    const abortable = struct({
      abort: enumerable(_abort),
      promise: getter(() => _abortPromise),
      reason: enumerable(abortReason),
      refresh: enumerable(_refreshIfNecessary),
      signal: getter(() => _abortSignal)
    });
    return _refreshIfNecessary();
  };
  const createDeferred = () => {
    let _promise;
    let _reject;
    let _resolve;
    const _refresh = () => {
      const previousResolve = _resolve ?? noop;
      const currentPromise = new Promise((resolve, reject) => {
        _resolve = resolve;
        _reject = reject;
      });
      previousResolve(_promise = currentPromise);
      return deferred;
    };
    const deferred = struct({
      promise: getter(() => _promise),
      refresh: enumerable(_refresh),
      reject: enumerable((reason) => _reject(reason)),
      resolve: enumerable((value2) => _resolve(value2))
    });
    return _refresh();
  };
  const createPromisor = (factory2) => {
    const _abortable = createAbortable();
    const _deferred = createDeferred();
    let _promise;
    const promisor = function(...args) {
      isUndefined(_promise) ? _deferred.refresh() : _abortable.abort();
      const currentPromise = tryResolve.call(this, factory2, _abortable.refresh().signal, ...args);
      (async () => {
        let isLatestPromise = _promise === (_promise = currentPromise);
        try {
          const value2 = await currentPromise.finally(() => {
            isLatestPromise = _promise === currentPromise;
            isLatestPromise && (_promise = void 0);
          });
          isLatestPromise && _deferred.resolve(value2);
        } catch (ex) {
          isLatestPromise && _deferred.reject(ex);
        }
      })();
      return currentPromise;
    };
    return Object.defineProperties(promisor, {
      abort: enumerable(_abortable.abort),
      promise: getter(() => _deferred.promise),
      refresh: enumerable(() => void _deferred.refresh())
    });
  };
  class SetupContext {
    constructor(_session) {
      __publicField(this, "_endpoints", EMPTY_OBJECT);
      __publicField(this, "_extraConfig", EMPTY_OBJECT);
      __publicField(this, "_revokeEndpointsProxy", noop);
      __publicField(this, "_beforeHttp", async () => {
        await this._refreshPromisor.promise.catch(noop);
      });
      __publicField(this, "_refreshPromisor", createPromisor((promisorSignal, signal) => {
        const abortSignal = isAbortSignal(signal) ? abortSignalForAny([signal, promisorSignal]) : promisorSignal;
        return this._fetchSetupEndpoint(abortSignal);
      }));
      this._session = _session;
      let _refreshPromise;
      this.refresh = (signal) => {
        this._refreshPromisor(signal).catch(noop);
        return _refreshPromise ?? (_refreshPromise = this._refreshPromisor.promise.finally(() => _refreshPromise = void 0).then(({ endpoints, ...rest }) => {
          this._resetEndpoints();
          ({ proxy: this._endpoints, revoke: this._revokeEndpointsProxy } = this._getEndpointsProxy(endpoints));
          this._extraConfig = deepFreeze(rest);
        }));
      };
    }
    get endpoints() {
      return this._endpoints;
    }
    get extraConfig() {
      return this._extraConfig;
    }
    _fetchSetupEndpoint(signal) {
      return this._session.http(null, {
        method: "POST",
        path: SETUP_ENDPOINT_PATH,
        errorLevel: "fatal",
        loadingContext: this.loadingContext,
        signal
      });
    }
    _getEndpointsProxy(endpoints) {
      const availableEndpoints = new Set(Object.keys(endpoints));
      const sessionAwareEndpoints = struct();
      return Proxy.revocable(
        EMPTY_OBJECT,
        withFreezeProxyHandlers({
          get: (target, endpoint, receiver) => {
            if (!availableEndpoints.has(endpoint)) {
              return Reflect.get(target, endpoint, receiver);
            }
            sessionAwareEndpoints[endpoint] ?? (sessionAwareEndpoints[endpoint] = (() => {
              const { method = "GET", url } = endpoints[endpoint];
              if (isUndefined(url || void 0)) return;
              return (...args) => {
                const httpOptions = this._getHttpOptions(method, url, ...args);
                return this._session.http(this._beforeHttp, httpOptions);
              };
            })());
            return sessionAwareEndpoints[endpoint];
          }
        })
      );
    }
    _getHttpOptions(method, path, ...args) {
      const { loadingContext } = this;
      const [request, requestParams] = args;
      const { path: pathParams, query: searchParams } = asPlainObject(requestParams);
      const params = searchParams && parseSearchParams(searchParams);
      if (isPlainObject(pathParams)) {
        for (const pathParamKey of Object.keys(pathParams)) {
          path = path.replace(`{${pathParamKey}}`, pathParams[pathParamKey]);
        }
      }
      return { loadingContext, ...request, method, params, path };
    }
    _resetEndpoints() {
      this._revokeEndpointsProxy();
      this._revokeEndpointsProxy = noop;
      this._endpoints = EMPTY_OBJECT;
    }
  }
  const ERR_SESSION_EXPIRED = Symbol("Error<SESSION_EXPIRED>");
  const ERR_SESSION_FACTORY_UNAVAILABLE = Symbol("Error<SESSION_FACTORY_UNAVAILABLE>");
  const ERR_SESSION_HTTP_UNAVAILABLE = Symbol("Error<SESSION_HTTP_UNAVAILABLE>");
  const ERR_SESSION_INVALID = Symbol("Error<SESSION_INVALID>");
  const ERR_SESSION_REFRESH_ABORTED = Symbol("Error<SESSION_REFRESH_ABORTED>");
  const EVT_SESSION_EXPIRED = "_sessionExpired";
  const EVT_SESSION_READY = "_sessionReady";
  const EVT_SESSION_REFRESHED = "_sessionRefreshed";
  const EVT_SESSION_REFRESHING_END = "_sessionRefreshingEnd";
  const EVT_SESSION_REFRESHING_START = "_sessionRefreshingStart";
  const INTERNAL_EVT_SESSION_DEADLINE = "_session.deadline";
  const INTERNAL_EVT_SESSION_READY = "_session.ready";
  const INTERNAL_EVT_SESSION_REFRESHING_END = "_session.refreshingEnd";
  const INTERNAL_EVT_SESSION_REFRESHING_START = "_session.refreshingStart";
  const _canAutofresh = async (refresher) => {
    const { specification } = refresher.context;
    const canAutofresh = await tryResolve(async () => {
      const _autoRefresh = specification.autoRefresh;
      return isFunction(_autoRefresh) ? _autoRefresh.call(specification, refresher.session) : _autoRefresh;
    }).catch(falsify);
    return boolOrFalse(canAutofresh);
  };
  const createSessionAutofresher = (refresher) => {
    let _unlistenExpired = refresher.context.emitter.on(EVT_SESSION_EXPIRED, () => _autofresh(false));
    let _autofreshSignal;
    let _autofreshPromisor = createPromisor(async (signal, skipCanAutofreshCheck = false) => {
      _autofreshSignal = signal;
      const canAutofresh = boolOrFalse(skipCanAutofreshCheck) || await _canAutofresh(refresher);
      if (_autofreshSignal !== signal) {
        return;
      }
      if (canAutofresh && refresher.pending && !refresher.refreshing) {
        refresher.refresh(_autofreshSignal).catch(noop);
      }
    });
    let _autofresh = (skipCanAutofreshCheck = false) => {
      if (!refresher.refreshing) void _autofreshPromisor(skipCanAutofreshCheck);
    };
    let _destruct = () => {
      _unlistenExpired();
      _autofreshPromisor.abort();
      _autofreshPromisor = _autofreshSignal = _unlistenExpired = void 0;
      _autofresh = _destruct = noop;
    };
    const autofresh = (skipCanAutofreshCheck = false) => _autofresh(skipCanAutofreshCheck);
    return Object.defineProperties(autofresh, {
      destruct: getter(() => _destruct, false)
    });
  };
  const DEFAULT_INTERVAL_MS = 1e3;
  const MAX_INTERVAL_MS = 2147483647;
  const createInterval = (callback, ms = DEFAULT_INTERVAL_MS, runCallbackAsap = false) => {
    var _a2;
    let _abortController = new AbortController();
    let _intervalDelay = clamp(0, ~~ms, MAX_INTERVAL_MS);
    let _shouldRunCallbackAsap = boolOrFalse(runCallbackAsap);
    if (!Number.isFinite(_intervalDelay)) {
      _intervalDelay = DEFAULT_INTERVAL_MS;
    }
    const _startTime = ((_a2 = document.timeline) == null ? void 0 : _a2.currentTime) ?? performance.now();
    const _cancel = () => {
      _abortController == null ? void 0 : _abortController.abort();
      _abortController = void 0;
    };
    const _frame2 = (time) => {
      if (!_abortController || _abortController.signal.aborted) return;
      _scheduleFrame(time);
      callback(time);
    };
    const _scheduleFrame = (time) => {
      let delay = 0;
      if (!_shouldRunCallbackAsap) {
        const elapsed = time - _startTime;
        const roundedElapsed = Math.round(elapsed / _intervalDelay) * _intervalDelay;
        const targetNext = _startTime + roundedElapsed + _intervalDelay;
        delay = targetNext - performance.now();
      }
      setTimeout(() => requestAnimationFrame(_frame2), delay);
    };
    _scheduleFrame(_startTime);
    _shouldRunCallbackAsap = false;
    return struct({
      cancel: enumerable(_cancel),
      delay: enumerable(ms),
      signal: enumerable(_abortController.signal)
    });
  };
  const createWatchListCurrentStateRecord = (entries) => {
    const statePropertyDescriptors = {};
    const entriesPropertyDescriptors = Object.getOwnPropertyDescriptors(entries);
    for (const key of Object.keys(entries)) {
      const { get, value: value2 } = entriesPropertyDescriptors[key];
      statePropertyDescriptors[key] = getter(
        get || (isFunction(value2) ? (
          // ensure that the `this` binding of the getter function is preserved
          value2.bind(entries)
        ) : () => value2)
      );
    }
    return struct(statePropertyDescriptors);
  };
  const createWatchListSubscriptionEventCallbacks = () => {
    const callbacks = { idle: null, resume: null };
    const descriptors = {};
    for (const key of Object.keys(callbacks)) {
      descriptors[key] = {
        get: () => callbacks[key] ?? noop,
        set: (callback) => {
          if (isNullish(callback)) {
            callbacks[key] = null;
          } else if (isFunction(callback) && callback !== callbacks[key]) {
            callbacks[key] = callback;
          }
        }
      };
    }
    return struct(descriptors);
  };
  const UNSUBSCRIBE_TOKEN = Symbol("<<UNSUBSCRIBE>>");
  const isWatchlistUnsubscribeToken = (currentStateSnapshotOrUnsubscribeToken) => currentStateSnapshotOrUnsubscribeToken === UNSUBSCRIBE_TOKEN;
  const createWatchlist = (entries) => {
    let lastStateSnapshot;
    const currentState = createWatchListCurrentStateRecord(entries);
    const subscriptionEventCallbacks = createWatchListSubscriptionEventCallbacks();
    const subscriptionCallbacksWithReferenceCounting = /* @__PURE__ */ new Map();
    const unsubscribeCallbacks = /* @__PURE__ */ new WeakMap();
    const _getCurrentStateSnapshot = () => Object.freeze({ ...currentState });
    const _isWithoutSubscriptionCallbacks = () => subscriptionCallbacksWithReferenceCounting.size === 0;
    const _notifySubscriptions = (unsubscribeToken) => {
      if (_isWithoutSubscriptionCallbacks()) return;
      if (isWatchlistUnsubscribeToken(unsubscribeToken)) {
        const subscriptionCallbacks = [];
        subscriptionCallbacksWithReferenceCounting.forEach((referenceCount, callback) => {
          subscriptionCallbacks.push(callback);
          const unsubscribeCallback = unsubscribeCallbacks.get(callback);
          while (referenceCount--) unsubscribeCallback == null ? void 0 : unsubscribeCallback();
        });
        subscriptionCallbacks.forEach((callback) => callback(unsubscribeToken));
        return true;
      }
      const currentStateSnapshot = lastStateSnapshot;
      lastStateSnapshot = _getCurrentStateSnapshot();
      for (const key of Object.keys(lastStateSnapshot)) {
        if (sameValue(lastStateSnapshot[key], currentStateSnapshot[key])) continue;
        subscriptionCallbacksWithReferenceCounting.forEach((_2, callback) => callback(lastStateSnapshot));
        return true;
      }
      return false;
    };
    const subscribe = (subscriptionCallback) => {
      if (!isFunction(subscriptionCallback)) return noop;
      const unsubscribeCallback = getMappedValue(subscriptionCallback, unsubscribeCallbacks, () => {
        let unsubscribe = () => {
          const subscriptionCallbackReferenceCount = subscriptionCallbacksWithReferenceCounting.get(subscriptionCallback) || 0;
          if (subscriptionCallbackReferenceCount === 1) {
            unsubscribe = void 0;
            subscriptionCallbacksWithReferenceCounting.delete(subscriptionCallback);
            unsubscribeCallbacks.delete(subscriptionCallback);
            if (_isWithoutSubscriptionCallbacks()) {
              lastStateSnapshot = void 0;
              subscriptionEventCallbacks.idle();
            }
          } else if (subscriptionCallbackReferenceCount > 1) {
            subscriptionCallbacksWithReferenceCounting.set(subscriptionCallback, subscriptionCallbackReferenceCount - 1);
          }
        };
        return () => {
          unsubscribe == null ? void 0 : unsubscribe();
        };
      });
      const willResumeSubscriptions = _isWithoutSubscriptionCallbacks();
      subscriptionCallbacksWithReferenceCounting.set(
        subscriptionCallback,
        (subscriptionCallbacksWithReferenceCounting.get(subscriptionCallback) || 0) + 1
      );
      if (willResumeSubscriptions) {
        lastStateSnapshot = _getCurrentStateSnapshot();
        subscriptionEventCallbacks.resume();
      }
      subscriptionCallback(lastStateSnapshot);
      return unsubscribeCallback;
    };
    return struct({
      idle: getter(_isWithoutSubscriptionCallbacks),
      on: enumerable(subscriptionEventCallbacks),
      cancelSubscriptions: enumerable(() => _notifySubscriptions(UNSUBSCRIBE_TOKEN)),
      requestNotification: enumerable(() => _notifySubscriptions()),
      snapshot: getter(() => lastStateSnapshot ?? _getCurrentStateSnapshot()),
      subscribe: enumerable(subscribe)
    });
  };
  const clock = (() => {
    let interval;
    const { cancelSubscriptions, requestNotification, subscribe, on: on2 } = createWatchlist({
      // Use wrapper function instead of direct reference to `Date.now`,
      // otherwise, tests will fail since `Date.now` won't be mocked
      now: () => Date.now()
    });
    on2.resume = () => {
      interval = createInterval(requestNotification, 1e3, false);
    };
    on2.idle = () => {
      interval == null ? void 0 : interval.cancel();
      interval = void 0;
    };
    return struct({
      cancelSubscriptions: enumerable(cancelSubscriptions),
      subscribe: enumerable(subscribe)
    });
  })();
  const createEventEmitter = () => {
    const _eventTarget = new class extends EventTarget {
    }();
    const _emitEvent = (type2, ...restArgs) => {
      const [detail] = restArgs;
      if (restArgs.length && isUndefined(detail)) {
        console.warn(
          "Unexpected value `undefined` provided for event detail.\n	Turn off this warning by doing either of the following:\n	(1) omit the optional event detail parameter.\n	(2) explicitly pass `null` for the event detail parameter (instead of `undefined`).\n"
        );
      }
      const event = new CustomEvent(
        type2,
        struct({
          bubbles: enumerable(false),
          cancelable: enumerable(false),
          detail: enumerable(detail ?? null)
        })
      );
      return _eventTarget.dispatchEvent(event);
    };
    const _onEvent = (type2, listener) => {
      if (!isFunction(listener)) return noop;
      const _listener = (evt) => listener.call(
        null,
        struct({
          detail: enumerable(evt.detail),
          timeStamp: enumerable(evt.timeStamp),
          type: enumerable(evt.type)
        })
      );
      _eventTarget.addEventListener(type2, _listener);
      return () => _eventTarget.removeEventListener(type2, _listener);
    };
    return struct({
      emit: enumerable(_emitEvent),
      on: enumerable(_onEvent)
    });
  };
  const createSessionDeadline = (emitter, specification) => {
    let _deadlineSignal;
    let _deadlineTimestamp = Infinity;
    let _refreshPromisorSignal;
    let _stopDeadlineClock;
    const _deadlineAbortable = createAbortable();
    const _deadlineEmitter = createEventEmitter();
    const _clearDeadline = () => {
      _deadlineSignal == null ? void 0 : _deadlineSignal.removeEventListener("abort", _clearDeadline);
      _deadlineTimestamp = Infinity;
      _stopDeadlineClock == null ? void 0 : _stopDeadlineClock();
      _deadlineAbortable.refresh();
      _deadlineEmitter.emit(INTERNAL_EVT_SESSION_DEADLINE);
    };
    const _refreshPromisor = createPromisor(async (signal, session) => {
      _refreshPromisorSignal = signal;
      const deadline = await tryResolve(() => {
        const _deadline = specification.deadline;
        return isFunction(_deadline) ? _deadline.call(specification, session, signal) : _deadline;
      }).catch(noop);
      if (_refreshPromisorSignal !== signal) return;
      const _deadlines = (Array.isArray(deadline) ? deadline : [deadline]).filter((deadline2) => deadline2 || deadline2 === 0);
      if (_deadlines.length > 0) {
        let _deadlineElapsed = false;
        let _signals = /* @__PURE__ */ new Set();
        for (const deadline2 of _deadlines) {
          if (isAbortSignal(deadline2)) {
            if (_deadlineElapsed = deadline2.aborted) break;
            _signals.add(deadline2);
          } else {
            _deadlineTimestamp = Math.min(_deadlineTimestamp, parseDate(deadline2) ?? Infinity);
            if (_deadlineElapsed = _deadlineTimestamp <= Date.now()) break;
          }
        }
        _deadlineElapsed || (_deadlineElapsed = _signals.size < 1 && !Number.isFinite(_deadlineTimestamp));
        if (!_deadlineElapsed) {
          _deadlineSignal = abortSignalForAny([..._signals, _deadlineAbortable.signal]);
          _deadlineSignal.addEventListener("abort", _clearDeadline);
          _startDeadlineClock();
        } else _deadlineSignal ?? (_deadlineSignal = abortedSignal());
        _deadlines.length = 0;
        _signals.clear();
      } else _deadlineSignal = void 0;
    });
    const _startDeadlineClock = () => {
      if (!Number.isFinite(_deadlineTimestamp)) return;
      let unsubscribeClock = clock.subscribe((snapshotOrSignal) => {
        if (isWatchlistUnsubscribeToken(snapshotOrSignal)) return _clearDeadline();
        if (snapshotOrSignal.now >= _deadlineTimestamp) _deadlineAbortable.abort();
      });
      _stopDeadlineClock = () => {
        unsubscribeClock == null ? void 0 : unsubscribeClock();
        unsubscribeClock = _stopDeadlineClock = void 0;
      };
    };
    return struct({
      elapse: enumerable(_deadlineAbortable.abort),
      elapsed: getter(() => _deadlineSignal && _deadlineSignal.aborted),
      on: enumerable(_deadlineEmitter.on),
      refresh: enumerable(_refreshPromisor.bind(void 0)),
      signal: getter(() => _deadlineAbortable.signal)
    });
  };
  const createSessionRefresher = (emitter, specification) => {
    let _refreshPending = false;
    let _refreshingPromise;
    let _refreshingSignal;
    let _waitForRefreshingPromise = true;
    let _session;
    const _sessionPlaceholder = Symbol("<next_session>");
    const _refresherEmitter = createEventEmitter();
    function _assertSession(value2) {
      var _a2;
      try {
        (_a2 = specification.assert) == null ? void 0 : _a2.call(specification, value2);
      } catch (ex) {
        throw ERR_SESSION_INVALID;
      }
    }
    function _assertSessionFactory(value2) {
      if (!isFunction(value2)) throw ERR_SESSION_FACTORY_UNAVAILABLE;
    }
    const _refreshPromisor = createPromisor((promisorSignal, signal) => {
      if (!_refreshingSignal) _refreshingSignal = promisorSignal;
      else return _refreshSession(isAbortSignal(signal) ? abortSignalForAny([signal, promisorSignal]) : promisorSignal);
    });
    const _refreshSession = async (signal) => {
      let nextSession = _sessionPlaceholder;
      try {
        _refreshPending = false;
        _refreshingSignal = signal;
        if (_waitForRefreshingPromise) {
          await (_refreshingPromise ?? (_refreshingPromise = (async () => {
            await ALREADY_RESOLVED_PROMISE;
            _waitForRefreshingPromise = false;
            _refresherEmitter.emit(INTERNAL_EVT_SESSION_REFRESHING_START);
          })()));
        }
        _assertSessionFactory(specification.onRefresh);
        nextSession = await tryResolve(() => specification.onRefresh(_session, signal)).finally(() => {
          if (signal.aborted) throw ERR_SESSION_REFRESH_ABORTED;
        });
      } finally {
        if (_refreshingSignal === signal) {
          try {
            if (nextSession !== _sessionPlaceholder) {
              _assertSession(nextSession);
              _session = nextSession;
              _refresherEmitter.emit(INTERNAL_EVT_SESSION_READY);
            }
          } finally {
            _refreshingPromise = void 0;
            _waitForRefreshingPromise = true;
            _refresherEmitter.emit(INTERNAL_EVT_SESSION_REFRESHING_END);
          }
        }
      }
    };
    emitter.on(EVT_SESSION_EXPIRED, () => _refreshPending = !_refreshingPromise);
    void _refreshPromisor();
    return struct({
      context: enumerable(
        struct({
          emitter: enumerable(emitter),
          specification: enumerable(specification)
        })
      ),
      on: enumerable(_refresherEmitter.on),
      pending: getter(() => _refreshPending),
      promise: getter(() => _refreshPromisor.promise),
      refresh: enumerable(_refreshPromisor.bind(void 0)),
      refreshing: getter(() => !!_refreshingPromise),
      session: getter(() => _session),
      signal: getter(() => _refreshingSignal)
    });
  };
  class SessionContext {
    constructor(_specification) {
      __publicField(this, "_session");
      __publicField(this, "_autofresh");
      __publicField(this, "_deadline");
      __publicField(this, "_refresher");
      __publicField(this, "_eventEmitter", createEventEmitter());
      this._specification = _specification;
      this._deadline = createSessionDeadline(this._eventEmitter, this._specification);
      this._refresher = createSessionRefresher(this._eventEmitter, this._specification);
      this._autofresh = createSessionAutofresher(this._refresher);
      this._deadline.on(INTERNAL_EVT_SESSION_DEADLINE, () => this._eventEmitter.emit(EVT_SESSION_EXPIRED));
      this._refresher.on(INTERNAL_EVT_SESSION_REFRESHING_START, () => this._eventEmitter.emit(EVT_SESSION_REFRESHING_START));
      this._refresher.on(INTERNAL_EVT_SESSION_REFRESHING_END, () => this._eventEmitter.emit(EVT_SESSION_REFRESHING_END));
      this._refresher.on(INTERNAL_EVT_SESSION_READY, () => {
        this._session = this._refresher.session;
        this._deadline.refresh(this._session).finally(() => this._eventEmitter.emit(EVT_SESSION_REFRESHED));
        this._eventEmitter.emit(EVT_SESSION_READY);
      });
      this.http = this._sessionHttp.bind(this);
      this.on = this._eventEmitter.on;
      this.refresh = this._refresher.refresh;
    }
    get isExpired() {
      return this._deadline.elapsed;
    }
    get refreshing() {
      return this._refresher.refreshing;
    }
    _assertSessionHttp(value2) {
      if (!isFunction(value2)) throw ERR_SESSION_HTTP_UNAVAILABLE;
    }
    async _sessionHttp(beforeHttp, ...args) {
      this._autofresh(true);
      while (true) {
        try {
          await this._refresher.promise.catch(noop);
          const { signal } = this._deadline;
          await (beforeHttp == null ? void 0 : beforeHttp(this._session, signal, ...args));
          this._assertSessionHttp(this._specification.http);
          return await this._specification.http(this._session, signal, ...args);
        } catch (ex) {
          if (ex !== ERR_SESSION_EXPIRED) throw ex;
          if (this._refresher.pending) continue;
          this._deadline.elapse();
        }
      }
    }
  }
  const API_VERSION = "v1";
  const errorHandlerHelper = (errorHandler, error) => {
    try {
      errorHandler == null ? void 0 : errorHandler(error);
    } catch {
      throw error;
    }
  };
  async function http(options) {
    const { errorLevel, loadingContext = "", path } = options;
    const versionless = options.versionless || false;
    const request = getRequestObject(options);
    const url = new URL(`${normalizeLoadingContext(loadingContext)}${versionless ? "" : API_VERSION}${normalizeUrl(path)}`);
    if (options.params) {
      options.params.forEach((value2, param) => {
        const decodedValue = decodeURIComponent(value2);
        if (decodedValue) url.searchParams.append(param, decodedValue);
      });
    }
    return (async () => {
      let errorPassThrough = false;
      const error = { level: errorLevel };
      try {
        const res = await fetch(url, request);
        if (res.ok) {
          if (res.status === 204) {
            return null;
          }
          try {
            const contentType = getResponseContentType(res);
            switch (contentType) {
              case "application/json":
                return await res.json();
              // (!!)
              default:
                const blob = await res.blob();
                const filename = getResponseDownloadFilename(res);
                return { blob, filename };
            }
          } catch (ex) {
            errorPassThrough = true;
            throw ex;
          }
        }
        error.type = getErrorType(res.status);
        const response = await res.json();
        error.message = options.errorMessage || `Service at ${url} not available`;
        error.errorCode = (response == null ? void 0 : response.status) == void 0 ? void 0 : String(response.status);
        error.requestId = response == null ? void 0 : response.requestId;
        if (isAdyenErrorResponse(response)) {
          error.message = response.detail;
          error.errorCode = response.errorCode;
          error.status = response.status;
        }
        errorHandlerHelper(options.errorHandler, error);
      } catch (ex) {
        if (errorPassThrough) {
          errorHandlerHelper(options.errorHandler, ex);
          throw ex;
        }
        if (!error.type) {
          error.type = ErrorTypes.NETWORK_ERROR;
        }
        errorHandlerHelper(options.errorHandler, ex);
        error.message = options.errorMessage || `Call to ${url} failed. Error: ${ex}`;
      }
      handleFetchError(error);
    })();
  }
  function httpGet(options) {
    return http({ ...options, method: "GET" });
  }
  class AuthSessionSpecification {
    constructor(onSessionCreate) {
      __publicField(this, "assert", (maybeSession) => {
        if (isPlainObject(maybeSession)) {
          const id2 = isString$1(maybeSession.id) ? maybeSession.id.trim() : void 0;
          const token = isString$1(maybeSession.token) ? maybeSession.token.trim() : void 0;
          if (id2 && token) return;
        }
        throw void 0;
      });
      __publicField(this, "deadline", (session) => {
        const deadlines = [];
        let issuedAt;
        let expiresAt;
        try {
          ({ iat: issuedAt, exp: expiresAt } = JSON.parse(atob(session == null ? void 0 : session.token.split(".")[1])));
          deadlines.push(expiresAt);
        } catch {
          issuedAt = Date.now();
        }
        if (!isUndefined(MAX_AGE_MS)) {
          const issuedAtDate = new Date(issuedAt);
          deadlines.push(issuedAtDate.setMilliseconds(issuedAtDate.getMilliseconds() + MAX_AGE_MS));
        }
        return deadlines;
      });
      __publicField(this, "http", async (session, sessionSignal, httpOptions) => {
        const { headers, signal, ...restOptions } = httpOptions;
        try {
          const sessionHttpOptions = {
            ...restOptions,
            headers: {
              ...headers,
              ...session && { Authorization: `Bearer ${session.token}` }
            },
            errorHandler: this._errorHandler,
            signal: isAbortSignal(signal) ? abortSignalForAny([sessionSignal, signal]) : sessionSignal
          };
          return await http(sessionHttpOptions);
        } catch (ex) {
          if ((ex == null ? void 0 : ex.type) === ErrorTypes.EXPIRED_TOKEN) throw ERR_SESSION_EXPIRED;
          throw ex;
        }
      });
      this.onSessionCreate = onSessionCreate;
      this._errorHandler = this._errorHandler.bind(this);
      Object.defineProperties(this, {
        autoRefresh: enumerable(AUTO_REFRESH),
        onRefresh: enumerable((_2, signal) => this.onSessionCreate(signal))
      });
    }
    _errorHandler(error) {
      try {
        if (this.errorHandler) this.errorHandler(error);
      } catch {
      }
      throw error;
    }
  }
  const _NO_ERR = Symbol("<<NO_ERR>>");
  function _assertError(error) {
    /* istanbul ignore if -- @preserve */
    if (error === _NO_ERR) {
      throw new TypeError("Illegal error");
    }
  }
  const createErrorContainer = () => {
    let _error = _NO_ERR;
    const _resetError = () => {
      _error = _NO_ERR;
    };
    const _setError = (error) => {
      _assertError(error);
      _error = error;
    };
    return struct({
      error: getter(() => _error === _NO_ERR ? void 0 : _error),
      hasError: getter(() => _error !== _NO_ERR),
      reset: enumerable(_resetError),
      set: enumerable(_setError)
    });
  };
  class AuthSession {
    constructor() {
      __publicField(this, "_canSkipSessionRefresh", false);
      __publicField(this, "_refreshPromisorSignal");
      __publicField(this, "_sessionIsFrozen", false);
      __publicField(this, "_errorContainer", createErrorContainer());
      __publicField(this, "_specification", new AuthSessionSpecification());
      __publicField(this, "_sessionContext", new SessionContext(this._specification));
      __publicField(this, "_setupContext", new SetupContext(this._sessionContext));
      __publicField(this, "_refreshPromisor", createPromisor(async (signal, skipSessionRefreshIfPossible = false) => {
        let authStateChanged = !this._refreshPromisorSignal;
        let isLatestRefresh = this._refreshPromisorSignal === (this._refreshPromisorSignal = signal);
        const onlySetupRefresh = boolOrFalse(skipSessionRefreshIfPossible) && this._canSkipSessionRefresh;
        if (authStateChanged) {
          authStateChanged = false;
          this._errorContainer.reset();
          this._onAuthStateChanged();
        }
        try {
          await (onlySetupRefresh ? this._setupContext : this._sessionContext).refresh(signal).finally(() => isLatestRefresh = this._refreshPromisorSignal === signal);
        } catch (ex) {
          if (!isLatestRefresh) return;
          if (!signal.aborted && (onlySetupRefresh || ex !== ERR_SESSION_REFRESH_ABORTED)) this._errorContainer.set(ex);
          authStateChanged = !onlySetupRefresh;
        } finally {
          if (authStateChanged || onlySetupRefresh && isLatestRefresh) {
            this._refreshPromisorSignal = void 0;
            this._onAuthStateChanged();
          }
        }
      }));
      __publicField(this, "_watchlist", createWatchlist({
        endpoints: () => this._setupContext.endpoints,
        extraConfig: () => this._setupContext.extraConfig,
        hasError: () => this._errorContainer.hasError,
        isExpired: () => this._sessionContext.isExpired,
        isFrozen: () => this._sessionIsFrozen,
        refreshing: () => !!this._refreshPromisorSignal
      }));
      __publicField(this, "freeze", () => {
        this._sessionIsFrozen = true;
        this._watchlist.on.resume = void 0;
        this._watchlist.cancelSubscriptions();
      });
      __publicField(this, "http", this._sessionContext.http.bind(this._sessionContext, null));
      __publicField(this, "refresh", this._refresh.bind(this));
      __publicField(this, "subscribe", this._watchlist.subscribe);
      this._watchlist.on.resume = () => {
        const unlisteners = [
          this._sessionContext.on(EVT_SESSION_EXPIRED, () => {
            this._canSkipSessionRefresh = false;
            this._onAuthStateChanged();
          }),
          this._sessionContext.on(EVT_SESSION_READY, () => {
            void this._refresh(this._canSkipSessionRefresh = true);
          })
        ];
        this._watchlist.on.idle = () => {
          this._watchlist.on.idle = void 0;
          unlisteners.forEach((unlisten) => unlisten());
          unlisteners.length = 0;
        };
        if (!this.context.refreshing && boolOrTrue(this.context.isExpired)) {
          this._refresh();
        }
      };
    }
    get context() {
      return this._watchlist.snapshot;
    }
    set loadingContext(loadingContext) {
      this._setupContext.loadingContext = loadingContext;
    }
    set errorHandler(errorHandler) {
      this._specification.errorHandler = errorHandler;
    }
    set onSessionCreate(onSessionCreate) {
      if (this._specification.onSessionCreate === onSessionCreate) return;
      this._specification.onSessionCreate = onSessionCreate;
      if (!this._refreshPromisorSignal) return;
      if (isFunction(this._specification.onSessionCreate)) {
        this._canSkipSessionRefresh = false;
        this._refresh();
      }
    }
    _onAuthStateChanged() {
      this._watchlist.requestNotification();
    }
    _refresh(skipSessionRefreshIfPossible = false) {
      void this._refreshPromisor(skipSessionRefreshIfPossible);
    }
  }
  const account = "Account";
  const accountBalance = "Account Balance";
  const accountDescription = "Account description";
  const accountID = "Account ID";
  const additions = "Additions";
  const adjustments = "Adjustments";
  const amount = "Amount";
  const and = "and";
  const apply = "Apply";
  const back = "Back";
  const balanceAccount = "Balance account";
  const balanceAccountId = "Balance account ID";
  const Booked = "Booked";
  const capture = "Captured";
  const category = "Category";
  const chargeback = "Chargebacks";
  const closeIconLabel = "Close";
  const contactSupport = "Contact support";
  const contactSupportForHelp = "Contact support for help.";
  const contactSupportForHelpAndShareErrorCode = "Contact support for help and share error code %{requestId}";
  const copied = "Copied";
  const copy$1 = "Copy";
  const correction = "Corrections";
  const currency = "Currency";
  const date = "Date";
  const dateRange = "Date range";
  const description = "Description";
  const dismiss = "Dismiss";
  const download$1 = "Download";
  const downloading = "Downloading";
  const email = "Email";
  const entityWasNotFound = "Entity was not found";
  const entityWasNotFoundDetail = "Transaction not found for the specified Account Holder";
  const fee = "Fees";
  const file = "File";
  const filterBar = "Filter bar";
  const from = "From";
  const full = "Full";
  const fundsCaptured = "Funds captured";
  const goBack = "Go back";
  const grantIssued = "Grant issued";
  const grantRepayment = "Grant repayments";
  const hideContent = "Hide content";
  const id = "ID";
  const incompleteField = "Incomplete field";
  const inProgress = "In progress";
  const loading = "Loading";
  const max = "max";
  const min = "min";
  const mobile = "Mobile";
  const netPayout = "Net payout";
  const nextPayouts = "Next Payouts";
  const noData = "No data";
  const noNegativeNumbersAllowed = "No negative numbers allowed";
  const noPayoutsFound = "No payouts found";
  const noReportsFound = "No reports found";
  const noTransactionsFound = "No transactions found";
  const other = "Other";
  const paginatedNavigation = "Paginated navigation";
  const partial = "Partial";
  const paymentId = "Payment ID";
  const paymentMethod = "Payment method";
  const payoutDetails = "Payout Details";
  const payoutsNotice = "Payout information is generated each day at midnight, UTC time.";
  const payoutsTitle = "Payouts";
  const Pending = "Pending";
  const pleaseComeBackLater = "Please come back later.";
  const pleaseReachOutToSupportForAssistance = "Please, reach out to support for assistance.";
  const reachOutToSupport = "Reach out to support";
  const referenceID = "Reference ID";
  const refresh = "Refresh";
  const refund = "Refunds";
  const refundAction = "Refund payment";
  const refundActionErrorSubtitle = "We couldn’t process the refund. Try again later.";
  const refundActionErrorTitle = "Something went wrong.";
  const refundActionSuccessSubtitle = "Your customer will receive the money in a maximum of 40 days. When the refund is successful you will see a new Refund transaction on your list.";
  const refundActionSuccessTitle = "Refund is sent!";
  const refundAmount = "Amount to refund";
  const refundNotice = "Refunds can take up to 40 days depending on the payment method. Fees are included.";
  const refundPayment = "Refund %{amount}";
  const refundReason = "Reason for refund";
  const refundReference = "Reference";
  const remainingAmount = "Remaining amount";
  const report = "Report";
  const reportsNotice = "Reports are generated each day at midnight, UTC time.";
  const reportsTitle = "Reports";
  const reset = "Reset";
  const Reversed = "Reversed";
  const somethingWentWrong = "Something went wrong.";
  const somethingWentWrongTryRefreshingOrComeBackLater = "Something went wrong. Try refreshing the page or come back later.";
  const status = "Status";
  const structuredList = "Structured list";
  const subtractions = "Subtractions";
  const sumOfSameDayPayouts = "Sum of same-day payouts";
  const tabs = "Tabs";
  const theErrorCodeIs = "The error code is %{requestId}";
  const thereAreNoResults = "There are no results";
  const theRequestIsMissingRequiredFieldsOrContainsInvalidData = "The request is missing required fields or contains invalid data.";
  const thereWasAnUnexpectedError = "There was an unexpected error";
  const theSelectedBalanceAccountIsIncorrect = "The selected balance account is incorrect";
  const timezone = "Timezone";
  const to = "To";
  const totalIncoming = "Total incoming";
  const totalOutgoing = "Total outgoing";
  const toValueShouldBeGreaterThanTheFromValue = "To value should be equal or greater than the From value";
  const transactionDetails = "Transaction details";
  const transactions = "Transactions";
  const transactionsOverviewTitle = "Transactions overview";
  const transactionType = "Transaction type";
  const transfer = "Transfers";
  const tryDifferentSearchOrResetYourFiltersAndWeWillTryAgain = "Try a different search or reset your filters, and we’ll try again.";
  const tryRefreshingThePageOrComeBackLater = "Try refreshing the page or come back later.";
  const txAmount = "Amount";
  const type = "Type";
  const value = "Value";
  const weCouldNotLoadThePayoutsOverview = "We couldn't load the payouts overview.";
  const weCouldNotLoadTheReportsOverview = "We couldn't load the reports overview.";
  const weCouldNotLoadTheTransactionsOverview = "We couldn't load the transactions overview.";
  const weCouldNotLoadYourBalanceAccounts = "We couldn't load your balance accounts.";
  const weCouldNotLoadYourPayouts = "We couldn't load your payouts.";
  const weCouldNotLoadYourReports = "We couldn't load your reports.";
  const weCouldNotLoadYourTransactions = "We couldn't load your transactions.";
  const EN_US = {
    account,
    accountBalance,
    accountDescription,
    accountID,
    additions,
    adjustments,
    amount,
    and,
    apply,
    back,
    balanceAccount,
    balanceAccountId,
    "balanceAccounts.all": "All accounts",
    Booked,
    "button.clearAll": "Clear all",
    "calendar.controls": "Calendar navigation controls",
    "calendar.nextMonth": "Next month",
    "calendar.previousMonth": "Previous month",
    "calendar.timezone": "Timezone is set on: GMT%{offset} (%{time})",
    "capital.accountIsInactive": "Your account is inactive",
    "capital.actionNeeded": "Action needed",
    "capital.annualPercentageRate": "Annual percentage rate",
    "capital.annualPercentageRateIsTheCostOfBorrowingForALoan": "The Annual Percentage Rate (APR) is the cost of borrowing of this loan under Adyen Capital User Terms, expressed as an annual rate.",
    "capital.bankAccountDetails": "Bank account details",
    "capital.bankAccountIban": "IBAN",
    "capital.bankAccountNumber": "Account number",
    "capital.bankCountryOrRegion": "Country/region",
    "capital.bankRoutingNumber": "Routing number",
    "capital.bankSortCode": "Sort code",
    "capital.businessFinancing": "Business financing",
    "capital.businessFinancingOffer": "Business financing offer",
    "capital.businessFinancingSummary": "Business financing summary",
    "capital.closed": "Closed",
    "capital.couldNotContinueWithTheOffer": "We couldn't continue with the offer.",
    "capital.couldNotLoadFinancialOffers": "We couldn't load financial offers.",
    "capital.dailyRepaymentRate": "Daily repayment rate",
    "capital.daysAndDaysLeft": "%{days} days (%{daysLeft} days left)",
    "capital.expectedRepaymentPeriod": "Expected repayment period",
    "capital.failed": "Failed",
    "capital.fees": "Fees",
    "capital.fullyRepaid": "Fully repaid",
    "capital.goToTermsAndConditions": "Go to Terms & Conditions",
    "capital.grantID": "Grant ID",
    "capital.howMuchMoneyDoYouNeed": "How much money do you need?",
    "capital.inProgress": "In progress",
    "capital.legalSubtitleAU": "Adyen Capital is provided by Adyen Australia Pty Limited.",
    "capital.legalSubtitleCA": "Adyen Capital is provided by Adyen Canada Ltd.",
    "capital.legalSubtitleEU": "Loans are issued by Adyen N.V.",
    "capital.legalSubtitleGB": "Loans are issued by Adyen N.V. represented by its London Branch.",
    "capital.legalSubtitleUS": "Loans are issued by Adyen N.V. San Francisco Branch and subject to credit approval.",
    "capital.maximumRepaymentPeriod": "Maximum repayment period",
    "capital.minimumRepaymentToRepayTheFinancingOnTime": "Minimum repayment every %{days} days to repay the financing on time",
    "capital.needSomeExtraMoney": "Need some extra money?",
    "capital.offerLegalNoticeDescriptionUS": "If your application for business credit is denied, you have the right to a written statement of the specific reasons for the denial. To obtain the statement, please contact Adyen's Credit Support Team by emailing %{email} within 60 days from the date you are notified of our decision. We will send you a written statement of reasons for the denial within 30 days of receiving your request for the statement. %{break} The Federal Equal Credit Opportunity Act prohibits creditors from discriminating against credit applicants on the basis of race, color, religion, national origin, sex, marital status, age (provided that the applicant has the legal capacity to enter into a binding contract), because all or part of the applicant's income derives from any public assistance program, or because the applicant has in good faith exercised any right under the Consumer Credit Protection Act. The federal agency that administers compliance with this law concerning this creditor is the Office of the Comptroller of the Currency (OCC), Customer Assistance Group, PO Box 53570, Houston, TX 77052.",
    "capital.offerLegalNoticeTitleUS": "Creditor: Adyen N.V. – San Francisco Branch %{break} 505 Brannan Street, San Francisco, CA 94107.",
    "capital.oneMonth": "1 month",
    "capital.pending": "Pending",
    "capital.primaryAccount": "Primary account",
    "capital.remaining": "Remaining",
    "capital.remainingAmount": "Remaining amount",
    "capital.remainingFees": "Remaining fees",
    "capital.repaid": "Repaid",
    "capital.repaidAmount": "Repaid amount",
    "capital.repaidFees": "Repaid fees",
    "capital.repaymentBalanceInfo": "Your current remaining amount, including fees, is %{amount}",
    "capital.repaymentThreshold": "Repayment threshold",
    "capital.requestedFunds": "Requested funds",
    "capital.requestFunds": "Request funds",
    "capital.requesting": "Requesting",
    "capital.reviewOffer": "Review offer",
    "capital.revoked": "Revoked",
    "capital.seeNewOffer": "See new offer",
    "capital.seeOptions": "See options",
    "capital.sendRepayment": "Send repayment",
    "capital.sendRepaymentNotice": "The additional repayment bank transfer made towards your loan could take 2-3 business days for it to be reflected on your loan account.",
    "capital.sendRepaymentSubtitle": "Transfer money to this bank account to repay back part of your loan or the entirety of it.",
    "capital.signTermsAndConditionsToReceiveFunds": "Sign the Terms & Conditions to receive your funds.",
    "capital.signTheTermsToReceiveYourFunds": "Sign the terms to receive your funds",
    "capital.submitInformation": "Submit information",
    "capital.termEnds": "Term ends: ",
    "capital.thereIsNoPrimaryAccountConfigured": "There is no primary account configured",
    "capital.thisOfferExpiresOn": "This offer expires on %{date}.",
    "capital.totalFees": "Total fees",
    "capital.totalRepaymentAmount": "Total repayment amount",
    "capital.unsupportedRegionDescription": "Business financing isn’t available in your region yet, but check back here for an offer.",
    "capital.unsupportedRegionTitle": "Stay tuned!",
    "capital.weCouldNotContinueWithTheOffer": "We couldn't continue with the offer.",
    "capital.weCouldNotContinueWithTheOfferContactSupportForHelp": "We couldn't continue with the offer. Contact support for help.",
    "capital.weCouldNotLoadFinancialOffers": "We couldn't load financial offers.",
    "capital.weCouldNotProcessThisRequestTryAgain": "We couldn't process this request. Try again with a new offer.",
    "capital.weNeedABitMoreInformationToProcessYourFundsPleaseCompleteTheseActions": "We need a bit more information to process your funds. Please complete these actions:",
    "capital.weNeedABitMoreInformationToProcessYourFundsPleaseCompleteThisAction": "We need a bit more information to process your funds. Please complete this action:",
    "capital.weNeedABitMoreInformationToProcessYourFundsPleaseCompleteThisActionBy": "We need a bit more information to process your funds. Please complete this action by %{date}:",
    "capital.weReceivedYourRequestAndWeAreWorkingOnItNowCheckBackSoon": "We received your request and we’re working on it now. Check back soon for the next steps.",
    "capital.writtenOff": "Written off",
    "capital.xDays": "%{days} days",
    "capital.xMonths": "%{months} months",
    "capital.xPercent": "%{percentage}%",
    "capital.youAcceptedButThenReturnedTheseFunds": "You accepted but then returned these funds",
    "capital.youAcceptedTheseFundsButDidNotRepayThem": "You accepted these funds but did not repay them",
    "capital.youAreRequestingFundingOf": "You’re requesting funding of",
    "capital.youHaveBeenPrequalifiedForBusinessFinancingUpToX.part1": "You have been pre-qualified for business financing",
    "capital.youHaveBeenPrequalifiedForBusinessFinancingUpToX.part2": " up to %{amount}.",
    "capital.yourRequestedFundsWere": "Your requested funds were: ",
    "capital.youShouldGetTheFundsWithinOneBusinessDay": "You should get the funds within one business day",
    "capital.youWillNeedToRepayAMinimumOfXEveryXDaysToPayOffTheFunds": "You will need to repay a minimum of %{amount} every %{days} days to fully pay off the funds by %{date}.",
    "capital.youWillSoonQualifyForAFinancialOffer": "You will soon qualify for a financial offer!",
    capture,
    category,
    chargeback,
    closeIconLabel,
    contactSupport,
    contactSupportForHelp,
    contactSupportForHelpAndShareErrorCode,
    copied,
    copy: copy$1,
    correction,
    currency,
    date,
    dateRange,
    "default": "Default",
    description,
    dismiss,
    "disputes.accept": "Accept",
    "disputes.accept.accepted": "Accepted",
    "disputes.accept.chargeback": "Accept chargeback",
    "disputes.accept.disputeAccepted": "Chargeback has been accepted",
    "disputes.accept.disputeDisclaimer": "By accepting, you agree that the disputed amount will not be returned to your account.",
    "disputes.accept.iAgree": "I agree",
    "disputes.accept.requestForInformation": "Accept request for information",
    "disputes.accept.requestForInformationAccepted": "Request for information has been accepted",
    "disputes.accept.requestForInformationDisclaimer": "Once this request for information is accepted, it will be marked as expired and may lead to a chargeback in the future.",
    "disputes.acceptedOn": "Accepted on",
    "disputes.account": "Account",
    "disputes.alert.autoDefended": "This chargeback was defended automatically.",
    "disputes.alert.notDefendable": "This chargeback can’t be defended. Contact support for details.",
    "disputes.alert.notDefendedExpired": "This request for information wasn’t responded to and was lost by default.",
    "disputes.alert.notDefendedLost": "This chargeback wasn’t defended and was lost by default.",
    "disputes.alert.responseDeadline": "The response deadline is %{date}",
    "disputes.contactSupport.toDefendDispute": "Contact support to defend this dispute.",
    "disputes.contactSupport.toDefendRequestForInformation": "Contact support to respond to this request for information.",
    "disputes.contactSupport.toResolveNotificationOfFraud": "Contact support to resolve this notification of fraud. Refund this payment to avoid a future chargeback and paying extra fees.",
    "disputes.currency": "Currency",
    "disputes.defend.chargeback": "Defend chargeback",
    "disputes.defend.chargebackFeeInformation": "A fee is charged for every defended chargeback. We recommend responding only when you have clear and convincing evidence.",
    "disputes.defend.continue": "Continue",
    "disputes.defend.defended": "Defended",
    "disputes.defend.evidenceSubmitted": "Evidence has been submitted",
    "disputes.defend.selectDefenseReason": "Select the reason you’re defending this chargeback.",
    "disputes.defend.somethingWentWrong": "Something went wrong",
    "disputes.defend.submit": "Submit",
    "disputes.defend.submitSuccessfulInformation": "The chargeback details will be reviewed by the scheme, which can take up to 60 days.",
    "disputes.defend.uploadDocumentsInformation": "Upload documents that support your dispute defense. Once submitted, no changes can be made.",
    "disputes.defendedOn": "Defended on",
    "disputes.defenseDocument.acquirerRepresentmentForm": "Acquirer Representment Form",
    "disputes.defenseDocument.acquirerRepresentmentFormAutomaticallyGenerated": "The Acquirer Representment Form is an automatically generated document that contains an overview of key dispute details.",
    "disputes.defenseDocument.acquirerRetrievalFulfilmentForm": "Acquirer Retrieval Fulfilment Form",
    "disputes.defenseDocument.acquirerRetrievalFulfilmentFormAutomaticallyGenerated": "The Acquirer Retrieval Fulfilment Form is an automatically generated document that contains an overview of key dispute details.",
    "disputes.defenseDocument.additionalInformation": "Additional Information",
    "disputes.defenseDocument.additionalTransactions": "Additional Transactions",
    "disputes.defenseDocument.additionalTransactionsConnectedWithDisputedFlight": "Additional transactions connected with the disputed flight, such as upgrades, excess baggage charges, and in-flight purchases",
    "disputes.defenseDocument.alternativeDefenseMaterial": "Alternative defense material",
    "disputes.defenseDocument.amexFaxCover": "Amex Fax Cover",
    "disputes.defenseDocument.appropriateExplanation": "Appropriate explanation",
    "disputes.defenseDocument.appropriateExplanationAndDocTwoSeparateTransactions": "An appropriate explanation and documentation showing two separate transactions.",
    "disputes.defenseDocument.authorizationNotObtained": "Authorization Not Obtained",
    "disputes.defenseDocument.authorizationNotObtainedHelp": "Authorization Not Obtained (Help)",
    "disputes.defenseDocument.autoGeneratedDocRetrievalRequestFulfilled": "Automatically generated document showing that the retrieval request was fulfilled",
    "disputes.defenseDocument.automaticallyGeneratedTransactionDetails": "Automatically generated transaction details",
    "disputes.defenseDocument.avsDocumentation": "AVS Documentation",
    "disputes.defenseDocument.cancelledRecurringBilling": "Cancelled recurring billing",
    "disputes.defenseDocument.cardholderAgreedToAmountRange": "Documentation supporting the claim that the cardholder agreed to a reasonable amount range.",
    "disputes.defenseDocument.cardholderResponsibleForAddendumTransaction": "Documentation to establish the cardholder is responsible for the addendum transaction",
    "disputes.defenseDocument.cardholderResponsibleForDisputedAmount": "Documentation to support that the cardholder is responsible for the disputed amount.",
    "disputes.defenseDocument.cardRecoveryBulletinOrExceptionFile": "Card Recovery Bulletin or Exception File",
    "disputes.defenseDocument.cardRecoveryBulletinOrExceptionFileHelp": "Card Recovery Bulletin or Exception File (Help)",
    "disputes.defenseDocument.chargebackRemediedOrInvalid": "Documentation to support that the chargeback is remedied or invalid.",
    "disputes.defenseDocument.chargeToWrongAccountNumber": "Charge to Wrong Account Number",
    "disputes.defenseDocument.chargeToWrongAccountNumberHelp": "Charge to Wrong Account Number (Help)",
    "disputes.defenseDocument.clearingText": "Clearing Text",
    "disputes.defenseDocument.compellingEvidence": "Compelling Evidence",
    "disputes.defenseDocument.copyOfInvoice": "Copy of the invoice or similar document",
    "disputes.defenseDocument.copyOfInvoiceOrOtherRelevantTransactionDetails": "Copy of the invoice, terminal receipt, sales ticket or any other document (Transaction Information Document) that provides the relevant transaction details like transaction amount, delivery address (if applicable) and description of the merchandise.",
    "disputes.defenseDocument.CopyOfSalesDraftDetails": "Copy of the invoice, terminal receipt, sales ticket or any other document (transaction information document) that provides the relevant details like transaction amount, delivery address (if applicable) and description of the merchandise",
    "disputes.defenseDocument.CopyOfSalesDraftTitle": "Copy of original Sales Draft",
    "disputes.defenseDocument.copyOfTid": "A copy of the TID as proof that the transaction involved a retail sale rather than a credit.",
    "disputes.defenseDocument.coverPageForAmexDisputes": "A cover page that will be sent for Amex disputes",
    "disputes.defenseDocument.creditNotProcessed": "Credit Not Processed",
    "disputes.defenseDocument.creditNotProcessedHelp": "Credit Not Processed (Help)",
    "disputes.defenseDocument.creditNotProcessedReason": "Credit Not Processed Reason",
    "disputes.defenseDocument.creditsOfMilesShowingConnectionToCardholder": "Credits of frequent flyer miles for the flight, showing connection to the cardholder",
    "disputes.defenseDocument.customerWrittenConfirmation": "The customer's written confirmation of registration to receive electronic delivery of goods or services.",
    "disputes.defenseDocument.defenseMaterial": "Defense Material",
    "disputes.defenseDocument.deffectiveMerchandise": "Deffective Merchandise",
    "disputes.defenseDocument.deffectiveMerchandiseHelp": "Deffective Merchandise (Help)",
    "disputes.defenseDocument.deliveryOfFlightTicketAtAddress": "Proof of delivery of the flight ticket at cardholder's address",
    "disputes.defenseDocument.descriptionOfDisputeReason": "A description of the dispute reason",
    "disputes.defenseDocument.descriptionOfMerchandiseOrServices": "A description of the merchandise or services. This can be for example the invoice.",
    "disputes.defenseDocument.differentSignature": "Different Signature",
    "disputes.defenseDocument.differentSignatureHelp": "Different Signature (Help)",
    "disputes.defenseDocument.disclosureAtPointOfInteraction": "Disclosure at the Point of Interaction",
    "disputes.defenseDocument.docAllOfFollowing": "A merchant statement documenting all of the following:",
    "disputes.defenseDocument.docCardholderIssuedPaperAirlineTickets": "Documentation establishing that the cardholder was issued paper airline tickets.",
    "disputes.defenseDocument.docChargebackCodeNotApplicable": "Documentation to support that the chargeback code is not applicable",
    "disputes.defenseDocument.docCorrectCurrency": "Documentation proving the correct currency was provided or specified",
    "disputes.defenseDocument.docIdentifyTransaction": "Documentation that would further identify the transaction",
    "disputes.defenseDocument.docMerchandiseNotCounterfeit": "Documentation to support the claim that the merchandise was not counterfeit",
    "disputes.defenseDocument.docProvingCardHolderParticipated": "Documentation proving the card holder participated in the transacion. This can be:",
    "disputes.defenseDocument.docRemediesChargeback": "Defense Material that remedies the chargeback.",
    "disputes.defenseDocument.docsTwoTransactionsWithSameShopper": "Provide copies of two documents (for example terminal receipts or invoices) belonging to two separate transactions with the same shopper.",
    "disputes.defenseDocument.docTermsOfSaleNotMisrepresented": "Documentation to prove that the terms of sale of the merchandise or services were not misrepresented",
    "disputes.defenseDocument.docTransactionOccurredOnPos": "Documentation that show that the transaction occurred on an attended POS terminal",
    "disputes.defenseDocument.docTwoDifferentTransactions": "Documentation showing Two Different Transactions",
    "disputes.defenseDocument.documentationOfPositiveAvsResponseXOrY": "Documentation of positive AVS response X or Y",
    "disputes.defenseDocument.documentCanBeCreditReasonDue": "A document can be a credit due reason.",
    "disputes.defenseDocument.documentCanBeProofOfDelivery": "A document can be a proof of delivery signature or a proof of receipt copy.",
    "disputes.defenseDocument.documentCanBeSubscriptionAgreement": "A document can be a subscription agreement.",
    "disputes.defenseDocument.documentCanBetUrlReturnPolicy": "A document can be a description, item URL, return policy, or a copy of a contract or an affidavit.",
    "disputes.defenseDocument.documentContainingImportantShipmentData": "A document containing important shipment data. It should include at least the shipment date.",
    "disputes.defenseDocument.documentShipmentDate": "Document containing Shipment Date",
    "disputes.defenseDocument.docViaFraudReporter": "Documentation that supports the second presentment from the Acquirer’s Loss Data File, the Acquirer Loss Data Report or the Acquirer Transaction Data Report via Fraud Reporter.",
    "disputes.defenseDocument.duplicateProcessing": "Duplicate Processing",
    "disputes.defenseDocument.duplicateProcessingHelp": "Duplicate Processing (Help)",
    "disputes.defenseDocument.evidenceCardHolderParticipation": "Compelling Evidence of Card holder Participation",
    "disputes.defenseDocument.evidenceProofingParticipationOfCardholder": "Compelling evidence proofing the participation of the cardholder in the transaction.",
    "disputes.defenseDocument.evidenceTransactionWasRecurring": "Description of the goods or services being provided with evidence that the transaction was recurring by providing the start date of the recurring transaction and, if used, an indication that SecureCode or CVC2 has been used on the initial transaction.",
    "disputes.defenseDocument.expiredCard": "Expired Card",
    "disputes.defenseDocument.expiredCardHelp": "Expired Card (Help)",
    "disputes.defenseDocument.explanation": "Explanation",
    "disputes.defenseDocument.explanationWhyCancellationCodeInvalid": "Explanation why the cancellation code is invalid.",
    "disputes.defenseDocument.falseTransaction": "False ransaction (Help)",
    "disputes.defenseDocument.firstChargebackNumberAndDate": "Reference number and date of first chargeback",
    "disputes.defenseDocument.flightManifest": "Flight Manifest",
    "disputes.defenseDocument.flightManifestShowingCardholderName": "Flight manifest showing the cardholder's name",
    "disputes.defenseDocument.flightTicket": "Flight Ticket",
    "disputes.defenseDocument.flightTicketUsed": "Flight Ticket Used",
    "disputes.defenseDocument.flightTicketWithCardholderName": "Flight Ticket or boarding pass showing the cardholder's name",
    "disputes.defenseDocument.flightTookPlace": "Flight Took Place",
    "disputes.defenseDocument.frequentFlyerInformation": "Frequent Flyer Information",
    "disputes.defenseDocument.ifDelayedProofShowingMerchantAbleToProvideServices": "If the service is delayed, proof showing that the merchant is able to provide the services (for example, documentation showing that the merchant is not out of business)",
    "disputes.defenseDocument.incorrectAmount": "Incorrect amount",
    "disputes.defenseDocument.latePresentment": "Late Presentment",
    "disputes.defenseDocument.latePresentmentHelp": "Late Presentment (Help)",
    "disputes.defenseDocument.latestRecurringTransactions": "Latest Recurring Transactions",
    "disputes.defenseDocument.memberMessageText": "Member Message Text",
    "disputes.defenseDocument.memberMessageTextSentToSchemes": "Member Message Text sent to the schemes.",
    "disputes.defenseDocument.merchandiseDescription": "Merchandise Description",
    "disputes.defenseDocument.merchandiseNotAsDescribed": "Merchandise not as described.",
    "disputes.defenseDocument.merchandiseNotReceived": "Merchandise Not Received",
    "disputes.defenseDocument.merchandiseNotReceivedHelp": "Merchandise Not Received (Help)",
    "disputes.defenseDocument.merchandiseSentToAvsConfirmedBillingAddress": " Documentation that shows the merchandise was sent to the AVS-confirmed billing address",
    "disputes.defenseDocument.merchantFraudPerformanceProgram": "Merchant Fraud Performance Program",
    "disputes.defenseDocument.merchantFraudPerformanceProgramHelp": "Merchant Fraud Performance Program (Help)",
    "disputes.defenseDocument.merchantObtainedCardAtTimeReservationMade": "Documentation establishing that the merchant obtained the cardholder's account number, name present on the card, and the confirmation number provided at the time the reservation was made.",
    "disputes.defenseDocument.merchantWrittenRebuttal": "Merchant's written rebuttal",
    "disputes.defenseDocument.missingSignature": "Missing Signature",
    "disputes.defenseDocument.missingSignatureHelp": "Missing Signature (Help)",
    "disputes.defenseDocument.moreThanOneTransactionProcessed": "More than one transaction was processed by providing the date(s) of previous transaction(s).",
    "disputes.defenseDocument.mpiData": "MPI Data",
    "disputes.defenseDocument.nonMatchingAccountNumber": "Non Matching Account Number",
    "disputes.defenseDocument.nonMatchingAccountNumberHelp": "Non Matching Account Number (Help)",
    "disputes.defenseDocument.noNotification": "Proof of No Notification",
    "disputes.defenseDocument.numberAndDateOfOriginalChargeback": "First chargeback reference number and date of original chargeback",
    "disputes.defenseDocument.originalAmount": "Original Amount",
    "disputes.defenseDocument.originalAmountIfDisputedRepresentsPartialShipment": "The original transaction amount if the disputed transaction represents partial shipment",
    "disputes.defenseDocument.other": "Other",
    "disputes.defenseDocument.otherHelp": "Other (Help)",
    "disputes.defenseDocument.paidByOtherMeansThanJCBCard": "Paid By Other Means Than JCB Card",
    "disputes.defenseDocument.paidByOtherMeansThanJCBCardHelp": "Paid By Other Means Than JCB Card (Help)",
    "disputes.defenseDocument.paperAirlineTicket": "Paper Airline Ticket",
    "disputes.defenseDocument.passengerId": "Passenger Identification Documentation",
    "disputes.defenseDocument.passengerIdLinkedToCardholder": "Passenger identification documentation showing a link to the cardholder",
    "disputes.defenseDocument.previousTransactionsNotDisputed": "Previous transactions were not disputed.",
    "disputes.defenseDocument.printedSignedReceipt": "A printed, signed terminal receipt",
    "disputes.defenseDocument.processingError": "Processing Error",
    "disputes.defenseDocument.processingErrorHelp": "Processing Error (Help)",
    "disputes.defenseDocument.proofAirlineTicketsWereUsed": "Documentation proving that the airline tickets were used by the cardholder or persons that the cardholder authorized.",
    "disputes.defenseDocument.proofCardAndCardholderSignature": "Proof of card presence and cardholder signature",
    "disputes.defenseDocument.proofCardPresence": "Proof of Card Presence",
    "disputes.defenseDocument.proofFlightTookPlace": "Documentation proving that the airline rendered the service (the flight took place)",
    "disputes.defenseDocument.proofGoodsServicesWereProvided": "Proof showing that the goods or services of the merchant were provided to the card holder",
    "disputes.defenseDocument.proofGoodsWereDeliveredAsDescribed": "Proof showing that the goods were delivered as described.",
    "disputes.defenseDocument.proofMerchantHadNotReceivedPreviousChargeback": "Proof showing that the merchant had not received a previous chargeback from the cardholder at the time of settlement.",
    "disputes.defenseDocument.proofMerchantHadNotReceivedPreviousChargebackAutoGenerated": "Proof showing that the merchant had not received a previous chargeback from the cardholder at the time of settlement. (This proof is automatically generated.)",
    "disputes.defenseDocument.proofMerchantNotNotifiedOfCancellation": "Proof showing that the merchant or acquirer was not notified of the cancellation at the time of settlement.",
    "disputes.defenseDocument.proofOfAccountTakeover": "Proof of Account Takeover",
    "disputes.defenseDocument.proofOfAddendum": "Proof of Addendum",
    "disputes.defenseDocument.proofOfDelayedDelivery": "Proof of Delayed Delivery",
    "disputes.defenseDocument.proofOfFulfillment": "Proof of Fulfillment",
    "disputes.defenseDocument.proofOfInvalidChargeback": "Proof of Invalid Chargeback",
    "disputes.defenseDocument.proofOfNoCancellation": "Proof of No Cancellation",
    "disputes.defenseDocument.proofOfNoChargebackReceived": "Proof of No Chargeback Received",
    "disputes.defenseDocument.proofOfNoShow": "Proof of No-Show",
    "disputes.defenseDocument.proofOfRecurringTransaction": "Merchant's Proof of Recurring Transaction",
    "disputes.defenseDocument.proofOfRefund": "Proof of Refund",
    "disputes.defenseDocument.proofOfRetailSale": "Proof of Retail Sale",
    "disputes.defenseDocument.proofProvidedMerchandise": "Proof of Provided Merchandise",
    "disputes.defenseDocument.proofRecurringContractNotCancelledAtTimeOfSettlement": "Proof showing that the recurring contract was not cancelled at the time of settlement.",
    "disputes.defenseDocument.proofRenewedMembership": "Proof of Renewed Membership",
    "disputes.defenseDocument.proofShowingCardholderRenewedMembership": "Proof showing that the cardholder renewed his membership to the service after the cancellation received.",
    "disputes.defenseDocument.proofShowingTrackingInformation": "Proof showing Tracking Info, Tracking Number.",
    "disputes.defenseDocument.proofValidIncreaseOfAmount": "Proof of Valid Increase of Amount",
    "disputes.defenseDocument.provideRefundId": "Provide the refund ID, for the difference in amount.",
    "disputes.defenseDocument.provingTransactionResultedFromAccountTakeover": "Documentation that supports the second presentment by proving that the transaction resulted from an account takeover. For example: The Acquirer Loss File report, the SAFE Acquirer Transaction Data report or a statement from the authorized cardholder confirming that the account was in fact taken over and that fraud subsequently occurred.",
    "disputes.defenseDocument.reasonableAmount": "Proof of reasonable amount",
    "disputes.defenseDocument.reasonForInvalidation": "Reason for Invalidation",
    "disputes.defenseDocument.reasonForInvalidationOfChargeback": "Reason for the invalidation of the chargeback. Please notice that this reason should be technical from nature, for example: the issuer submitted documentation that failed to support the chargeback.",
    "disputes.defenseDocument.rebuttalCancellationNotAccepted": "Rebuttal of Cancellation Never Accepted",
    "disputes.defenseDocument.rebuttalGivenToCardholder": "Rebuttal or proper disclosure given to the cardholder at the point of interaction.",
    "disputes.defenseDocument.rebuttalStatingCancellationNotAccepted": "Rebuttal stating that the cancellation was never accepted",
    "disputes.defenseDocument.receiptOfFlightTicketAtBillingAddress": "Proof of receipt of the flight ticket at the cardholder's billing address",
    "disputes.defenseDocument.receiptOrOther": "A receipt, work order, or other document signed by the customer substantiating that the goods or services were received by the customer.",
    "disputes.defenseDocument.resultsOfMpiCalls": "Results of MPI lookup service calls.",
    "disputes.defenseDocument.retrievalRequestFulfilled": "Proof showing that the retrieval request was fulfilled",
    "disputes.defenseDocument.retrievalRequestNotHonored": "Retrieval Request Not Honored",
    "disputes.defenseDocument.retrievalRequestNotHonoredHelp": "Retrieval Request Not Honored (Help)",
    "disputes.defenseDocument.serviceNotRendered": "Service Not Rendered",
    "disputes.defenseDocument.serviceNotRenderedHelp": "Service Not Rendered (Help)",
    "disputes.defenseDocument.shipmentDocumentation": "Shipment Documentation",
    "disputes.defenseDocument.shipToAddress": "Ship-To Address",
    "disputes.defenseDocument.shipToAddressIfApplicable": '"Ship to" address (if applicable)',
    "disputes.defenseDocument.signatureOrChipPinEvidence": "Signature or Chip PIN Evidence",
    "disputes.defenseDocument.signedTerminalReceipt": "Signed Terminal Receipt",
    "disputes.defenseDocument.SplitSales": "Duplicate Processing",
    "disputes.defenseDocument.SplitSalesHelp": "Duplicate Processing (Help)",
    "disputes.defenseDocument.statementMerchantDidNotReceiveGoods": "Statement from the merchant stating that the merchant did not receive the goods.",
    "disputes.defenseDocument.SupplementalDocumentsDetails": "Complimentary information to the sales draft (e.g. Cardholder’s permission for recurring Transaction, MOTO/Electronic Commerce ordering form, Magnetic-stripe phone record.)",
    "disputes.defenseDocument.SupplementalDocumentsTitle": "Additional transaction documents",
    "disputes.defenseDocument.TEDocumentDetails": "Information related to the delivery of the travel and entertainment service (e.g. Hotel guest folio, Signature on file, Car rental agreement, etc.)",
    "disputes.defenseDocument.TEDocumentTitle": "Travel and Entertainment information",
    "disputes.defenseDocument.transactionAfterReservationCancelled": "Transaction After Reservation Cancelled",
    "disputes.defenseDocument.transactionAfterReservationCancelledHelp": "Transaction After Reservation Cancelled (Help)",
    "disputes.defenseDocument.transactionNotRecognizedChipLiabilityShift": "Transaction Not Recognized - Contactless and Card Not Presented",
    "disputes.defenseDocument.transactionNotRecognizedChipLiabilityShiftHelp": "Transaction Not Recognized - Contactless and Card Not Presented (Help)",
    "disputes.defenseDocument.transactionNotRecognizedContactlessAndCardNotPresented": "Transaction Not Recognized - Contactless and Card Not Presented",
    "disputes.defenseDocument.transactionNotRecognizedContactlessAndCardNotPresentedHelp": "Transaction Not Recognized - Contactless and Card Not Presented (Help)",
    "disputes.defenseDocument.unauthorisedReason": "Unauthorised reason",
    "disputes.defenseDocument.uploadListOfRefundIds": "Upload list of Refund Id(s).",
    "disputes.defenseDocument.writtenCorrespondenceExchanged": "Copies of written correspondence exchanged between the merchant and the customer (such as letter, email, or fax) showing that the customer participated in the transaction.",
    "disputes.defenseDocument.writtenRebutalGoodsRepairedOrReplaced": "Written rebutal documenting that the goods were repaired or replaced.",
    "disputes.defenseReason": "Defense reason",
    "disputes.defenseReason.3dSecureFullyAuthenticatedTransaction": "3D Secure Fully Authenticated Transaction",
    "disputes.defenseReason.3dSecureLiabilityShiftNotFullyAuthenticated": "3D Secure Liability Shift (not fully authenticated)",
    "disputes.defenseReason.accountNumberNotListedInExceptions": "The Account Number was not listed on the Exception File",
    "disputes.defenseReason.accountNumberNotListedInExceptionsFor60Days": "Account Number has not been on the Exception File with a Pickup Response for a minimum of 60 calendar days.",
    "disputes.defenseReason.accountTakeover": "Account Takeover",
    "disputes.defenseReason.acquirerDefendChargebackIfIssuerRequested": "The acquirer can defend the chargeback if the issuer requested it or if friendly-fraud is suspected. This might lead to further escalation with the issuer.",
    "disputes.defenseReason.acquirerProvidesCorrectDateWithinTimeLimit": "The acquirer provides the correct transaction date that is within applicable time limit set forth in section Time Frame for First Presentment.",
    "disputes.defenseReason.additionalInformation": "Additional Information",
    "disputes.defenseReason.addressMerchandiseSentAvsConfirmed": "The merchant can provide documentation that it received a positive Address Verification Service (AVS) response of X (Both the nine-digit Postal zip code as well as the first five numerical characters contained in the address match) or Y (Both the five-digit Postal zip code as well as the first five numerical characters contained in the address match) for the transaction and documentation showing that the address to which the merchandise was sent is the same as the AVS confirmed address.",
    "disputes.defenseReason.addressVerificationService": "Address Verification Service (AVS)",
    "disputes.defenseReason.addressVerificationServiceAdditionalInformation": "Address Verification Service (AVS) Additional Information",
    "disputes.defenseReason.airlineCompellingEvidence": "Airline Compelling Evidence",
    "disputes.defenseReason.airlineFlightProvided": "Airline Flight Provided",
    "disputes.defenseReason.atmDispute": "ATM Dispute",
    "disputes.defenseReason.authorisationReceivedForAmount": "Authorisation was received for the transaction amount or greater from the issuer.",
    "disputes.defenseReason.authorisedOnline": "Transaction was Authorised Online",
    "disputes.defenseReason.autoGeneratedRecurringTransactionDetails": "Automatically generated recurring transaction details.",
    "disputes.defenseReason.autoResponseSentToIssuer": "An automatically generated response has been sent to the issuer. This response was generated just before the Request for Information expires and contains the relevant data present in the system. Please notice that this response may be incomplete (for example if the merchandise description was not provided), which may lead to an invalid response. It is therefore recommended for the merchant to always upload the invoice (or the other requested information) for RFI's.",
    "disputes.defenseReason.autoResponseToRfi": "Automatically Generated Response to a Request for Information",
    "disputes.defenseReason.buyerExceededWindowToFileReturn": "Buyer has exceeded the window to file a return",
    "disputes.defenseReason.cancellationCodeWasInvalidAsShownByExplanationProvided": "The cancellation code was invalid as is shown by the explanation provided.",
    "disputes.defenseReason.cancellationContractFailed": "Cancellation Terms of the Contract failed",
    "disputes.defenseReason.cancellationOrReturns": "Cancellation or Returns",
    "disputes.defenseReason.cardAndSignatureForCorporateFleetCardTransaction": "Card was present and a signature exists for a Corporate Fleet Card transaction.",
    "disputes.defenseReason.cardholderAgreedToAmountAsReasonable": "The cardholder agreed to an amount range as reasonable, and the transaction amount did not exceed this amount range.",
    "disputes.defenseReason.cardholderBilledForSeparateAdditionalAmount": "For example, after the cardholder initially is billed for a vehicle rental, the cardholder is billed for a separate additional amount that represents unpaid parking tickets. The cardholder claims that he or she did not authorize the transaction for the parking tickets. The merchant should provide information about the violations showing that they were issued during the period that the vehicle was rented by the cardholder, as well as the rental agreement with proof of card presence and signature authorizing such charges.",
    "disputes.defenseReason.cardholderCancelledRecurringServiceButRenewedLater": "The cardholder cancelled the recurring service, but renewed his membership after the cancellation.",
    "disputes.defenseReason.cardholderDidNotMeetCancellationTerms": "The cardholder failed to meet the cancellation terms of the contract.",
    "disputes.defenseReason.cardholderNotifiedBeforeRecurringTransaction": "The transaction amount was not within the range of amounts preauthorized but the Merchant notified the Cardholder before processing Recurring Transaction",
    "disputes.defenseReason.cardholderNotifiedButNoReply": "Cardholder was notified but did not reply",
    "disputes.defenseReason.cardholderParticipated": "The Cardholder Participated in the Transaction",
    "disputes.defenseReason.cardholderResponsibleForAddendumTransaction": "Merchants may remedy the dispute with documentation substantiating the cardholder has participated in the original transaction and documentation to establish the cardholder is responsible for the addendum transaction.",
    "disputes.defenseReason.cardholderResponsibleForDisputedAmount": "The merchant also must include documentation substantiating that the cardholder is responsible for the disputed amount if the amount represents final audit charges not included in the original hotel/motel or vehicle cardholder billing.",
    "disputes.defenseReason.cardholderShouldHaveReturnedGoods": "The cardholder should have returned the goods to the merchant, but the merchant never received these goods.",
    "disputes.defenseReason.cardPresenceProof": "Proof of Card Presence Available",
    "disputes.defenseReason.cardPresentAndChipUsedNoPinProvided": "Card was present and Chip was used, but no PIN provided.",
    "disputes.defenseReason.cardWithSignatureNotProcessedMastercardNetwork": "Card was present and a signature exists for a transaction that was not processed via the MasterCard Wordlwide Network.",
    "disputes.defenseReason.cbCodeNotApplicable": "Chargeback code not applicable (card present transaction)",
    "disputes.defenseReason.chargebackBundlingInvalid": "Chargeback bundling invalid for this reason code or MCC code",
    "disputes.defenseReason.chargebackCodeNA3dSecureNotOffered": "Chargeback code is not applicable because 3D secure was not offered for the original transaction.",
    "disputes.defenseReason.chargebackInvalidCorrectAmountAndCurrencyProvided": "The acquirer determines that the chargeback was invalid the correct transaction amount and currency code were provided.",
    "disputes.defenseReason.chargebackReceivedAfterMastercardTimeLimit": "The chargeback was received after MasterCard's 120 days time limit after the authorisation.",
    "disputes.defenseReason.chipLiabilityShift": "Chip Liability Shift",
    "disputes.defenseReason.chipTransaction": "Chip Transaction",
    "disputes.defenseReason.chipTransactionReportedSAFE": "Chip Transaction Reported to SAFE",
    "disputes.defenseReason.claimNotJustifiedSinceTransactionNotChargebacked": "The issuer claims that a previous chargeback indicated the cancellation of the service. This claim is however not justified, since the transaction indicated by the issuer is not chargebacked or was not chargebacked at the time of settlement.",
    "disputes.defenseReason.compellingEvidence": "Compelling Evidence",
    "disputes.defenseReason.compellingEvidenceRecurringTransactions": "Compelling Evidence for Recurring Transactions",
    "disputes.defenseReason.correctTransactionAmount": "Correct Transaction Amount",
    "disputes.defenseReason.correctTransactionCurrency": "Correct transaction currency",
    "disputes.defenseReason.correctTransactionDateProvided": "Correct transaction date provided",
    "disputes.defenseReason.creditOrCancellationPolicyDisclosed": "Credit or Cancellation Policy Properly Disclosed",
    "disputes.defenseReason.creditOrCancellationPolicyDisclosedToCardholder": "The merchant can substantiate that the credit or cancellation policy was properly disclosed to the cardholder at the point of interaction.",
    "disputes.defenseReason.creditPreviouslyIssued": "Credit previously issued",
    "disputes.defenseReason.cvc2ValidationProgram": "CVC 2 Validation Program",
    "disputes.defenseReason.de22DontMatchInFaceToFaceTransaction": "DE 22 (Point of Service [POS] Entry Mode) of the authorization message and DE 22 (Point of Service Data Code) of the clearing messages do not match in a Face-to-Face transaction.",
    "disputes.defenseReason.defenseReasonIfProblemsWithScans": "This defense reason can only be used if there are problems with the quality of the MasterCom scan of the documentation. Do not use this defense reason if the substance of the documentation received shows that the issuer processed an invalid first chargeback. One must use this defense reason when the first chargeback documentation does not correspond to the transaction being charged back (for example, the documentation concerns a different transaction) or when the documentation is incomplete because of a scanning error. For example, the documentation provided is a partial scan with missing information, or it relates to another card or to another transaction.",
    "disputes.defenseReason.deficiencyCorrected": "Deficiency Corrected",
    "disputes.defenseReason.delayInSubmittingTransaction": "The acquirer delayed presentment due to the merchant’s delay in submitting the transaction, as permitted under Chapter 3, Transaction Records of the Transaction Processing Rules, or a national bank holiday of at least four consecutive days prevented the acquirer from receiving the transaction within the applicable seven-calendar-day time frame.",
    "disputes.defenseReason.disputedSurcharge": "Disputed Surcharge",
    "disputes.defenseReason.disputedSurchargeIncorrectCalculation": "Disputed Surcharge - Incorrect Pro-rated Calculation",
    "disputes.defenseReason.docToProveNoPaymentByOtherMean": "Documents (other than Transaction Receipt) to prove that Merchant did not receive payment by other means for the same merchandise or service.",
    "disputes.defenseReason.documentationIncreasedDebitCardholderAccount": "The merchant can provide documentation that validates the increased debit to the cardholder's account. For example, documentation showing that the cardholder is responsible for the additional charges applied to his account.",
    "disputes.defenseReason.documentationReceivedWasIllegible": "Documentation Received was Illegible",
    "disputes.defenseReason.documentsSentToFulfillRetrievalRequest": "The supporting documents have been sent to fulfill the retrieval request.",
    "disputes.defenseReason.duplicateChargeback": "Duplicate Chargeback",
    "disputes.defenseReason.emergencyPaymentAuthorizationService": "Emergency Payment Authorization Service",
    "disputes.defenseReason.emvDeviceNonEmvCard": "EMV liability shift: EMV device, non-EMV card",
    "disputes.defenseReason.emvLiabilityShift": "EMV Liability Shift",
    "disputes.defenseReason.evidenceCardholderAuthorizedTransaction": "The transaction was a non face-to-face (for example e-commerce) transaction. There is however evidence that the cardholder authorized the transaction.",
    "disputes.defenseReason.evidenceGoodsNotDamaged": "There is evidence that the goods or services described on the invoice were delivered as described (not damaged or incomplete). For example, the merchant documents that the cardholder signed acknowledging the goods were received in good condition.",
    "disputes.defenseReason.evidenceServicesProvidedAndReceivedWrittenCorrespondence": "The merchant can provide additional compelling evidence such as description of the goods or services provided; a receipt, work order or other document acknowledged by the customer that the goods or services were received by the customer; the customer's written confirmation of registration; any written correspondence exchanged between the merchant and the customer (such as letter, email or fax).",
    "disputes.defenseReason.evidenceThatCardholderParticipated": "The merchant can provide compelling evidence to establish that the cardholder participated in the transaction.",
    "disputes.defenseReason.faceToFaceTransactionNoConflictingInformation": "Face-to-Face Transaction with No Conflicting Information in Authorization and Clearing Message",
    "disputes.defenseReason.faceToFaceTransactionWithConflictingInformation": "Face-to-Face Transaction with Conflicting Information in Authorization and Clearing Message",
    "disputes.defenseReason.fallbackDefenseReasonCode": "Fallback defense reason code if all other defense reason codes do not apply. Use this reason if there is any documentation available that remedies the chargeback.",
    "disputes.defenseReason.firstChargebackCodeNotApplicable": "Chargeback code used for the First Chargeback is not applicable to the Transaction.",
    "disputes.defenseReason.firstChargebackDoesNotMeetPrerequisites": "The first chargeback does not meet the prerequisites for the dispute reason code. For example, an issuer processes a chargeback for message reason code 4837 (No Cardholder Authorization), with a cardholder letter alleging nonreceipt of merchandise. Since message reason code 4837 does not address issues related to nonreceipt of merchandise, the issuer's first chargeback was invalid, since it does not meet the prerequisites of message reason code 4837, which require the chargeback to include a cardholder letter stating that the transaction was not authorized.",
    "disputes.defenseReason.firstChargebackInvalid": "Information provided by the issuer that is relevant is illegible to the point where it cannot be established that the first chargeback is valid. One must make every attempt to qualify the documentation before using this defense reason.",
    "disputes.defenseReason.formatCbmmddyyArdXxxExpected": "The issuer did not provide the information required properly. Expected was the DE72 message text to be in the format CBMMDDYY ARD XXXXXXXXXXXXXXXXXXXXXXX, where MMDDYY denotes the date and XXXXXXXXXXXXXXXXXXXXXXX the Acquirer Reference Data of the chargeback containing the documentation to support this chargeback.",
    "disputes.defenseReason.formatMultipleTransactionsNnnExpected": "The issuer did not provide the information required properly. Expected was the DE72 message text to be in the format MULTIPLE TRANSACTIONS NNN, where NNN denotes the number of chargebacks to which the supplied documentation applies to.",
    "disputes.defenseReason.formatRpcsMmddyyExpected": "The issuer did not provide the information required properly. Expected was the DE72 message text to be in the format RPCS MMDDYY, where MMDDYY denotes date the account number was listed in the Recurring Payment Cancellation Service (RPCS).",
    "disputes.defenseReason.fraudEvidence": "Card Present Fraud Evidence",
    "disputes.defenseReason.goodsNotReturned": "Goods not Returned",
    "disputes.defenseReason.goodsOrServicesProvided": "The goods or services were provided",
    "disputes.defenseReason.goodsRepairedOrReplaced": "Goods Repaired or Replaced",
    "disputes.defenseReason.goodsWereAsDescribed": "Goods were as Described",
    "disputes.defenseReason.goodsWereRepairedOrReplaced": "The merchant can document that the goods that led to the chargeback, were repaired or replaced.",
    "disputes.defenseReason.identifiedAddendum": "Identified Addendum",
    "disputes.defenseReason.increasedTransactionAmount": "Increased Transaction Amount",
    "disputes.defenseReason.intraregionalTransactionReportedSAFE": "The acquirer can demonstrate that the intraregional transaction was reported to SAFE as counterfeit fraud and occurred at a hybrid terminal (except for the U.S. region).",
    "disputes.defenseReason.invalidAcquirerReferenceData": "Invalid Acquirer Reference Data on chargeback",
    "disputes.defenseReason.invalidCancellationCode": "Invalid Cancellation Code",
    "disputes.defenseReason.invalidChargeback": "Invalid Chargeback",
    "disputes.defenseReason.invalidChargebackBasedOnMcc": "Invalid chargeback based on MCC",
    "disputes.defenseReason.invalidChargebackReasonCode": "Invalid chargeback reason code for E-commerce/ POS payment",
    "disputes.defenseReason.invalidMessageText": "Invalid Message Text",
    "disputes.defenseReason.invalidReferenceDataDocumentationNotRequired": "Invalid Acquirer Reference Data on chargeback; documentation was provided or not required.",
    "disputes.defenseReason.issuerDidNotIncludeTwoSetsOfArns": "The issuer did not include two sets of acquirer reference numbers (ARNs). Without this information one cannot validate the issuer's claim.",
    "disputes.defenseReason.issuerDidNotProvideRequiredDocumentation": "The issuer did not provide the required documentation for this chargeback. This reason can only be chosen between 9 and 45 days of the first chargeback.",
    "disputes.defenseReason.issuerHasInitiatedTooManyFraudulentDisputes": "The acquirer can defend the chargeback if the issuer has initiated too many fraudulent disputes on this PAN eg. more than 35 within the previous 120 calendar days for Visa.",
    "disputes.defenseReason.issuerProcessedChargebackMoreThanOnce": "Use this defense strategy to remedy situations where the issuer has processed a first chargeback for the same transaction more than once.",
    "disputes.defenseReason.justifiedDelayedPresentment": "Justified delayed presentment",
    "disputes.defenseReason.liabilityShiftFullAuthenticated": "3D Secure Fully Authenticated Transaction",
    "disputes.defenseReason.manyFraudulentChargebacks": "Too Many Fraudulent Chargebacks",
    "disputes.defenseReason.membershipRenewedAfterCancellation": "Membership was Renewed after Cancellation",
    "disputes.defenseReason.merchandiseNotReturned": "The merchandise was never returned",
    "disputes.defenseReason.merchandiseWasNotCounterfeit": "Merchandise was not counterfeit",
    "disputes.defenseReason.merchandiseWasReceivedByShopper": "The merchandise was received by the shopper",
    "disputes.defenseReason.merchantCanProvideAdditionalCompellingEvidence": "The transaction is recurring, merchant can provide additional compelling evidence such as description of the goods or services provided; a receipt, work order or other document acknowledged by the customer that the goods or services were received by the customer; the customer's written confirmation of registration; any written correspondence exchanged between the merchant and the customer (such as letter, email or fax).",
    "disputes.defenseReason.merchantCanProvideAdditionalInformation": "The merchant can provide additional information that would help to identify the transaction. This should include at least a description of the merchandise or services. This could, for example, be an invoice.",
    "disputes.defenseReason.merchantCantReceiveThisChargebackBasedOnTheirMcc": "The merchant can not receive this chargeback based on their MCC",
    "disputes.defenseReason.merchantNotNotifiedOfCancellation": "Merchant was not Notified of Cancellation",
    "disputes.defenseReason.merchantProvidedServicesToCardholderProof": "There is proof that the merchant provided the services to the cardholder or person that the cardholder authorized.",
    "disputes.defenseReason.merchantProvideMissingDocuments": "The merchant can provide the documents that were missing or were illegible, causing the chargeback.",
    "disputes.defenseReason.noCreditSlip": "No credit slip or other advisement has been given to the card holder",
    "disputes.defenseReason.noPriorChargebackReceived": "No prior chargeback received",
    "disputes.defenseReason.noShowTransaction": "No Show Transaction",
    "disputes.defenseReason.not3dSecureTransaction": "Not a 3D Secure transaction",
    "disputes.defenseReason.notAgreeWithRefund": "The merchant did not agree with the refund",
    "disputes.defenseReason.notPosTransaction": "Transaction was not a POS transaction",
    "disputes.defenseReason.parcelServiceReceipt": "Proof that the cardholder received the merchandise or a person authorized by the cardholder received the merchandise. For example, the card acceptor provided proof of a United Parcel Service (UPS) receipt.",
    "disputes.defenseReason.pastChargebackTimeLimit": "Past Chargeback Time Limit",
    "disputes.defenseReason.paymentByOtherMeans": "Payment by Other Means",
    "disputes.defenseReason.paypassAmountBelowProtectionAmount": "The transaction was a PayPass transaction with an amount below the chargeback protection amount.",
    "disputes.defenseReason.paypassTransaction": "PayPass Transaction",
    "disputes.defenseReason.pinForOneOrBothTransactions": "A PIN was present for one or both transactions.",
    "disputes.defenseReason.pinTransaction": "PIN Transaction",
    "disputes.defenseReason.pinUsedToVerifyCardholder": "PIN was used to verify the cardholder's presence in a POS environment.",
    "disputes.defenseReason.posTransactionAndSignedTerminalReceiptAvailable": "The transaction was a POS transaction and a signed terminal receipt is available.",
    "disputes.defenseReason.posTransactionCardholderWasPresentProof": "The transaction was a POS transaction and documentation is avaible to proof that the cardholder was present.",
    "disputes.defenseReason.prevChargedbackTwoTransactionsWithSameAccount": "The issuer previously charged back two or more transactions involving the same MasterCard card account prior to the authorization approval date of the disputed transaction",
    "disputes.defenseReason.previousChargebackCancellingRecurringContract": "The issuer claims that a previous transaction was chargebacked, cancelling the recurring contract. There is however proof that no prior transaction has been chargebacked at the time of settlement.",
    "disputes.defenseReason.proofCardholderReceivedMerchandise": "There is proof that the cardholder or person that the cardholder authorized received the merchandise. For example:",
    "disputes.defenseReason.proofDeficiencyCorrected": "The acquirer can document it corrected the deficiency that led to the chargeback.",
    "disputes.defenseReason.proofOfCardPresenceAvailableNotAuthorisedMastercardNetwork": "Proof of Card Presence Available (Not authorised via MasterCard Wold Wide Network)",
    "disputes.defenseReason.proofOfCardPresenceMastercardCorporateFleet": "Proof of Card Presence Available (Mastercard Corporate Fleet Card)",
    "disputes.defenseReason.provideInformationForCollectionOrFraudCase": "Provide the required information for collection or fraud case",
    "disputes.defenseReason.provideMissingInformation": "Provide Missing Information",
    "disputes.defenseReason.provideTransactionalInformation": "Provide the requested transactional information to the issuer. At least this should include a copy of the invoice, receipt, sales ticket or any other document that provides the relevant order details, like the description of merchandise or services and the shipping data (if applicable).",
    "disputes.defenseReason.provideTransactionalInfoTravelDetails": "Provide the requested transactional information to the issuer. At least this should include a copy of the invoice, receipt, sales ticket or any other document that provides the relevant order details, like the passenger name, travel agency (if applicable), ticket number (if applicable) and airline flight information.",
    "disputes.defenseReason.purchaseProperlyPosted": "Purchase Properly Posted",
    "disputes.defenseReason.qpsTransaction": "QPS Transaction",
    "disputes.defenseReason.qpsTransactionWithAmountLessThanChargebackProtectionAmount": "The transaction was a QPS transaction with a transaction amount equal to or less than the chargeback protection amount.",
    "disputes.defenseReason.receiptWithItemsBilledBecauseOfLossTheftDamages": "Card was present and a signed terminal receipt is available. The transaction involves loss, theft or damage. The merchant should provide the receipt containing specially the items that were additionally billed, because of the loss, theft or damages.",
    "disputes.defenseReason.recurringTransactionCompellingEvidence": "Recurring Transaction Compelling Evidence",
    "disputes.defenseReason.recurringTransactionCompellingMerchantEvidence": "Recurring Transaction Compelling Merchant Evidence",
    "disputes.defenseReason.reponseToRfi": "Response to Request for Information",
    "disputes.defenseReason.reponseToRfiCardPresent": "Response to a Request for Information (Card Present only)",
    "disputes.defenseReason.requiredDocumentationNotReceived": "Non-receipt of Required Documentation to Support Chargeback",
    "disputes.defenseReason.responseToRfiAirlines": "Response to Request for Information (Airlines only)",
    "disputes.defenseReason.responseToRfiCarRental": "Response to Request for Information (Car Rental only)",
    "disputes.defenseReason.retrievalRequestFulfilled": "Retrieval request fulfilled",
    "disputes.defenseReason.returnNotAccepted": "The cancellation of services or the return of the merchandise was not accepted.",
    "disputes.defenseReason.scanningError": "Scanning error - unrelated documents or partial scan",
    "disputes.defenseReason.serviceCancelledButMerchantNotNotified": "The service was cancelled, but the merchant and acquirer were not notified in time to prevent the recurring transaction.",
    "disputes.defenseReason.serviceNotCancelled": "Service was not Cancelled",
    "disputes.defenseReason.serviceNotCancelledEvidence": "There is evidence that shows that the service was not cancelled at the time of the settlement.",
    "disputes.defenseReason.servicesProvidedAfterCancellation": "Services Provided after Cancellation",
    "disputes.defenseReason.servicesProvidedAndUsedAfterCancellation": "The merchant has provided services after the cancellation date, which have been used by the cardholder.",
    "disputes.defenseReason.shopperClaimsRefundWasPromisedButNotExecuted": "The shopper claims that a refund was promised but not executed. To defend against this, simply upload a statement that this was not agreed.",
    "disputes.defenseReason.shopperUsedAirlineTicket": "Shopper has or could have used the provided airline ticket",
    "disputes.defenseReason.signedImprintedSalesSlipInvoicePosReceipt": "A signed and imprinted sales slip, invoice, or terminal-generated POS receipt showing that the cardholder, or a person that the cardholder authorized, picked up the merchandise. This documentation proves that the merchant did not ship or deliver the merchandise.",
    "disputes.defenseReason.signedTerminalReceiptAvailable": "Signed Terminal Receipt Available",
    "disputes.defenseReason.supplyDefenseMaterial": "Supply Defense Material",
    "disputes.defenseReason.surchargeCorrectlyProcessed": "The acquirer substantiates that the surcharge was correctly processed.",
    "disputes.defenseReason.surchargeIncorrectlyCalculatedByIssuer": "The acquirer substantiates that the pro-rated surcharge was incorrectly calculated by the issuer.",
    "disputes.defenseReason.termsOfSaleWereNotMisrepresented": "Terms of sale were not misrepresented",
    "disputes.defenseReason.thisReasonIsTechnical": "Please take care when using this dispute reason; this reason is technical in nature and does not always address the true nature of the dispute.",
    "disputes.defenseReason.timeBetweenAuthorisationAndSettlementWithinTimeLimits": "The time between the authorisation and the settlement was within the time limits set by the schemes. For normal transactions the time limit is 180 days. In case the card account is no longer active/valid, the settlement should take place within 30 days for normal cards and 6 days for Visa Electron cards.",
    "disputes.defenseReason.transactioAuthorisedEmergencyPaymentAuthorizationService": "The transaction was authorised through the Emergency Payment Authorization Service.",
    "disputes.defenseReason.transactionAmountAlreadyRefunded": "The credit was previously issued, for example, the merchant already refunded the full transaction amount to the card holder.",
    "disputes.defenseReason.transactionApproved3dSecureAuthenticated": "The transaction approved by the issuer was fully (directory and authentication response both Y) 3D Secure authenticated.",
    "disputes.defenseReason.transactionBetweenChipLiabilityShiftProgramCustomers": "The transaction was between customers that participate in the appropriate Chip Liability Shift Program, occurred at a hybrid terminal, and was initiated with a non-EMV chip card.",
    "disputes.defenseReason.transactionFallsCvc2ValidationProgram": "The transaction falls under the CVC2 Validation Program",
    "disputes.defenseReason.transactionFromAccountTakeover": "The transaction resulted from an account takeover.",
    "disputes.defenseReason.transactionInformationDocument": "The Transaction Information Document (TID) shows that the amount was processed correctly",
    "disputes.defenseReason.transactionIssuerApproved3dSecureAuthenticated": "The transaction approved by the issuer was fully (directory and authentication response both Y) 3D Secure authenticated.",
    "disputes.defenseReason.transactionNotChargebackedAutoDefense": "The issuer claims that a previous chargeback indicated the cancellation of the service. This claim is however not justified, since the transaction indicated by the issuer is not chargebacked or was not chargebacked at the time of settlement. This can be defended automatically by the system.",
    "disputes.defenseReason.transactionNotFully3dSecureAuthenticated": "The transaction approved by the issuer was not fully 3D Secure authenticated, but there was a liability shift for the given dispute reason.",
    "disputes.defenseReason.transactionNotRecurring": "Transaction is not Recurring",
    "disputes.defenseReason.transactionNotRecurringTransactionInstallment": "The transaction was not recurring. For example, if the transaction is an installment.",
    "disputes.defenseReason.transactionSettledWithinTimeLimit": "Transaction was settled within Time Limit",
    "disputes.defenseReason.transactionsInitiatedDueToLossTheftOrDamages": "Transactions was initiated due to loss, theft or damages",
    "disputes.defenseReason.transactionWasAuthorised": "Transaction was Authorised",
    "disputes.defenseReason.transactionWasAuthorisedOnline": "Transaction was authorised online.",
    "disputes.defenseReason.transactionWasECommerceGivenChargebackReasonNotApplicable": "The transaction was a E-Commerce, MOTO or Recurring transaction. The given chargeback reason is not applicable for these transaction types.",
    "disputes.defenseReason.transactionWasInFaceToFaceEnvironment": "The transaction took place in a face-to-face (POS) environment.",
    "disputes.defenseReason.transactionWasProperlyIdentifiedAsInstallmentTransaction": "The issuer claimed that the transaction was not for an installment billing, and transaction was properly identified as an installment transaction in the authorization request.",
    "disputes.defenseReason.transactionWasResultOfGuaranteedReservation": "The transaction was the result of Guaranteed Reservation Service (a No-Show)",
    "disputes.defenseReason.twoDifferentTidsNonAtm": "Two Different TIDs-Non-ATM",
    "disputes.defenseReason.twoDifferentTidsWithSameCardholderAccount": "The Merchant can provide documentation to support two separate transactions by providing two different TIDs with the same cardholder account number.",
    "disputes.defenseReason.twoDifferentTransactions": "Two Different Transactions",
    "disputes.defenseReason.twoPreviousFraudRelatedChargebacks": "Two or More Previous Fraud-related Chargebacks",
    "disputes.defenseReason.twoSeparateTransactions": "There is documentation available to support the claim that there were two separate transactions.",
    "disputes.defenseReason.unfoundedCardholderDispute": "Unfounded cardholder dispute",
    "disputes.defenseReason.unreasonableAmount": "Unreasonable Amount",
    "disputes.defenseReason.uploadReturnPolicyDocument": "To defend against this dispute, upload a document that states the return policy, e.g. ToS",
    "disputes.defenseReason.useThisDefenseReasonIfApplicable": "Use this defense reason if one of the following is applicable:",
    "disputes.defenseReason.validityOfTransactionChargedExplanation": "The merchant can provide an explanation that substantiates the validity of the transaction charged.",
    "disputes.defenseReason.waiverFormAbsolvingMerchantResponsibility": "A written merchant rebuttal to the claim of non-receipt of merchandise, such as a waiver form absolving merchant responsibility.",
    "disputes.disputedAmount": "Disputed amount",
    "disputes.disputeManagementTitle": "Dispute management",
    "disputes.disputeReason": "Reason",
    "disputes.disputeReference": "Dispute reference",
    "disputes.documentRequirements": "Document requirements",
    "disputes.documentRequirements.acceptableFormatAndSize": "Max 2MB for PDF or 10MB for JPEG, JPG, TIFF",
    "disputes.documentRequirements.mustBeInEnglish": "Must be in English",
    "disputes.documentRequirements.recommendedSize": "Recommended A4 or US letter size",
    "disputes.empty.noChargebacksFound": "No chargebacks found",
    "disputes.empty.noDisputesFound": "No disputes found",
    "disputes.empty.noFraudAlertsFound": "No fraud alerts found",
    "disputes.empty.tryDifferentSearchOrCheckAgainLaterForNewChargebacks": "Try different filters or check again later for new chargebacks.",
    "disputes.empty.tryDifferentSearchOrCheckAgainLaterForNewDisputes": "Try different filters or check again later for new disputes.",
    "disputes.empty.tryDifferentSearchOrCheckAgainLaterForNewFraudAlerts": "Try different filters or check again later for new fraud alerts.",
    "disputes.error.couldNotLoadDisputesOverview": "We could not load the disputes overview component",
    "disputes.error.entityWasNotFound": "Entity was not found",
    "disputes.error.entityWasNotFoundDetail": "Dispute not found for the specified Account Holder",
    "disputes.error.failedRetry": "Failed, retry",
    "disputes.error.weCouldNotLoadYourDispute": "We could not load your dispute.",
    "disputes.error.weCouldNotLoadYourDisputes": "We could not load your disputes.",
    "disputes.error.weCouldNotProcessTheDisputePleaseTryAgainOrContactSupport": "We couldn't process this dispute. Please try again, or contact support if you continue to have problems.",
    "disputes.evidence": "Evidence",
    "disputes.expiredOn": "Expired on",
    "disputes.goBack": "Go back",
    "disputes.gridCell.dueDate": "Due: %{dueDate}",
    "disputes.inputError.fileIsOverSizeLimitForTypeChooseASmallerFileAndTryAgain": "File is over %{size} limit for %{type}. Choose a smaller file and try again.",
    "disputes.inputError.somethingWentWrongPleaseCheckYourDocuments": "Something went wrong, please check that your documents are meeting requirements.",
    "disputes.inputError.uploadAtLeastOneSupportingDocumentToContinue": "Upload at least one supporting document to continue",
    "disputes.issuerComment.showLess": "Show less",
    "disputes.issuerComment.showMore": "Show more",
    "disputes.issuerComment.title": "The issuer came back with some feedback:",
    "disputes.merchantReference": "Merchant reference",
    "disputes.openedOn": "Opened on",
    "disputes.paymentMethod": "Payment method",
    "disputes.paymentReference": "Payment reference",
    "disputes.reason": "Reason",
    "disputes.reasonCategory.adjustment": "Adjustment",
    "disputes.reasonCategory.authorisationError": "Authorisation error",
    "disputes.reasonCategory.consumerDispute": "Consumer dispute",
    "disputes.reasonCategory.fraud": "Fraud",
    "disputes.reasonCategory.other": "Other",
    "disputes.reasonCategory.processingError": "Processing error",
    "disputes.reasonCategory.requestForInformation": "Request for information",
    "disputes.reasonCode": "Reason code",
    "disputes.respondBy": "Respond by",
    "disputes.showDisputeDetails": "Show details",
    "disputes.status": "Status",
    "disputes.status.accepted": "Accepted",
    "disputes.status.expired": "Expired",
    "disputes.status.lost": "Lost",
    "disputes.status.pending": "Pending",
    "disputes.status.responded": "Responded",
    "disputes.status.undefended": "Undefended",
    "disputes.status.unresponded": "Unresponded",
    "disputes.status.won": "Won",
    "disputes.statusGroup.chargebacks": "Chargebacks",
    "disputes.statusGroup.fraudAlerts": "Fraud alerts",
    "disputes.statusGroup.ongoingAndClosed": "Ongoing & closed",
    "disputes.title": "Disputes",
    "disputes.totalPaymentAmount": "Total payment amount",
    "disputes.type.chargeback": "Chargeback",
    "disputes.type.notificationOfFraud": "Notification of fraud",
    "disputes.type.requestForInformation": "Request for information",
    "disputes.uploadDocuments.addOptionalDocument": "Add optional document",
    "disputes.uploadDocuments.extraRequiredDocument": "Required document",
    "disputes.uploadDocuments.optionalDocument": "Optional document",
    "disputes.uploadDocuments.selectDocumentType": "Select document type",
    "disputes.uploadDocuments.selectOneOfTheRequiredOptions": "Select one of the required options",
    download: download$1,
    downloading,
    email,
    entityWasNotFound,
    entityWasNotFoundDetail,
    "error.pleaseTryAgainLater": "Please try again later.",
    "error.somethingWentWrongWithDownload": "Something went wrong with the download",
    "expandableCard.collapse": "Collapse",
    "expandableCard.expand": "Expand",
    "export": "Export",
    fee,
    file,
    "filter.date.since": "Since %{date}",
    "filter.date.until": "Until %{date}",
    filterBar,
    "filterPlaceholder.category": "Type",
    "filterPlaceholder.currency": "Currency",
    "filterPlaceholder.status": "Status",
    from,
    full,
    fundsCaptured,
    goBack,
    grantIssued,
    grantRepayment,
    hideContent,
    id,
    incompleteField,
    inProgress,
    "inputError.disallowedFileType": "File type not accepted",
    "inputError.fileRequired": "File required",
    "inputError.tooManyFiles": "Too many files",
    "inputError.veryLargeFile": "File size exceeds the maximum file size",
    loading,
    max,
    min,
    mobile,
    netPayout,
    nextPayouts,
    noData,
    noNegativeNumbersAllowed,
    noPayoutsFound,
    noReportsFound,
    noTransactionsFound,
    other,
    paginatedNavigation,
    "pagination.nextPage": "Next page",
    "pagination.previousPage": "Previous page",
    "pagination.showing": "Showing",
    partial,
    paymentId,
    paymentMethod,
    payoutDetails,
    payoutsNotice,
    payoutsTitle,
    Pending,
    pleaseComeBackLater,
    pleaseReachOutToSupportForAssistance,
    "rangePreset.custom": "Custom",
    "rangePreset.last30Days": "Last 30 days",
    "rangePreset.last7Days": "Last 7 days",
    "rangePreset.lastMonth": "Last month",
    "rangePreset.lastWeek": "Last week",
    "rangePreset.thisMonth": "This month",
    "rangePreset.thisWeek": "This week",
    "rangePreset.yearToDate": "Year to date",
    reachOutToSupport,
    referenceID,
    refresh,
    refund,
    "refund.amountAlreadyRefunded": "You already refunded %{amount}",
    "refund.amountFailed": "The refund for %{amount} has failed. It is not currently possible to refund this amount. Please contact support.",
    "refund.amountInProgress": "The partial refund of %{amount} is being processed.",
    "refund.fee": "Fee",
    "refund.fullAmountFailed": "It is not possible to refund this payment. Please contact support.",
    "refund.fullAmountRefunded": "The full amount has been refunded back to the customer",
    "refund.goToPayment": "Go to payment",
    "refund.maximumRefundable": "You can only refund a maximum of %{amount}",
    "refund.onlyRefundable": "You can only refund %{amount}",
    "refund.originalAmount": "Original Amount",
    "refund.originalPayment": "Original Payment",
    "refund.paymentPspReference": "Payment PSP Reference",
    "refund.pspReference": "PSP Reference",
    "refund.refundFee": "Refund Fee",
    "refund.refundPspReference": "Refund PSP Reference",
    "refund.returnToRefund": "Return to refund",
    "refund.theRefundIsBeingProcessed": "The refund is being processed.",
    refundAction,
    refundActionErrorSubtitle,
    refundActionErrorTitle,
    refundActionSuccessSubtitle,
    refundActionSuccessTitle,
    refundAmount,
    "refundAmount.excess": "You cannot exceed the available amount of %{amount}",
    "refundAmount.required": "Enter a refund amount",
    "refunded.full": "Fully refunded",
    "refunded.partial": "Partially refunded",
    refundNotice,
    refundPayment,
    refundReason,
    "refundReason.duplicate": "Duplicate",
    "refundReason.fraudulent": "Fraudulent",
    "refundReason.issue_with_item_sold": "Issue with item sold",
    "refundReason.other": "Other",
    "refundReason.requested_by_customer": "Requested by customer",
    refundReference,
    "refundReference.placeholder": "Enter the reference here",
    remainingAmount,
    report,
    "reportsError.tooManyDownloads": "We couldn't download all the files. Please try again later.",
    reportsNotice,
    reportsTitle,
    "reportType.payout": "Payout",
    reset,
    Reversed,
    "select.filter.placeholder": "Placeholder",
    "select.noOptionsFound": "No options match this search",
    somethingWentWrong,
    somethingWentWrongTryRefreshingOrComeBackLater,
    status,
    structuredList,
    subtractions,
    sumOfSameDayPayouts,
    tabs,
    theErrorCodeIs,
    thereAreNoResults,
    theRequestIsMissingRequiredFieldsOrContainsInvalidData,
    thereWasAnUnexpectedError,
    theSelectedBalanceAccountIsIncorrect,
    timezone,
    to,
    "tooltip.ATM": "Money withdrawn at an ATM",
    "tooltip.Capital": "Money from an incoming loan grant or outgoing loan repayment",
    "tooltip.Chargeback": "Money returned to a customer after a disputed transaction",
    "tooltip.Correction": "Adjustments to your funds, including transaction reversals and deposit corrections",
    "tooltip.Fee": "Transaction costs and payment method fees",
    "tooltip.Other": "Transactions not in another category, usually an adjustment",
    "tooltip.Payment": "Money received to your account from a sales transaction",
    "tooltip.Refund": "Money sent back to a customer from a refunded transaction",
    "tooltip.totalIncoming": "All money received into your account based on the selected filters",
    "tooltip.totalOutgoing": "All fees, refunds, payouts, and other charges based on the selected filters",
    "tooltip.Transfer": "Money moved between your account and another account",
    totalIncoming,
    totalOutgoing,
    toValueShouldBeGreaterThanTheFromValue,
    transactionDetails,
    transactions,
    transactionsOverviewTitle,
    transactionType,
    transfer,
    tryDifferentSearchOrResetYourFiltersAndWeWillTryAgain,
    tryRefreshingThePageOrComeBackLater,
    txAmount,
    "txType.ATM": "ATM",
    "txType.Capital": "Capital",
    "txType.Chargeback": "Chargeback",
    "txType.Correction": "Correction",
    "txType.Fee": "Fee",
    "txType.Other": "Other",
    "txType.Payment": "Payment",
    "txType.Refund": "Refund",
    "txType.Transfer": "Transfer",
    type,
    "uploadedFile.remove": "Delete %{filename} file",
    "uploadFile.browse": "Browse files",
    value,
    weCouldNotLoadThePayoutsOverview,
    weCouldNotLoadTheReportsOverview,
    weCouldNotLoadTheTransactionsOverview,
    weCouldNotLoadYourBalanceAccounts,
    weCouldNotLoadYourPayouts,
    weCouldNotLoadYourReports,
    weCouldNotLoadYourTransactions
  };
  const _en_US = { ...EN_US };
  const da_DK = { da_DK: () => ({}) };
  const de_DE = { de_DE: () => ({}) };
  const es_ES = { es_ES: () => ({}) };
  const fi_FI = { fi_FI: () => ({}) };
  const fr_FR = { fr_FR: () => ({}) };
  const it_IT = { it_IT: () => ({}) };
  const nl_NL = { nl_NL: () => ({}) };
  const no_NO = { no_NO: () => ({}) };
  const pt_BR = { pt_BR: () => ({}) };
  const sv_SE = { sv_SE: () => ({}) };
  const en_US = { en_US: _en_US };
  const all_locales = {
    ...da_DK,
    ...de_DE,
    ...en_US,
    ...es_ES,
    ...fi_FI,
    ...fr_FR,
    ...it_IT,
    ...nl_NL,
    ...no_NO,
    ...pt_BR,
    ...sv_SE
  };
  const FALLBACK_LOCALE = "en-US";
  const DEFAULT_TRANSLATIONS = en_US["en_US"];
  const DEFAULT_DATETIME_FORMAT = { year: "numeric", month: "2-digit", day: "2-digit" };
  const EXCLUDE_PROPS = ["constructor", "i18n", "watch", "preferredTranslations"];
  const getLocalesFromTranslationSourcesRecord = (sources) => [
    ...new Set(
      Object.keys(sources).map((locale) => locale.replace(/_/g, "-")).sort()
    )
  ];
  const SUPPORTED_LOCALES = [
    "da-DK",
    "de-DE",
    "en-US",
    "es-ES",
    "fi-FI",
    "fr-FR",
    "it-IT",
    "nl-NL",
    "no-NO",
    "pt-BR",
    "sv-SE"
  ];
  const CURRENCY_CODES = {
    AED: "د.إ",
    AFN: "؋",
    ALL: "L",
    ANG: "ƒ",
    AOA: "Kz",
    ARS: "$",
    AUD: "$",
    AWG: "ƒ",
    AZN: "₼",
    BAM: "KM",
    BBD: "$",
    BDT: "৳",
    BGN: "лв",
    BHD: ".د.ب",
    BIF: "FBu",
    BMD: "$",
    BND: "$",
    BOB: "Bs.",
    BRL: "R$",
    BSD: "$",
    BTC: "฿",
    BTN: "Nu.",
    BWP: "P",
    BYR: "p.",
    BYN: "Br",
    BZD: "BZ$",
    CAD: "$",
    CDF: "FC",
    CHF: "Fr.",
    CLP: "$",
    CNY: "¥",
    COP: "$",
    CRC: "₡",
    CUC: "$",
    CUP: "₱",
    CVE: "$",
    CZK: "Kč",
    DJF: "Fdj",
    DKK: "kr",
    DOP: "RD$",
    DZD: "دج",
    EEK: "kr",
    EGP: "£",
    ERN: "Nfk",
    ETB: "Br",
    EUR: "€",
    FJD: "$",
    FKP: "£",
    GBP: "£",
    GEL: "₾",
    GGP: "£",
    GHC: "₵",
    GHS: "GH₵",
    GIP: "£",
    GMD: "D",
    GNF: "FG",
    GTQ: "Q",
    GYD: "$",
    HKD: "$",
    HNL: "L",
    HRK: "kn",
    HTG: "G",
    HUF: "Ft",
    IDR: "Rp",
    ILS: "₪",
    IMP: "£",
    INR: "₹",
    IQD: "ع.د",
    IRR: "﷼",
    ISK: "kr",
    JEP: "£",
    JMD: "J$",
    JPY: "¥",
    KES: "KSh",
    KGS: "лв",
    KHR: "៛",
    KMF: "CF",
    KPW: "₩",
    KRW: "₩",
    KYD: "$",
    KZT: "₸",
    LAK: "₭",
    LBP: "£",
    LKR: "₨",
    LRD: "$",
    LSL: "M",
    LTL: "Lt",
    LVL: "Ls",
    MAD: "MAD",
    MDL: "lei",
    MGA: "Ar",
    MKD: "ден",
    MMK: "K",
    MNT: "₮",
    MOP: "MOP$",
    MUR: "₨",
    MVR: "Rf",
    MWK: "MK",
    MXN: "$",
    MYR: "RM",
    MZN: "MT",
    NAD: "$",
    NGN: "₦",
    NIO: "C$",
    NOK: "kr",
    NPR: "₨",
    NZD: "$",
    OMR: "﷼",
    PAB: "B/.",
    PEN: "S/.",
    PGK: "K",
    PHP: "₱",
    PKR: "₨",
    PLN: "zł",
    PYG: "Gs",
    QAR: "﷼",
    RMB: "￥",
    RON: "lei",
    RSD: "Дин.",
    RUB: "₽",
    RWF: "R₣",
    SAR: "﷼",
    SBD: "$",
    SCR: "₨",
    SDG: "ج.س.",
    SEK: "kr",
    SGD: "$",
    SHP: "£",
    SLL: "Le",
    SOS: "S",
    SRD: "$",
    SSP: "£",
    STD: "Db",
    SVC: "$",
    SYP: "£",
    SZL: "E",
    THB: "฿",
    TJS: "SM",
    TMT: "T",
    TND: "د.ت",
    TOP: "T$",
    TRL: "₤",
    TRY: "₺",
    TTD: "TT$",
    TVD: "$",
    TWD: "NT$",
    TZS: "TSh",
    UAH: "₴",
    UGX: "USh",
    USD: "$",
    UYU: "$U",
    UZS: "лв",
    VEF: "Bs",
    VND: "₫",
    VUV: "VT",
    WST: "WS$",
    XAF: "FCFA",
    XBT: "Ƀ",
    XCD: "$",
    XOF: "CFA",
    XPF: "₣",
    YER: "﷼",
    ZAR: "R",
    ZWD: "Z$"
  };
  const CURRENCY_DECIMALS = {
    // ZERO_DECIMAL_CURRENCIES
    IDR: 1,
    JPY: 1,
    KRW: 1,
    VND: 1,
    BYR: 1,
    CVE: 1,
    DJF: 1,
    GHC: 1,
    GNF: 1,
    KMF: 1,
    PYG: 1,
    RWF: 1,
    UGX: 1,
    VUV: 1,
    XAF: 1,
    XOF: 1,
    XPF: 1,
    // ONE_DECIMAL_CURRENCIES
    MRO: 10,
    // THREE_DECIMAL_CURRENCIES
    BHD: 1e3,
    IQD: 1e3,
    JOD: 1e3,
    KWD: 1e3,
    OMR: 1e3,
    LYD: 1e3,
    TND: 1e3
  };
  const getDivider = (currencyCode) => CURRENCY_DECIMALS[currencyCode] || 100;
  const isValidCurrencyCode = (currencyCode) => !!CURRENCY_CODES[currencyCode];
  const getCurrencyCode = (currencyCode) => isValidCurrencyCode(currencyCode) ? CURRENCY_CODES[currencyCode] : null;
  const getDecimalAmount = (amount2, currencyCode) => {
    const divider = getDivider(currencyCode);
    return parseInt(String(amount2), 10) / divider;
  };
  const getLocalisedAmount = (amount2, locale, currencyCode, hideCurrency = false, options = {}) => {
    const stringAmount = amount2.toString();
    const decimalAmount = getDecimalAmount(stringAmount, currencyCode);
    const formatterLocale = locale.replace("_", "-");
    const formatterOptions = {
      style: "currency",
      currency: currencyCode,
      currencyDisplay: "symbol",
      ...options
    };
    try {
      return hideCurrency ? formatAmountWithoutCurrency(formatterLocale, formatterOptions, decimalAmount) : decimalAmount.toLocaleString(formatterLocale, formatterOptions);
    } catch (e2) {
      return stringAmount;
    }
  };
  const formatAmountWithoutCurrency = (locale, options, amount2) => {
    return Intl.NumberFormat(locale, options).formatToParts(amount2).filter((p2) => p2.type !== "currency").reduce((s2, p2) => s2 + p2.value, "").trim();
  };
  const REGEX_TZ_OFFSET = /GMT(?:[-+](?:0?\d|1[0-4])(?::?[0-5]\d)?)?$/;
  const { BASE_FORMAT_OPTIONS, BASE_LOCALE, SYSTEM_TIMEZONE, SYSTEM_TIMEZONE_FORMATTER } = (() => {
    const BASE_LOCALE2 = "en-US";
    const DIGITS_22 = "2-digit";
    const NUMERIC2 = "numeric";
    const SHORT2 = "short";
    const TZ_LONG = "longOffset";
    const FRACTIONAL_SECOND_DIGITS = 3;
    const BASE_FORMAT_OPTIONS2 = Object.freeze({
      year: NUMERIC2,
      month: SHORT2,
      day: NUMERIC2,
      hour: DIGITS_22,
      minute: DIGITS_22,
      second: DIGITS_22,
      fractionalSecondDigits: FRACTIONAL_SECOND_DIGITS,
      timeZoneName: TZ_LONG
      // should not be changed — needed for the tz offsets regexp
    });
    let SYSTEM_TIMEZONE2;
    let SYSTEM_TIMEZONE_FORMATTER2;
    try {
      SYSTEM_TIMEZONE_FORMATTER2 = new Intl.DateTimeFormat(BASE_LOCALE2, BASE_FORMAT_OPTIONS2);
      SYSTEM_TIMEZONE2 = SYSTEM_TIMEZONE_FORMATTER2.resolvedOptions().timeZone;
    } catch (ex) {
      SYSTEM_TIMEZONE2 = void 0;
    }
    return { BASE_FORMAT_OPTIONS: BASE_FORMAT_OPTIONS2, BASE_LOCALE: BASE_LOCALE2, SYSTEM_TIMEZONE: SYSTEM_TIMEZONE2, SYSTEM_TIMEZONE_FORMATTER: SYSTEM_TIMEZONE_FORMATTER2 };
  })();
  const REGEX_GMT_OFFSET_UNWANTED_SUBSTRINGS = /\+(?=-)|([+-]00:00)/g;
  const REGEX_TZ_SINGLE_DIGIT_OFFSET = /(^\D?)(\d)$/;
  const computeTimezoneOffsetInMinutes = ([offsetHours, offsetMinutes]) => (Math.abs(offsetHours * 60) + offsetMinutes) * (offsetHours < 0 ? -1 : 1);
  const computeTimezoneOffsetsFromMinutes = (timezoneOffsetInMinutes) => Object.freeze([
    Math.floor(timezoneOffsetInMinutes / 60),
    // offset hours
    mod(timezoneOffsetInMinutes, 60)
    // offset minutes
  ]);
  const parseTimezoneOffset = (offset) => parseInt(offset, 10) || 0;
  const getGMTSuffixForTimezoneOffset = (timezoneOffset) => {
    const offsets = computeTimezoneOffsetsFromMinutes(timezoneOffset);
    const offsetString = offsets.map((offset) => `${offset}`.replace(REGEX_TZ_SINGLE_DIGIT_OFFSET, "$10$2")).join(":");
    return `GMT+${offsetString}`.replace(REGEX_GMT_OFFSET_UNWANTED_SUBSTRINGS, "");
  };
  const getTimezoneOffsetFromFormattedDateString = (date2) => {
    var _a2;
    const offsets = ((_a2 = date2 == null ? void 0 : date2.match(REGEX_TZ_OFFSET)) == null ? void 0 : _a2[0].replace("GMT", "").split(":", 2).map(parseTimezoneOffset)) ?? EMPTY_ARRAY;
    return computeTimezoneOffsetInMinutes(offsets.concat(0, 0).slice(0, 2));
  };
  const getTimezoneOffsetForTimestamp = (timestamp, timezoneFormatter = SYSTEM_TIMEZONE_FORMATTER) => {
    const systemOffset = getTimezoneOffsetFromFormattedDateString(SYSTEM_TIMEZONE_FORMATTER == null ? void 0 : SYSTEM_TIMEZONE_FORMATTER.format(timestamp));
    const timezoneOffset = getTimezoneOffsetFromFormattedDateString(timezoneFormatter == null ? void 0 : timezoneFormatter.format(timestamp));
    return timezoneOffset - systemOffset;
  };
  const restamp = (restamper2, time, direction = 1) => {
    const { offset, timestamp } = restamper2(time);
    return timestamp - offset * direction * 6e4;
  };
  const systemToTimezone = (restamper2, time) => restamp(restamper2, time, 1);
  const timezoneToSystem = (restamper2, time) => restamp(restamper2, time, -1);
  const restamper = (() => {
    let getTimeZone;
    let setTimeZone;
    if (!isUndefined(SYSTEM_TIMEZONE)) {
      getTimeZone = function() {
        return this.TIMEZONE;
      };
      setTimeZone = function(timeZone) {
        if (!isNullish(timeZone)) {
          try {
            const nextFormatter = new Intl.DateTimeFormat(BASE_LOCALE, { ...BASE_FORMAT_OPTIONS, timeZone });
            const nextTimeZone = nextFormatter.resolvedOptions().timeZone;
            if (this.TIMEZONE === nextTimeZone) return;
            this.TIMEZONE = nextTimeZone;
            this.formatter = nextFormatter;
          } catch (ex) {
          }
        } else {
          this.TIMEZONE = SYSTEM_TIMEZONE;
          this.formatter = SYSTEM_TIMEZONE_FORMATTER;
        }
      };
    }
    function restamp2(...args) {
      if (args.length === 0) return restamp2.call(this, Date.now());
      const time = args[0];
      const timestamp = new Date(time).getTime();
      const formatter = this.formatter ?? SYSTEM_TIMEZONE_FORMATTER;
      return Object.freeze({
        formatted: formatter == null ? void 0 : formatter.format(timestamp),
        offset: getTimezoneOffsetForTimestamp(timestamp, formatter),
        timestamp
      });
    }
    return () => {
      const context = { TIMEZONE: SYSTEM_TIMEZONE };
      const set = setTimeZone == null ? void 0 : setTimeZone.bind(context);
      const tz = struct({
        current: { get: getTimeZone == null ? void 0 : getTimeZone.bind(context), set },
        system: { value: SYSTEM_TIMEZONE }
      });
      return Object.defineProperties(restamp2.bind(context), {
        tz: { get: () => tz, set }
      });
    };
  })();
  const DEFAULT_TRANSLATION_OPTIONS = { values: EMPTY_OBJECT, count: 0 };
  const LOCALE_FORMAT_REGEX = /^[a-z]{2}-[A-Z]{2}$/;
  const toTwoLetterCode = (locale) => locale.substring(0, 2).toLowerCase();
  function matchLocale(locale, supportedLocales) {
    if (!locale) return null;
    const twoLetterCode = toTwoLetterCode(locale);
    return supportedLocales.find((supportedLocale) => toTwoLetterCode(supportedLocale) === twoLetterCode) || null;
  }
  function formatLocale(locale) {
    const localeString = locale.replace("_", "-");
    if (LOCALE_FORMAT_REGEX.test(localeString)) return localeString;
    const [languageCode, countryCode] = localeString.split("-");
    if (!languageCode || !countryCode) return null;
    const fullLocale = `${languageCode.toLowerCase()}-${countryCode.toUpperCase()}`;
    return fullLocale.length === 5 ? fullLocale : null;
  }
  function parseLocale(locale, supportedLocales) {
    const trimmedLocale = locale.trim();
    if (!trimmedLocale || trimmedLocale.length < 1 || trimmedLocale.length > 5) return FALLBACK_LOCALE;
    const formattedLocale = formatLocale(trimmedLocale);
    if (formattedLocale && supportedLocales.includes(formattedLocale)) return formattedLocale;
    return matchLocale(formattedLocale ?? trimmedLocale, supportedLocales);
  }
  function formatCustomTranslations(customTranslations = EMPTY_OBJECT, supportedLocales) {
    if (customTranslations === EMPTY_OBJECT) return customTranslations;
    return Object.keys(customTranslations).reduce((translations, locale) => {
      const formattedLocale = formatLocale(locale) || parseLocale(locale, supportedLocales);
      if (formattedLocale && customTranslations[locale]) {
        translations[formattedLocale] = customTranslations[locale];
      }
      return translations;
    }, {});
  }
  const replaceTranslationValues = (translation, values) => {
    if (isFunction(values)) {
      const repetitions = /* @__PURE__ */ new Map();
      let placeholderIndex = -1;
      return translation.replace(/%{(\w+)}/g, (_2, placeholder) => {
        let repetitionIndex = repetitions.get(placeholder) ?? -1;
        const replacementValue = values(placeholder, ++placeholderIndex, ++repetitionIndex) ?? "";
        repetitions.set(placeholder, repetitionIndex);
        return replacementValue;
      });
    }
    return translation.replace(/%{(\w+)}/g, (_2, placeholder) => (values == null ? void 0 : values[placeholder]) ?? "");
  };
  const getTranslation = (translations, key, options = DEFAULT_TRANSLATION_OPTIONS) => {
    const count = options.count ?? 0;
    const countKey = `${key}__${count}`;
    if (hasOwnProperty(translations, countKey) && translations[countKey]) {
      return replaceTranslationValues(translations[countKey], options.values);
    }
    const pluralKey = `${key}__plural`;
    if (hasOwnProperty(translations, pluralKey) && count > 1 && translations[pluralKey]) {
      return replaceTranslationValues(translations[pluralKey], options.values);
    }
    if (hasOwnProperty(translations, key) && translations[key]) {
      return replaceTranslationValues(translations[key], options.values);
    }
    return null;
  };
  const loadTranslations = async (locale, fetchTranslationFromCdnPromise, customTranslations = EMPTY_OBJECT) => {
    const localeToLoad = parseLocale(locale, SUPPORTED_LOCALES) || FALLBACK_LOCALE;
    const loadedLocale = fetchTranslationFromCdnPromise(localeToLoad);
    return {
      ...DEFAULT_TRANSLATIONS,
      // Default en-US translations (in case any other translation file is missing any key)
      ...await loadedLocale ?? EMPTY_OBJECT,
      // Merge with our locale file of the locale they are loading
      ...asPlainObject(customTranslations == null ? void 0 : customTranslations[locale])
      // Merge with their custom locales if available
    };
  };
  function createTranslationsLoader() {
    let _locale3 = this.locale;
    let _preferredLocale = _locale3;
    let _supportedLocales2 = [...this.supportedLocales];
    return struct({
      load: {
        value: (fetchTranslationFromCdnPromise, customTranslations) => loadTranslations(_locale3, fetchTranslationFromCdnPromise, customTranslations)
      },
      locale: {
        get: () => _locale3,
        set: (locale) => {
          _preferredLocale = locale;
          _locale3 = formatLocale(locale) || parseLocale(locale, _supportedLocales2) || FALLBACK_LOCALE;
        }
      },
      supportedLocales: {
        get: () => _supportedLocales2,
        set(supportedLocales) {
          _supportedLocales2 = supportedLocales;
          this.locale = _preferredLocale;
        }
      }
    });
  }
  function getLocalizationProxyDescriptors() {
    var _a2;
    const descriptors = {};
    for (const [prop, descriptor] of Object.entries(Object.getOwnPropertyDescriptors(Localization.prototype))) {
      if (EXCLUDE_PROPS.includes(prop)) continue;
      if (isFunction(descriptor.get)) {
        descriptors[prop] = {
          get: descriptor.get.bind(this),
          ...prop === "timezone" && { set: (_a2 = descriptor.set) == null ? void 0 : _a2.bind(this) }
        };
      } else if (isFunction(descriptor.value)) {
        descriptors[prop] = { value: descriptor.value.bind(this) };
      } else {
        descriptors[prop] = { get: () => this[prop] };
      }
    }
    return descriptors;
  }
  class Localization {
    constructor(locale = FALLBACK_LOCALE, availableTranslations, cdnTranslationsUrl = "") {
      __privateAdd(this, _Localization_instances);
      __privateAdd(this, _locale, FALLBACK_LOCALE);
      __privateAdd(this, _languageCode, toTwoLetterCode(__privateGet(this, _locale)));
      __privateAdd(this, _availableLocales, [FALLBACK_LOCALE]);
      __privateAdd(this, _supportedLocales, __privateGet(this, _availableLocales));
      __privateAdd(this, _customTranslations);
      __privateAdd(this, _translations, DEFAULT_TRANSLATIONS);
      __privateAdd(this, _translationsLoader, createTranslationsLoader.call(this));
      __privateAdd(this, _fetchTranslationFromCdnPromise);
      __privateAdd(this, _ready, ALREADY_RESOLVED_PROMISE);
      __privateAdd(this, _currentRefresh);
      __privateAdd(this, _markRefreshAsDone);
      __privateAdd(this, _refreshWatchlist, createWatchlist({ timestamp: () => performance.now() }));
      __privateAdd(this, _restamp, restamper());
      __publicField(this, "watch", __privateGet(this, _refreshWatchlist).subscribe.bind(void 0));
      __publicField(this, "i18n", struct(getLocalizationProxyDescriptors.call(this)));
      __publicField(this, "preferredTranslations");
      this.watch(noop);
      __privateSet(this, _fetchTranslationFromCdnPromise, (locale2) => httpGet({
        loadingContext: cdnTranslationsUrl,
        path: `/${locale2}.json`,
        versionless: true,
        skipContentType: true,
        errorLevel: "info"
      }));
      this.preferredTranslations = Object.freeze(
        (availableTranslations == null ? void 0 : availableTranslations.reduce((records, curr) => ({ ...records, ...curr }), en_US)) ?? { ...en_US }
      );
      __privateSet(this, _availableLocales, getLocalesFromTranslationSourcesRecord(this.preferredTranslations));
      this.locale = locale;
    }
    get customTranslations() {
      return __privateGet(this, _customTranslations) ?? {};
    }
    set customTranslations(customTranslations) {
      let translations = void 0;
      let supportedLocales = [...__privateGet(this, _availableLocales)];
      if (!isNullish(customTranslations)) {
        translations = formatCustomTranslations(customTranslations, SUPPORTED_LOCALES);
        const localesFromCustomTranslations = Object.keys(translations);
        supportedLocales = [...supportedLocales, ...localesFromCustomTranslations].sort().filter((locale, index, locales) => locales.indexOf(locale) === index);
      }
      __privateGet(this, _translationsLoader).supportedLocales = supportedLocales;
      __privateMethod(this, _Localization_instances, refreshTranslations_fn).call(this, translations);
    }
    get languageCode() {
      return __privateGet(this, _languageCode);
    }
    get lastRefreshTimestamp() {
      return __privateGet(this, _refreshWatchlist).snapshot.timestamp;
    }
    get locale() {
      return __privateGet(this, _locale);
    }
    set locale(locale) {
      if (!isNullish(locale)) {
        __privateGet(this, _translationsLoader).locale = locale;
        if (__privateGet(this, _locale) === __privateGet(this, _translationsLoader).locale) return;
        __privateMethod(this, _Localization_instances, refreshTranslations_fn).call(this, __privateGet(this, _customTranslations));
      } else this.locale = FALLBACK_LOCALE;
    }
    get ready() {
      return __privateGet(this, _ready);
    }
    get supportedLocales() {
      return __privateGet(this, _supportedLocales);
    }
    get timezone() {
      return __privateGet(this, _restamp).tz.current;
    }
    set timezone(timezone2) {
      __privateGet(this, _restamp).tz = timezone2;
    }
    /**
     * Returns a translated string from a key in the current {@link Localization.locale}
     * @param key - Translation key
     * @param options - Translation options
     * @returns Translated string
     */
    get(key, options) {
      const translation = getTranslation(__privateGet(this, _translations), key, options);
      return isNull(translation) ? key : translation;
    }
    /**
     * Returns a boolean that checks if the translation key exists in the current {@link Localization.locale}
     * @param key - Translation key
     * @param options - Translation options
     * @returns boolean
     */
    has(key, options) {
      const translation = getTranslation(__privateGet(this, _translations), key, options);
      return !!translation;
    }
    /**
     * Returns a localized string for an amount
     * @param amount - Amount to be converted
     * @param currencyCode - Currency code of the amount
     * @param options - Options for String.prototype.toLocaleString
     */
    amount(amount2, currencyCode, options) {
      const { hideCurrency, ...restOfOptions } = options || {};
      const localisedAmount = getLocalisedAmount(amount2, __privateGet(this, _locale), currencyCode, hideCurrency, {
        ...restOfOptions,
        currencyDisplay: "symbol",
        signDisplay: "never"
      });
      return amount2 < 0 ? `- ${localisedAmount}` : localisedAmount;
    }
    /**
     * Returns a localized string for a date
     * @param date - Date to be localized
     * @param options - Options for {@link Date.toLocaleDateString}
     */
    date(date2, options = {}) {
      const dateOptions = { ...DEFAULT_DATETIME_FORMAT, timeZone: __privateGet(this, _restamp).tz.current, ...options };
      return new Date(date2).toLocaleDateString(__privateGet(this, _locale), dateOptions);
    }
    /**
     * Returns a localized string for a full date
     * @param date - Date to be localized
     */
    fullDate(date2) {
      return this.date(date2, {
        month: "short",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
        hour12: false
      });
    }
  }
  _locale = new WeakMap();
  _languageCode = new WeakMap();
  _availableLocales = new WeakMap();
  _supportedLocales = new WeakMap();
  _customTranslations = new WeakMap();
  _translations = new WeakMap();
  _translationsLoader = new WeakMap();
  _fetchTranslationFromCdnPromise = new WeakMap();
  _ready = new WeakMap();
  _currentRefresh = new WeakMap();
  _markRefreshAsDone = new WeakMap();
  _refreshWatchlist = new WeakMap();
  _restamp = new WeakMap();
  _Localization_instances = new WeakSet();
  refreshTranslations_fn = function(customTranslations) {
    if (isUndefined(__privateGet(this, _markRefreshAsDone))) {
      __privateSet(this, _ready, new Promise((resolve) => {
        __privateSet(this, _markRefreshAsDone, () => {
          resolve(__privateGet(this, _currentRefresh));
          __privateSet(this, _currentRefresh, __privateSet(this, _markRefreshAsDone, void 0));
        });
      }));
    }
    const currentRefreshDone = () => {
      var _a2;
      if (__privateGet(this, _currentRefresh) === currentRefresh) (_a2 = __privateGet(this, _markRefreshAsDone)) == null ? void 0 : _a2.call(this);
    };
    const currentRefresh = __privateSet(this, _currentRefresh, (async () => {
      __privateSet(this, _translations, await __privateGet(this, _translationsLoader).load(__privateGet(this, _fetchTranslationFromCdnPromise), customTranslations));
      __privateSet(this, _locale, __privateGet(this, _translationsLoader).locale);
      __privateSet(this, _supportedLocales, Object.freeze(__privateGet(this, _translationsLoader).supportedLocales));
      __privateSet(this, _customTranslations, customTranslations);
      __privateSet(this, _languageCode, toTwoLetterCode(__privateGet(this, _locale)));
      __privateGet(this, _refreshWatchlist).requestNotification();
    })());
    currentRefresh.then(currentRefreshDone).catch((reason) => {
      currentRefreshDone();
      console.error(reason);
    });
  };
  class Assets {
    constructor(cdnContext) {
      __publicField(this, "resourceContext");
      __publicField(this, "returnAsset", ({ name, resourceUrl, mainFolder, extension, subFolder }) => `${resourceUrl}/${mainFolder ? `${mainFolder}/` : ""}${subFolder ? `${subFolder}/` : ""}${name}${extension ? `.${extension}` : ""}`);
      __publicField(this, "getAssetUrl", (props) => {
        return this.returnAsset({ resourceUrl: this.resourceContext, ...props });
      });
      this.resourceContext = cdnContext;
    }
    getAsset(defaultProps = {}) {
      return (props) => this.getAssetUrl({ ...defaultProps, ...props });
    }
  }
  class Core {
    // [TODO]: Change the error handling strategy.
    constructor(options) {
      __publicField(this, "components", []);
      __publicField(this, "options");
      __publicField(this, "localization");
      __publicField(this, "loadingContext");
      __publicField(this, "session", new AuthSession());
      __publicField(this, "onError");
      __publicField(this, "getImageAsset");
      /**
       * Updates global configurations, resets the internal state and remounts each element.
       * @param options - props to update
       * @returns this - the element instance
       */
      __publicField(this, "update", async (options = EMPTY_OBJECT) => {
        this.setOptions(options);
        await this.initialize();
        this.components.forEach((component) => {
          if (component.props.core === this) {
            component.update(this.getPropsForComponent(this.options));
          }
        });
        return this;
      });
      /**
       * Remove the reference of a component
       * @param component - reference to the component to be removed
       * @returns this - the element instance
       */
      __publicField(this, "remove", (component) => {
        this.components = this.components.filter((c2) => c2._id !== component._id);
        component.unmount();
        return this;
      });
      /**
       * @internal
       * Register components in core to be able to update them all at once
       */
      __publicField(this, "registerComponent", (component) => {
        if (component.props.core === this) {
          this.components.push(component);
        }
      });
      /**
       * @internal
       * Enhances the config object passed when AdyenPlatformExperience is initialised (environment, clientKey, etc...)
       * (Re)Initializes core properties & processes (i18n, etc...)
       * @param options - the config object passed when AdyenPlatformExperience is initialised
       * @returns this
       */
      __publicField(this, "setOptions", (options) => {
        var _a2, _b2;
        this.options = { ...this.options, ...options };
        this.localization.locale = (_a2 = this.options) == null ? void 0 : _a2.locale;
        this.localization.customTranslations = (_b2 = this.options) == null ? void 0 : _b2.translations;
        this.session.loadingContext = this.loadingContext;
        this.session.onSessionCreate = this.options.onSessionCreate;
        return this;
      });
      this.options = { environment: FALLBACK_ENV, ...options };
      const { cdnTranslationsUrl, cdnAssetsUrl, apiUrl } = resolveEnvironment(this.options.environment);
      this.localization = new Localization(options.locale, options.availableTranslations, cdnTranslationsUrl);
      this.loadingContext = apiUrl;
      this.getImageAsset = new Assets(cdnAssetsUrl).getAsset({ extension: "svg", subFolder: "images" });
      this.setOptions(options);
    }
    async initialize() {
      return Promise.all([this.localization.ready]).then(() => this);
    }
    /**
     * @internal
     * @param options - options that will be merged to the global Checkout props
     * @returns props for a new UIElement
     */
    getPropsForComponent(options) {
      return { ...options };
    }
  }
  __publicField(Core, "version", "1.7.1");
  var n, l$1, t$1, u$2, i$1, r$1, o$1, e$1, f$2, c$1, s$1, a$1, h$1, p$1 = {}, v$1 = [], y$1 = /acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i, d$1 = Array.isArray;
  function w$1(n2, l2) {
    for (var t2 in l2) n2[t2] = l2[t2];
    return n2;
  }
  function g$1(n2) {
    n2 && n2.parentNode && n2.parentNode.removeChild(n2);
  }
  function _$1(l2, t2, u2) {
    var i2, r2, o2, e2 = {};
    for (o2 in t2) "key" == o2 ? i2 = t2[o2] : "ref" == o2 ? r2 = t2[o2] : e2[o2] = t2[o2];
    if (arguments.length > 2 && (e2.children = arguments.length > 3 ? n.call(arguments, 2) : u2), "function" == typeof l2 && null != l2.defaultProps) for (o2 in l2.defaultProps) void 0 === e2[o2] && (e2[o2] = l2.defaultProps[o2]);
    return m$1(l2, e2, i2, r2, null);
  }
  function m$1(n2, u2, i2, r2, o2) {
    var e2 = { type: n2, props: u2, key: i2, ref: r2, __k: null, __: null, __b: 0, __e: null, __c: null, constructor: void 0, __v: null == o2 ? ++t$1 : o2, __i: -1, __u: 0 };
    return null == o2 && null != l$1.vnode && l$1.vnode(e2), e2;
  }
  function b() {
    return { current: null };
  }
  function k$1(n2) {
    return n2.children;
  }
  function x$1(n2, l2) {
    this.props = n2, this.context = l2;
  }
  function S(n2, l2) {
    if (null == l2) return n2.__ ? S(n2.__, n2.__i + 1) : null;
    for (var t2; l2 < n2.__k.length; l2++) if (null != (t2 = n2.__k[l2]) && null != t2.__e) return t2.__e;
    return "function" == typeof n2.type ? S(n2) : null;
  }
  function C$1(n2) {
    var l2, t2;
    if (null != (n2 = n2.__) && null != n2.__c) {
      for (n2.__e = n2.__c.base = null, l2 = 0; l2 < n2.__k.length; l2++) if (null != (t2 = n2.__k[l2]) && null != t2.__e) {
        n2.__e = n2.__c.base = t2.__e;
        break;
      }
      return C$1(n2);
    }
  }
  function M$1(n2) {
    (!n2.__d && (n2.__d = true) && i$1.push(n2) && !$$1.__r++ || r$1 !== l$1.debounceRendering) && ((r$1 = l$1.debounceRendering) || o$1)($$1);
  }
  function $$1() {
    for (var n2, t2, u2, r2, o2, f2, c2, s2 = 1; i$1.length; ) i$1.length > s2 && i$1.sort(e$1), n2 = i$1.shift(), s2 = i$1.length, n2.__d && (u2 = void 0, o2 = (r2 = (t2 = n2).__v).__e, f2 = [], c2 = [], t2.__P && ((u2 = w$1({}, r2)).__v = r2.__v + 1, l$1.vnode && l$1.vnode(u2), O(t2.__P, u2, r2, t2.__n, t2.__P.namespaceURI, 32 & r2.__u ? [o2] : null, f2, null == o2 ? S(r2) : o2, !!(32 & r2.__u), c2), u2.__v = r2.__v, u2.__.__k[u2.__i] = u2, z$1(f2, u2, c2), u2.__e != o2 && C$1(u2)));
    $$1.__r = 0;
  }
  function I(n2, l2, t2, u2, i2, r2, o2, e2, f2, c2, s2) {
    var a2, h2, y2, d2, w2, g2, _2 = u2 && u2.__k || v$1, m2 = l2.length;
    for (f2 = P$1(t2, l2, _2, f2, m2), a2 = 0; a2 < m2; a2++) null != (y2 = t2.__k[a2]) && (h2 = -1 === y2.__i ? p$1 : _2[y2.__i] || p$1, y2.__i = a2, g2 = O(n2, y2, h2, i2, r2, o2, e2, f2, c2, s2), d2 = y2.__e, y2.ref && h2.ref != y2.ref && (h2.ref && q$2(h2.ref, null, y2), s2.push(y2.ref, y2.__c || d2, y2)), null == w2 && null != d2 && (w2 = d2), 4 & y2.__u || h2.__k === y2.__k ? f2 = A$2(y2, f2, n2) : "function" == typeof y2.type && void 0 !== g2 ? f2 = g2 : d2 && (f2 = d2.nextSibling), y2.__u &= -7);
    return t2.__e = w2, f2;
  }
  function P$1(n2, l2, t2, u2, i2) {
    var r2, o2, e2, f2, c2, s2 = t2.length, a2 = s2, h2 = 0;
    for (n2.__k = new Array(i2), r2 = 0; r2 < i2; r2++) null != (o2 = l2[r2]) && "boolean" != typeof o2 && "function" != typeof o2 ? (f2 = r2 + h2, (o2 = n2.__k[r2] = "string" == typeof o2 || "number" == typeof o2 || "bigint" == typeof o2 || o2.constructor == String ? m$1(null, o2, null, null, null) : d$1(o2) ? m$1(k$1, { children: o2 }, null, null, null) : void 0 === o2.constructor && o2.__b > 0 ? m$1(o2.type, o2.props, o2.key, o2.ref ? o2.ref : null, o2.__v) : o2).__ = n2, o2.__b = n2.__b + 1, e2 = null, -1 !== (c2 = o2.__i = L(o2, t2, f2, a2)) && (a2--, (e2 = t2[c2]) && (e2.__u |= 2)), null == e2 || null === e2.__v ? (-1 == c2 && (i2 > s2 ? h2-- : i2 < s2 && h2++), "function" != typeof o2.type && (o2.__u |= 4)) : c2 != f2 && (c2 == f2 - 1 ? h2-- : c2 == f2 + 1 ? h2++ : (c2 > f2 ? h2-- : h2++, o2.__u |= 4))) : n2.__k[r2] = null;
    if (a2) for (r2 = 0; r2 < s2; r2++) null != (e2 = t2[r2]) && 0 == (2 & e2.__u) && (e2.__e == u2 && (u2 = S(e2)), B$2(e2, e2));
    return u2;
  }
  function A$2(n2, l2, t2) {
    var u2, i2;
    if ("function" == typeof n2.type) {
      for (u2 = n2.__k, i2 = 0; u2 && i2 < u2.length; i2++) u2[i2] && (u2[i2].__ = n2, l2 = A$2(u2[i2], l2, t2));
      return l2;
    }
    n2.__e != l2 && (l2 && n2.type && !t2.contains(l2) && (l2 = S(n2)), t2.insertBefore(n2.__e, l2 || null), l2 = n2.__e);
    do {
      l2 = l2 && l2.nextSibling;
    } while (null != l2 && 8 == l2.nodeType);
    return l2;
  }
  function H$1(n2, l2) {
    return l2 = l2 || [], null == n2 || "boolean" == typeof n2 || (d$1(n2) ? n2.some(function(n3) {
      H$1(n3, l2);
    }) : l2.push(n2)), l2;
  }
  function L(n2, l2, t2, u2) {
    var i2, r2, o2 = n2.key, e2 = n2.type, f2 = l2[t2];
    if (null === f2 && null == n2.key || f2 && o2 == f2.key && e2 === f2.type && 0 == (2 & f2.__u)) return t2;
    if (u2 > (null != f2 && 0 == (2 & f2.__u) ? 1 : 0)) for (i2 = t2 - 1, r2 = t2 + 1; i2 >= 0 || r2 < l2.length; ) {
      if (i2 >= 0) {
        if ((f2 = l2[i2]) && 0 == (2 & f2.__u) && o2 == f2.key && e2 === f2.type) return i2;
        i2--;
      }
      if (r2 < l2.length) {
        if ((f2 = l2[r2]) && 0 == (2 & f2.__u) && o2 == f2.key && e2 === f2.type) return r2;
        r2++;
      }
    }
    return -1;
  }
  function T$2(n2, l2, t2) {
    "-" == l2[0] ? n2.setProperty(l2, null == t2 ? "" : t2) : n2[l2] = null == t2 ? "" : "number" != typeof t2 || y$1.test(l2) ? t2 : t2 + "px";
  }
  function j$2(n2, l2, t2, u2, i2) {
    var r2;
    n: if ("style" == l2) if ("string" == typeof t2) n2.style.cssText = t2;
    else {
      if ("string" == typeof u2 && (n2.style.cssText = u2 = ""), u2) for (l2 in u2) t2 && l2 in t2 || T$2(n2.style, l2, "");
      if (t2) for (l2 in t2) u2 && t2[l2] === u2[l2] || T$2(n2.style, l2, t2[l2]);
    }
    else if ("o" == l2[0] && "n" == l2[1]) r2 = l2 != (l2 = l2.replace(f$2, "$1")), l2 = l2.toLowerCase() in n2 || "onFocusOut" == l2 || "onFocusIn" == l2 ? l2.toLowerCase().slice(2) : l2.slice(2), n2.l || (n2.l = {}), n2.l[l2 + r2] = t2, t2 ? u2 ? t2.t = u2.t : (t2.t = c$1, n2.addEventListener(l2, r2 ? a$1 : s$1, r2)) : n2.removeEventListener(l2, r2 ? a$1 : s$1, r2);
    else {
      if ("http://www.w3.org/2000/svg" == i2) l2 = l2.replace(/xlink(H|:h)/, "h").replace(/sName$/, "s");
      else if ("width" != l2 && "height" != l2 && "href" != l2 && "list" != l2 && "form" != l2 && "tabIndex" != l2 && "download" != l2 && "rowSpan" != l2 && "colSpan" != l2 && "role" != l2 && "popover" != l2 && l2 in n2) try {
        n2[l2] = null == t2 ? "" : t2;
        break n;
      } catch (n3) {
      }
      "function" == typeof t2 || (null == t2 || false === t2 && "-" != l2[4] ? n2.removeAttribute(l2) : n2.setAttribute(l2, "popover" == l2 && 1 == t2 ? "" : t2));
    }
  }
  function F$2(n2) {
    return function(t2) {
      if (this.l) {
        var u2 = this.l[t2.type + n2];
        if (null == t2.u) t2.u = c$1++;
        else if (t2.u < u2.t) return;
        return u2(l$1.event ? l$1.event(t2) : t2);
      }
    };
  }
  function O(n2, t2, u2, i2, r2, o2, e2, f2, c2, s2) {
    var a2, h2, p2, v2, y2, _2, m2, b2, S2, C2, M2, $2, P2, A2, H2, L2, T2, j2 = t2.type;
    if (void 0 !== t2.constructor) return null;
    128 & u2.__u && (c2 = !!(32 & u2.__u), o2 = [f2 = t2.__e = u2.__e]), (a2 = l$1.__b) && a2(t2);
    n: if ("function" == typeof j2) try {
      if (b2 = t2.props, S2 = "prototype" in j2 && j2.prototype.render, C2 = (a2 = j2.contextType) && i2[a2.__c], M2 = a2 ? C2 ? C2.props.value : a2.__ : i2, u2.__c ? m2 = (h2 = t2.__c = u2.__c).__ = h2.__E : (S2 ? t2.__c = h2 = new j2(b2, M2) : (t2.__c = h2 = new x$1(b2, M2), h2.constructor = j2, h2.render = D$2), C2 && C2.sub(h2), h2.props = b2, h2.state || (h2.state = {}), h2.context = M2, h2.__n = i2, p2 = h2.__d = true, h2.__h = [], h2._sb = []), S2 && null == h2.__s && (h2.__s = h2.state), S2 && null != j2.getDerivedStateFromProps && (h2.__s == h2.state && (h2.__s = w$1({}, h2.__s)), w$1(h2.__s, j2.getDerivedStateFromProps(b2, h2.__s))), v2 = h2.props, y2 = h2.state, h2.__v = t2, p2) S2 && null == j2.getDerivedStateFromProps && null != h2.componentWillMount && h2.componentWillMount(), S2 && null != h2.componentDidMount && h2.__h.push(h2.componentDidMount);
      else {
        if (S2 && null == j2.getDerivedStateFromProps && b2 !== v2 && null != h2.componentWillReceiveProps && h2.componentWillReceiveProps(b2, M2), !h2.__e && (null != h2.shouldComponentUpdate && false === h2.shouldComponentUpdate(b2, h2.__s, M2) || t2.__v == u2.__v)) {
          for (t2.__v != u2.__v && (h2.props = b2, h2.state = h2.__s, h2.__d = false), t2.__e = u2.__e, t2.__k = u2.__k, t2.__k.some(function(n3) {
            n3 && (n3.__ = t2);
          }), $2 = 0; $2 < h2._sb.length; $2++) h2.__h.push(h2._sb[$2]);
          h2._sb = [], h2.__h.length && e2.push(h2);
          break n;
        }
        null != h2.componentWillUpdate && h2.componentWillUpdate(b2, h2.__s, M2), S2 && null != h2.componentDidUpdate && h2.__h.push(function() {
          h2.componentDidUpdate(v2, y2, _2);
        });
      }
      if (h2.context = M2, h2.props = b2, h2.__P = n2, h2.__e = false, P2 = l$1.__r, A2 = 0, S2) {
        for (h2.state = h2.__s, h2.__d = false, P2 && P2(t2), a2 = h2.render(h2.props, h2.state, h2.context), H2 = 0; H2 < h2._sb.length; H2++) h2.__h.push(h2._sb[H2]);
        h2._sb = [];
      } else do {
        h2.__d = false, P2 && P2(t2), a2 = h2.render(h2.props, h2.state, h2.context), h2.state = h2.__s;
      } while (h2.__d && ++A2 < 25);
      h2.state = h2.__s, null != h2.getChildContext && (i2 = w$1(w$1({}, i2), h2.getChildContext())), S2 && !p2 && null != h2.getSnapshotBeforeUpdate && (_2 = h2.getSnapshotBeforeUpdate(v2, y2)), L2 = a2, null != a2 && a2.type === k$1 && null == a2.key && (L2 = N$1(a2.props.children)), f2 = I(n2, d$1(L2) ? L2 : [L2], t2, u2, i2, r2, o2, e2, f2, c2, s2), h2.base = t2.__e, t2.__u &= -161, h2.__h.length && e2.push(h2), m2 && (h2.__E = h2.__ = null);
    } catch (n3) {
      if (t2.__v = null, c2 || null != o2) if (n3.then) {
        for (t2.__u |= c2 ? 160 : 128; f2 && 8 == f2.nodeType && f2.nextSibling; ) f2 = f2.nextSibling;
        o2[o2.indexOf(f2)] = null, t2.__e = f2;
      } else for (T2 = o2.length; T2--; ) g$1(o2[T2]);
      else t2.__e = u2.__e, t2.__k = u2.__k;
      l$1.__e(n3, t2, u2);
    }
    else null == o2 && t2.__v == u2.__v ? (t2.__k = u2.__k, t2.__e = u2.__e) : f2 = t2.__e = V$1(u2.__e, t2, u2, i2, r2, o2, e2, c2, s2);
    return (a2 = l$1.diffed) && a2(t2), 128 & t2.__u ? void 0 : f2;
  }
  function z$1(n2, t2, u2) {
    for (var i2 = 0; i2 < u2.length; i2++) q$2(u2[i2], u2[++i2], u2[++i2]);
    l$1.__c && l$1.__c(t2, n2), n2.some(function(t3) {
      try {
        n2 = t3.__h, t3.__h = [], n2.some(function(n3) {
          n3.call(t3);
        });
      } catch (n3) {
        l$1.__e(n3, t3.__v);
      }
    });
  }
  function N$1(n2) {
    return "object" != typeof n2 || null == n2 ? n2 : d$1(n2) ? n2.map(N$1) : w$1({}, n2);
  }
  function V$1(t2, u2, i2, r2, o2, e2, f2, c2, s2) {
    var a2, h2, v2, y2, w2, _2, m2, b2 = i2.props, k2 = u2.props, x2 = u2.type;
    if ("svg" == x2 ? o2 = "http://www.w3.org/2000/svg" : "math" == x2 ? o2 = "http://www.w3.org/1998/Math/MathML" : o2 || (o2 = "http://www.w3.org/1999/xhtml"), null != e2) {
      for (a2 = 0; a2 < e2.length; a2++) if ((w2 = e2[a2]) && "setAttribute" in w2 == !!x2 && (x2 ? w2.localName == x2 : 3 == w2.nodeType)) {
        t2 = w2, e2[a2] = null;
        break;
      }
    }
    if (null == t2) {
      if (null == x2) return document.createTextNode(k2);
      t2 = document.createElementNS(o2, x2, k2.is && k2), c2 && (l$1.__m && l$1.__m(u2, e2), c2 = false), e2 = null;
    }
    if (null === x2) b2 === k2 || c2 && t2.data === k2 || (t2.data = k2);
    else {
      if (e2 = e2 && n.call(t2.childNodes), b2 = i2.props || p$1, !c2 && null != e2) for (b2 = {}, a2 = 0; a2 < t2.attributes.length; a2++) b2[(w2 = t2.attributes[a2]).name] = w2.value;
      for (a2 in b2) if (w2 = b2[a2], "children" == a2) ;
      else if ("dangerouslySetInnerHTML" == a2) v2 = w2;
      else if (!(a2 in k2)) {
        if ("value" == a2 && "defaultValue" in k2 || "checked" == a2 && "defaultChecked" in k2) continue;
        j$2(t2, a2, null, w2, o2);
      }
      for (a2 in k2) w2 = k2[a2], "children" == a2 ? y2 = w2 : "dangerouslySetInnerHTML" == a2 ? h2 = w2 : "value" == a2 ? _2 = w2 : "checked" == a2 ? m2 = w2 : c2 && "function" != typeof w2 || b2[a2] === w2 || j$2(t2, a2, w2, b2[a2], o2);
      if (h2) c2 || v2 && (h2.__html === v2.__html || h2.__html === t2.innerHTML) || (t2.innerHTML = h2.__html), u2.__k = [];
      else if (v2 && (t2.innerHTML = ""), I("template" === u2.type ? t2.content : t2, d$1(y2) ? y2 : [y2], u2, i2, r2, "foreignObject" == x2 ? "http://www.w3.org/1999/xhtml" : o2, e2, f2, e2 ? e2[0] : i2.__k && S(i2, 0), c2, s2), null != e2) for (a2 = e2.length; a2--; ) g$1(e2[a2]);
      c2 || (a2 = "value", "progress" == x2 && null == _2 ? t2.removeAttribute("value") : void 0 !== _2 && (_2 !== t2[a2] || "progress" == x2 && !_2 || "option" == x2 && _2 !== b2[a2]) && j$2(t2, a2, _2, b2[a2], o2), a2 = "checked", void 0 !== m2 && m2 !== t2[a2] && j$2(t2, a2, m2, b2[a2], o2));
    }
    return t2;
  }
  function q$2(n2, t2, u2) {
    try {
      if ("function" == typeof n2) {
        var i2 = "function" == typeof n2.__u;
        i2 && n2.__u(), i2 && null == t2 || (n2.__u = n2(t2));
      } else n2.current = t2;
    } catch (n3) {
      l$1.__e(n3, u2);
    }
  }
  function B$2(n2, t2, u2) {
    var i2, r2;
    if (l$1.unmount && l$1.unmount(n2), (i2 = n2.ref) && (i2.current && i2.current !== n2.__e || q$2(i2, null, t2)), null != (i2 = n2.__c)) {
      if (i2.componentWillUnmount) try {
        i2.componentWillUnmount();
      } catch (n3) {
        l$1.__e(n3, t2);
      }
      i2.base = i2.__P = null;
    }
    if (i2 = n2.__k) for (r2 = 0; r2 < i2.length; r2++) i2[r2] && B$2(i2[r2], t2, u2 || "function" != typeof n2.type);
    u2 || g$1(n2.__e), n2.__c = n2.__ = n2.__e = void 0;
  }
  function D$2(n2, l2, t2) {
    return this.constructor(n2, t2);
  }
  function E$1(t2, u2, i2) {
    var r2, o2, e2, f2;
    u2 == document && (u2 = document.documentElement), l$1.__ && l$1.__(t2, u2), o2 = (r2 = false) ? null : u2.__k, e2 = [], f2 = [], O(u2, t2 = u2.__k = _$1(k$1, null, [t2]), o2 || p$1, p$1, u2.namespaceURI, o2 ? null : u2.firstChild ? n.call(u2.childNodes) : null, e2, o2 ? o2.__e : u2.firstChild, r2, f2), z$1(e2, t2, f2);
  }
  function J$1(l2, t2, u2) {
    var i2, r2, o2, e2, f2 = w$1({}, l2.props);
    for (o2 in l2.type && l2.type.defaultProps && (e2 = l2.type.defaultProps), t2) "key" == o2 ? i2 = t2[o2] : "ref" == o2 ? r2 = t2[o2] : f2[o2] = void 0 === t2[o2] && void 0 !== e2 ? e2[o2] : t2[o2];
    return arguments.length > 2 && (f2.children = arguments.length > 3 ? n.call(arguments, 2) : u2), m$1(l2.type, f2, i2 || l2.key, r2 || l2.ref, null);
  }
  function K$1(n2) {
    function l2(n3) {
      var t2, u2;
      return this.getChildContext || (t2 = /* @__PURE__ */ new Set(), (u2 = {})[l2.__c] = this, this.getChildContext = function() {
        return u2;
      }, this.componentWillUnmount = function() {
        t2 = null;
      }, this.shouldComponentUpdate = function(n4) {
        this.props.value !== n4.value && t2.forEach(function(n5) {
          n5.__e = true, M$1(n5);
        });
      }, this.sub = function(n4) {
        t2.add(n4);
        var l3 = n4.componentWillUnmount;
        n4.componentWillUnmount = function() {
          t2 && t2.delete(n4), l3 && l3.call(n4);
        };
      }), n3.children;
    }
    return l2.__c = "__cC" + h$1++, l2.__ = n2, l2.Provider = l2.__l = (l2.Consumer = function(n3, l3) {
      return n3.children(l3);
    }).contextType = l2, l2;
  }
  n = v$1.slice, l$1 = { __e: function(n2, l2, t2, u2) {
    for (var i2, r2, o2; l2 = l2.__; ) if ((i2 = l2.__c) && !i2.__) try {
      if ((r2 = i2.constructor) && null != r2.getDerivedStateFromError && (i2.setState(r2.getDerivedStateFromError(n2)), o2 = i2.__d), null != i2.componentDidCatch && (i2.componentDidCatch(n2, u2 || {}), o2 = i2.__d), o2) return i2.__E = i2;
    } catch (l3) {
      n2 = l3;
    }
    throw n2;
  } }, t$1 = 0, u$2 = function(n2) {
    return null != n2 && null == n2.constructor;
  }, x$1.prototype.setState = function(n2, l2) {
    var t2;
    t2 = null != this.__s && this.__s !== this.state ? this.__s : this.__s = w$1({}, this.state), "function" == typeof n2 && (n2 = n2(w$1({}, t2), this.props)), n2 && w$1(t2, n2), null != n2 && this.__v && (l2 && this._sb.push(l2), M$1(this));
  }, x$1.prototype.forceUpdate = function(n2) {
    this.__v && (this.__e = true, n2 && this.__h.push(n2), M$1(this));
  }, x$1.prototype.render = k$1, i$1 = [], o$1 = "function" == typeof Promise ? Promise.prototype.then.bind(Promise.resolve()) : setTimeout, e$1 = function(n2, l2) {
    return n2.__v.__b - l2.__v.__b;
  }, $$1.__r = 0, f$2 = /(PointerCapture)$|Capture$/i, c$1 = 0, s$1 = F$2(false), a$1 = F$2(true), h$1 = 0;
  var f$1 = 0;
  function u$1(e2, t2, n2, o2, i2, u2) {
    t2 || (t2 = {});
    var a2, c2, p2 = t2;
    if ("ref" in p2) for (c2 in p2 = {}, t2) "ref" == c2 ? a2 = t2[c2] : p2[c2] = t2[c2];
    var l2 = { type: e2, props: p2, key: n2, ref: a2, __k: null, __: null, __b: 0, __e: null, __c: null, constructor: void 0, __v: --f$1, __i: -1, __u: 0, __source: i2, __self: u2 };
    if ("function" == typeof e2 && (a2 = e2.defaultProps)) for (c2 in a2) void 0 === p2[c2] && (p2[c2] = a2[c2]);
    return l$1.vnode && l$1.vnode(l2), l2;
  }
  var t, r, u, i, o = 0, f = [], c = l$1, e = c.__b, a = c.__r, v = c.diffed, l = c.__c, m = c.unmount, s = c.__;
  function p(n2, t2) {
    c.__h && c.__h(r, n2, o || t2), o = 0;
    var u2 = r.__H || (r.__H = { __: [], __h: [] });
    return n2 >= u2.__.length && u2.__.push({}), u2.__[n2];
  }
  function d(n2) {
    return o = 1, h(D$1, n2);
  }
  function h(n2, u2, i2) {
    var o2 = p(t++, 2);
    if (o2.t = n2, !o2.__c && (o2.__ = [i2 ? i2(u2) : D$1(void 0, u2), function(n3) {
      var t2 = o2.__N ? o2.__N[0] : o2.__[0], r2 = o2.t(t2, n3);
      t2 !== r2 && (o2.__N = [r2, o2.__[1]], o2.__c.setState({}));
    }], o2.__c = r, !r.__f)) {
      var f2 = function(n3, t2, r2) {
        if (!o2.__c.__H) return true;
        var u3 = o2.__c.__H.__.filter(function(n4) {
          return !!n4.__c;
        });
        if (u3.every(function(n4) {
          return !n4.__N;
        })) return !c2 || c2.call(this, n3, t2, r2);
        var i3 = o2.__c.props !== n3;
        return u3.forEach(function(n4) {
          if (n4.__N) {
            var t3 = n4.__[0];
            n4.__ = n4.__N, n4.__N = void 0, t3 !== n4.__[0] && (i3 = true);
          }
        }), c2 && c2.call(this, n3, t2, r2) || i3;
      };
      r.__f = true;
      var c2 = r.shouldComponentUpdate, e2 = r.componentWillUpdate;
      r.componentWillUpdate = function(n3, t2, r2) {
        if (this.__e) {
          var u3 = c2;
          c2 = void 0, f2(n3, t2, r2), c2 = u3;
        }
        e2 && e2.call(this, n3, t2, r2);
      }, r.shouldComponentUpdate = f2;
    }
    return o2.__N || o2.__;
  }
  function y(n2, u2) {
    var i2 = p(t++, 3);
    !c.__s && C(i2.__H, u2) && (i2.__ = n2, i2.u = u2, r.__H.__h.push(i2));
  }
  function _(n2, u2) {
    var i2 = p(t++, 4);
    !c.__s && C(i2.__H, u2) && (i2.__ = n2, i2.u = u2, r.__h.push(i2));
  }
  function A$1(n2) {
    return o = 5, T$1(function() {
      return { current: n2 };
    }, []);
  }
  function F$1(n2, t2, r2) {
    o = 6, _(function() {
      if ("function" == typeof n2) {
        var r3 = n2(t2());
        return function() {
          n2(null), r3 && "function" == typeof r3 && r3();
        };
      }
      if (n2) return n2.current = t2(), function() {
        return n2.current = null;
      };
    }, null == r2 ? r2 : r2.concat(n2));
  }
  function T$1(n2, r2) {
    var u2 = p(t++, 7);
    return C(u2.__H, r2) && (u2.__ = n2(), u2.__H = r2, u2.__h = n2), u2.__;
  }
  function q$1(n2, t2) {
    return o = 8, T$1(function() {
      return n2;
    }, t2);
  }
  function x(n2) {
    var u2 = r.context[n2.__c], i2 = p(t++, 9);
    return i2.c = n2, u2 ? (null == i2.__ && (i2.__ = true, u2.sub(r)), u2.props.value) : n2.__;
  }
  function j$1() {
    for (var n2; n2 = f.shift(); ) if (n2.__P && n2.__H) try {
      n2.__H.__h.forEach(z), n2.__H.__h.forEach(B$1), n2.__H.__h = [];
    } catch (t2) {
      n2.__H.__h = [], c.__e(t2, n2.__v);
    }
  }
  c.__b = function(n2) {
    r = null, e && e(n2);
  }, c.__ = function(n2, t2) {
    n2 && t2.__k && t2.__k.__m && (n2.__m = t2.__k.__m), s && s(n2, t2);
  }, c.__r = function(n2) {
    a && a(n2), t = 0;
    var i2 = (r = n2.__c).__H;
    i2 && (u === r ? (i2.__h = [], r.__h = [], i2.__.forEach(function(n3) {
      n3.__N && (n3.__ = n3.__N), n3.u = n3.__N = void 0;
    })) : (i2.__h.forEach(z), i2.__h.forEach(B$1), i2.__h = [], t = 0)), u = r;
  }, c.diffed = function(n2) {
    v && v(n2);
    var t2 = n2.__c;
    t2 && t2.__H && (t2.__H.__h.length && (1 !== f.push(t2) && i === c.requestAnimationFrame || ((i = c.requestAnimationFrame) || w)(j$1)), t2.__H.__.forEach(function(n3) {
      n3.u && (n3.__H = n3.u), n3.u = void 0;
    })), u = r = null;
  }, c.__c = function(n2, t2) {
    t2.some(function(n3) {
      try {
        n3.__h.forEach(z), n3.__h = n3.__h.filter(function(n4) {
          return !n4.__ || B$1(n4);
        });
      } catch (r2) {
        t2.some(function(n4) {
          n4.__h && (n4.__h = []);
        }), t2 = [], c.__e(r2, n3.__v);
      }
    }), l && l(n2, t2);
  }, c.unmount = function(n2) {
    m && m(n2);
    var t2, r2 = n2.__c;
    r2 && r2.__H && (r2.__H.__.forEach(function(n3) {
      try {
        z(n3);
      } catch (n4) {
        t2 = n4;
      }
    }), r2.__H = void 0, t2 && c.__e(t2, r2.__v));
  };
  var k = "function" == typeof requestAnimationFrame;
  function w(n2) {
    var t2, r2 = function() {
      clearTimeout(u2), k && cancelAnimationFrame(t2), setTimeout(n2);
    }, u2 = setTimeout(r2, 100);
    k && (t2 = requestAnimationFrame(r2));
  }
  function z(n2) {
    var t2 = r, u2 = n2.__c;
    "function" == typeof u2 && (n2.__c = void 0, u2()), r = t2;
  }
  function B$1(n2) {
    var t2 = r;
    n2.__c = n2.__(), r = t2;
  }
  function C(n2, t2) {
    return !n2 || n2.length !== t2.length || t2.some(function(t3, r2) {
      return t3 !== n2[r2];
    });
  }
  function D$1(n2, t2) {
    return "function" == typeof t2 ? t2(n2) : t2;
  }
  const DEFAULT_TYPOGRAPHY_CLASSNAME = "adyen-pe-typography";
  function getDefaultExportFromCjs(x2) {
    return x2 && x2.__esModule && Object.prototype.hasOwnProperty.call(x2, "default") ? x2["default"] : x2;
  }
  var classnames = { exports: {} };
  /*!
  	Copyright (c) 2018 Jed Watson.
  	Licensed under the MIT License (MIT), see
  	http://jedwatson.github.io/classnames
  */
  var hasRequiredClassnames;
  function requireClassnames() {
    if (hasRequiredClassnames) return classnames.exports;
    hasRequiredClassnames = 1;
    (function(module2) {
      (function() {
        var hasOwn = {}.hasOwnProperty;
        function classNames() {
          var classes2 = "";
          for (var i2 = 0; i2 < arguments.length; i2++) {
            var arg = arguments[i2];
            if (arg) {
              classes2 = appendClass(classes2, parseValue(arg));
            }
          }
          return classes2;
        }
        function parseValue(arg) {
          if (typeof arg === "string" || typeof arg === "number") {
            return arg;
          }
          if (typeof arg !== "object") {
            return "";
          }
          if (Array.isArray(arg)) {
            return classNames.apply(null, arg);
          }
          if (arg.toString !== Object.prototype.toString && !arg.toString.toString().includes("[native code]")) {
            return arg.toString();
          }
          var classes2 = "";
          for (var key in arg) {
            if (hasOwn.call(arg, key) && arg[key]) {
              classes2 = appendClass(classes2, key);
            }
          }
          return classes2;
        }
        function appendClass(value2, newClass) {
          if (!newClass) {
            return value2;
          }
          if (value2) {
            return value2 + " " + newClass;
          }
          return value2 + newClass;
        }
        if (module2.exports) {
          classNames.default = classNames;
          module2.exports = classNames;
        } else {
          window.classNames = classNames;
        }
      })();
    })(classnames);
    return classnames.exports;
  }
  var classnamesExports = requireClassnames();
  const cx = /* @__PURE__ */ getDefaultExportFromCjs(classnamesExports);
  var TypographyVariant = /* @__PURE__ */ ((TypographyVariant2) => {
    TypographyVariant2["CAPTION"] = "caption";
    TypographyVariant2["BODY"] = "body";
    TypographyVariant2["SUBTITLE"] = "subtitle";
    TypographyVariant2["TITLE"] = "title";
    return TypographyVariant2;
  })(TypographyVariant || {});
  var TypographyModifier = /* @__PURE__ */ ((TypographyModifier2) => {
    TypographyModifier2["WIDE"] = "wide";
    TypographyModifier2["STRONGER"] = "stronger";
    TypographyModifier2["STRONGER_WIDE"] = "stronger-wide";
    TypographyModifier2["STRONGEST"] = "strongest";
    TypographyModifier2["STRONGEST_WIDE"] = "strongest-wide";
    TypographyModifier2["MEDIUM"] = "m";
    TypographyModifier2["LARGE"] = "l";
    TypographyModifier2["MOBILE"] = "mobile";
    return TypographyModifier2;
  })(TypographyModifier || {});
  var TypographyElement = /* @__PURE__ */ ((TypographyElement2) => {
    TypographyElement2["H1"] = "h1";
    TypographyElement2["H2"] = "h2";
    TypographyElement2["H3"] = "h3";
    TypographyElement2["H4"] = "h4";
    TypographyElement2["H5"] = "h5";
    TypographyElement2["H6"] = "h6";
    TypographyElement2["DIV"] = "div";
    TypographyElement2["PARAGRAPH"] = "p";
    TypographyElement2["SPAN"] = "span";
    return TypographyElement2;
  })(TypographyElement || {});
  function g(n2, t2) {
    for (var e2 in t2) n2[e2] = t2[e2];
    return n2;
  }
  function E(n2, t2) {
    for (var e2 in n2) if ("__source" !== e2 && !(e2 in t2)) return true;
    for (var r2 in t2) if ("__source" !== r2 && n2[r2] !== t2[r2]) return true;
    return false;
  }
  function N(n2, t2) {
    this.props = n2, this.context = t2;
  }
  function M(n2, e2) {
    function r2(n3) {
      var t2 = this.props.ref, r3 = t2 == n3.ref;
      return !r3 && t2 && (t2.call ? t2(null) : t2.current = null), e2 ? !e2(this.props, n3) || !r3 : E(this.props, n3);
    }
    function u2(e3) {
      return this.shouldComponentUpdate = r2, _$1(n2, e3);
    }
    return u2.displayName = "Memo(" + (n2.displayName || n2.name) + ")", u2.prototype.isReactComponent = true, u2.__f = true, u2;
  }
  (N.prototype = new x$1()).isPureReactComponent = true, N.prototype.shouldComponentUpdate = function(n2, t2) {
    return E(this.props, n2) || E(this.state, t2);
  };
  var T = l$1.__b;
  l$1.__b = function(n2) {
    n2.type && n2.type.__f && n2.ref && (n2.props.ref = n2.ref, n2.ref = null), T && T(n2);
  };
  var A = "undefined" != typeof Symbol && Symbol.for && Symbol.for("react.forward_ref") || 3911;
  function D(n2) {
    function t2(t3) {
      var e2 = g({}, t3);
      return delete e2.ref, n2(e2, t3.ref || null);
    }
    return t2.$$typeof = A, t2.render = t2, t2.prototype.isReactComponent = t2.__f = true, t2.displayName = "ForwardRef(" + (n2.displayName || n2.name) + ")", t2;
  }
  var F = l$1.__e;
  l$1.__e = function(n2, t2, e2, r2) {
    if (n2.then) {
      for (var u2, o2 = t2; o2 = o2.__; ) if ((u2 = o2.__c) && u2.__c) return null == t2.__e && (t2.__e = e2.__e, t2.__k = e2.__k), u2.__c(n2, t2);
    }
    F(n2, t2, e2, r2);
  };
  var U = l$1.unmount;
  function V(n2, t2, e2) {
    return n2 && (n2.__c && n2.__c.__H && (n2.__c.__H.__.forEach(function(n3) {
      "function" == typeof n3.__c && n3.__c();
    }), n2.__c.__H = null), null != (n2 = g({}, n2)).__c && (n2.__c.__P === e2 && (n2.__c.__P = t2), n2.__c = null), n2.__k = n2.__k && n2.__k.map(function(n3) {
      return V(n3, t2, e2);
    })), n2;
  }
  function W(n2, t2, e2) {
    return n2 && e2 && (n2.__v = null, n2.__k = n2.__k && n2.__k.map(function(n3) {
      return W(n3, t2, e2);
    }), n2.__c && n2.__c.__P === t2 && (n2.__e && e2.appendChild(n2.__e), n2.__c.__e = true, n2.__c.__P = e2)), n2;
  }
  function P() {
    this.__u = 0, this.o = null, this.__b = null;
  }
  function j(n2) {
    var t2 = n2.__.__c;
    return t2 && t2.__a && t2.__a(n2);
  }
  function B() {
    this.i = null, this.l = null;
  }
  l$1.unmount = function(n2) {
    var t2 = n2.__c;
    t2 && t2.__R && t2.__R(), t2 && 32 & n2.__u && (n2.type = null), U && U(n2);
  }, (P.prototype = new x$1()).__c = function(n2, t2) {
    var e2 = t2.__c, r2 = this;
    null == r2.o && (r2.o = []), r2.o.push(e2);
    var u2 = j(r2.__v), o2 = false, i2 = function() {
      o2 || (o2 = true, e2.__R = null, u2 ? u2(c2) : c2());
    };
    e2.__R = i2;
    var c2 = function() {
      if (!--r2.__u) {
        if (r2.state.__a) {
          var n3 = r2.state.__a;
          r2.__v.__k[0] = W(n3, n3.__c.__P, n3.__c.__O);
        }
        var t3;
        for (r2.setState({ __a: r2.__b = null }); t3 = r2.o.pop(); ) t3.forceUpdate();
      }
    };
    r2.__u++ || 32 & t2.__u || r2.setState({ __a: r2.__b = r2.__v.__k[0] }), n2.then(i2, i2);
  }, P.prototype.componentWillUnmount = function() {
    this.o = [];
  }, P.prototype.render = function(n2, e2) {
    if (this.__b) {
      if (this.__v.__k) {
        var r2 = document.createElement("div"), o2 = this.__v.__k[0].__c;
        this.__v.__k[0] = V(this.__b, r2, o2.__O = o2.__P);
      }
      this.__b = null;
    }
    var i2 = e2.__a && _$1(k$1, null, n2.fallback);
    return i2 && (i2.__u &= -33), [_$1(k$1, null, e2.__a ? null : n2.children), i2];
  };
  var H = function(n2, t2, e2) {
    if (++e2[1] === e2[0] && n2.l.delete(t2), n2.props.revealOrder && ("t" !== n2.props.revealOrder[0] || !n2.l.size)) for (e2 = n2.i; e2; ) {
      for (; e2.length > 3; ) e2.pop()();
      if (e2[1] < e2[0]) break;
      n2.i = e2 = e2[2];
    }
  };
  function Z(n2) {
    return this.getChildContext = function() {
      return n2.context;
    }, n2.children;
  }
  function Y(n2) {
    var e2 = this, r2 = n2.h;
    e2.componentWillUnmount = function() {
      E$1(null, e2.v), e2.v = null, e2.h = null;
    }, e2.h && e2.h !== r2 && e2.componentWillUnmount(), e2.v || (e2.h = r2, e2.v = { nodeType: 1, parentNode: r2, childNodes: [], contains: function() {
      return true;
    }, appendChild: function(n3) {
      this.childNodes.push(n3), e2.h.appendChild(n3);
    }, insertBefore: function(n3, t2) {
      this.childNodes.push(n3), e2.h.insertBefore(n3, t2);
    }, removeChild: function(n3) {
      this.childNodes.splice(this.childNodes.indexOf(n3) >>> 1, 1), e2.h.removeChild(n3);
    } }), E$1(_$1(Z, { context: e2.context }, n2.__v), e2.v);
  }
  function $(n2, e2) {
    var r2 = _$1(Y, { __v: n2, h: e2 });
    return r2.containerInfo = e2, r2;
  }
  (B.prototype = new x$1()).__a = function(n2) {
    var t2 = this, e2 = j(t2.__v), r2 = t2.l.get(n2);
    return r2[0]++, function(u2) {
      var o2 = function() {
        t2.props.revealOrder ? (r2.push(u2), H(t2, n2, r2)) : u2();
      };
      e2 ? e2(o2) : o2();
    };
  }, B.prototype.render = function(n2) {
    this.i = null, this.l = /* @__PURE__ */ new Map();
    var t2 = H$1(n2.children);
    n2.revealOrder && "b" === n2.revealOrder[0] && t2.reverse();
    for (var e2 = t2.length; e2--; ) this.l.set(t2[e2], this.i = [1, 0, this.i]);
    return n2.children;
  }, B.prototype.componentDidUpdate = B.prototype.componentDidMount = function() {
    var n2 = this;
    this.l.forEach(function(t2, e2) {
      H(n2, e2, t2);
    });
  };
  var q = "undefined" != typeof Symbol && Symbol.for && Symbol.for("react.element") || 60103, G = /^(?:accent|alignment|arabic|baseline|cap|clip(?!PathU)|color|dominant|fill|flood|font|glyph(?!R)|horiz|image(!S)|letter|lighting|marker(?!H|W|U)|overline|paint|pointer|shape|stop|strikethrough|stroke|text(?!L)|transform|underline|unicode|units|v|vector|vert|word|writing|x(?!C))[A-Z]/, J = /^on(Ani|Tra|Tou|BeforeInp|Compo)/, K = /[A-Z0-9]/g, Q = "undefined" != typeof document, X = function(n2) {
    return ("undefined" != typeof Symbol && "symbol" == typeof Symbol() ? /fil|che|rad/ : /fil|che|ra/).test(n2);
  };
  x$1.prototype.isReactComponent = {}, ["componentWillMount", "componentWillReceiveProps", "componentWillUpdate"].forEach(function(t2) {
    Object.defineProperty(x$1.prototype, t2, { configurable: true, get: function() {
      return this["UNSAFE_" + t2];
    }, set: function(n2) {
      Object.defineProperty(this, t2, { configurable: true, writable: true, value: n2 });
    } });
  });
  var en = l$1.event;
  function rn() {
  }
  function un() {
    return this.cancelBubble;
  }
  function on() {
    return this.defaultPrevented;
  }
  l$1.event = function(n2) {
    return en && (n2 = en(n2)), n2.persist = rn, n2.isPropagationStopped = un, n2.isDefaultPrevented = on, n2.nativeEvent = n2;
  };
  var ln = { enumerable: false, configurable: true, get: function() {
    return this.class;
  } }, fn = l$1.vnode;
  l$1.vnode = function(n2) {
    "string" == typeof n2.type && function(n3) {
      var t2 = n3.props, e2 = n3.type, u2 = {}, o2 = -1 === e2.indexOf("-");
      for (var i2 in t2) {
        var c2 = t2[i2];
        if (!("value" === i2 && "defaultValue" in t2 && null == c2 || Q && "children" === i2 && "noscript" === e2 || "class" === i2 || "className" === i2)) {
          var l2 = i2.toLowerCase();
          "defaultValue" === i2 && "value" in t2 && null == t2.value ? i2 = "value" : "download" === i2 && true === c2 ? c2 = "" : "translate" === l2 && "no" === c2 ? c2 = false : "o" === l2[0] && "n" === l2[1] ? "ondoubleclick" === l2 ? i2 = "ondblclick" : "onchange" !== l2 || "input" !== e2 && "textarea" !== e2 || X(t2.type) ? "onfocus" === l2 ? i2 = "onfocusin" : "onblur" === l2 ? i2 = "onfocusout" : J.test(i2) && (i2 = l2) : l2 = i2 = "oninput" : o2 && G.test(i2) ? i2 = i2.replace(K, "-$&").toLowerCase() : null === c2 && (c2 = void 0), "oninput" === l2 && u2[i2 = l2] && (i2 = "oninputCapture"), u2[i2] = c2;
        }
      }
      "select" == e2 && u2.multiple && Array.isArray(u2.value) && (u2.value = H$1(t2.children).forEach(function(n4) {
        n4.props.selected = -1 != u2.value.indexOf(n4.props.value);
      })), "select" == e2 && null != u2.defaultValue && (u2.value = H$1(t2.children).forEach(function(n4) {
        n4.props.selected = u2.multiple ? -1 != u2.defaultValue.indexOf(n4.props.value) : u2.defaultValue == n4.props.value;
      })), t2.class && !t2.className ? (u2.class = t2.class, Object.defineProperty(u2, "className", ln)) : (t2.className && !t2.class || t2.class && t2.className) && (u2.class = u2.className = t2.className), n3.props = u2;
    }(n2), n2.$$typeof = q, fn && fn(n2);
  };
  var an = l$1.__r;
  l$1.__r = function(n2) {
    an && an(n2), n2.__c;
  };
  var sn = l$1.diffed;
  l$1.diffed = function(n2) {
    sn && sn(n2);
    var t2 = n2.props, e2 = n2.__e;
    null != e2 && "textarea" === n2.type && "value" in t2 && t2.value !== e2.value && (e2.value = null == t2.value ? "" : t2.value);
  };
  function Typography({ el, className, stronger, strongest, variant, medium, large, testId, wide, children }) {
    const Tag2 = el || "p";
    const conditionalClasses = T$1(
      () => ({
        // Caption
        [`${DEFAULT_TYPOGRAPHY_CLASSNAME}--${TypographyVariant.CAPTION}`]: variant === TypographyVariant.CAPTION,
        [`${DEFAULT_TYPOGRAPHY_CLASSNAME}--${TypographyVariant.CAPTION}-${TypographyModifier.WIDE}`]: variant === TypographyVariant.CAPTION && wide,
        [`${DEFAULT_TYPOGRAPHY_CLASSNAME}--${TypographyVariant.CAPTION}-${TypographyModifier.STRONGER}`]: variant === TypographyVariant.CAPTION && stronger,
        // Body
        [`${DEFAULT_TYPOGRAPHY_CLASSNAME}--${TypographyVariant.BODY}`]: variant === TypographyVariant.BODY,
        [`${DEFAULT_TYPOGRAPHY_CLASSNAME}--${TypographyVariant.BODY}-${TypographyModifier.WIDE}`]: variant === TypographyVariant.BODY && wide,
        [`${DEFAULT_TYPOGRAPHY_CLASSNAME}--${TypographyVariant.BODY}-${TypographyModifier.STRONGER}`]: variant === TypographyVariant.BODY && stronger,
        [`${DEFAULT_TYPOGRAPHY_CLASSNAME}--${TypographyVariant.BODY}-${TypographyModifier.STRONGEST}`]: variant === TypographyVariant.BODY && strongest,
        // Subtitle
        [`${DEFAULT_TYPOGRAPHY_CLASSNAME}--${TypographyVariant.SUBTITLE}`]: variant === TypographyVariant.SUBTITLE,
        [`${DEFAULT_TYPOGRAPHY_CLASSNAME}--${TypographyVariant.SUBTITLE}-${TypographyModifier.STRONGER}`]: variant === TypographyVariant.SUBTITLE && stronger,
        // Title
        [`${DEFAULT_TYPOGRAPHY_CLASSNAME}--${TypographyVariant.TITLE}`]: variant === TypographyVariant.TITLE && !medium && !large,
        [`${DEFAULT_TYPOGRAPHY_CLASSNAME}--${TypographyVariant.TITLE}-${TypographyModifier.MEDIUM}`]: variant === TypographyVariant.TITLE && medium,
        [`${DEFAULT_TYPOGRAPHY_CLASSNAME}--${TypographyVariant.TITLE}-${TypographyModifier.LARGE}`]: variant === TypographyVariant.TITLE && large
      }),
      [variant, wide, stronger, medium, large, strongest]
    );
    return /* @__PURE__ */ u$1(Tag2, { className: cx([`${DEFAULT_TYPOGRAPHY_CLASSNAME}`, conditionalClasses, className]), "data-testid": testId, children });
  }
  const Typography$1 = M(Typography);
  const CoreContext = K$1({
    i18n: new Localization().i18n,
    loadingContext: "",
    commonProps: {},
    updateCore: noop,
    componentRef: { current: null }
  });
  const useCoreContext = () => x(CoreContext);
  const fixedForwardRef = (render) => D(render);
  const memoComparator = (() => {
    const _comparedProps = /* @__PURE__ */ new Set();
    const _propHasChanged = (prev, next, prop, getters) => {
      let getter2 = getters == null ? void 0 : getters[prop];
      getter2 = isFunction(getter2) ? getter2 : identity;
      return !sameValue(getter2(prev[prop]), getter2(next[prop]));
    };
    const comparator = (getters) => (prev, next) => {
      try {
        for (const prop in prev) {
          _comparedProps.add(prop);
          if (_propHasChanged(prev, next, prop, getters)) return false;
        }
        for (const prop in next) {
          if (_comparedProps.has(prop)) continue;
          _comparedProps.add(prop);
          if (_propHasChanged(prev, next, prop, getters)) return false;
        }
        return true;
      } finally {
        _comparedProps.clear();
      }
    };
    return Object.defineProperty(comparator, "exclude", { value: noop });
  })();
  const EXCESS_WHITESPACE_CHAR = /^\s+|\s+(?=\s|$)/g;
  const parseClassName = (fallbackClassName, className) => {
    const classes2 = className ? typeof className === "string" ? className : (className == null ? void 0 : className.value) ?? "" : "";
    return classes2.replace(EXCESS_WHITESPACE_CHAR, "") || fallbackClassName.replace(EXCESS_WHITESPACE_CHAR, "") || void 0;
  };
  const getClassName = (className, fallbackClassName, requiredClassName) => cx(parseClassName("", requiredClassName), parseClassName(parseClassName("", fallbackClassName) || "", className));
  const getModifierClasses = (prefix, modifiers = [], baseClasses = []) => cx([...baseClasses, ...modifiers == null ? void 0 : modifiers.map((m2) => prefix ? `${prefix}--${m2}` : m2)]);
  const parseBooleanProp = (prop) => boolify(prop, (prop == null ? void 0 : prop.value) ?? prop);
  const DEFAULT_BUTTON_CLASSNAME = "adyen-pe-button";
  const BUTTON_ANCHOR_CLASSNAME = "adyen-pe-button__anchor";
  const BUTTON_ACTION_CLASSNAME = `${DEFAULT_BUTTON_CLASSNAME}-actions`;
  const ICON_BUTTON_CLASSNAME = `${DEFAULT_BUTTON_CLASSNAME}--icon`;
  const ICON_BUTTON_CONTENT_CLASSNAME = `${DEFAULT_BUTTON_CLASSNAME}--icon-content`;
  const BUTTON_ACTION_CONTAINER_CLASSNAME = `${BUTTON_ACTION_CLASSNAME}__container-wrapper`;
  const BUTTON_LABEL_CLASSNAME = `${DEFAULT_BUTTON_CLASSNAME}__label`;
  const BUTTON_ICON_RIGHT_CLASSNAME = `${DEFAULT_BUTTON_CLASSNAME}__icon-right`;
  const BUTTON_ICON_LEFT_CLASSNAME = `${DEFAULT_BUTTON_CLASSNAME}__icon-left`;
  const BUTTON_CONDENSED_CLASSNAME = `${DEFAULT_BUTTON_CLASSNAME}--condensed`;
  const BUTTON_FULL_WIDTH_CLASSNAME = `${DEFAULT_BUTTON_CLASSNAME}--full-width`;
  const BUTTON_LOADING_CLASSNAME = `${DEFAULT_BUTTON_CLASSNAME}--loading`;
  const BUTTON_LABEL_CENTERED_CLASSNAME = `${BUTTON_LABEL_CLASSNAME}--centered`;
  const Spinner = ({ inline = false, size = "large" }) => /* @__PURE__ */ u$1("div", { className: `adyen-pe-spinner__wrapper ${inline ? "adyen-pe-spinner__wrapper--inline" : ""}`, children: /* @__PURE__ */ u$1("div", { className: `adyen-pe-spinner adyen-pe-spinner--${size}` }) });
  const useButton = (className, classNameModifiers, defaultClassName, disabled, props, onClick) => {
    const { children, iconLeft, iconRight, iconButton = false, fullWidth, condensed, state = "default" } = props;
    const click = q$1(
      (e2) => {
        e2.preventDefault();
        if (!disabled) {
          onClick == null ? void 0 : onClick(e2);
        }
      },
      [disabled, onClick]
    );
    const classes2 = T$1(
      () => getModifierClasses(defaultClassName, classNameModifiers, [defaultClassName, className]),
      [defaultClassName, classNameModifiers, className]
    );
    const allProps = T$1(
      () => ({
        ...props,
        className: cx(classes2, {
          [ICON_BUTTON_CLASSNAME]: iconButton,
          [BUTTON_CONDENSED_CLASSNAME]: condensed,
          [BUTTON_FULL_WIDTH_CLASSNAME]: fullWidth,
          [BUTTON_LOADING_CLASSNAME]: state === "loading"
        }),
        disabled: disabled || state === "loading"
      }),
      [classes2, condensed, disabled, fullWidth, iconButton, props, state]
    );
    const allChildren = T$1(
      () => iconButton ? /* @__PURE__ */ u$1("div", { className: `${ICON_BUTTON_CONTENT_CLASSNAME}`, children }) : /* @__PURE__ */ u$1(k$1, { children: [
        state === "loading" && /* @__PURE__ */ u$1(Spinner, { size: "x-small" }),
        iconLeft && /* @__PURE__ */ u$1("span", { className: BUTTON_ICON_LEFT_CLASSNAME, children: iconLeft }),
        /* @__PURE__ */ u$1(
          Typography$1,
          {
            className: cx(BUTTON_LABEL_CLASSNAME, {
              [BUTTON_LABEL_CENTERED_CLASSNAME]: props.align === "center"
            }),
            el: TypographyElement.SPAN,
            variant: TypographyVariant.BODY,
            children
          }
        ),
        iconRight && /* @__PURE__ */ u$1("span", { className: BUTTON_ICON_RIGHT_CLASSNAME, children: iconRight })
      ] }),
      [children, iconButton, iconLeft, iconRight, props.align, state]
    );
    return { classes: classes2, click, allChildren, allProps };
  };
  var ButtonVariant = /* @__PURE__ */ ((ButtonVariant2) => {
    ButtonVariant2["PRIMARY"] = "primary";
    ButtonVariant2["SECONDARY"] = "secondary";
    ButtonVariant2["TERTIARY"] = "tertiary";
    ButtonVariant2["TERTIARY_WITH_BACKGROUND"] = "tertiary-with-background";
    ButtonVariant2["LINK"] = "link";
    return ButtonVariant2;
  })(ButtonVariant || {});
  function Button(props, ref) {
    const classNameValue = T$1(() => parseClassName("", props.className) || "", [props.className]);
    const disabledValue = T$1(() => parseBooleanProp(props.disabled || false), [props.disabled]);
    const { click, allChildren, allProps } = useButton(
      classNameValue,
      [...props.classNameModifiers || [], props.variant || ButtonVariant.PRIMARY],
      DEFAULT_BUTTON_CLASSNAME,
      disabledValue,
      props,
      props.onClick
    );
    const { classNameModifiers, ...restOfAllProps } = allProps;
    return /* @__PURE__ */ u$1("button", { ...restOfAllProps, ref, type: props.type || "button", onClick: click, children: allChildren });
  }
  const Button$1 = fixedForwardRef(Button);
  const IMAGE_BREAKPOINT_SIZES = {
    md: 680
  };
  const ErrorMessageDisplay = ({
    title,
    message,
    imageDesktop,
    imageMobile,
    withImage,
    centered,
    refreshComponent,
    onContactSupport,
    translationValues,
    absolutePosition = true,
    outlined = true,
    renderSecondaryButton,
    withBackground
  }) => {
    const { i18n, updateCore, getImageAsset } = useCoreContext();
    const renderMessage = q$1(
      (errorMessage) => {
        if (Array.isArray(errorMessage)) {
          return errorMessage.map(
            (message2, i2) => i2 === 0 ? /* @__PURE__ */ u$1(k$1, { children: [
              i18n.get(message2),
              translationValues && translationValues[message2] && /* @__PURE__ */ u$1(k$1, { children: translationValues[message2] })
            ] }) : /* @__PURE__ */ u$1(k$1, { children: [
              /* @__PURE__ */ u$1("br", {}),
              i18n.get(message2),
              translationValues && translationValues[message2] && /* @__PURE__ */ u$1(k$1, { children: translationValues[message2] })
            ] })
          );
        }
        return i18n.get(errorMessage);
      },
      [i18n, translationValues]
    );
    return /* @__PURE__ */ u$1(
      "div",
      {
        className: cx(["adyen-pe-error-message-display"], {
          "adyen-pe-error-message-display--absolute-position": absolutePosition,
          "adyen-pe-error-message-display--outlined": outlined,
          "adyen-pe-error-message-display--with-background": withBackground !== false && !outlined,
          "adyen-pe-error-message-display--centered": centered
        }),
        children: [
          (imageDesktop || imageMobile || withImage) && /* @__PURE__ */ u$1("div", { className: "adyen-pe-error-message-display__illustration", children: /* @__PURE__ */ u$1("picture", { children: [
            /* @__PURE__ */ u$1("source", { type: "image/svg+xml", media: `(min-width: ${IMAGE_BREAKPOINT_SIZES.md}px)`, srcSet: imageDesktop }),
            /* @__PURE__ */ u$1("source", { type: "image/svg+xml", media: `(max-width: ${IMAGE_BREAKPOINT_SIZES.md}px)`, srcSet: imageMobile }),
            /* @__PURE__ */ u$1("img", { srcSet: imageDesktop ?? (getImageAsset == null ? void 0 : getImageAsset({ name: "no-results" })), alt: i18n.get("thereWasAnUnexpectedError") })
          ] }) }),
          /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.TITLE, children: i18n.get(title) }),
          message && /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.BODY, children: renderMessage(message) }),
          (onContactSupport || refreshComponent || renderSecondaryButton) && /* @__PURE__ */ u$1("div", { className: "adyen-pe-error-message-display__button", children: [
            renderSecondaryButton && renderSecondaryButton(),
            onContactSupport && /* @__PURE__ */ u$1(Button$1, { onClick: onContactSupport, children: i18n.get("reachOutToSupport") }),
            !onContactSupport && refreshComponent && /* @__PURE__ */ u$1(Button$1, { onClick: updateCore, children: i18n.get("refresh") })
          ] })
        ]
      }
    );
  };
  const getComponentAvailabilityFromEndpoint = (context, endpoint) => {
    return isFunction(context.endpoints[endpoint]);
  };
  const componentAvailabilityRegistry = {
    transactions: (context) => getComponentAvailabilityFromEndpoint(context, "getTransactions"),
    transactionDetails: (context) => getComponentAvailabilityFromEndpoint(context, "getTransaction"),
    payouts: (context) => getComponentAvailabilityFromEndpoint(context, "getPayouts"),
    payoutDetails: (context) => getComponentAvailabilityFromEndpoint(context, "getPayout"),
    reports: (context) => getComponentAvailabilityFromEndpoint(context, "getReports"),
    capitalOverview: (context) => getComponentAvailabilityFromEndpoint(context, "getDynamicGrantOffersConfiguration"),
    capitalOffer: (context) => getComponentAvailabilityFromEndpoint(context, "getDynamicGrantOffer"),
    disputes: (context) => getComponentAvailabilityFromEndpoint(context, "getDisputeList"),
    disputesManagement: (context) => getComponentAvailabilityFromEndpoint(context, "getDisputeDetail")
  };
  const sessionReady = async (session) => {
    const ready = createDeferred();
    const readyPromise = ready.promise;
    const refreshInProgress = session.context.refreshing;
    let didTriggerRefresh = void 0;
    let canRefreshSession = void 0;
    let sessionUnsubscribe = session.subscribe((maybeUnsubscribeToken) => {
      if (isWatchlistUnsubscribeToken(maybeUnsubscribeToken)) {
        ready.resolve();
        return;
      }
      didTriggerRefresh ?? (didTriggerRefresh = session.context.refreshing);
      if (session.context.refreshing) return;
      if (boolOrTrue(session.context.isExpired)) {
        if (canRefreshSession ?? (canRefreshSession = !(refreshInProgress || didTriggerRefresh))) {
          canRefreshSession = false;
          session.refresh();
          return;
        }
      }
      ready.resolve();
    });
    readyPromise.finally(() => {
      sessionUnsubscribe();
      sessionUnsubscribe = null;
    });
    return readyPromise;
  };
  const sessionAwareComponentAvailability = async (type2, session) => {
    var _a2;
    await sessionReady(session);
    return boolOrFalse(await ((_a2 = componentAvailabilityRegistry[type2]) == null ? void 0 : _a2.call(componentAvailabilityRegistry, session.context)));
  };
  const componentAvailabilityErrors = (type2) => {
    switch (type2) {
      case "payouts":
        return "weCouldNotLoadThePayoutsOverview";
      case "transactions":
        return "weCouldNotLoadTheTransactionsOverview";
      case "transactionDetails":
        return "weCouldNotLoadYourTransactions";
      case "payoutDetails":
        return "weCouldNotLoadYourPayouts";
      case "reports":
        return "weCouldNotLoadTheReportsOverview";
      default:
        return "somethingWentWrong";
    }
  };
  const ConfigContext = K$1({
    endpoints: EMPTY_OBJECT,
    extraConfig: EMPTY_OBJECT,
    hasError: false,
    http: asyncNoop,
    isExpired: void 0,
    isFrozen: false,
    refresh: noop,
    refreshing: false
  });
  const ConfigProvider = ({ children, session, type: type2 }) => {
    const { http: http2, refresh: refresh2 } = T$1(() => session, [session]);
    const [, setContextCounter] = d(0);
    const [unsubscribeCounter, setUnsubscribeCounter] = d(0);
    const [hasPermission, setHasPermission] = d();
    y(() => {
      sessionAwareComponentAvailability(type2, session).then(setHasPermission);
    }, [session, type2]);
    y(() => {
      return session.subscribe((maybeContext) => {
        const stateUpdater = isWatchlistUnsubscribeToken(maybeContext) ? setUnsubscribeCounter : setContextCounter;
        stateUpdater((count) => count + 1);
      });
    }, [unsubscribeCounter]);
    return /* @__PURE__ */ u$1(ConfigContext.Provider, { value: { ...session.context, http: http2, refresh: refresh2 }, children: !isUndefined(hasPermission) && (hasPermission ? H$1(children) : /* @__PURE__ */ u$1(
      ErrorMessageDisplay,
      {
        withImage: true,
        centered: true,
        title: "somethingWentWrong",
        message: [componentAvailabilityErrors(type2), "contactSupportForHelp"]
      }
    )) });
  };
  const useConfigContext = () => x(ConfigContext);
  const useBooleanState = (initialState = false) => {
    const [state, setState] = d(initialState);
    const updateState = q$1((state2) => setState(state2), []);
    const toggleState = q$1(() => setState((state2) => !state2), []);
    return [state, updateState, toggleState];
  };
  const CoreProvider = ({
    i18n = new Localization().i18n,
    children,
    commonProps: _commonProps,
    loadingContext: _loadingContext,
    updateCore,
    externalErrorHandler,
    componentRef,
    getImageAsset
  }) => {
    const [ready, setReady] = useBooleanState(false);
    const commonProps = T$1(() => _commonProps || {}, [_commonProps]);
    const loadingContext = T$1(() => _loadingContext ?? "", [_loadingContext]);
    y(() => {
      (async () => {
        await (i18n == null ? void 0 : i18n.ready);
        setReady(true);
      })().catch();
    }, []);
    const coreContextValues = T$1(
      () => ({ i18n, commonProps, loadingContext, updateCore, externalErrorHandler, componentRef, getImageAsset }),
      [commonProps, componentRef, externalErrorHandler, i18n, loadingContext, getImageAsset, updateCore]
    );
    if (!ready) return null;
    return /* @__PURE__ */ u$1(CoreContext.Provider, { value: coreContextValues, children: H$1(children) });
  };
  class BaseElement {
    constructor(props) {
      __publicField(this, "_component");
      __publicField(this, "_node", null);
      __publicField(this, "_id", `${(_a = this.constructor) == null ? void 0 : _a.type}-${uuid()}`);
      __publicField(this, "defaultProps", {});
      __publicField(this, "props");
      __publicField(this, "state", {});
      this.props = this.formatProps({ ...this == null ? void 0 : this.defaultProps, ...props });
      this.props.core.registerComponent(this);
    }
    /**
     * Executed during creation of any element.
     * Gives a chance to any component to format the props we're receiving.
     */
    formatProps(props) {
      return props;
    }
    /**
     * Executed on the `data` getter.
     * Returns the component data necessary for making a request
     */
    formatData() {
      return {};
    }
    setState(newState) {
      this.state = { ...this.state, ...newState };
    }
    /**
     * Returns the component data ready to submit to the Checkout API
     * Note: this does not ensure validity, check isValid first
     */
    get data() {
      return {
        ...this.formatData(),
        clientStateDataIndicator: true
      };
    }
    render() {
      throw new Error("Component cannot be rendered.");
    }
    mount(domNode) {
      const node = isString$1(domNode) ? document.querySelector(domNode) : domNode;
      if (!node) throw new Error("Component could not mount. Root node was not found.");
      if (this._node) this.unmount();
      this._node = node;
      this._component = this.render();
      E$1(this._component, node);
      return this;
    }
    /**
     * Updates props, resets the internal state and remounts the element.
     * @param props - props to update
     * @returns this - the element instance
     */
    update(props) {
      this.props = this.formatProps({ ...this.props, ...props });
      this._component = this.render();
      if (this._node) E$1(this._component, this._node);
      return this;
    }
    /**
     * Unmounts an element and mounts it again on the same node i.e. allows mount w/o having to pass a node.
     * Should be "private" & undocumented (although being a public function is useful for testing).
     * Left in for legacy reasons
     */
    remount(component) {
      if (!this._node) throw new Error("Component is not mounted.");
      const newComponent = component || this.render();
      E$1(newComponent, this._node);
      return this;
    }
    /**
     * Unmounts an element from the DOM
     */
    unmount() {
      if (this._node) E$1(null, this._node);
      return this;
    }
    /**
     * Unmounts an element and removes it from the parent instance
     * For "destroy" type cleanup - when you don't intend to use the component again
     */
    remove() {
      this.unmount();
      this.props.core.remove(this);
    }
  }
  __publicField(BaseElement, "type");
  class UIElement extends BaseElement {
    constructor(props) {
      super(props);
      __publicField(this, "componentRef", null);
      __publicField(this, "componentToRender", null);
      __publicField(this, "elementRef");
      __publicField(this, "onContactSupport");
      __publicField(this, "customClassNames");
      __publicField(this, "compRef");
      __publicField(this, "setUIElementStatus");
      this.setState = this.setState.bind(this);
      this.onContactSupport = props.onContactSupport;
      this.elementRef = this;
      this.compRef = b();
    }
    get isValid() {
      return !!this.state.isValid;
    }
    /**
     * Get the element's displayable name
     */
    get displayName() {
      return this.type;
    }
    /**
     * Get the element accessible name, used in the aria-label of the button that controls selected component
     */
    get accessibleName() {
      return this.displayName;
    }
    /**
     * Return the type of an element
     */
    get type() {
      var _a2;
      return (_a2 = this.constructor) == null ? void 0 : _a2.type;
    }
    formatProps(props) {
      return props;
    }
    /**
     * Formats the component data output
     */
    formatData() {
      return {
        ...this.state
      };
    }
    setState(newState) {
      this.state = { ...this.state, ...newState };
    }
    setStatus(status2, props) {
      var _a2, _b2;
      if ((_a2 = this.componentRef) == null ? void 0 : _a2.setStatus) {
        this.componentRef.setStatus(status2, props);
      } else {
        (_b2 = this.setUIElementStatus) == null ? void 0 : _b2.call(this, status2);
      }
      return this;
    }
    render() {
      const core = this.props.core;
      const updateCore = core.update.bind(core);
      const externalErrorHandler = this.props.onError || core.onError || null;
      core.session.errorHandler = externalErrorHandler;
      return /* @__PURE__ */ u$1(ConfigProvider, { type: this.type, session: core.session, children: /* @__PURE__ */ u$1(
        CoreProvider,
        {
          i18n: core.localization.i18n,
          loadingContext: core.loadingContext,
          updateCore,
          externalErrorHandler,
          componentRef: this.compRef,
          getImageAsset: core.getImageAsset,
          children: this.componentToRender && /* @__PURE__ */ u$1("div", { ref: this.compRef, className: cx("adyen-pe-component", this.customClassNames), children: /* @__PURE__ */ u$1("div", { className: "adyen-pe-component__container", children: this.componentToRender() }) })
        }
      ) }, performance.now());
    }
  }
  function useFetch({
    fetchOptions: { keepPrevData, onSuccess, enabled } = { keepPrevData: true },
    queryFn
  }) {
    const cancelRequest = A$1(false);
    const initialState = {
      error: void 0,
      data: void 0,
      isFetching: boolOrTrue(enabled)
    };
    const fetchReducer = (state2, action) => {
      switch (action.type) {
        case "loading":
          return { ...initialState, isFetching: true, data: keepPrevData ? state2.data : void 0 };
        case "fetched":
          return { ...initialState, data: action.payload, isFetching: false };
        case "error":
          return { ...initialState, error: action.payload, isFetching: false };
        default:
          return state2;
      }
    };
    const [state, dispatch] = h(fetchReducer, initialState);
    const fetchData = q$1(async () => {
      dispatch({ type: "loading" });
      try {
        if (cancelRequest.current) return;
        const data = await queryFn();
        onSuccess == null ? void 0 : onSuccess(data);
        dispatch({ type: "fetched", payload: data });
      } catch (error) {
        if (cancelRequest.current) return;
        dispatch({ type: "error", payload: error });
      }
    }, [dispatch, queryFn, onSuccess]);
    y(() => {
      cancelRequest.current = false;
      if (boolOrTrue(enabled)) void fetchData();
      return () => {
        cancelRequest.current = true;
      };
    }, [enabled, fetchData]);
    return state;
  }
  const ACCORDION_BASE_CLASS = "adyen-pe-accordion";
  const ACCORDION_HEADER_CLASS = ACCORDION_BASE_CLASS + "__header";
  const ACCORDION_HEADER_CONTAINER_CLASS = ACCORDION_HEADER_CLASS + "-container";
  const ACCORDION_HEADER_CONTROLLER_CLASS = ACCORDION_HEADER_CLASS + "-controller";
  const ACCORDION_CONTENT_CLASS = ACCORDION_BASE_CLASS + "__content";
  const icons = {
    "angle-right": () => Promise.resolve().then(() => angleRight),
    "checkmark-circle-fill": () => Promise.resolve().then(() => checkmarkCircleFill),
    "checkmark-square-fill": () => Promise.resolve().then(() => checkmarkSquareFill),
    checkmark: () => Promise.resolve().then(() => checkmark),
    "chevron-down": () => Promise.resolve().then(() => chevronDown),
    "chevron-left": () => Promise.resolve().then(() => chevronLeft),
    "chevron-right": () => Promise.resolve().then(() => chevronRight),
    "chevron-up": () => Promise.resolve().then(() => chevronUp),
    copy: () => Promise.resolve().then(() => copy),
    "cross-circle-fill": () => Promise.resolve().then(() => crossCircleFill),
    cross: () => Promise.resolve().then(() => cross),
    download: () => Promise.resolve().then(() => download),
    "external-link": () => Promise.resolve().then(() => externalLink),
    filter: () => Promise.resolve().then(() => filter),
    "info-filled": () => Promise.resolve().then(() => infoFilled),
    "minus-circle-outline": () => Promise.resolve().then(() => minusCircleOutline),
    plus: () => Promise.resolve().then(() => plus),
    "plus-circle-outline": () => Promise.resolve().then(() => plusCircleOutline),
    square: () => Promise.resolve().then(() => square),
    "trash-can": () => Promise.resolve().then(() => trashCan),
    upload: () => Promise.resolve().then(() => upload),
    "warning-filled": () => Promise.resolve().then(() => warningFilled),
    warning: () => Promise.resolve().then(() => warning)
  };
  const Icon$1 = ({ className, name, ...props }) => {
    const [IconComponent, setIconComponent] = d(null);
    y(() => {
      if (icons[name]) {
        icons[name]().then(({ default: LoadedIcon }) => {
          setIconComponent(/* @__PURE__ */ u$1(LoadedIcon, {}));
        });
      } else {
        setIconComponent(null);
        console.error(`Icon with name "${name}" does not exist.`);
      }
    }, [name]);
    return IconComponent && /* @__PURE__ */ u$1("span", { className: cx("adyen-pe-icon", className), role: "img", "aria-hidden": true, ...props, children: IconComponent });
  };
  function Accordion({ children, classNames, header, headerInformation }) {
    var _a2;
    const [isExpanded, setIsExpanded] = d(false);
    const accordionContentRef = A$1(null);
    const toggle = q$1(() => {
      setIsExpanded(!isExpanded);
    }, [isExpanded]);
    return /* @__PURE__ */ u$1("div", { className: cx(ACCORDION_BASE_CLASS, classNames), children: [
      /* @__PURE__ */ u$1("h3", { className: ACCORDION_HEADER_CLASS, children: [
        /* @__PURE__ */ u$1(
          "button",
          {
            id: "accordion-controller",
            "aria-controls": "accordion-content",
            className: ACCORDION_HEADER_CONTAINER_CLASS,
            onClick: toggle,
            "aria-expanded": isExpanded,
            children: /* @__PURE__ */ u$1("div", { className: ACCORDION_HEADER_CONTROLLER_CLASS, children: [
              header,
              isExpanded ? /* @__PURE__ */ u$1(Icon$1, { name: "chevron-up" }) : /* @__PURE__ */ u$1(Icon$1, { name: "chevron-down" })
            ] })
          }
        ),
        headerInformation && /* @__PURE__ */ u$1("div", { children: headerInformation })
      ] }),
      /* @__PURE__ */ u$1(
        "div",
        {
          role: "region",
          id: "accordion-content",
          "aria-labelledby": "accordion-controller",
          style: { maxHeight: isExpanded ? (_a2 = accordionContentRef == null ? void 0 : accordionContentRef.current) == null ? void 0 : _a2.offsetHeight : 0 },
          className: ACCORDION_CONTENT_CLASS,
          children: /* @__PURE__ */ u$1("div", { ref: accordionContentRef, children })
        }
      )
    ] });
  }
  var InteractionKeyCode = /* @__PURE__ */ ((InteractionKeyCode2) => {
    InteractionKeyCode2["ARROW_DOWN"] = "ArrowDown";
    InteractionKeyCode2["ARROW_LEFT"] = "ArrowLeft";
    InteractionKeyCode2["ARROW_RIGHT"] = "ArrowRight";
    InteractionKeyCode2["ARROW_UP"] = "ArrowUp";
    InteractionKeyCode2["BACKSPACE"] = "Backspace";
    InteractionKeyCode2["END"] = "End";
    InteractionKeyCode2["ENTER"] = "Enter";
    InteractionKeyCode2["ESCAPE"] = "Escape";
    InteractionKeyCode2["HOME"] = "Home";
    InteractionKeyCode2["PAGE_DOWN"] = "PageDown";
    InteractionKeyCode2["PAGE_UP"] = "PageUp";
    InteractionKeyCode2["SPACE"] = "Space";
    InteractionKeyCode2["TAB"] = "Tab";
    return InteractionKeyCode2;
  })(InteractionKeyCode || {});
  var FilterParam = /* @__PURE__ */ ((FilterParam2) => {
    FilterParam2["BALANCE_ACCOUNT"] = "balanceAccount";
    FilterParam2["CATEGORIES"] = "categories";
    FilterParam2["CURRENCIES"] = "currencies";
    FilterParam2["CREATED_SINCE"] = "createdSince";
    FilterParam2["CREATED_UNTIL"] = "createdUntil";
    FilterParam2["STATUSES"] = "statuses";
    FilterParam2["MIN_AMOUNT"] = "minAmount";
    FilterParam2["MAX_AMOUNT"] = "maxAmount";
    return FilterParam2;
  })(FilterParam || {});
  const CARD_BASE_CLASS = "adyen-pe-card";
  const CARD_EXPANDABLE_CLASS = `${CARD_BASE_CLASS}--expandable`;
  const CARD_TOGGLE_CLASS = `${CARD_BASE_CLASS}__toggle`;
  const CARD_BODY = `${CARD_BASE_CLASS}__body`;
  const CARD_HEADER = `${CARD_BASE_CLASS}__header`;
  const CARD_TITLE = `${CARD_BASE_CLASS}__title`;
  const CARD_SUBTITLE = `${CARD_BASE_CLASS}__subtitle`;
  const CARD_HEADER_CONTENT = `${CARD_HEADER}-content`;
  const CARD_BODY_WITH_TITLE = `${CARD_BODY}--with-title`;
  const CARD_NO_OUTLINE = `${CARD_BASE_CLASS}--no-outline`;
  const CARD_NO_PADDING = `${CARD_BASE_CLASS}--no-padding`;
  const CARD_FILLED = `${CARD_BASE_CLASS}--filled`;
  const CARD_FOOTER = `${CARD_BASE_CLASS}__footer`;
  const CARD_COMPACT = `${CARD_BASE_CLASS}--compact`;
  const Card = ({
    title,
    subTitle,
    children,
    expandable = false,
    footer,
    el,
    renderHeader,
    renderFooter,
    filled,
    noOutline,
    noPadding,
    classNameModifiers,
    testId,
    compact
  }) => {
    const Tag2 = el || "header";
    const [showContent, setShowContent] = d(false);
    const cardId = T$1(() => uuid(), []);
    const toggleExpansion = q$1(() => {
      if (expandable) {
        setShowContent((showContent2) => !showContent2);
      }
    }, [expandable]);
    const onKeyDown = q$1(
      (evt) => {
        switch (evt.code) {
          case InteractionKeyCode.ENTER:
          case InteractionKeyCode.SPACE:
            evt.preventDefault();
            toggleExpansion();
            return;
        }
      },
      [toggleExpansion]
    );
    const cardContainerAttributes = T$1(() => {
      return expandable ? {
        role: "button",
        tabIndex: 0,
        onClick: toggleExpansion,
        onKeyDown,
        "aria-controls": cardId,
        "aria-expanded": showContent
      } : {};
    }, [expandable, showContent, cardId, onKeyDown, toggleExpansion]);
    return /* @__PURE__ */ u$1(
      "section",
      {
        "data-testid": testId,
        className: cx(CARD_BASE_CLASS, classNameModifiers, {
          [CARD_FILLED]: filled,
          [CARD_NO_OUTLINE]: noOutline,
          [CARD_NO_PADDING]: noPadding,
          [CARD_EXPANDABLE_CLASS]: expandable,
          [CARD_COMPACT]: compact
        }),
        ...cardContainerAttributes,
        children: [
          (title || renderHeader) && /* @__PURE__ */ u$1(Tag2, { className: cx(CARD_HEADER), children: /* @__PURE__ */ u$1("div", { className: cx(CARD_HEADER_CONTENT), children: [
            expandable && /* @__PURE__ */ u$1(Icon$1, { name: showContent ? "chevron-up" : "chevron-down", className: CARD_TOGGLE_CLASS, role: "presentation" }),
            renderHeader ? renderHeader : /* @__PURE__ */ u$1("span", { className: CARD_TITLE, children: title }),
            subTitle && /* @__PURE__ */ u$1("div", { className: CARD_SUBTITLE, children: subTitle })
          ] }) }),
          (!expandable || showContent) && /* @__PURE__ */ u$1(
            "div",
            {
              id: cardId,
              className: cx(CARD_BODY, {
                [CARD_BODY_WITH_TITLE]: title || renderHeader
              }),
              children
            }
          ),
          (footer || renderFooter) && /* @__PURE__ */ u$1("footer", { className: CARD_FOOTER, children: renderFooter ? renderFooter : footer })
        ]
      }
    );
  };
  const DIGITS_2 = "2-digit";
  const LONG = "long";
  const NUMERIC = "numeric";
  const SHORT = "short";
  const SHORT_OFFSET = "shortOffset";
  const BASE_DATE_FORMAT = {
    month: LONG,
    day: NUMERIC,
    year: NUMERIC
  };
  const BASE_TIME_FORMAT = {
    hour: DIGITS_2,
    minute: DIGITS_2
  };
  const BASE_DATE_TIME_FORMAT = {
    ...BASE_DATE_FORMAT,
    ...BASE_TIME_FORMAT,
    month: SHORT,
    hour12: false
  };
  const BASE_DATE_TIME_MOBILE_FORMAT = { ...BASE_DATE_TIME_FORMAT, year: void 0 };
  const DATE_FORMAT_CAPITAL_OVERVIEW = { ...BASE_DATE_FORMAT, month: "short" };
  const DATE_FORMAT_MISSING_ACTION = { ...BASE_DATE_FORMAT, month: "long" };
  const DATE_FORMAT_PAYOUTS = BASE_DATE_FORMAT;
  const DATE_FORMAT_PAYOUTS_MOBILE = BASE_DATE_TIME_MOBILE_FORMAT;
  const DATE_FORMAT_PAYOUT_DETAILS = { ...BASE_DATE_FORMAT, weekday: LONG };
  const DATE_FORMAT_REPORTS = { ...BASE_DATE_FORMAT, month: SHORT };
  const DATE_FORMAT_TRANSACTIONS = BASE_DATE_TIME_FORMAT;
  const DATE_FORMAT_TRANSACTIONS_MOBILE = BASE_DATE_TIME_MOBILE_FORMAT;
  const DATE_FORMAT_TRANSACTION_DETAILS = {
    ...BASE_DATE_FORMAT,
    ...BASE_TIME_FORMAT,
    weekday: LONG,
    timeZoneName: SHORT_OFFSET
  };
  const DATE_FORMAT_DISPUTES = BASE_DATE_FORMAT;
  const DATE_FORMAT_DISPUTE_DETAILS = {
    ...BASE_DATE_TIME_FORMAT,
    hour12: true,
    timeZoneName: SHORT_OFFSET
  };
  const DATE_FORMAT_RESPONSE_DEADLINE = {
    month: SHORT,
    weekday: LONG,
    hour: DIGITS_2,
    minute: NUMERIC,
    year: void 0,
    timeZoneName: SHORT_OFFSET
  };
  const BREAKPOINTS = {
    sm: 480,
    md: 768,
    lg: 1024
  };
  const SL_BASE_CLASS = "adyen-pe-structured-list";
  const SL_ALIGN_END = `${SL_BASE_CLASS}--align-end`;
  const SL_ITEM_CLASS = `${SL_BASE_CLASS}__item`;
  const SL_GRID_CLASS = `${SL_BASE_CLASS}__grid`;
  const SL_CONTENT_CLASS = `${SL_BASE_CLASS}__content`;
  const SL_LABEL_CLASS = `${SL_BASE_CLASS}__label`;
  const SL_ITEM_WITH_HIGHLIGHT_CLASS = `${SL_ITEM_CLASS}--has-highlight`;
  const useStructuredListItems = (items) => {
    const { i18n } = useCoreContext();
    return T$1(() => {
      return items.map((item) => {
        return {
          key: item.key,
          value: item.value,
          id: uuid(),
          label: i18n.get(item.key),
          type: item.type,
          config: item.config
        };
      });
    }, [i18n, items]);
  };
  const DEFAULT_LAYOUT = "6-6";
  function StructuredList({
    items,
    highlightable,
    renderValue,
    renderLabel,
    layout = DEFAULT_LAYOUT,
    grid = true,
    classNames,
    align = "end"
  }) {
    const [LABEL_COL_CLASS, VALUE_COL_CLASS] = T$1(() => {
      return layout.split("-").map((w2) => `${SL_GRID_CLASS}--width-${w2}-of-12`);
    }, [layout]);
    const formattedItems = useStructuredListItems(items);
    const { i18n } = useCoreContext();
    return /* @__PURE__ */ u$1("dl", { "aria-label": i18n.get("structuredList"), className: cx(SL_BASE_CLASS, classNames, { [SL_ALIGN_END]: align === "end" }), children: formattedItems.map((item, index) => /* @__PURE__ */ u$1(
      "div",
      {
        className: cx(SL_ITEM_CLASS, {
          [SL_ITEM_WITH_HIGHLIGHT_CLASS]: highlightable,
          [SL_GRID_CLASS]: grid
        }),
        children: [
          /* @__PURE__ */ u$1("dt", { className: cx(SL_LABEL_CLASS, LABEL_COL_CLASS), children: renderLabel ? renderLabel(item.label, items[index].key) : /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.BODY, children: item.label }) }),
          /* @__PURE__ */ u$1("dd", { "aria-label": `${i18n.get(item.key)} ${i18n.get("value")}`, className: cx(SL_CONTENT_CLASS, VALUE_COL_CLASS), children: renderValue ? renderValue(item.value, item.key, item.type, item.config) : /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.BODY, children: item.value }) })
        ]
      },
      `${index}_${item.id || "0"}`
    )) });
  }
  const BASE_CLASS$o = "adyen-pe-overview-details";
  const SKELETON_CLASS = `${BASE_CLASS$o}__skeleton`;
  const SKELETON_CONTAINER = `${SKELETON_CLASS}-container`;
  const SKELETON_LOADING = `${SKELETON_CLASS}--loading-content`;
  const STATUS_SKELETON = `${BASE_CLASS$o}__status-skeleton`;
  const DataOverviewDetailsSkeleton = ({ skeletonRowNumber = 0 }) => {
    const className = cx(SKELETON_CLASS, SKELETON_LOADING);
    const skeletonRows = Array.from({ length: skeletonRowNumber });
    const statusSkeletonRows = Array.from({ length: 2 });
    return /* @__PURE__ */ u$1("div", { className: SKELETON_CONTAINER, children: [
      /* @__PURE__ */ u$1("div", { className: STATUS_SKELETON, children: statusSkeletonRows.map((_2, index) => /* @__PURE__ */ u$1("span", { className }, `status-skeleton-${index}`)) }),
      skeletonRows.map((_2, index) => /* @__PURE__ */ u$1("span", { className }, `skeleton-${index}`))
    ] });
  };
  const DataOverviewDetailsSkeleton$1 = M(DataOverviewDetailsSkeleton);
  const _useAtomicTimezoneOperation = (operation) => {
    const { i18n } = useCoreContext();
    return q$1(
      (...args) => {
        const timezoneToRestore = i18n.timezone;
        try {
          return operation(...args);
        } finally {
          i18n.timezone = timezoneToRestore;
        }
      },
      [i18n, operation]
    );
  };
  const _useActiveTimezone = (timezone2) => {
    const { i18n } = useCoreContext();
    const getActiveTimezone = _useAtomicTimezoneOperation(
      q$1(() => {
        i18n.timezone = void 0;
        i18n.timezone = timezone2;
        return i18n.timezone;
      }, [i18n, timezone2])
    );
    return T$1(getActiveTimezone, [getActiveTimezone]);
  };
  const useTimezoneAwareDateFormatting = (timezone2) => {
    const { i18n } = useCoreContext();
    const activeTimezone = _useActiveTimezone(timezone2);
    const dateFormat = _useAtomicTimezoneOperation(
      q$1(
        (...args) => {
          i18n.timezone = activeTimezone;
          return i18n.date(...args);
        },
        [i18n, activeTimezone]
      )
    );
    const fullDateFormat = _useAtomicTimezoneOperation(
      q$1(
        (...args) => {
          i18n.timezone = activeTimezone;
          return i18n.fullDate(...args);
        },
        [i18n, activeTimezone]
      )
    );
    return { dateFormat, fullDateFormat };
  };
  const PD_BASE_CLASS = "adyen-pe-payout-data";
  const PD_TITLE_CONTAINER_CLASS = `${PD_BASE_CLASS}__title-container`;
  const PD_TITLE_CLASS = `${PD_BASE_CLASS}__title`;
  const PD_TITLE_CLASS_WITH_EXTRA_DETAILS = `${PD_BASE_CLASS}__title--with-extra-details`;
  const PD_TITLE_BA_CLASS = `${PD_BASE_CLASS}__title--ba-id`;
  const PD_CONTENT_CLASS = `${PD_BASE_CLASS}__content`;
  const PD_EXTRA_DETAILS_CLASS = `${PD_BASE_CLASS}__extra-details`;
  const PD_EXTRA_DETAILS_LABEL = `${PD_BASE_CLASS}__extra-details-label`;
  const PD_EXTRA_DETAILS_ICON = `${PD_BASE_CLASS}__extra-details-icon`;
  const PD_BUTTON_ACTIONS = `${PD_BASE_CLASS}__button-actions`;
  const PD_SECTION_CLASS = `${PD_CONTENT_CLASS}--section`;
  const PD_CARD_CLASS = `${PD_CONTENT_CLASS}--card`;
  const PD_CARD_TITLE_CLASS = `${PD_CARD_CLASS}-title`;
  const PD_SECTION_AMOUNT_CLASS = `${PD_SECTION_CLASS}-amount`;
  const PD_SECTION_GROSS_AMOUNT_CLASS = `${PD_SECTION_AMOUNT_CLASS}-gross`;
  const PD_SECTION_NET_AMOUNT_CLASS = `${PD_SECTION_AMOUNT_CLASS}-net`;
  const PD_UNPAID_AMOUNT = `${PD_BASE_CLASS}--unpaid-amount`;
  var TagVariant = /* @__PURE__ */ ((TagVariant2) => {
    TagVariant2["DEFAULT"] = "default";
    TagVariant2["WARNING"] = "warning";
    TagVariant2["ERROR"] = "error";
    TagVariant2["SUCCESS"] = "success";
    TagVariant2["WHITE"] = "white";
    TagVariant2["LIGHT"] = "light";
    TagVariant2["LIGHT_WITH_OUTLINE"] = "light-with-outline";
    TagVariant2["BLUE"] = "blue";
    return TagVariant2;
  })(TagVariant || {});
  const Tag = M(({ variant = TagVariant.DEFAULT, label, children }) => {
    return /* @__PURE__ */ u$1(
      "div",
      {
        className: cx("adyen-pe-tag", {
          // [TODO]: These Bento tag variants definitions are outdated
          "adyen-pe-tag--success": variant === TagVariant.SUCCESS,
          "adyen-pe-tag--default": variant === TagVariant.DEFAULT,
          "adyen-pe-tag--warning": variant === TagVariant.WARNING,
          "adyen-pe-tag--error": variant === TagVariant.ERROR,
          "adyen-pe-tag--primary": variant === TagVariant.WHITE,
          "adyen-pe-tag--light": variant === TagVariant.LIGHT,
          "adyen-pe-tag--light-with-outline": variant === TagVariant.LIGHT_WITH_OUTLINE,
          // Adopted from the latest Bento tag variants spec
          "adyen-pe-tag--blue": variant === TagVariant.BLUE
        }),
        children: children || label
      }
    );
  });
  function Link({
    href,
    children,
    variant = "default",
    truncate,
    target = "_blank",
    withIcon = true,
    classNames = [],
    ...props
  }) {
    const onClick = q$1((e2) => e2.stopPropagation(), []);
    return /* @__PURE__ */ u$1(
      "a",
      {
        className: cx("adyen-pe-link", [...classNames], {
          [`adyen-pe-link--${variant}`]: variant !== "default",
          "adyen-pe-link--truncate": truncate
        }),
        href,
        target,
        rel: "noopener noreferrer",
        onClick,
        ...props,
        children: [
          /* @__PURE__ */ u$1(Typography$1, { className: "adyen-pe-link__text", el: TypographyElement.SPAN, variant: TypographyVariant.BODY, children }),
          withIcon && target === "_blank" && /* @__PURE__ */ u$1(Icon$1, { name: "external-link" })
        ]
      }
    );
  }
  const Icon = ({ className, alt, url }) => {
    return /* @__PURE__ */ u$1("div", { className: "adyen-pe-data-grid__icon-container", children: /* @__PURE__ */ u$1("img", { className: cx("adyen-pe-data-grid__icon", className), alt, src: url }) });
  };
  const DataGridContext = K$1(EMPTY_OBJECT);
  const useDataGridContext = () => x(DataGridContext);
  function DataGridCell({
    children,
    column,
    position,
    ...props
  }) {
    const { registerCells } = useDataGridContext();
    const ref = A$1(null);
    y(() => {
      var _a2;
      if (ref.current) {
        registerCells({
          column,
          width: (_a2 = ref.current) == null ? void 0 : _a2.getBoundingClientRect().width
        });
      }
    }, [column, registerCells]);
    return /* @__PURE__ */ u$1(
      "div",
      {
        role: "cell",
        className: cx("adyen-pe-data-grid__cell", {
          "adyen-pe-data-grid__cell--right": position === "right",
          "adyen-pe-data-grid__cell--center": position === "center"
        }),
        ...props,
        children: children && u$2(children) ? J$1(children, {
          ...children == null ? void 0 : children.props,
          ref,
          style: { width: "min-content" }
        }) : null
      }
    );
  }
  const isCustomDataObject = (item) => {
    return !!item && typeof item === "object" && "value" in item;
  };
  const _isIconType = (item) => {
    return !!item && typeof item === "object" && item.type === "icon";
  };
  const _isButtonType$1 = (item) => {
    return !!item && typeof item === "object" && item.type === "button";
  };
  const _isLinkType = (item) => {
    return !!item && typeof item === "object" && item.type === "link";
  };
  const TableCells = ({
    columns,
    customCells,
    item,
    rowIndex
  }) => {
    return /* @__PURE__ */ u$1(k$1, { children: columns.map(({ key, position }) => {
      var _a2, _b2, _c2, _d2, _e, _f, _g;
      if (customCells == null ? void 0 : customCells[key])
        return /* @__PURE__ */ u$1(DataGridCell, { "aria-labelledby": String(key), column: key, position, children: /* @__PURE__ */ u$1("div", {
          style: { width: "min-content" },
          // TODO create safeguard to remove "as any" assertion
          children: customCells[key]({
            key,
            value: item[key],
            item,
            rowIndex
          })
        }) }, key);
      const data = item[key];
      const { value: value2, type: type2 } = isCustomDataObject(data) ? data : { value: data, type: "text" };
      const icon = _isIconType(data) ? { url: (_a2 = data == null ? void 0 : data.config) == null ? void 0 : _a2.src, alt: ((_b2 = data == null ? void 0 : data.config) == null ? void 0 : _b2.alt) !== void 0 && ((_c2 = data == null ? void 0 : data.config) == null ? void 0 : _c2.alt) !== null ? (_d2 = data == null ? void 0 : data.config) == null ? void 0 : _d2.alt : data.value } : void 0;
      const buttonCallback = _isButtonType$1(data) ? (e2) => {
        var _a3;
        e2.stopPropagation();
        (_a3 = data == null ? void 0 : data.config) == null ? void 0 : _a3.action();
      } : void 0;
      return /* @__PURE__ */ u$1(DataGridCell, { "aria-labelledby": String(key), column: key, position, children: /* @__PURE__ */ u$1("div", { className: "adyen-pe-data-grid__cell-value", children: [
        _isIconType(data) && data.config && (icon == null ? void 0 : icon.url) && /* @__PURE__ */ u$1("div", { className: cx("adyen-pe-data-grid__icon-cell", (_e = data == null ? void 0 : data.config) == null ? void 0 : _e.className), children: [
          /* @__PURE__ */ u$1(Icon, { ...icon }),
          value2.trim() && /* @__PURE__ */ u$1("span", { children: value2 })
        ] }),
        type2 === "text" && /* @__PURE__ */ u$1("span", { className: cx((_f = data == null ? void 0 : data.config) == null ? void 0 : _f.className), children: value2 }),
        type2 === "button" && data.config && buttonCallback && /* @__PURE__ */ u$1(Button$1, { className: cx((_g = data.config) == null ? void 0 : _g.className), onClick: buttonCallback, variant: ButtonVariant.SECONDARY, children: value2 }),
        _isLinkType(data) && data.config && /* @__PURE__ */ u$1(
          Link,
          {
            classNames: data.config.className ? [data.config.className] : [],
            href: data.config.href,
            target: data.config.target,
            children: value2
          }
        )
      ] }) }, key);
    }) });
  };
  var ButtonActionsLayoutBasic = /* @__PURE__ */ ((ButtonActionsLayoutBasic2) => {
    ButtonActionsLayoutBasic2["BUTTONS_END"] = "buttons-end";
    ButtonActionsLayoutBasic2["FILL_CONTAINER"] = "fill-container";
    ButtonActionsLayoutBasic2["SPACE_BETWEEN"] = "space-between";
    ButtonActionsLayoutBasic2["VERTICAL_STACK"] = "vertical-stack";
    return ButtonActionsLayoutBasic2;
  })(ButtonActionsLayoutBasic || {});
  var ButtonActionsLayoutExtended = /* @__PURE__ */ ((ButtonActionsLayoutExtended2) => {
    ButtonActionsLayoutExtended2["BUTTONS_START"] = "buttons-start";
    return ButtonActionsLayoutExtended2;
  })(ButtonActionsLayoutExtended || {});
  const ButtonActionsLayout = { ...ButtonActionsLayoutBasic, ...ButtonActionsLayoutExtended };
  function ButtonActions({ actions, layout = ButtonActionsLayout.BUTTONS_END }) {
    const conditionalClasses = () => {
      return `${BUTTON_ACTION_CLASSNAME}--${layout}`;
    };
    const generateButtonVariantByIndex = (actionIndex) => {
      const lastActionIndex = actions.length - 1;
      return actionIndex === lastActionIndex ? ButtonVariant.PRIMARY : ButtonVariant.SECONDARY;
    };
    const reversedActions = T$1(() => [...actions].reverse(), [actions]);
    return /* @__PURE__ */ u$1("div", { className: BUTTON_ACTION_CLASSNAME, children: /* @__PURE__ */ u$1("div", { className: `${BUTTON_ACTION_CONTAINER_CLASSNAME} ${conditionalClasses()}`, role: "group", children: reversedActions.map((button, index) => /* @__PURE__ */ u$1(
      Button$1,
      {
        className: cx(button.classNames),
        "aria-label": button.title,
        disabled: button.disabled,
        variant: button.variant || generateButtonVariantByIndex(index),
        onClick: button.event,
        state: button.state ?? "default",
        children: button.renderTitle ? button.renderTitle(button.title) : button.title
      },
      `${index}_${button.title || "0"}`
    )) }) });
  }
  const ButtonActions$1 = M(ButtonActions);
  const PayoutData = ({
    balanceAccountId: balanceAccountId2,
    balanceAccountDescription,
    payout: payoutData,
    extraFields
  }) => {
    var _a2;
    const { payout } = payoutData ?? EMPTY_OBJECT;
    const { dateFormat } = useTimezoneAwareDateFormatting("UTC");
    const { i18n } = useCoreContext();
    const adjustments2 = T$1(() => {
      var _a3, _b2;
      const data = (_b2 = (_a3 = payoutData == null ? void 0 : payoutData.amountBreakdowns) == null ? void 0 : _a3.adjustmentBreakdown) == null ? void 0 : _b2.reduce(
        (accumulator, currentValue) => {
          var _a4, _b3, _c2, _d2, _e, _f, _g;
          const payoutValue = ((_a4 = currentValue == null ? void 0 : currentValue.amount) == null ? void 0 : _a4.value) && ((_b3 = currentValue == null ? void 0 : currentValue.amount) == null ? void 0 : _b3.currency) ? i18n.amount((_c2 = currentValue == null ? void 0 : currentValue.amount) == null ? void 0 : _c2.value, (_d2 = currentValue == null ? void 0 : currentValue.amount) == null ? void 0 : _d2.currency, { hideCurrency: true }) : (((_e = currentValue == null ? void 0 : currentValue.amount) == null ? void 0 : _e.value) ?? "").toString();
          const translationKey = `${currentValue == null ? void 0 : currentValue.category}`;
          const categoryTranslation = i18n.get(translationKey);
          const categoryLabel = (currentValue == null ? void 0 : currentValue.category) && categoryTranslation !== translationKey ? categoryTranslation : currentValue == null ? void 0 : currentValue.category;
          if ((currentValue == null ? void 0 : currentValue.category) && payoutValue && categoryLabel) {
            const targetObj = accumulator[((_f = currentValue == null ? void 0 : currentValue.amount) == null ? void 0 : _f.value) && ((_g = currentValue == null ? void 0 : currentValue.amount) == null ? void 0 : _g.value) < 0 ? "subtractions" : "additions"];
            targetObj.push({ key: categoryLabel, value: payoutValue });
          }
          return accumulator;
        },
        { subtractions: [], additions: [] }
      );
      data == null ? void 0 : data.subtractions.sort((a2, b2) => a2.key.localeCompare(b2.key));
      data == null ? void 0 : data.additions.sort((a2, b2) => a2.key.localeCompare(b2.key));
      return data;
    }, [i18n, payoutData]);
    const fundsCaptured2 = T$1(() => {
      var _a3, _b2;
      const data = (_b2 = (_a3 = payoutData == null ? void 0 : payoutData.amountBreakdowns) == null ? void 0 : _a3.fundsCapturedBreakdown) == null ? void 0 : _b2.reduce((items, breakdown) => {
        var _a4, _b3, _c2, _d2;
        if (((_a4 = breakdown == null ? void 0 : breakdown.amount) == null ? void 0 : _a4.value) === 0) return items;
        if (((_b3 = breakdown == null ? void 0 : breakdown.amount) == null ? void 0 : _b3.value) && breakdown.category) {
          items.push({
            key: breakdown.category,
            value: i18n.amount((_c2 = breakdown == null ? void 0 : breakdown.amount) == null ? void 0 : _c2.value, (_d2 = breakdown == null ? void 0 : breakdown.amount) == null ? void 0 : _d2.currency, { hideCurrency: true })
          });
        }
        return items;
      }, []);
      data == null ? void 0 : data.sort((a2, b2) => {
        if (a2.key === "capture") return -1;
        if (b2.key === "capture") return 1;
        return a2.key.localeCompare(b2.key);
      });
      return data;
    }, [payoutData, i18n]);
    const creationDate = T$1(
      () => (payout == null ? void 0 : payout.createdAt) ? dateFormat(new Date(payout == null ? void 0 : payout.createdAt), DATE_FORMAT_PAYOUT_DETAILS) : "",
      [payout, dateFormat]
    );
    const extraDetails = Object.entries(extraFields || {}).filter(([, field]) => field.type !== "button" && field.visibility !== "hidden").map(([key, value2]) => ({
      key,
      value: isCustomDataObject(value2) ? value2.value : value2,
      type: isCustomDataObject(value2) ? value2.type : "text",
      config: isCustomDataObject(value2) ? value2.config : void 0
    })) || [];
    const buttonActions = T$1(() => {
      const extraActions = extraFields ? Object.values(extraFields).filter((field) => field.type === "button").map((field) => {
        var _a3, _b2, _c2;
        return {
          title: field.value,
          variant: ButtonVariant.SECONDARY,
          event: (_a3 = field.config) == null ? void 0 : _a3.action,
          classNames: ((_b2 = field == null ? void 0 : field.config) == null ? void 0 : _b2.className) ? [(_c2 = field == null ? void 0 : field.config) == null ? void 0 : _c2.className] : []
        };
      }) : [];
      const actions = [...extraActions].filter(Boolean);
      return actions;
    }, [extraFields]);
    return /* @__PURE__ */ u$1(k$1, { children: !payout ? /* @__PURE__ */ u$1(DataOverviewDetailsSkeleton$1, { skeletonRowNumber: 6 }) : /* @__PURE__ */ u$1("div", { className: PD_BASE_CLASS, children: [
      /* @__PURE__ */ u$1(
        "div",
        {
          className: cx(PD_TITLE_CLASS, {
            [PD_TITLE_CLASS_WITH_EXTRA_DETAILS]: extraDetails.length
          }),
          children: [
            /* @__PURE__ */ u$1("div", { className: PD_TITLE_CONTAINER_CLASS, children: [
              /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.SUBTITLE, stronger: true, children: i18n.get("netPayout") }),
              payout.isSumOfSameDayPayouts && /* @__PURE__ */ u$1(Tag, { variant: TagVariant.BLUE, label: i18n.get("sumOfSameDayPayouts") })
            ] }),
            /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.TITLE, large: true, children: `${i18n.amount(payout.payoutAmount.value, payout.payoutAmount.currency, {
              hideCurrency: true
            })} ${payout.payoutAmount.currency}` }),
            /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.BODY, children: creationDate }),
            /* @__PURE__ */ u$1("div", { className: PD_SECTION_CLASS, children: [
              balanceAccountDescription && /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.CAPTION, stronger: true, wide: true, children: `${balanceAccountDescription}` }),
              /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.CAPTION, className: PD_TITLE_BA_CLASS, children: `${balanceAccountId2}` })
            ] })
          ]
        }
      ),
      extraDetails && extraDetails.length > 0 ? /* @__PURE__ */ u$1("div", { children: /* @__PURE__ */ u$1(
        StructuredList,
        {
          classNames: PD_EXTRA_DETAILS_CLASS,
          items: extraDetails,
          align: "start",
          layout: "5-7",
          renderLabel: (label) => /* @__PURE__ */ u$1("div", { className: PD_EXTRA_DETAILS_LABEL, children: label }),
          renderValue: (val, key, type2, config) => {
            if (type2 === "link" && config) {
              return /* @__PURE__ */ u$1(Link, { classNames: [cx(config == null ? void 0 : config.className)], href: config.href, target: config.target || "_blank", children: val });
            }
            if (type2 === "icon" && config) {
              const icon = { url: config.src, alt: config.alt || val };
              return /* @__PURE__ */ u$1("div", { className: cx(PD_EXTRA_DETAILS_ICON, config == null ? void 0 : config.className), children: [
                /* @__PURE__ */ u$1(Icon, { ...icon }),
                /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.BODY, children: val })
              ] });
            }
            return /* @__PURE__ */ u$1(Typography$1, { className: cx(config == null ? void 0 : config.className), variant: TypographyVariant.BODY, children: val });
          }
        }
      ) }) : null,
      /* @__PURE__ */ u$1("div", { className: PD_CONTENT_CLASS, children: [
        /* @__PURE__ */ u$1("div", { className: PD_SECTION_CLASS, children: (payout == null ? void 0 : payout.fundsCapturedAmount) && (fundsCaptured2 && Object.keys(fundsCaptured2).length > 0 ? /* @__PURE__ */ u$1(
          Accordion,
          {
            header: /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.BODY, children: i18n.get("fundsCaptured") }),
            headerInformation: /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.BODY, children: i18n.amount(payout.fundsCapturedAmount.value, payout.fundsCapturedAmount.currency) }),
            children: /* @__PURE__ */ u$1("div", { className: PD_SECTION_CLASS, children: /* @__PURE__ */ u$1("div", { className: PD_CARD_CLASS, children: /* @__PURE__ */ u$1(Card, { noPadding: true, children: /* @__PURE__ */ u$1(StructuredList, { items: fundsCaptured2 }) }) }) })
          }
        ) : /* @__PURE__ */ u$1("div", { className: cx(PD_SECTION_AMOUNT_CLASS, PD_SECTION_GROSS_AMOUNT_CLASS), children: [
          /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.BODY, children: i18n.get("fundsCaptured") }),
          /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.BODY, children: i18n.amount(payout.fundsCapturedAmount.value, payout.fundsCapturedAmount.currency) })
        ] })) }),
        /* @__PURE__ */ u$1("div", { className: PD_SECTION_CLASS, children: (adjustments2 == null ? void 0 : adjustments2.subtractions) && Object.keys(adjustments2 == null ? void 0 : adjustments2.subtractions).length > 0 || (adjustments2 == null ? void 0 : adjustments2.additions) && Object.keys(adjustments2 == null ? void 0 : adjustments2.additions).length > 0 ? /* @__PURE__ */ u$1(
          Accordion,
          {
            header: /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.BODY, children: i18n.get("adjustments") }),
            headerInformation: /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.BODY, children: i18n.amount(payout.adjustmentAmount.value, payout.adjustmentAmount.currency) }),
            children: [
              (adjustments2 == null ? void 0 : adjustments2.additions) && Object.keys(adjustments2 == null ? void 0 : adjustments2.additions).length > 0 && /* @__PURE__ */ u$1("div", { className: PD_CARD_CLASS, children: /* @__PURE__ */ u$1(
                Card,
                {
                  noPadding: true,
                  renderHeader: /* @__PURE__ */ u$1(Typography$1, { className: PD_CARD_TITLE_CLASS, variant: TypographyVariant.CAPTION, stronger: true, children: i18n.get("additions") }),
                  children: /* @__PURE__ */ u$1(StructuredList, { items: adjustments2 == null ? void 0 : adjustments2.additions })
                }
              ) }),
              (adjustments2 == null ? void 0 : adjustments2.subtractions) && Object.keys(adjustments2 == null ? void 0 : adjustments2.subtractions).length > 0 && /* @__PURE__ */ u$1("div", { className: PD_CARD_CLASS, children: /* @__PURE__ */ u$1(
                Card,
                {
                  noPadding: true,
                  renderHeader: /* @__PURE__ */ u$1(Typography$1, { className: PD_CARD_TITLE_CLASS, variant: TypographyVariant.CAPTION, stronger: true, children: i18n.get("subtractions") }),
                  children: /* @__PURE__ */ u$1(StructuredList, { items: adjustments2 == null ? void 0 : adjustments2.subtractions })
                }
              ) })
            ]
          }
        ) : /* @__PURE__ */ u$1("div", { className: cx(PD_SECTION_AMOUNT_CLASS, PD_SECTION_GROSS_AMOUNT_CLASS), children: [
          /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.BODY, children: i18n.get("adjustments") }),
          /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.BODY, children: i18n.amount(payout.adjustmentAmount.value, payout.adjustmentAmount.currency) })
        ] }) }),
        /* @__PURE__ */ u$1("div", { className: cx(PD_SECTION_CLASS), children: /* @__PURE__ */ u$1("div", { className: cx(PD_SECTION_AMOUNT_CLASS, PD_SECTION_NET_AMOUNT_CLASS), children: [
          /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.BODY, stronger: true, children: i18n.get("netPayout") }),
          /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.BODY, stronger: true, children: i18n.amount(payout.payoutAmount.value, payout.payoutAmount.currency) })
        ] }) })
      ] }),
      ((_a2 = payoutData == null ? void 0 : payoutData.payout) == null ? void 0 : _a2.unpaidAmount) && /* @__PURE__ */ u$1("div", { className: PD_UNPAID_AMOUNT, children: [
        /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.BODY, children: i18n.get("remainingAmount") }),
        /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.BODY, children: i18n.amount(payoutData.payout.unpaidAmount.value, payoutData.payout.unpaidAmount.currency) })
      ] }),
      buttonActions.length ? /* @__PURE__ */ u$1("div", { className: PD_BUTTON_ACTIONS, children: /* @__PURE__ */ u$1(ButtonActions$1, { actions: buttonActions, layout: ButtonActionsLayoutBasic.BUTTONS_END }) }) : null
    ] }) });
  };
  var AlertTypeOption = /* @__PURE__ */ ((AlertTypeOption2) => {
    AlertTypeOption2["WARNING"] = "warning";
    AlertTypeOption2["CRITICAL"] = "critical";
    AlertTypeOption2["HIGHLIGHT"] = "highlight";
    AlertTypeOption2["SUCCESS"] = "success";
    return AlertTypeOption2;
  })(AlertTypeOption || {});
  var AlertVariantOption = /* @__PURE__ */ ((AlertVariantOption2) => {
    AlertVariantOption2["DEFAULT"] = "default";
    AlertVariantOption2["TIP"] = "tip";
    return AlertVariantOption2;
  })(AlertVariantOption || {});
  const AlertIcon = ({ className, type: type2 }) => {
    switch (type2) {
      case AlertTypeOption.WARNING:
        return /* @__PURE__ */ u$1(Icon$1, { name: "warning-filled", className });
      case AlertTypeOption.CRITICAL:
        return /* @__PURE__ */ u$1(Icon$1, { name: "cross-circle-fill", className });
      case AlertTypeOption.HIGHLIGHT:
        return /* @__PURE__ */ u$1(Icon$1, { name: "info-filled", className });
      case AlertTypeOption.SUCCESS:
      default:
        return /* @__PURE__ */ u$1(Icon$1, { name: "checkmark-circle-fill", className });
    }
  };
  const Alert = ({ className, description: description2, title, type: type2, children, onClose, variant = AlertVariantOption.DEFAULT }) => /* @__PURE__ */ u$1("div", { className: cx("adyen-pe-alert", `adyen-pe-alert--${type2}`, `adyen-pe-alert--${variant}`, className), role: "alert", children: [
    /* @__PURE__ */ u$1(AlertIcon, { type: type2, className: "adyen-pe-alert__icon" }),
    /* @__PURE__ */ u$1("div", { className: "adyen-pe-alert__content", children: [
      title && variant !== AlertVariantOption.TIP && /* @__PURE__ */ u$1(Typography$1, { className: "adyen-pe-alert__title", el: TypographyElement.DIV, variant: TypographyVariant.BODY, wide: true, strongest: true, children: title }),
      description2 && /* @__PURE__ */ u$1(
        Typography$1,
        {
          className: "adyen-pe-alert__description",
          el: TypographyElement.DIV,
          variant: variant !== AlertVariantOption.TIP ? TypographyVariant.CAPTION : TypographyVariant.BODY,
          wide: true,
          children: description2
        }
      ),
      children
    ] }),
    onClose && variant !== AlertVariantOption.TIP && /* @__PURE__ */ u$1("div", { className: "adyen-pe-alert__close-button", children: /* @__PURE__ */ u$1(Button$1, { iconButton: true, variant: ButtonVariant.TERTIARY, onClick: onClose, children: /* @__PURE__ */ u$1(Icon$1, { name: "cross" }) }) })
  ] });
  const PAYMENT_METHODS = Object.freeze({
    klarna: "Klarna",
    paypal: "PayPal"
  });
  function parsePaymentMethodType(paymentMethod2, format) {
    if (paymentMethod2.lastFourDigits) return format === "detail" ? "•••• •••• •••• " + paymentMethod2.lastFourDigits : paymentMethod2.lastFourDigits;
    return paymentMethod2.description || PAYMENT_METHODS[paymentMethod2.type] || paymentMethod2.type;
  }
  const getPaymentMethodType = (data) => {
    return (data == null ? void 0 : data.paymentMethod) ? data.paymentMethod.type : (data == null ? void 0 : data.bankAccount) ? "bankTransfer" : null;
  };
  const getDisplayablePaymentMethod = (data) => {
    var _a2;
    return (data == null ? void 0 : data.paymentMethod) ? parsePaymentMethodType(data.paymentMethod, "detail") : (_a2 = data == null ? void 0 : data.bankAccount) == null ? void 0 : _a2.accountNumberLastFourDigits;
  };
  const useStatusBoxData = ({ timezone: timezone2, paymentMethodData, bankAccount, amountData, createdAt }) => {
    const paymentProps = T$1(() => ({ paymentMethod: paymentMethodData, bankAccount }), [paymentMethodData, bankAccount]);
    const { i18n } = useCoreContext();
    const { dateFormat } = useTimezoneAwareDateFormatting(timezone2);
    const amount2 = T$1(() => {
      if (amountData) {
        const { currency: currency2, value: value2 } = amountData;
        return `${i18n.amount(value2, currency2, { hideCurrency: true })} ${currency2}`;
      }
    }, [amountData, i18n]);
    const paymentMethodType = T$1(() => {
      return getPaymentMethodType(paymentProps);
    }, [paymentProps]);
    const paymentMethod2 = T$1(() => {
      return getDisplayablePaymentMethod(paymentProps);
    }, [paymentProps]);
    const date2 = T$1(() => {
      return createdAt && dateFormat(new Date(createdAt), DATE_FORMAT_TRANSACTION_DETAILS);
    }, [createdAt, dateFormat]);
    return { amount: amount2, date: date2, paymentMethod: paymentMethod2, paymentMethodType };
  };
  var ActiveView = /* @__PURE__ */ ((ActiveView2) => {
    ActiveView2[ActiveView2["DETAILS"] = 0] = "DETAILS";
    ActiveView2[ActiveView2["REFUND"] = 1] = "REFUND";
    ActiveView2[ActiveView2["REFUND_SUCCESS"] = 2] = "REFUND_SUCCESS";
    ActiveView2[ActiveView2["REFUND_ERROR"] = 3] = "REFUND_ERROR";
    return ActiveView2;
  })(ActiveView || {});
  var RefundedState = /* @__PURE__ */ ((RefundedState2) => {
    RefundedState2[RefundedState2["INDETERMINATE"] = 0] = "INDETERMINATE";
    RefundedState2[RefundedState2["PARTIAL"] = 1] = "PARTIAL";
    RefundedState2[RefundedState2["FULL"] = 2] = "FULL";
    return RefundedState2;
  })(RefundedState || {});
  var RefundMode = /* @__PURE__ */ ((RefundMode2) => {
    RefundMode2["NON_REFUNDABLE"] = "non_refundable";
    RefundMode2["PARTIAL_AMOUNT"] = "partially_refundable_any_amount";
    RefundMode2["PARTIAL_LINE_ITEMS"] = "partially_refundable_with_line_items_required";
    RefundMode2["FULL_AMOUNT"] = "fully_refundable_only";
    return RefundMode2;
  })(RefundMode || {});
  var RefundStatus = /* @__PURE__ */ ((RefundStatus2) => {
    RefundStatus2["IN_PROGRESS"] = "in_progress";
    RefundStatus2["COMPLETED"] = "completed";
    RefundStatus2["FAILED"] = "failed";
    return RefundStatus2;
  })(RefundStatus || {});
  var RefundType = /* @__PURE__ */ ((RefundType2) => {
    RefundType2["PARTIAL"] = "partial";
    RefundType2["FULL"] = "full";
    return RefundType2;
  })(RefundType || {});
  const TransactionDetailsContext = K$1({
    availableItems: EMPTY_ARRAY,
    primaryAction: noop,
    secondaryAction: noop,
    transaction: EMPTY_OBJECT,
    extraFields: EMPTY_OBJECT,
    dataCustomization: EMPTY_OBJECT
  });
  const TransactionDetailsProvider = M(
    ({
      children,
      lineItems,
      refundAvailable: primaryActionAvailable,
      refundDisabled,
      setActiveView,
      setPrimaryAction,
      setSecondaryAction,
      transaction,
      transactionNavigator,
      extraFields,
      dataCustomization
    }) => {
      const { i18n } = useCoreContext();
      const { currentTransaction, canNavigateBackward, canNavigateForward, backward, forward } = transactionNavigator;
      const primaryActionLabel = T$1(() => ({ title: i18n.get("refundAction") }), [i18n]);
      const primaryActionDisabled = T$1(() => !primaryActionAvailable || refundDisabled, [primaryActionAvailable, refundDisabled]);
      const primaryAction = q$1(
        () => void (!primaryActionDisabled && setActiveView(ActiveView.REFUND)),
        [primaryActionDisabled, setActiveView]
      );
      const _secondaryAction = T$1(() => {
        if (currentTransaction !== transaction.id) return;
        if (canNavigateBackward) return 2;
        if (canNavigateForward) return 1;
      }, [canNavigateBackward, canNavigateForward, currentTransaction, transaction]);
      const secondaryAction = q$1(() => {
        switch (_secondaryAction) {
          case 2:
            return void backward();
          case 1:
            return void forward();
        }
      }, [_secondaryAction, backward, forward]);
      const secondaryActionLabel = T$1(() => {
        switch (_secondaryAction) {
          case 2:
            return {
              title: i18n.get("refund.returnToRefund"),
              renderTitle: (title) => /* @__PURE__ */ u$1(k$1, { children: [
                /* @__PURE__ */ u$1(Icon$1, { style: { transform: "scaleX(-1)" }, name: "angle-right" }),
                /* @__PURE__ */ u$1("span", { children: title })
              ] })
            };
          case 1:
            return {
              title: i18n.get("refund.goToPayment"),
              renderTitle: (title) => /* @__PURE__ */ u$1(k$1, { children: [
                /* @__PURE__ */ u$1(Icon$1, { name: "angle-right" }),
                /* @__PURE__ */ u$1("span", { children: title })
              ] })
            };
        }
      }, [_secondaryAction, i18n]);
      y(() => {
        setPrimaryAction(
          primaryActionAvailable ? Object.freeze({
            disabled: primaryActionDisabled,
            event: primaryAction,
            variant: ButtonVariant.PRIMARY,
            ...primaryActionLabel
          }) : void 0
        );
      }, [primaryAction, primaryActionAvailable, primaryActionDisabled, primaryActionLabel, setPrimaryAction]);
      y(() => {
        setSecondaryAction(
          _secondaryAction && secondaryActionLabel ? Object.freeze({
            disabled: false,
            event: secondaryAction,
            variant: ButtonVariant.SECONDARY,
            ...secondaryActionLabel
          }) : void 0
        );
      }, [_secondaryAction, secondaryAction, secondaryActionLabel, setSecondaryAction]);
      return /* @__PURE__ */ u$1(
        TransactionDetailsContext.Provider,
        {
          value: { availableItems: lineItems, primaryAction, secondaryAction, transaction, extraFields, dataCustomization },
          children
        }
      );
    }
  );
  const useTransactionDetailsContext = () => x(TransactionDetailsContext);
  const REFUND_REASONS = Object.freeze(["requested_by_customer", "issue_with_item_sold", "fraudulent", "duplicate", "other"]);
  const useRefundAction = ({
    refundAmount: amount2,
    refundReason: refundReason2,
    refundInProgress,
    refundTransaction,
    setActiveView,
    transactionId
  }) => {
    const { i18n } = useCoreContext();
    const refundAmountLabel = T$1(() => {
      const formattedAmount = i18n.amount(amount2.value, amount2.currency);
      return { title: i18n.get("refundPayment", { values: { amount: formattedAmount } }) };
    }, [amount2, i18n]);
    const refundPaymentLabel = T$1(() => {
      return { title: i18n.get("refundAction") };
    }, [i18n]);
    const refundingPaymentLabel = T$1(
      () => ({
        title: `${i18n.get("inProgress")}..`,
        state: "loading"
      }),
      [i18n]
    );
    const refundParams = T$1(
      () => ({
        path: { transactionId }
      }),
      [transactionId]
    );
    const refundPayload = T$1(
      () => ({
        amount: amount2,
        refundReason: refundReason2
        // ...(refundMode === RefundMode.PARTIAL_LINE_ITEMS && { lineItems: [] }),
      }),
      [amount2, refundReason2]
    );
    const refundAction2 = q$1(
      // [TODO]: Fix broken/missing type inference for useMutation mutate()
      () => refundTransaction == null ? void 0 : refundTransaction(
        {
          body: refundPayload,
          contentType: "application/json"
        },
        refundParams
      ).then(() => {
        setActiveView(ActiveView.REFUND_SUCCESS);
      }).catch(() => {
        setActiveView(ActiveView.REFUND_ERROR);
      }),
      [refundTransaction, refundParams, refundPayload, setActiveView]
    );
    const refundActionLabel = T$1(() => {
      if (refundInProgress) return refundingPaymentLabel;
      if (amount2.value > 0) return refundAmountLabel;
      return refundPaymentLabel;
    }, [amount2, refundInProgress, refundAmountLabel, refundPaymentLabel, refundingPaymentLabel]);
    return { refundAction: refundAction2, refundActionLabel };
  };
  const useRefundContextActions = ({
    interactionsDisabled,
    refundAmount: refundAmount2,
    setActiveView,
    setPrimaryAction,
    setSecondaryAction,
    ...refundActionProps
  }) => {
    const { refundAction: refundAction2, refundActionLabel: primaryActionLabel } = useRefundAction({ ...refundActionProps, refundAmount: refundAmount2, setActiveView });
    const { i18n } = useCoreContext();
    const primaryActionDisabled = T$1(() => interactionsDisabled || refundAmount2.value <= 0, [refundAmount2, interactionsDisabled]);
    const primaryAction = q$1(() => !primaryActionDisabled && refundAction2(), [primaryActionDisabled, refundAction2]);
    const secondaryActionDisabled = interactionsDisabled;
    const secondaryActionLabel = T$1(() => i18n.get("back"), [i18n]);
    const secondaryAction = q$1(
      () => void (!secondaryActionDisabled && setActiveView(ActiveView.DETAILS)),
      [secondaryActionDisabled, setActiveView]
    );
    y(() => {
      setPrimaryAction(
        Object.freeze({
          disabled: primaryActionDisabled,
          event: primaryAction,
          variant: ButtonVariant.PRIMARY,
          ...primaryActionLabel
        })
      );
    }, [primaryAction, primaryActionDisabled, primaryActionLabel, setPrimaryAction]);
    y(() => {
      setSecondaryAction(
        Object.freeze({
          disabled: secondaryActionDisabled,
          event: secondaryAction,
          title: secondaryActionLabel,
          variant: ButtonVariant.SECONDARY
        })
      );
    }, [secondaryAction, secondaryActionDisabled, secondaryActionLabel, setSecondaryAction]);
    return { primaryAction, secondaryAction };
  };
  const useRefundContextAmount = ({
    availableAmount,
    currency: currency2,
    interactionsDisabled,
    items,
    refundMode
  }) => {
    const [refundAmount2, setRefundAmount] = d(0);
    const _amount = T$1(() => {
      switch (refundMode) {
        case RefundMode.NON_REFUNDABLE:
          return 0;
        case RefundMode.PARTIAL_LINE_ITEMS:
        case RefundMode.PARTIAL_AMOUNT:
          return refundAmount2;
        // case RefundMode.PARTIAL_LINE_ITEMS:
        //     return items.reduce((total, { amount, quantity }) => total + amount * quantity, 0);
        case RefundMode.FULL_AMOUNT:
        default:
          return availableAmount;
      }
    }, [availableAmount, items, refundMode, refundAmount2]);
    const amount2 = T$1(() => Object.freeze({ currency: currency2, value: _amount }), [_amount, currency2]);
    const canSetRefundAmount = T$1(() => !interactionsDisabled && refundMode === RefundMode.PARTIAL_AMOUNT, [interactionsDisabled, refundMode]);
    const setAmount = q$1(
      (amount22) => void (canSetRefundAmount && setRefundAmount(clamp(0, amount22, availableAmount))),
      [availableAmount, canSetRefundAmount]
    );
    y(() => {
      setRefundAmount(availableAmount);
    }, [availableAmount]);
    return [amount2, setAmount];
  };
  const _updateRefundItemQuantity = (refundableItems, nextRefundItems, refundItem, refundQuantity = 0) => {
    const { ...refundableItem } = refundableItems.get(refundItem.id);
    const quantity = clamp(0, Math.trunc(refundQuantity), refundableItem.quantity += refundItem.quantity);
    refundableItem.quantity -= quantity;
    refundableItems.set(refundItem.id, Object.freeze(refundableItem));
    if (quantity > 0) nextRefundItems.push(Object.freeze({ ...refundableItem, quantity }));
  };
  const updateRefundItems = (refundableItems, currentRefundItems, refundItemUpdates = EMPTY_ARRAY) => {
    const refundQuantities = new Map((refundItemUpdates == null ? void 0 : refundItemUpdates.map(({ id: id2, quantity }) => [id2, quantity])) ?? EMPTY_ARRAY);
    const nextRefundItems = [];
    currentRefundItems.forEach((item) => {
      const refundQuantity = refundQuantities.get(item.id);
      if (isUndefined(refundQuantity)) {
        nextRefundItems.push(item);
      } else if (refundQuantities.delete(item.id)) {
        _updateRefundItemQuantity(refundableItems, nextRefundItems, item, refundQuantity);
      }
    });
    refundQuantities.forEach((refundQuantity, id2) => {
      _updateRefundItemQuantity(refundableItems, nextRefundItems, { id: id2, quantity: 0 }, refundQuantity);
    });
    return nextRefundItems.length > 0 ? Object.freeze(nextRefundItems) : EMPTY_ARRAY;
  };
  const useRefundContextLineItems = ({ currency: currency2, lineItems }) => {
    const [items, setItems] = d(EMPTY_ARRAY);
    const refundableItems = T$1(() => {
      const items2 = lineItems == null ? void 0 : lineItems.filter((item) => {
        if (item.amountIncludingTax.currency !== currency2) return;
        const qty = item.availableQuantity;
        return qty > 0 && Number.isFinite(qty) && Math.trunc(qty) === qty;
      }).map(
        ({ id: id2, ...item }) => [
          id2,
          Object.freeze({
            amount: item.amountIncludingTax.value,
            quantity: item.availableQuantity,
            id: id2
          })
        ]
      );
      return new Map(items2 ?? EMPTY_ARRAY);
    }, [currency2, lineItems]);
    const availableItems = T$1(
      () => (lineItems == null ? void 0 : lineItems.filter(({ id: id2 }) => refundableItems.has(id2))) ?? EMPTY_ARRAY,
      [items, lineItems, refundableItems]
    );
    const clearItems = q$1(
      function(ids) {
        setItems((items2) => {
          const _items = arguments.length === 0 ? new Map(items2.map(({ id: id2 }) => [id2, 0])) : new Map((ids == null ? void 0 : ids.map((id2) => [id2, 0])) ?? EMPTY_ARRAY);
          const itemUpdates = [..._items].map(([id2, quantity]) => ({ id: id2, quantity }));
          return updateRefundItems(refundableItems, items2, itemUpdates);
        });
      },
      [refundableItems]
    );
    const updateItems = q$1(
      (itemUpdates) => setItems((items2) => updateRefundItems(refundableItems, items2, itemUpdates)),
      [refundableItems]
    );
    return { availableItems, clearItems, items, updateItems };
  };
  const useRefundContextReason = ({ interactionsDisabled, refundMode }) => {
    const [refundReason2, setReason] = d(REFUND_REASONS[0]);
    const canSetRefundReason = T$1(
      // [TODO]: Remove refund mode check here and use the `refundable` field from `useTransactionRefundMetadata`
      () => !interactionsDisabled && refundMode !== RefundMode.NON_REFUNDABLE,
      [interactionsDisabled, refundMode]
    );
    const setRefundReason = q$1(
      (reason) => void (canSetRefundReason && setReason(reason)),
      [canSetRefundReason]
    );
    return [refundReason2, setRefundReason];
  };
  const catchCallback = (reason) => {
    setTimeout(() => {
      throw reason;
    }, 0);
  };
  function useMutation({
    queryFn,
    options
  }) {
    const { retry = false, retryDelay = 1e3, onSuccess, onError, onSettled, shouldRetry } = options || EMPTY_OBJECT;
    const [data, setData] = d(null);
    const [error, setError] = d(null);
    const [status2, setStatus] = d("idle");
    const mountedRef = A$1(true);
    const retryCountRef = A$1(0);
    const reset2 = q$1(() => {
      setData(null);
      setError(null);
      setStatus("idle");
      retryCountRef.current = 0;
    }, []);
    const resetRetries = q$1(() => {
      retryCountRef.current = 0;
    }, []);
    const mutate = q$1(
      async (...variables) => {
        try {
          setStatus("loading");
          setError(null);
          const result = await (queryFn == null ? void 0 : queryFn(...variables));
          if (mountedRef.current) {
            setData(result);
            setStatus("success");
          }
          ALREADY_RESOLVED_PROMISE.then(() => {
            onSuccess && tryResolve(onSuccess, result).catch(catchCallback);
            onSettled && tryResolve(onSettled, result, null).catch(catchCallback);
            resetRetries();
          });
          return result;
        } catch (error2) {
          let maxRetries = 0;
          if (isNumber(retry) && (shouldRetry ? shouldRetry(error2) : true)) {
            maxRetries = Math.max(0, Math.floor(retry));
          } else {
            maxRetries = 0;
          }
          if (retryCountRef.current++ < maxRetries) {
            const delay = isFunction(retryDelay) ? retryDelay(retryCountRef.current) : retryDelay ?? 1e3;
            await new Promise((resolve) => setTimeout(resolve, delay));
            return mutate(...variables);
          }
          if (mountedRef.current) {
            setError(error2);
            setStatus("error");
          }
          ALREADY_RESOLVED_PROMISE.then(() => {
            onError && tryResolve(onError, error2).catch(catchCallback);
            onSettled && tryResolve(onSettled, void 0, error2).catch(catchCallback);
            resetRetries();
          });
          throw error2;
        }
      },
      [queryFn, onSuccess, onSettled, retry, shouldRetry, retryDelay, resetRetries, onError]
    );
    y(() => {
      return () => {
        mountedRef.current = false;
      };
    }, []);
    return T$1(
      () => ({
        data,
        error,
        status: status2,
        isIdle: status2 === "idle",
        isLoading: status2 === "loading",
        isSuccess: status2 === "success",
        isError: status2 === "error",
        mutate,
        reset: reset2
      }),
      [data, error, status2, mutate, reset2]
    );
  }
  const TransactionRefundContext = K$1({
    amount: 0,
    availableAmount: 0,
    availableItems: EMPTY_ARRAY,
    clearItems: noop,
    currency: "",
    interactionsDisabled: false,
    items: EMPTY_ARRAY,
    primaryAction: noop,
    refundMode: RefundMode.FULL_AMOUNT,
    refundReason: REFUND_REASONS[0],
    secondaryAction: noop,
    setAmount: noop,
    setRefundReason: noop,
    transactionId: "",
    updateItems: noop
  });
  const TransactionRefundProvider = M(
    ({
      availableAmount,
      children,
      currency: currency2,
      lineItems,
      refreshTransaction,
      refundMode,
      setActiveView,
      setPrimaryAction,
      setSecondaryAction,
      transactionId
    }) => {
      const { isLoading: refundInProgress, mutate: refundTransaction } = useMutation({
        queryFn: useConfigContext().endpoints.initiateRefund
      });
      const { availableItems, clearItems, items, updateItems } = useRefundContextLineItems({ currency: currency2, lineItems });
      const interactionsDisabled = refundInProgress;
      const [refundAmount2, setAmount] = useRefundContextAmount({ availableAmount, currency: currency2, interactionsDisabled, items, refundMode });
      const [refundReason2, setRefundReason] = useRefundContextReason({ interactionsDisabled, refundMode });
      const { value: amount2 } = refundAmount2;
      const { primaryAction, secondaryAction } = useRefundContextActions({
        interactionsDisabled,
        refreshTransaction,
        refundAmount: refundAmount2,
        refundInProgress,
        refundReason: refundReason2,
        refundTransaction,
        setActiveView,
        setPrimaryAction,
        setSecondaryAction,
        transactionId
      });
      return /* @__PURE__ */ u$1(
        TransactionRefundContext.Provider,
        {
          value: {
            amount: amount2,
            availableAmount,
            availableItems,
            clearItems,
            currency: currency2,
            interactionsDisabled,
            items,
            primaryAction,
            refundMode,
            refundReason: refundReason2,
            secondaryAction,
            setAmount,
            setRefundReason,
            transactionId,
            updateItems
          },
          children
        }
      );
    }
  );
  const useTransactionRefundContext = () => x(TransactionRefundContext);
  const createDuplexTransactionNavigator = () => {
    let [currentTransactionId, previousTransactionId, fromTransactionId, toTransactionId] = EMPTY_ARRAY;
    const canNavigateBackward = () => !!(currentTransactionId && currentTransactionId === toTransactionId && fromTransactionId);
    const canNavigateForward = () => !!(currentTransactionId && currentTransactionId === fromTransactionId && toTransactionId);
    let onNavigation = null;
    const backward = () => {
      if (canNavigateBackward()) {
        previousTransactionId = currentTransactionId;
        currentTransactionId = fromTransactionId;
        triggerNavigationCallback();
      }
    };
    const forward = () => {
      if (canNavigateForward()) {
        previousTransactionId = currentTransactionId;
        currentTransactionId = toTransactionId;
        triggerNavigationCallback();
      }
    };
    const reset2 = (_fromTransactionId, _toTransactionId) => {
      const cachedCurrentTransactionId = currentTransactionId;
      currentTransactionId = previousTransactionId = fromTransactionId = toTransactionId = void 0;
      if (!isEmptyString(_fromTransactionId) && !isEmptyString(_toTransactionId)) {
        fromTransactionId = _fromTransactionId;
        toTransactionId = _toTransactionId;
        currentTransactionId = cachedCurrentTransactionId === fromTransactionId || cachedCurrentTransactionId === toTransactionId ? cachedCurrentTransactionId : fromTransactionId;
        if (cachedCurrentTransactionId !== currentTransactionId) triggerNavigationCallback();
      }
    };
    const setNavigationCallback = (callback) => {
      if (isNullish(callback)) {
        onNavigation = null;
      } else if (isFunction(callback) && onNavigation !== (onNavigation = callback)) {
        triggerNavigationCallback();
      }
    };
    const triggerNavigationCallback = () => {
      const from2 = previousTransactionId;
      const to2 = currentTransactionId;
      previousTransactionId = void 0;
      onNavigation == null ? void 0 : onNavigation(
        struct({
          from: getter(() => from2),
          to: getter(() => to2)
        })
      );
    };
    return struct({
      backward: enumerable(backward),
      forward: enumerable(forward),
      canNavigateBackward: getter(canNavigateBackward),
      canNavigateForward: getter(canNavigateForward),
      currentTransaction: getter(() => currentTransactionId),
      onNavigation: { set: setNavigationCallback },
      reset: enumerable(reset2)
    });
  };
  const useTransaction = (initialTransaction) => {
    const [transaction, setTransaction] = d(initialTransaction);
    const [fetchTransactionId, setFetchTransactionId] = d(initialTransaction.id);
    const [lastFetchTimestamp, setLastFetchTimestamp] = d(performance.now());
    const { getTransaction } = useConfigContext().endpoints;
    const _transactionNavigator = A$1(createDuplexTransactionNavigator());
    const transactionNavigator = _transactionNavigator.current;
    const navigationAction = A$1(false);
    const cachedIsFetching = A$1(false);
    const cachedInitialTransaction = A$1(initialTransaction);
    const lastFetchTransactionId = A$1(fetchTransactionId);
    const fetchEnabled = T$1(() => !!getTransaction && !!fetchTransactionId && navigationAction.current, [fetchTransactionId, getTransaction]);
    const queryFn = q$1(
      () => getTransaction(EMPTY_OBJECT, {
        path: { transactionId: fetchTransactionId }
      }),
      [fetchTransactionId, getTransaction]
    );
    const {
      data,
      error,
      isFetching: fetchingTransaction
    } = useFetch({
      fetchOptions: { enabled: fetchEnabled },
      queryFn
    });
    const refreshTransaction = q$1(() => {
      return setFetchTransactionId(void 0);
    }, []);
    y(() => {
      if (!fetchTransactionId) setFetchTransactionId(transaction.id);
    }, [fetchTransactionId, transaction]);
    y(() => {
      var _a2;
      const navigator2 = _transactionNavigator.current;
      const transaction2 = cachedInitialTransaction.current;
      if (transaction2.category === "Refund") {
        navigator2.reset(transaction2.id, (_a2 = transaction2.refundMetadata) == null ? void 0 : _a2.originalPaymentId);
        navigator2.onNavigation = ({ to: id2 }) => {
          navigationAction.current = true;
          setLastFetchTimestamp(performance.now());
          if (id2) setFetchTransactionId(id2);
        };
      }
      return () => {
        navigationAction.current = false;
        navigator2.onNavigation = null;
        navigator2.reset();
      };
    }, []);
    y(() => {
      if (cachedIsFetching.current === fetchingTransaction) return;
      if (cachedIsFetching.current = fetchingTransaction) return;
      if (!data || error) {
        setFetchTransactionId(lastFetchTransactionId.current);
      } else {
        const initialTransaction2 = cachedInitialTransaction.current;
        setTransaction(() => ({
          ...data.id === initialTransaction2.id ? initialTransaction2 : EMPTY_OBJECT,
          ...data
        }));
        lastFetchTransactionId.current = fetchTransactionId;
      }
    }, [data, error, fetchingTransaction, fetchTransactionId, lastFetchTimestamp]);
    return { fetchingTransaction, refreshTransaction, transaction, transactionNavigator };
  };
  const checkRefundStatusCollection = (predicate, refundStatusCollection) => {
    let every = refundStatusCollection ? (refundStatusCollection == null ? void 0 : refundStatusCollection.length) > 0 : false;
    let some2 = false;
    refundStatusCollection == null ? void 0 : refundStatusCollection.forEach((item) => {
      const passesCheck = !!predicate(item);
      every && (every = passesCheck);
      some2 || (some2 = passesCheck);
    });
    return { every, some: some2 };
  };
  const allStatuses = ["completed", "in_progress", "failed"];
  const useTransactionRefundMetadata = (transaction) => {
    var _a2, _b2, _c2;
    const { i18n } = useCoreContext();
    const details = transaction == null ? void 0 : transaction.refundDetails;
    const refundMode = (details == null ? void 0 : details.refundMode) ?? RefundMode.FULL_AMOUNT;
    const refundLocked = boolOrFalse(details == null ? void 0 : details.refundLocked);
    const refundable = refundMode !== RefundMode.NON_REFUNDABLE;
    const originalAmount = (_a2 = transaction == null ? void 0 : transaction.originalAmount) == null ? void 0 : _a2.value;
    const refundableAmount = T$1(() => {
      var _a3;
      return transaction ? Math.max(0, ((_a3 = details == null ? void 0 : details.refundableAmount) == null ? void 0 : _a3.value) ?? 0) : 0;
    }, [details, transaction]);
    const refundAuthorization = isFunction(useConfigContext().endpoints.initiateRefund);
    const refundAvailable = refundAuthorization && refundable && refundableAmount > 0;
    const refundCurrency = ((_b2 = details == null ? void 0 : details.refundableAmount) == null ? void 0 : _b2.currency) ?? (transaction == null ? void 0 : transaction.amount.currency) ?? "";
    const refundDisabled = !refundAvailable || refundLocked;
    const statuses = T$1(() => {
      var _a3;
      const statusDetails = ((_a3 = transaction == null ? void 0 : transaction.refundDetails) == null ? void 0 : _a3.refundStatuses) ?? [];
      return (statusDetails == null ? void 0 : statusDetails.filter((currentStatus) => currentStatus.amount.value !== 0).sort((firstStatus, secondStatus) => {
        if (allStatuses.includes(firstStatus.status) && allStatuses.includes(secondStatus.status)) {
          return allStatuses.indexOf(firstStatus.status) > allStatuses.indexOf(secondStatus.status) ? 0 : -1;
        }
        return -1;
      }).reduce((res, currentStatusValue) => {
        var _a4;
        const currentStatus = currentStatusValue.status;
        const amount2 = ~currentStatusValue.amount.value + 1;
        if (res == null ? void 0 : res[currentStatus]) {
          (_a4 = res == null ? void 0 : res[currentStatus]) == null ? void 0 : _a4.amounts.push(amount2);
          return res;
        } else {
          return { ...res, [currentStatus]: { amounts: [amount2], currency: currentStatusValue.amount.currency } };
        }
      }, {})) ?? {};
    }, [(_c2 = transaction == null ? void 0 : transaction.refundDetails) == null ? void 0 : _c2.refundStatuses]);
    const refundedAmount = T$1(() => {
      var _a3, _b3;
      const totalCompleted = (_b3 = (_a3 = statuses.completed) == null ? void 0 : _a3.amounts) == null ? void 0 : _b3.reduce((sum, amount2) => sum + amount2, 0);
      return totalCompleted ? Math.max(0, totalCompleted ?? 0) : 0;
    }, [statuses]);
    const { some: someRefunded, every: allRefunded } = T$1(
      () => checkRefundStatusCollection(({ status: status2 }) => status2 === RefundStatus.COMPLETED, details == null ? void 0 : details.refundStatuses),
      [details == null ? void 0 : details.refundStatuses]
    );
    const refundStatuses = T$1(() => {
      var _a3;
      if (refundableAmount === 0 && refundedAmount > 0 && allRefunded && refundedAmount === originalAmount) {
        return [{ type: AlertTypeOption.HIGHLIGHT, label: i18n.get("refund.fullAmountRefunded") }];
      } else {
        const statusAlerts = (_a3 = Object.keys(statuses)) == null ? void 0 : _a3.map((status2) => {
          var _a4, _b3;
          const currentStatus = status2;
          const formattedAmount = (_a4 = statuses == null ? void 0 : statuses[currentStatus]) == null ? void 0 : _a4.amounts.reduce((res, value2, currentIndex) => {
            var _a5, _b4, _c3;
            const amountsLength = (_a5 = statuses == null ? void 0 : statuses[currentStatus]) == null ? void 0 : _a5.amounts.length;
            if (amountsLength > 1 && currentIndex === amountsLength - 1)
              return `${res ? `${res}` : ""} ${i18n.get("and")} ${i18n.amount(value2, (_b4 = statuses == null ? void 0 : statuses[currentStatus]) == null ? void 0 : _b4.currency)}`;
            return `${res ? `${res},` : ""} ${i18n.amount(value2, (_c3 = statuses == null ? void 0 : statuses[currentStatus]) == null ? void 0 : _c3.currency)}`;
          }, "");
          const totalAmount = (_b3 = statuses == null ? void 0 : statuses[currentStatus]) == null ? void 0 : _b3.amounts.reduce((sum, amount2) => sum + amount2, 0);
          switch (status2) {
            case RefundStatus.COMPLETED:
              return {
                type: AlertTypeOption.HIGHLIGHT,
                label: i18n.get("refund.amountAlreadyRefunded", { values: { amount: formattedAmount } })
              };
            case RefundStatus.IN_PROGRESS:
              if (totalAmount === originalAmount) {
                return {
                  type: AlertTypeOption.HIGHLIGHT,
                  label: i18n.get("refund.theRefundIsBeingProcessed")
                };
              } else {
                return {
                  type: AlertTypeOption.HIGHLIGHT,
                  label: i18n.get("refund.amountInProgress", { values: { amount: formattedAmount } })
                };
              }
            case RefundStatus.FAILED:
              if (totalAmount === originalAmount) {
                return {
                  type: AlertTypeOption.WARNING,
                  label: i18n.get("refund.fullAmountFailed")
                };
              } else {
                return {
                  type: AlertTypeOption.WARNING,
                  label: i18n.get("refund.amountFailed", { values: { amount: formattedAmount } })
                };
              }
            default:
              return;
          }
        });
        return statusAlerts ?? [];
      }
    }, [refundableAmount, originalAmount, i18n, refundedAmount, statuses, allRefunded]);
    const refundableAmountLabel = T$1(() => {
      if (refundableAmount > 0) {
        const formattedAmount = i18n.amount(refundableAmount, refundCurrency);
        switch (refundMode) {
          case RefundMode.FULL_AMOUNT:
            return {
              type: AlertTypeOption.HIGHLIGHT,
              description: i18n.get("refund.onlyRefundable", { values: { amount: formattedAmount } })
            };
          case RefundMode.PARTIAL_AMOUNT:
            return {
              type: AlertTypeOption.HIGHLIGHT,
              description: i18n.get("refund.maximumRefundable", { values: { amount: formattedAmount } })
            };
          default:
            return null;
        }
      }
      return null;
    }, [i18n, refundableAmount, refundCurrency, refundMode]);
    const refundedState = T$1(() => {
      switch (refundMode) {
        case RefundMode.NON_REFUNDABLE:
          if (refundableAmount === 0 && refundedAmount > 0 && allRefunded && refundedAmount === originalAmount) {
            return RefundedState.FULL;
          }
      }
      switch (refundMode) {
        case RefundMode.PARTIAL_AMOUNT:
        case RefundMode.PARTIAL_LINE_ITEMS:
          if (refundableAmount > 0 && someRefunded && refundedAmount > 0 && !isUndefined(originalAmount) && refundedAmount < originalAmount) {
            return RefundedState.PARTIAL;
          }
      }
      return RefundedState.INDETERMINATE;
    }, [refundableAmount, refundedAmount, refundMode, originalAmount, someRefunded, allRefunded]);
    return {
      refundableAmount,
      // the maximum amount still available for refund
      refundable,
      // whether the refund mode of the payment allows for refund
      refundableAmountLabel,
      refundAvailable,
      // whether a refund can be initiated for the payment
      refundAuthorization,
      // whether the authenticated user has sufficient permission to initiate refunds
      refundCurrency,
      // the payment currency for any initiated refund
      refundDisabled,
      // whether refund action for the payment is disabled (refund view should be prevented)
      refundedAmount,
      // the total amount already refunded
      refundedState,
      // whether the payment is yet to be, partially or fully refunded
      refundStatuses,
      //the refund statuses
      refundLocked,
      // whether refund action for the payment is temporarily locked
      refundMode
      // the refund mode of the payment
    };
  };
  const DEFAULT_POPOVER_CLASSNAME = "adyen-pe-popover";
  const DEFAULT_TOOLTIP_CLASSNAME = "adyen-pe-tooltip";
  const POPOVER_CONTAINER_CLASSNAME = `${DEFAULT_POPOVER_CLASSNAME}-container`;
  const POPOVER_HEADER_CLASSNAME = `${DEFAULT_POPOVER_CLASSNAME}__header`;
  const POPOVER_HEADER_TITLE_CLASSNAME = `${DEFAULT_POPOVER_CLASSNAME}__header-title`;
  const POPOVER_CONTENT_CLASSNAME = `${DEFAULT_POPOVER_CLASSNAME}__content`;
  const TOOLTIP_CONTENT_CLASSNAME = `${DEFAULT_TOOLTIP_CLASSNAME}__content`;
  const POPOVER_FOOTER_CLASSNAME = `${DEFAULT_POPOVER_CLASSNAME}__footer`;
  function PopoverDismissButton({ image = true, onClick }) {
    const { i18n } = useCoreContext();
    const getConditionalClasses = () => {
      return image ? "adyen-pe-popover-dismiss-button--on-image" : "";
    };
    return /* @__PURE__ */ u$1(k$1, { children: /* @__PURE__ */ u$1(
      Button$1,
      {
        className: getConditionalClasses(),
        iconButton: true,
        variant: ButtonVariant.TERTIARY,
        onClick,
        "aria-label": i18n.get("closeIconLabel"),
        children: /* @__PURE__ */ u$1("svg", { role: "img", xmlns: "http://www.w3.org/2000/svg", width: "16", height: "16", fill: "none", children: [
          /* @__PURE__ */ u$1("title", { children: "dismiss" }),
          /* @__PURE__ */ u$1(
            "path",
            {
              fill: "#00112C",
              fillRule: "evenodd",
              d: "M11.4697 12.5303C11.7626 12.8232 12.2374 12.8232 12.5303 12.5303C12.8232 12.2374 12.8232 11.7626 12.5303 11.4697L9.06066 8L12.5303 4.53033C12.8232 4.23744 12.8232 3.76256 12.5303 3.46967C12.2374 3.17678 11.7626 3.17678 11.4697 3.46967L8 6.93934L4.53033 3.46967C4.23744 3.17678 3.76256 3.17678 3.46967 3.46967C3.17678 3.76256 3.17678 4.23744 3.46967 4.53033L6.93934 8L3.46967 11.4697C3.17678 11.7626 3.17678 12.2374 3.46967 12.5303C3.76256 12.8232 4.23744 12.8232 4.53033 12.5303L8 9.06066L11.4697 12.5303Z",
              clipRule: "evenodd"
            }
          )
        ] })
      }
    ) });
  }
  const PopoverDismissButton$1 = M(PopoverDismissButton);
  function PopoverTitle({ title, isImageTitle = false }) {
    const getVariant = () => {
      return isImageTitle ? TypographyVariant.SUBTITLE : TypographyVariant.BODY;
    };
    return /* @__PURE__ */ u$1(Typography$1, { strongest: !isImageTitle, variant: getVariant(), children: title });
  }
  const PopoverTitle$1 = M(PopoverTitle);
  var PopoverContainerVariant = /* @__PURE__ */ ((PopoverContainerVariant2) => {
    PopoverContainerVariant2["TOOLTIP"] = "tooltip";
    PopoverContainerVariant2["POPOVER"] = "popover";
    return PopoverContainerVariant2;
  })(PopoverContainerVariant || {});
  var PopoverContainerPosition = /* @__PURE__ */ ((PopoverContainerPosition2) => {
    PopoverContainerPosition2["TOP"] = "top";
    PopoverContainerPosition2["RIGHT"] = "right";
    PopoverContainerPosition2["BOTTOM"] = "bottom";
    PopoverContainerPosition2["LEFT"] = "left";
    PopoverContainerPosition2["TOP_LEFT"] = "top-left";
    PopoverContainerPosition2["TOP_RIGHT"] = "top-right";
    PopoverContainerPosition2["BOTTOM_LEFT"] = "bottom-left";
    PopoverContainerPosition2["BOTTOM_RIGHT"] = "bottom-right";
    return PopoverContainerPosition2;
  })(PopoverContainerPosition || {});
  var PopoverContainerSize = /* @__PURE__ */ ((PopoverContainerSize2) => {
    PopoverContainerSize2["MEDIUM"] = "medium";
    PopoverContainerSize2["WIDE"] = "wide";
    return PopoverContainerSize2;
  })(PopoverContainerSize || {});
  const popoverUtil = /* @__PURE__ */ (() => {
    let popoverRefs = [];
    const closePopoversOutsideOfClick = (eventPath) => {
      const index = eventPath.reduce((index2, path) => {
        const pathMatchIndex = path instanceof Node ? popoverRefs.findIndex((popoverRef) => {
          const popoverRefId = popoverRef.element.getAttribute("id");
          const pathId = path && (path == null ? void 0 : path.getAttribute) ? path == null ? void 0 : path.getAttribute("id") : null;
          return popoverRefId === pathId;
        }) : -1;
        if (index2 === -1 && pathMatchIndex !== -1) return pathMatchIndex;
        return index2;
      }, -1);
      if (index === -1) {
        closeNestedPopovers(0);
      } else {
        index + 1 <= popoverRefs.length - 1 && closeNestedPopovers(index + 1);
      }
    };
    const remove = (currentRef) => {
      const index = popoverRefs.findIndex((refs) => refs.element.getAttribute("id") === currentRef.getAttribute("id"));
      if (index >= 0) {
        popoverRefs.splice(index, 1);
      }
    };
    const add = (currentRef, callback) => {
      const index = popoverRefs.findIndex((refs) => refs.element.getAttribute("id") === currentRef.getAttribute("id"));
      if (index >= 0) return;
      popoverRefs.push({ element: currentRef, callback });
    };
    const closeNestedPopovers = (fromIndex) => {
      var _a2, _b2;
      const popoverLength = popoverRefs.length;
      for (let i2 = fromIndex; i2 < popoverLength; i2++) {
        (_b2 = (_a2 = popoverRefs == null ? void 0 : popoverRefs[i2]) == null ? void 0 : _a2.callback) == null ? void 0 : _b2.call(_a2);
      }
      popoverRefs.splice(fromIndex);
    };
    const closeAll = () => {
      popoverRefs.forEach((ref) => {
        var _a2;
        return (_a2 = ref == null ? void 0 : ref.callback) == null ? void 0 : _a2.call(ref);
      });
      popoverRefs = [];
    };
    return { add, remove, closeAll, closePopoversOutsideOfClick };
  })();
  const REF = Symbol("_ref");
  class ReflexError extends Error {
  }
  class UnknownRefError extends ReflexError {
  }
  class MissingReflexActionError extends ReflexError {
  }
  function assertReflexAction(value2) {
    if (!isFunction(value2)) throw new MissingReflexActionError();
  }
  const isReflex = (value2) => {
    try {
      if (isFunction(value2) && hasOwnProperty(value2, "current") && hasOwnProperty(value2, REF) && !sameValue(value2, value2[REF])) {
        const notDefined = value2.actions.get(EMPTY_OBJECT);
        const size = value2.actions.size;
        return isUndefined(notDefined) && Number.isInteger(size) && size >= 0;
      }
    } catch {
    }
    return false;
  };
  const unwrap = (reflexable) => isReflex(reflexable) ? unwrap(reflexable[REF]) : reflexable;
  function isRefObject(ref) {
    return !!ref.current;
  }
  const createReflexRegister = /* @__PURE__ */ (() => {
    const _getRecordForRef = (register, ref) => {
      const record = register.get(ref);
      if (!record) throw new UnknownRefError();
      return record;
    };
    const _bindReflexAction = (register, reflexable, action) => {
      let record;
      let actions;
      const _ref = unwrap(reflexable);
      try {
        record = _getRecordForRef(register, _ref);
      } catch {
        assertReflexAction(action);
      }
      if (record) [, actions] = record;
      else {
        const isCallbackRef = isFunction(_ref);
        const _updateCurrentInstance = isCallbackRef ? (instance) => {
          _ref(_current = instance);
        } : (instance) => {
          if (_ref) {
            _ref.current = instance;
            _current = _ref.current;
          }
        };
        const reflex = (instance) => {
          if (actions.size === 0) {
            return;
          }
          const previous = _current;
          _updateCurrentInstance(instance);
          if (!sameValue(_current, previous)) {
            for (const [action2] of actions) {
              action2(_current, previous);
            }
          }
        };
        let _current = isCallbackRef ? null : _ref.current;
        register.set(_ref, record = [reflex, actions = /* @__PURE__ */ new Map()]);
        Object.defineProperties(reflex, {
          [REF]: { value: _ref },
          actions: {
            value: struct({
              get: { value: actions.get.bind(actions) },
              size: { get: () => actions.size }
            })
          },
          current: {
            get: () => _current,
            set: isCallbackRef ? void 0 : reflex
          }
        });
      }
      if (action) {
        actions.set(action, 1 + (actions.get(action) || 0));
      }
      return record[0];
    };
    const _unbindReflexAction = (register, reflexable, action) => {
      const _ref = unwrap(reflexable);
      const [, actions] = _getRecordForRef(register, _ref);
      const bindings = actions.get(action) || 0;
      if (bindings === 1) actions.delete(action);
      else if (bindings > 1) actions.set(action, bindings - 1);
      if (actions.size === 0 && _ref) register.delete(_ref);
    };
    return () => {
      const _register = /* @__PURE__ */ new WeakMap();
      return struct({
        bind: enumerable(_bindReflexAction.bind(void 0, _register)),
        unbind: enumerable(_unbindReflexAction.bind(void 0, _register))
      });
    };
  })();
  const $globalReflexRegister = createReflexRegister();
  const createIsolatedFauxReflex = (action) => {
    assertReflexAction(action);
    const $actions = new WeakMap([[action, 1]]);
    const reflex = (instance) => {
      if (sameValue(_current, instance)) return;
      const previous = _current;
      action(_current = instance, previous);
    };
    let _current = null;
    return Object.defineProperties(reflex, {
      [REF]: { value: reflex },
      actions: {
        value: struct({
          get: { value: $actions.get.bind($actions) },
          size: { value: 1 }
        })
      },
      current: {
        get: () => _current,
        set: reflex
      }
    });
  };
  const createReflexContainer = (register = $globalReflexRegister) => {
    let _reflex;
    let _reflexable = null;
    let _reflexAction;
    let _released = false;
    const _refreshContainer = (action) => {
      _reflex = void 0;
      _reflexable = null;
      _reflexAction = action;
      _released = false;
    };
    const _releaseContainer = () => {
      if (!_released) {
        _unbindReflexAction();
        _released = true;
      }
    };
    const _unbindReflexAction = () => {
      try {
        if (!_reflexable) return;
        register.unbind(_reflexable, _reflexAction);
      } catch {
      }
    };
    const _updateContainer = (action, reflexable) => {
      assertReflexAction(action);
      if (_released) _refreshContainer(action);
      const currentReflexable = isNullish(reflexable) ? null : reflexable;
      if (_reflexAction === action && _reflexable === currentReflexable) {
        if (_reflex) return;
      } else if (_reflexable) {
        if (sameValue(unwrap(_reflexable), unwrap(currentReflexable))) {
          _reflex = register.bind(_reflexable, action);
          _unbindReflexAction();
          _reflexAction = action;
          return;
        }
        _unbindReflexAction();
      }
      _reflexAction = action;
      _reflex = (_reflexable = currentReflexable) ? register.bind(_reflexable, _reflexAction) : createIsolatedFauxReflex(_reflexAction);
    };
    return struct({
      action: { get: () => _reflexAction },
      reflex: { get: () => _reflex },
      release: { value: _releaseContainer },
      update: { value: _updateContainer }
    });
  };
  const useReflex = (action, reflexable) => {
    const container = A$1(createReflexContainer());
    _(() => container.current.release, []);
    return T$1(() => {
      container.current.update(action, reflexable);
      return container.current.reflex;
    }, [action, reflexable]);
  };
  const CONTROL_ELEMENT_PROPERTY = Symbol("__control.Elem.");
  var ClickOutsideVariant = /* @__PURE__ */ ((ClickOutsideVariant2) => {
    ClickOutsideVariant2["POPOVER"] = "POPOVER";
    ClickOutsideVariant2["DEFAULT"] = "DEFAULT";
    return ClickOutsideVariant2;
  })(ClickOutsideVariant || {});
  const onFocusoutCapture = (e2) => {
    e2.stopImmediatePropagation();
  };
  const useClickOutside = (rootElementRef, callback, disableClickOutside, variant) => {
    const ref = A$1(null);
    const handleClickOutside = q$1(
      (e2) => {
        const eventPath = e2.composedPath();
        if (!(ref && ref.current)) return;
        if (variant === "POPOVER") {
          popoverUtil.closePopoversOutsideOfClick(eventPath);
        } else {
          let eventPathIndex = 0;
          let samePath = false;
          let currentElement = eventPath[eventPathIndex];
          while (currentElement instanceof Element) {
            if (samePath || (samePath = currentElement == null ? void 0 : currentElement.isSameNode(ref.current))) break;
            currentElement = eventPath[++eventPathIndex] ?? currentElement.parentElement;
            if ((currentElement == null ? void 0 : currentElement[CONTROL_ELEMENT_PROPERTY]) instanceof Element) {
              currentElement = currentElement[CONTROL_ELEMENT_PROPERTY];
              eventPath.length = 0;
            }
          }
          if (callback && !samePath) callback(true);
        }
      },
      [ref, callback, variant]
    );
    const clickOutsideHandlerRef = A$1(handleClickOutside);
    y(() => {
      return () => {
        if (ref.current) popoverUtil.remove(ref.current);
        document.removeEventListener("click", clickOutsideHandlerRef.current, true);
      };
    }, []);
    y(() => {
      document.removeEventListener("click", clickOutsideHandlerRef.current, true);
      clickOutsideHandlerRef.current = handleClickOutside;
      document.addEventListener("click", clickOutsideHandlerRef.current, true);
      if (variant === "POPOVER") {
        if (ref.current instanceof Element) popoverUtil.add(ref.current, callback);
      }
      return () => {
        if (ref.current) popoverUtil.remove(ref.current);
        document.removeEventListener("click", clickOutsideHandlerRef.current, true);
      };
    }, [handleClickOutside, callback, variant]);
    y(() => {
      if (disableClickOutside) {
        document.removeEventListener("click", clickOutsideHandlerRef.current, true);
      } else {
        document.addEventListener("click", clickOutsideHandlerRef.current, true);
      }
    }, [disableClickOutside]);
    return useReflex(
      q$1(
        (current, previous) => {
          if (previous instanceof Element) {
            previous.removeEventListener("focusout", onFocusoutCapture, true);
          }
          if (current instanceof Element) {
            if (!disableClickOutside) {
              current.addEventListener("focusout", onFocusoutCapture, true);
              ref.current = current;
            }
          }
        },
        [disableClickOutside, variant]
      ),
      rootElementRef
    );
  };
  const SELECTORS = `
    a[href],
    audio[controls],
    video[controls],
    button,
    input,
    select,
    textarea,
    [contenteditable],
    [tabindex]
`.replace(/\s+/, "");
  const ATTRIBUTES = ["contenteditable", "controls", "disabled", "hidden", "href", "inert", "tabindex"];
  const CHECKED_RADIOS = /* @__PURE__ */ new Map();
  const isInput = (element) => element.tagName === "INPUT";
  const isRadio = (element) => isInput(element) && element.type === "radio";
  const isCheckedRadio = (element) => {
    const name = element.name;
    const form = element.form;
    const checkedRadiosForForm = CHECKED_RADIOS.get(form);
    let checkedRadio = checkedRadiosForForm == null ? void 0 : checkedRadiosForForm.get(name);
    if (isUndefined(checkedRadio) && form) {
      checkedRadio = form.querySelector(`input[type=radio][name='${name}']:checked`) || null;
      CHECKED_RADIOS.set(form, (checkedRadiosForForm || /* @__PURE__ */ new Map()).set(name, checkedRadio));
    }
    return checkedRadio === element;
  };
  const shouldRefresh = (tabbables, records) => {
    for (const record of records) {
      if (record.type !== "attributes") {
        if (some(record.addedNodes, (node) => node instanceof Element && isTabbable(node))) return true;
        if (some(record.removedNodes, (node) => tabbables.includes(node))) return true;
      } else if (isTabbable(record.target)) return true;
      else if (tabbables.includes(record.target)) return true;
    }
    return false;
  };
  const focusIsWithin = (rootElement = document.body, elementWithFocus) => {
    if (isUndefined(rootElement)) return false;
    if (isNullish(elementWithFocus)) return !!document.activeElement && focusIsWithin(rootElement, document.activeElement);
    let parentElement = elementWithFocus == null ? void 0 : elementWithFocus.parentNode;
    while (parentElement) {
      if (parentElement === rootElement) return true;
      parentElement = parentElement == null ? void 0 : parentElement.parentNode;
    }
    return false;
  };
  const isFocusable = (element) => !// [TODO]: Include all of these checks
  // (1) matches focusable elements selector
  // (2) is disabled element
  // (3) is inert or inert subtree child
  // (4) is hidden input
  // (5) with visibility: hidden
  // (6) is summary of open details element
  // (7) is details with summary element
  // (8) is disabled fieldset subtree child
  /* (1) */
  (!element.matches(SELECTORS) || /* (2) */
  (element == null ? void 0 : element.disabled) || /* (3) */
  /^(true)?$/.test(element.getAttribute("inert")) || /* (4) */
  isInput(element) && element.hidden);
  const isTabbable = (element) => !(isRadio(element) && !isCheckedRadio(element) || // (1) is not checked radio button
  (element == null ? void 0 : element.tabIndex) < 0 || // (2) has negative tabindex
  !isFocusable(element));
  const withTabbableRoot = () => {
    const observer = new MutationObserver((records) => shouldRefresh(tabbables, records) && getTabbables());
    const tabbables = [];
    let currentIndex = -1;
    let root = null;
    const focusAt = (tabbableIndex) => {
      var _a2;
      if (tabbableIndex < 0) return;
      const constrainedIndex = Math.min(tabbableIndex, tabbables.length - 1);
      if (currentIndex !== constrainedIndex) currentIndex = constrainedIndex;
      (_a2 = tabbables[currentIndex]) == null ? void 0 : _a2.focus();
    };
    const getTabbables = () => {
      tabbables.length = 0;
      if (!(root instanceof Element)) return;
      root.querySelectorAll(SELECTORS).forEach((maybeTabbable) => isTabbable(maybeTabbable) && tabbables.push(maybeTabbable));
      if (!focusIsWithin(root)) return;
      tabbableRoot.current = document.activeElement;
    };
    const tabbableRoot = Object.create(null, {
      current: {
        get: () => tabbables[currentIndex] ?? null,
        set: (maybeTabbableOrOffset) => {
          if (!maybeTabbableOrOffset) return;
          if (!isNumber(maybeTabbableOrOffset)) return focusAt(tabbables.indexOf(maybeTabbableOrOffset));
          if (maybeTabbableOrOffset !== ~~maybeTabbableOrOffset) return;
          return focusAt(mod(currentIndex + maybeTabbableOrOffset, tabbables.length));
        }
      },
      root: {
        get: () => root,
        set: (maybeElement) => {
          if (maybeElement === root) return;
          root && observer.disconnect();
          root = maybeElement instanceof Element ? maybeElement : null;
          tabbables.length = 0;
          if (!root) return;
          observer.observe(root, {
            attributeFilter: ATTRIBUTES,
            attributes: true,
            childList: true,
            subtree: true
          });
          getTabbables();
        }
      },
      tabbables: { value: tabbables }
    });
    return tabbableRoot;
  };
  const useFocusTrap = (rootElementRef, onEscape) => {
    const escapedFocus = A$1(false);
    const focusElement = A$1(null);
    const interactionKeyPressed = A$1(false);
    const tabbableRoot = T$1(withTabbableRoot, []);
    const onClickCapture = T$1(() => {
      let lastFocusableElement = null;
      let raf;
      return (evt) => {
        if (!isUndefined(raf)) cancelAnimationFrame(raf);
        let element = evt.target;
        while (element && element !== evt.currentTarget) {
          if (isFocusable(element)) {
            lastFocusableElement = element;
            raf = requestAnimationFrame(() => {
              raf = requestAnimationFrame(() => {
                var _a2;
                if (focusElement.current !== lastFocusableElement && lastFocusableElement instanceof HTMLElement) {
                  (_a2 = focusElement.current = lastFocusableElement) == null ? void 0 : _a2.focus();
                }
                lastFocusableElement = null;
                raf = void 0;
              });
            });
            return;
          }
          element = element.parentNode;
        }
      };
    }, []);
    const onFocusInCapture = q$1((evt) => {
      tabbableRoot.current = focusElement.current = evt.target;
    }, []);
    const onFocusOutCapture = q$1((evt) => {
      if (tabbableRoot.tabbables.includes(evt.relatedTarget)) return;
      if (focusIsWithin(evt.currentTarget, evt.relatedTarget)) return;
      if (interactionKeyPressed.current) return;
      escapedFocus.current = true;
      requestAnimationFrame(() => {
        if (escapedFocus.current) onEscape(escapedFocus.current = false);
      });
    }, []);
    const onKeyDownCapture = T$1(() => {
      let raf;
      return (evt) => {
        switch (evt.code) {
          case InteractionKeyCode.ARROW_DOWN:
          case InteractionKeyCode.ARROW_LEFT:
          case InteractionKeyCode.ARROW_RIGHT:
          case InteractionKeyCode.ARROW_UP:
          case InteractionKeyCode.END:
          case InteractionKeyCode.ESCAPE:
          case InteractionKeyCode.HOME:
          case InteractionKeyCode.PAGE_DOWN:
          case InteractionKeyCode.PAGE_UP:
          case InteractionKeyCode.TAB:
            cancelAnimationFrame(raf);
            raf = requestAnimationFrame(() => {
              raf = requestAnimationFrame(() => {
                interactionKeyPressed.current = false;
                raf = void 0;
              });
            });
            interactionKeyPressed.current = true;
            break;
        }
        if (evt.code === InteractionKeyCode.TAB) {
          evt.preventDefault();
          tabbableRoot.current = evt.shiftKey ? -1 : 1;
        } else if (evt.code === InteractionKeyCode.ESCAPE) onEscape(true);
      };
    }, []);
    return useReflex(
      q$1((current, previous) => {
        if (previous instanceof Element) {
          previous.removeEventListener("keydown", onKeyDownCapture, true);
          previous.removeEventListener("focusin", onFocusInCapture, true);
          previous.removeEventListener("focusout", onFocusOutCapture, true);
          current.removeEventListener("click", onClickCapture, true);
        }
        if (current instanceof Element) {
          current.addEventListener("keydown", onKeyDownCapture, true);
          current.addEventListener("focusin", onFocusInCapture, true);
          current.addEventListener("focusout", onFocusOutCapture, true);
          current.addEventListener("click", onClickCapture, true);
          escapedFocus.current = false;
          tabbableRoot.root = current;
        } else tabbableRoot.root = null;
      }, []),
      rootElementRef
    );
  };
  const getIntersectionObserver = (() => {
    const observerCallbackMap = /* @__PURE__ */ new WeakMap();
    const withIntersectionObserver = struct({
      remove: enumerable(function() {
        remove(this.observerCallback);
      })
    });
    const findObserver = (callbackFn, root) => {
      let observerInstance = observerCallbackMap.get(callbackFn);
      if (isUndefined(observerInstance)) {
        const observer = new IntersectionObserver(
          (entries) => {
            entries.forEach((entry) => {
              if (callbackFn) callbackFn(entry);
            });
          },
          { root: root ?? null, rootMargin: "", threshold: [1] }
        );
        observerInstance = structFrom(withIntersectionObserver, {
          observerCallback: enumerable(callbackFn),
          observer: enumerable(observer)
        });
        observerCallbackMap.set(callbackFn, observerInstance);
      }
      return observerInstance;
    };
    const remove = (callbackFn) => {
      const currentObserver = observerCallbackMap.get(callbackFn);
      currentObserver == null ? void 0 : currentObserver.observer.disconnect();
      observerCallbackMap.delete(callbackFn);
    };
    return findObserver;
  })();
  const FULL_WIDTH_TOOLTIP_POSITIONS = [
    PopoverContainerPosition.BOTTOM_RIGHT,
    PopoverContainerPosition.BOTTOM_LEFT,
    PopoverContainerPosition.TOP_RIGHT,
    PopoverContainerPosition.TOP_LEFT
  ];
  const POPOVER_DIAGONAL_HORIZONTAL_OFFSET = 5;
  const ARROW_OFFSET = 4;
  const SCREEN_EDGE_MARGIN = 10;
  const calculateOffset = ({
    position,
    variant,
    offset,
    additionalStyle,
    fixedPositioning,
    fullWidth,
    popover,
    targetElement
  }) => {
    let translateX = 0;
    let translateY = 0;
    const isTooltip = variant === PopoverContainerVariant.TOOLTIP;
    const popoverHeight = popover.clientHeight;
    const popoverWidth = popover.clientWidth;
    const popoverContent = popover.firstChild;
    const popoverContentHeight = popoverContent.offsetHeight;
    const popoverContentWidth = popoverContent.offsetWidth;
    const bodyPosition = document.body.getBoundingClientRect();
    const targetPosition = targetElement.getBoundingClientRect();
    const toCenterFullWidth = bodyPosition.x + (bodyPosition.width - popoverContentWidth) / 2;
    const toCenterX = targetPosition.x + (targetPosition.width - popoverContentWidth) / 2;
    const toCenterY = targetPosition.y + (targetPosition.height - popoverContentHeight) / 2;
    const scrollX = window.scrollX;
    const scrollY = window.scrollY;
    switch (position) {
      case PopoverContainerPosition.BOTTOM:
        translateX = fullWidth ? toCenterFullWidth : isTooltip ? toCenterX : targetPosition.x;
        translateY = targetPosition.y + targetPosition.height + offset[1];
        if (!fixedPositioning) {
          if (!fullWidth) {
            translateX += scrollX;
          }
          translateY += scrollY;
        }
        break;
      case PopoverContainerPosition.TOP:
        translateX = isTooltip ? toCenterX : targetPosition.x;
        translateY = targetPosition.y - (popoverHeight + offset[0]);
        if (!fixedPositioning) {
          translateX += scrollX;
          translateY += scrollY - popoverContent.clientHeight + popoverHeight;
        }
        break;
      case PopoverContainerPosition.RIGHT:
        translateX = targetPosition.x + targetPosition.width + offset[2];
        translateY = isTooltip ? toCenterY : targetPosition.y - targetPosition.height / 2;
        if (!fixedPositioning) {
          translateX += scrollX;
          translateY += scrollY;
        }
        break;
      case PopoverContainerPosition.LEFT:
        translateX = targetPosition.x - (popoverWidth + offset[3]);
        translateY = isTooltip ? toCenterY : targetPosition.y - targetPosition.height / 2;
        if (!fixedPositioning) {
          translateX += scrollX;
          translateY += scrollY;
        }
        break;
      case PopoverContainerPosition.BOTTOM_LEFT:
        translateX = 5;
        translateY = targetPosition.y + targetPosition.height + offset[1];
        if (!fixedPositioning) {
          translateX += scrollX;
          translateY += scrollY;
        }
        break;
      case PopoverContainerPosition.BOTTOM_RIGHT:
        translateX = -5;
        translateY = targetPosition.y + targetPosition.height + offset[1];
        if (!fixedPositioning) {
          translateX += scrollX;
          translateY += scrollY;
        }
        break;
      case PopoverContainerPosition.TOP_LEFT:
        translateX = POPOVER_DIAGONAL_HORIZONTAL_OFFSET;
        translateY = targetPosition.y - popoverHeight;
        if (!fixedPositioning) {
          translateX += scrollX;
          translateY += scrollY - popoverContent.clientHeight + popoverHeight;
        }
        break;
      case PopoverContainerPosition.TOP_RIGHT:
        translateX = -5;
        translateY = targetPosition.y - popoverHeight;
        if (!fixedPositioning) {
          translateX += scrollX;
          translateY += scrollY - popoverContent.clientHeight + popoverHeight;
        }
        break;
    }
    const offsetStyle = {};
    if (additionalStyle) {
      const isMaxLimits = !!additionalStyle.maxY && translateY + (popover == null ? void 0 : popover.clientHeight) > additionalStyle.maxY;
      const isMinLimits = !!additionalStyle.minY && translateY < additionalStyle.minY;
      if (isMaxLimits && additionalStyle.maxY) {
        const targetVerticalPosition = targetPosition.y + targetPosition.height + 8;
        const height = Math.max(0, additionalStyle.maxY - targetVerticalPosition);
        if (height > 20) {
          offsetStyle.height = `${height}px`;
        }
        offsetStyle["overflow-y"] = "scroll";
      }
      if (isMinLimits && additionalStyle.minY && translateY) {
        const popoverHeight2 = popover.offsetHeight ?? popover.clientHeight;
        const targetHeight = Math.max(0, popoverHeight2 - (additionalStyle.minY - translateY));
        offsetStyle.height = `${targetHeight}px`;
        if (targetHeight) {
          offsetStyle["overflow-y"] = "scroll";
        }
      }
      if (isMinLimits) {
        translateY = additionalStyle.minY ?? 0;
      }
    }
    const isAlignedToRight = position === PopoverContainerPosition.TOP_RIGHT || position === PopoverContainerPosition.BOTTOM_RIGHT;
    return {
      inset: isAlignedToRight ? "0 0 auto auto" : "0 auto auto 0",
      margin: "0",
      position: fixedPositioning ? "fixed" : "absolute",
      transform: `translate3d(${translateX}px, ${translateY}px, 0)`,
      visibility: "hidden",
      right: isAlignedToRight ? 0 : "auto",
      ...offsetStyle
    };
  };
  const usePopoverPositioner = (offset, targetElement, variant, position, arrowRef, setToTargetWidth, showOverlay, fitPosition, fixedPositioning, additionalStyle, ref, contentRef) => {
    const [initialPosition, setInitialPosition] = d(true);
    const [showPopover, setShowPopover] = d(fitPosition ? !fitPosition : !!position);
    const [currentPosition, setCurrentPosition] = d(position || PopoverContainerPosition.TOP);
    const [checkedPositions, setCheckedPosition] = d([]);
    const observerCallback = q$1(
      (entry) => {
        var _a2;
        const screenWidth = document.documentElement.clientWidth;
        const targetPosition = (_a2 = targetElement.current) == null ? void 0 : _a2.getBoundingClientRect();
        if (entry.intersectionRatio === 1) return setShowPopover(true);
        if (!initialPosition && entry.intersectionRatio !== 1) {
          if (checkedPositions && checkedPositions.length === (fitPosition ? 8 : 4)) {
            const bestPos = checkedPositions.reduce((res, pos) => pos[1] > res[1] ? pos : res, checkedPositions[0]);
            setCurrentPosition(bestPos[0]);
            return setShowPopover(true);
          }
          setShowPopover(false);
          switch (currentPosition) {
            case PopoverContainerPosition.TOP:
              setCheckedPosition((value2) => [...value2, [PopoverContainerPosition.TOP, entry.intersectionRatio]]);
              setCurrentPosition(PopoverContainerPosition.BOTTOM);
              break;
            case PopoverContainerPosition.BOTTOM:
              setCheckedPosition((value2) => [...value2, [PopoverContainerPosition.BOTTOM, entry.intersectionRatio]]);
              setCurrentPosition(
                fitPosition ? ((targetPosition == null ? void 0 : targetPosition.x) || 0) > screenWidth / 2 ? PopoverContainerPosition.BOTTOM_RIGHT : PopoverContainerPosition.BOTTOM_LEFT : PopoverContainerPosition.RIGHT
              );
              break;
            case PopoverContainerPosition.BOTTOM_LEFT:
              setCheckedPosition((value2) => [...value2, [PopoverContainerPosition.BOTTOM_LEFT, entry.intersectionRatio]]);
              setCurrentPosition(fitPosition ? PopoverContainerPosition.TOP_LEFT : PopoverContainerPosition.RIGHT);
              break;
            case PopoverContainerPosition.BOTTOM_RIGHT:
              setCheckedPosition((value2) => [...value2, [PopoverContainerPosition.BOTTOM_RIGHT, entry.intersectionRatio]]);
              setCurrentPosition(fitPosition ? PopoverContainerPosition.TOP_RIGHT : PopoverContainerPosition.RIGHT);
              break;
            case PopoverContainerPosition.TOP_LEFT:
              setCheckedPosition((value2) => [...value2, [PopoverContainerPosition.TOP_LEFT, entry.intersectionRatio]]);
              setCurrentPosition(fitPosition ? PopoverContainerPosition.BOTTOM_LEFT : PopoverContainerPosition.RIGHT);
              break;
            case PopoverContainerPosition.TOP_RIGHT:
              setCheckedPosition((value2) => [...value2, [PopoverContainerPosition.TOP_RIGHT, entry.intersectionRatio]]);
              setCurrentPosition(fitPosition ? PopoverContainerPosition.BOTTOM_RIGHT : PopoverContainerPosition.RIGHT);
              break;
            case PopoverContainerPosition.RIGHT:
              setCheckedPosition((value2) => [...value2, [PopoverContainerPosition.RIGHT, entry.intersectionRatio]]);
              setCurrentPosition(PopoverContainerPosition.LEFT);
              break;
            case PopoverContainerPosition.LEFT:
              setCheckedPosition((value2) => [...value2, [PopoverContainerPosition.LEFT, entry.intersectionRatio]]);
              setCurrentPosition(PopoverContainerPosition.TOP);
              break;
          }
        }
      },
      [targetElement, initialPosition, checkedPositions, fitPosition, currentPosition]
    );
    const observerCallbackRef = A$1(observerCallback);
    y(() => {
      getIntersectionObserver(observerCallbackRef.current).remove();
      observerCallbackRef.current = observerCallback;
    }, [observerCallback]);
    return useReflex(
      q$1(
        (current, previous) => {
          var _a2, _b2, _c2;
          if (previous && (!position || fitPosition)) {
            const observer = getIntersectionObserver(observerCallback).observer;
            observer.unobserve(previous);
          }
          if (current && targetElement.current) {
            if (!position || fitPosition) {
              const observer = getIntersectionObserver(observerCallback).observer;
              observer.observe(current);
            }
            if (!(current instanceof Element)) return;
            const popoverStyle = calculateOffset({
              variant,
              offset,
              additionalStyle,
              fixedPositioning,
              fullWidth: showOverlay,
              popover: current,
              position: currentPosition,
              targetElement: targetElement.current
            });
            const style = {
              ...popoverStyle,
              ...showPopover && { visibility: "visible" },
              ...setToTargetWidth && {
                "min-width": "fit-content",
                width: `${targetElement.current.clientWidth}px`
              }
            };
            current.setAttribute(
              "style",
              Object.entries(style).map((entry) => entry.join(":")).join(";")
            );
            if (initialPosition) setInitialPosition(false);
            if (variant && variant === PopoverContainerVariant.TOOLTIP && arrowRef && isRefObject(arrowRef)) {
              (_a2 = arrowRef.current) == null ? void 0 : _a2.setAttribute("data-popover-placement", currentPosition);
              if (FULL_WIDTH_TOOLTIP_POSITIONS.includes(currentPosition)) {
                const targetPosition = targetElement.current.getBoundingClientRect();
                const popoverContent = current.firstChild;
                const popoverContentWidth = popoverContent.offsetWidth;
                const positionX = targetPosition.x + (targetPosition.width - popoverContentWidth) / 2;
                const popoverContentHeight = popoverContent.offsetHeight;
                const positionY = currentPosition === PopoverContainerPosition.BOTTOM_RIGHT || currentPosition === PopoverContainerPosition.BOTTOM_LEFT ? popoverContentHeight + ARROW_OFFSET : ARROW_OFFSET;
                (_b2 = arrowRef.current) == null ? void 0 : _b2.setAttribute(
                  "style",
                  `transform: translate3d(${positionX}px, -${positionY}px, 0) rotate(45deg); inset: 0 0 auto auto`
                );
              }
            }
            if (variant && variant === PopoverContainerVariant.TOOLTIP && contentRef && isRefObject(contentRef) && FULL_WIDTH_TOOLTIP_POSITIONS.includes(currentPosition)) {
              const screenWidth = document.documentElement.clientWidth;
              (_c2 = contentRef.current) == null ? void 0 : _c2.setAttribute("style", `max-width: ${screenWidth - SCREEN_EDGE_MARGIN}px`);
            }
          }
        },
        [
          position,
          fitPosition,
          targetElement,
          observerCallback,
          variant,
          offset,
          additionalStyle,
          fixedPositioning,
          showOverlay,
          currentPosition,
          showPopover,
          setToTargetWidth,
          initialPosition,
          arrowRef,
          contentRef
        ]
      ),
      ref
    );
  };
  const useUniqueIdentifier = (ref) => {
    const id2 = A$1();
    return useReflex(
      q$1(
        (current, previous) => {
          if (previous instanceof Element && previous.id === id2.current) previous.id = "";
          if (!(current instanceof Element)) return;
          current.id = id2.current || (id2.current = uniqueId());
        },
        [ref]
      ),
      ref
    );
  };
  const findFirstFocusableElement = (root) => {
    var _a2;
    let focusable;
    const elements = (_a2 = root.querySelector(`.${TOOLTIP_CONTENT_CLASSNAME}`)) == null ? void 0 : _a2.querySelectorAll(SELECTORS);
    if (elements) {
      Array.prototype.some.call(elements, (elem) => {
        if (isFocusable(elem)) return focusable = elem;
      });
      return focusable;
    }
    return null;
  };
  const getGapByVariant = (variant) => {
    return variant === PopoverContainerVariant.TOOLTIP ? [10, 3, 5, 5] : [8, 8, 8, 8];
  };
  function Popover({
    actions,
    disableFocusTrap = false,
    actionsLayout = ButtonActionsLayoutBasic.SPACE_BETWEEN,
    variant = PopoverContainerVariant.TOOLTIP,
    title,
    open: open2,
    dismissible,
    modifiers,
    divider,
    fitContent,
    withoutSpace,
    containerSize,
    position,
    targetElement,
    setToTargetWidth,
    dismiss: dismiss2,
    children,
    withContentPadding,
    classNameModifiers,
    showOverlay = false,
    fitPosition,
    fixedPositioning = false,
    additionalStyle,
    ...uncontrolledProps
  }) {
    const isDismissible = T$1(() => isFunction(dismiss2) && boolOrTrue(dismissible), [dismiss2, dismissible]);
    const arrowRef = useUniqueIdentifier();
    const contentRef = useUniqueIdentifier();
    const popoverOpen = A$1();
    const onCloseFocusTrap = q$1(
      (interactionKeyPressed) => {
        var _a2;
        dismiss2 && dismiss2();
        if (interactionKeyPressed) {
          (_a2 = targetElement == null ? void 0 : targetElement.current) == null ? void 0 : _a2.focus();
        }
      },
      [dismiss2, targetElement]
    );
    const onKeyDown = q$1(
      (e2) => {
        if (e2.code === InteractionKeyCode.ESCAPE) {
          dismiss2 && dismiss2();
          (targetElement == null ? void 0 : targetElement.current).focus();
        }
      },
      [dismiss2, targetElement]
    );
    const cachedOnKeyDown = A$1(onKeyDown);
    const autoFocusAnimFrame = A$1();
    const popoverPositionAnchorElement = useClickOutside(
      usePopoverPositioner(
        getGapByVariant(variant),
        targetElement,
        variant,
        position,
        arrowRef,
        setToTargetWidth,
        showOverlay,
        fitPosition,
        fixedPositioning,
        additionalStyle,
        void 0,
        contentRef
      ),
      dismiss2,
      variant === PopoverContainerVariant.TOOLTIP && !open2,
      ClickOutsideVariant.POPOVER
    );
    const popoverFocusTrapElement = useFocusTrap(disableFocusTrap ? null : popoverPositionAnchorElement, onCloseFocusTrap);
    const popoverElement = useReflex(
      q$1(
        (current, previous) => {
          if (previous instanceof Element) {
            previous[CONTROL_ELEMENT_PROPERTY] = void 0;
            delete previous[CONTROL_ELEMENT_PROPERTY];
          }
          if (current instanceof Element) {
            current[CONTROL_ELEMENT_PROPERTY] = targetElement.current;
            cancelAnimationFrame(autoFocusAnimFrame.current);
            autoFocusAnimFrame.current = requestAnimationFrame(() => {
              if (popoverOpen.current === open2) return;
              if (!(popoverOpen.current = open2)) return;
              const focusable = findFirstFocusableElement(current);
              focusable == null ? void 0 : focusable.focus();
            });
          }
        },
        [open2, targetElement]
      ),
      disableFocusTrap ? popoverPositionAnchorElement : popoverFocusTrapElement
    );
    const popoverElementWithId = useUniqueIdentifier(popoverElement);
    const conditionalClasses = T$1(
      () => ({
        [`${DEFAULT_POPOVER_CLASSNAME}--medium`]: containerSize === PopoverContainerSize.MEDIUM,
        [`${DEFAULT_POPOVER_CLASSNAME}--with-divider`]: !!divider,
        [`${DEFAULT_POPOVER_CLASSNAME}--wide`]: containerSize === PopoverContainerSize.WIDE,
        [`${DEFAULT_POPOVER_CLASSNAME}--fit-content`]: fitContent,
        [`${DEFAULT_POPOVER_CLASSNAME}--without-space`]: withoutSpace,
        [`${DEFAULT_POPOVER_CLASSNAME}--auto-width`]: showOverlay
      }),
      [containerSize, divider, withoutSpace, fitContent, showOverlay]
    );
    y(() => {
      if (popoverElement.current) popoverElement.current[CONTROL_ELEMENT_PROPERTY] = targetElement.current;
    }, [popoverElement, targetElement]);
    y(() => {
      document.removeEventListener("keydown", cachedOnKeyDown.current);
      document.addEventListener("keydown", cachedOnKeyDown.current = onKeyDown);
      return () => document.removeEventListener("keydown", cachedOnKeyDown.current);
    }, [onKeyDown]);
    const classNamesByVariant = variant === PopoverContainerVariant.TOOLTIP ? DEFAULT_TOOLTIP_CLASSNAME : `${DEFAULT_POPOVER_CLASSNAME} ${POPOVER_CONTAINER_CLASSNAME}`;
    const classNamesContentByVariant = variant === PopoverContainerVariant.TOOLTIP ? TOOLTIP_CONTENT_CLASSNAME : `${POPOVER_CONTENT_CLASSNAME}`;
    return $(
      /* @__PURE__ */ u$1(k$1, { children: open2 ? /* @__PURE__ */ u$1(k$1, { children: [
        showOverlay && /* @__PURE__ */ u$1("div", { className: "adyen-pe-popover__overlay" }),
        /* @__PURE__ */ u$1(
          "div",
          {
            id: "popover",
            ref: popoverElementWithId,
            ...uncontrolledProps,
            className: cx(classNamesByVariant, conditionalClasses, classNameModifiers),
            style: { visibility: "hidden" },
            role: uncontrolledProps.role ?? (variant === PopoverContainerVariant.POPOVER ? "dialog" : "tooltip"),
            children: [
              (title || isDismissible) && /* @__PURE__ */ u$1("div", { className: getModifierClasses(POPOVER_HEADER_CLASSNAME, modifiers, [POPOVER_HEADER_CLASSNAME]), children: [
                title && /* @__PURE__ */ u$1("div", { className: POPOVER_HEADER_TITLE_CLASSNAME, children: /* @__PURE__ */ u$1(PopoverTitle$1, { title }) }),
                isDismissible && /* @__PURE__ */ u$1(PopoverDismissButton$1, { onClick: dismiss2 })
              ] }),
              children && /* @__PURE__ */ u$1(k$1, { children: [
                /* @__PURE__ */ u$1(
                  "div",
                  {
                    className: cx(classNamesContentByVariant, {
                      [`${POPOVER_CONTENT_CLASSNAME}--with-padding`]: withContentPadding,
                      [`${POPOVER_CONTENT_CLASSNAME}--overlay`]: showOverlay
                    }),
                    ref: contentRef,
                    children
                  }
                ),
                variant === PopoverContainerVariant.TOOLTIP && /* @__PURE__ */ u$1("span", { "data-popover-placement": "hidden", ref: arrowRef, className: "adyen-pe-tooltip__arrow" })
              ] }),
              actions && /* @__PURE__ */ u$1("div", { className: POPOVER_FOOTER_CLASSNAME, children: /* @__PURE__ */ u$1(ButtonActions$1, { actions, layout: actionsLayout }) })
            ]
          }
        )
      ] }) : null }),
      document.getElementsByTagName("body")[0]
    );
  }
  const useTooltipListeners = () => {
    const [isVisible, setIsVisible] = useBooleanState();
    const showTooltip = q$1(() => setIsVisible(true), [setIsVisible]);
    const hideTooltip = q$1(() => setIsVisible(false), [setIsVisible]);
    const onKeyDown = q$1(
      (evt) => {
        switch (evt.code) {
          case InteractionKeyCode.ESCAPE:
            hideTooltip();
            break;
        }
      },
      [hideTooltip]
    );
    return {
      listeners: {
        onfocusoutCapture: hideTooltip,
        onMouseLeave: hideTooltip,
        onKeyDown,
        onFocus: showTooltip,
        onMouseEnter: showTooltip
      },
      isVisible
    };
  };
  const isString = (content) => {
    return typeof content === "string";
  };
  const Tooltip = ({ content, children, triggerRef, showTooltip, position, isContainerHovered = false }) => {
    var _a2, _b2, _c2;
    const controllerRef = useUniqueIdentifier();
    const { isVisible, listeners } = useTooltipListeners();
    return /* @__PURE__ */ u$1(k$1, { children: [
      children ? J$1(children, {
        ...children == null ? void 0 : children.props,
        role: "button",
        tabIndex: -1,
        ref: controllerRef,
        className: ((_a2 = children == null ? void 0 : children.props) == null ? void 0 : _a2.className) ? cx(`${(_b2 = children == null ? void 0 : children.props) == null ? void 0 : _b2.className} adyen-pe__tooltip-target`, {
          " adyen-pe__tooltip-target--hovered": isContainerHovered
        }) : cx("adyen-pe__tooltip-target", { "adyen-pe__tooltip-target--hovered": isContainerHovered }),
        ...listeners,
        "aria-describedby": `tooltip-${(_c2 = controllerRef.current) == null ? void 0 : _c2.id}`
      }) : null,
      (isVisible || showTooltip) && /* @__PURE__ */ u$1(
        Popover,
        {
          fitPosition: true,
          variant: PopoverContainerVariant.TOOLTIP,
          targetElement: triggerRef ?? controllerRef,
          position,
          open: isVisible || showTooltip,
          children: /* @__PURE__ */ u$1(k$1, { children: content && isString(content) ? /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.CAPTION, children: content }) : { content } })
        }
      )
    ] });
  };
  function Category({ value: value2, isContainerHovered }) {
    const { i18n } = useCoreContext();
    const tooltipKey = `tooltip.${value2}`;
    return /* @__PURE__ */ u$1(k$1, { children: i18n.has(tooltipKey) && /* @__PURE__ */ u$1(Tooltip, { content: i18n.get(tooltipKey), isContainerHovered, children: /* @__PURE__ */ u$1("span", { children: /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.BODY, children: i18n.has(`txType.${value2}`) ? i18n.get(`txType.${value2}`) : `${value2}` }) }) }) });
  }
  const UNDEFINED_ERROR = { title: "thereWasAnUnexpectedError", message: ["contactSupportForHelp"] };
  const getCommonErrorMessage = (error, onContactSupport) => {
    if (!error) return null;
    switch (error.errorCode) {
      case "29_001":
        return {
          title: "theRequestIsMissingRequiredFieldsOrContainsInvalidData",
          message: ["contactSupportForHelp"],
          onContactSupport
        };
      case "30_112":
        return {
          title: "entityWasNotFound",
          message: ["entityWasNotFoundDetail"],
          onContactSupport
        };
      case "00_403":
        return UNDEFINED_ERROR;
      default:
        return null;
    }
  };
  const CopyText = ({ textToCopy, isHovered, buttonLabel, showCopyTextTooltip = true, type: type2 = "Link", ...restProps }) => {
    const { i18n } = useCoreContext();
    const [tooltipLabel, setTooltipLabel] = d(i18n.get("copy"));
    const onClick = q$1(async () => {
      if (textToCopy) {
        try {
          await navigator.clipboard.writeText(textToCopy);
          setTooltipLabel(i18n.get("copied"));
        } catch (e2) {
          console.log(e2);
        }
      }
    }, [i18n, textToCopy]);
    const resetTooltipLabel = q$1(() => {
      setTooltipLabel(i18n.get("copy"));
    }, [i18n]);
    return /* @__PURE__ */ u$1(
      "span",
      {
        className: cx("adyen-pe-copy-text__container", {
          ["adyen-pe-copy-text__container--information"]: type2 === "Link"
        }),
        ...restProps,
        children: [
          showCopyTextTooltip ? /* @__PURE__ */ u$1(Tooltip, { content: textToCopy, isContainerHovered: isHovered, children: /* @__PURE__ */ u$1(
            "span",
            {
              className: cx({
                ["adyen-pe-copy-text__label"]: type2 !== "Default",
                ["adyen-pe-copy-text__information"]: type2 === "Link",
                ["adyen-pe-copy-text__text"]: type2 === "Text"
              }),
              children: buttonLabel || textToCopy
            }
          ) }) : /* @__PURE__ */ u$1(
            "span",
            {
              className: cx({
                ["adyen-pe-copy-text__label"]: type2 !== "Default",
                ["adyen-pe-copy-text__information"]: type2 === "Link",
                ["adyen-pe-copy-text__text"]: type2 === "Text"
              }),
              children: buttonLabel || textToCopy
            }
          ),
          /* @__PURE__ */ u$1(Tooltip, { content: tooltipLabel, children: /* @__PURE__ */ u$1(
            Button$1,
            {
              variant: ButtonVariant.TERTIARY,
              className: "adyen-pe-copy-text",
              onClick,
              onBlur: resetTooltipLabel,
              onMouseLeaveCapture: resetTooltipLabel,
              "data-testid": "copyText",
              children: /* @__PURE__ */ u$1(
                "div",
                {
                  className: cx("adyen-pe-copy-text__icon", {
                    ["adyen-pe-copy-text__icon--information"]: type2 === "Link"
                  }),
                  children: /* @__PURE__ */ u$1(Icon$1, { name: "copy", "data-testid": "copy-icon" })
                }
              )
            }
          ) })
        ]
      }
    );
  };
  const getErrorMessage = (error, errorMessage, onContactSupport) => {
    if (!error) return UNDEFINED_ERROR;
    const commonError = getCommonErrorMessage(error, onContactSupport);
    if (commonError) return commonError;
    switch (error.errorCode) {
      case void 0:
        return {
          title: "somethingWentWrong",
          message: [errorMessage, "tryRefreshingThePageOrComeBackLater"],
          refreshComponent: true
        };
      case "00_500": {
        const secondaryErrorMessage = onContactSupport ? "theErrorCodeIs" : "contactSupportForHelpAndShareErrorCode";
        return {
          title: "somethingWentWrong",
          message: [errorMessage, secondaryErrorMessage],
          translationValues: {
            [secondaryErrorMessage]: error.requestId ? /* @__PURE__ */ u$1(CopyText, { textToCopy: error.requestId }) : null
          },
          onContactSupport
        };
      }
      default:
        return UNDEFINED_ERROR;
    }
  };
  const DataOverviewError = ({
    error,
    errorMessage,
    onContactSupport
  }) => {
    const {
      title,
      message,
      refreshComponent,
      translationValues,
      onContactSupport: ContactSupport
    } = getErrorMessage(error, errorMessage, onContactSupport);
    return /* @__PURE__ */ u$1(
      ErrorMessageDisplay,
      {
        title,
        message,
        translationValues,
        withImage: true,
        centered: true,
        refreshComponent,
        onContactSupport: ContactSupport
      }
    );
  };
  const TableBody = ({
    data,
    columns,
    customCells,
    onRowHover
  }) => {
    const { i18n } = useCoreContext();
    return /* @__PURE__ */ u$1(k$1, { children: data == null ? void 0 : data.map((item, index) => /* @__PURE__ */ u$1(
      "div",
      {
        role: "row",
        tabIndex: 0,
        className: "adyen-pe-data-grid__row",
        onMouseEnter: i18n.has(`tooltip.${item == null ? void 0 : item.category}`) && onRowHover ? () => onRowHover(index) : noop,
        onFocus: i18n.has(`tooltip.${item == null ? void 0 : item.category}`) && onRowHover ? () => onRowHover(index) : noop,
        onMouseLeave: i18n.has(`tooltip.${item == null ? void 0 : item.category}`) && onRowHover ? () => onRowHover() : noop,
        onBlur: i18n.has(`tooltip.${item == null ? void 0 : item.category}`) && onRowHover ? () => onRowHover() : noop,
        children: /* @__PURE__ */ u$1(TableCells, { columns, customCells, item, rowIndex: index })
      },
      item
    )) });
  };
  const useInteractiveDataGrid = ({ totalRows }) => {
    const [state, dispatch] = h(
      (currentState, action) => {
        const total = totalRows;
        if (total > 1) {
          const nextIndex = action.index;
          if (nextIndex < total && nextIndex >= 0) {
            if (action.type === "ACTIVE") {
              return Object.freeze({ ...currentState, index: action.index ?? 0, activeIndex: action.index });
            } else {
              return Object.freeze({ ...currentState, index: action.index ?? 0, activeIndex: -1 });
            }
          }
        }
        return currentState;
      },
      INITIAL_STATE
    );
    const ref = useReflex(
      q$1(
        (current) => {
          var _a2;
          if (!(current instanceof Element)) return;
          const optionIndex = Number((_a2 = current.dataset) == null ? void 0 : _a2.index);
          if (state.activeIndex === -1 && optionIndex === 0 || optionIndex === state.index) {
            current.setAttribute("tabindex", "0");
          } else {
            current.setAttribute("tabindex", "-1");
          }
          if (optionIndex === state.activeIndex) {
            current == null ? void 0 : current.focus();
          }
        },
        [state.activeIndex, state.index]
      )
    );
    const onKeyDownCapture = q$1(
      (evt) => {
        var _a2, _b2;
        const isRow = ((_a2 = evt.target) == null ? void 0 : _a2.getAttribute("role")) === "row";
        if (!isRow) {
          if (evt.code === InteractionKeyCode.ARROW_LEFT) {
            dispatch({
              type: "ACTIVE",
              index: state.index
            });
          }
          return;
        }
        switch (evt.code) {
          case InteractionKeyCode.ARROW_DOWN:
          case InteractionKeyCode.ARROW_UP:
            dispatch({
              type: "ACTIVE",
              index: evt.code === InteractionKeyCode.ARROW_DOWN ? state.index + 1 : state.index - 1
            });
            break;
          case InteractionKeyCode.HOME:
            dispatch({
              type: "ACTIVE",
              index: 0
            });
            break;
          case InteractionKeyCode.END:
            dispatch({
              type: "ACTIVE",
              index: totalRows - 1
            });
            break;
          case InteractionKeyCode.ENTER:
            (_b2 = evt.currentTarget) == null ? void 0 : _b2.click();
            break;
          default:
            return;
        }
        evt.stopPropagation();
      },
      [totalRows, state.index]
    );
    const onFocusCapture = q$1(
      (index) => (evt) => {
        var _a2;
        const isRow = ((_a2 = evt.target) == null ? void 0 : _a2.localName) === "tr";
        if (!isRow || state.index === -1) dispatch({ type: "CURRENT", index });
      },
      [state.index]
    );
    return { listeners: { onKeyDownCapture, onFocusCapture }, ref, activeIndex: state.activeIndex, currentIndex: state.index };
  };
  const InteractiveBody = ({
    data,
    columns,
    onRowClick,
    customCells,
    onRowHover
  }) => {
    const onClickCallBack = q$1(
      (item) => () => onRowClick == null ? void 0 : onRowClick.callback((onRowClick == null ? void 0 : onRowClick.retrievedField) ? item[onRowClick.retrievedField] : item),
      [onRowClick]
    );
    const { i18n } = useCoreContext();
    const { currentIndex, listeners, ref } = useInteractiveDataGrid({ totalRows: (data == null ? void 0 : data.length) ?? 0 });
    return /* @__PURE__ */ u$1(k$1, { children: data == null ? void 0 : data.map((item, index) => /* @__PURE__ */ u$1(
      "div",
      {
        role: "row",
        tabIndex: 0,
        onMouseEnter: i18n.has(`tooltip.${item == null ? void 0 : item.category}`) && onRowHover ? () => onRowHover(index) : noop,
        onFocus: i18n.has(`tooltip.${item == null ? void 0 : item.category}`) && onRowHover ? () => onRowHover(index) : noop,
        onMouseLeave: i18n.has(`tooltip.${item == null ? void 0 : item.category}`) && onRowHover ? () => onRowHover() : noop,
        onBlur: i18n.has(`tooltip.${item == null ? void 0 : item.category}`) && onRowHover ? () => onRowHover() : noop,
        ref,
        "aria-selected": index === currentIndex,
        "data-index": index,
        className: "adyen-pe-data-grid__row adyen-pe-data-grid__row--clickable",
        onClick: onClickCallBack(item),
        onFocusCapture: listeners.onFocusCapture(index),
        onKeyDownCapture: listeners.onKeyDownCapture,
        children: /* @__PURE__ */ u$1(TableCells, { columns, customCells, item, rowIndex: index })
      },
      item
    )) });
  };
  const SkeletonBody = ({ columnsNumber, loading: loading2, emptyMessageDisplay }) => {
    const rows = Array.from({ length: 10 }, (_2, index) => index);
    const columns = Array.from({ length: columnsNumber }, (_2, index) => index);
    return /* @__PURE__ */ u$1(k$1, { children: [
      rows.map((_2, i2) => /* @__PURE__ */ u$1("div", { className: "adyen-pe-data-grid__row", children: columns.map((_22, index) => /* @__PURE__ */ u$1("div", { className: "adyen-pe-data-grid__cell adyen-pe-data-grid__skeleton-cell", children: /* @__PURE__ */ u$1(
        "span",
        {
          className: cx({
            "adyen-pe-data-grid__skeleton-cell-content adyen-pe-data-grid__skeleton-cell-content--loading": loading2,
            "adyen-pe-data-grid__empty-cell": !loading2
          })
        }
      ) }, `adyen-pe-data-grid-skeleton-cell-${index}`)) }, `adyen-pe-data-grid-skeleton-row-${i2}`)),
      !loading2 && emptyMessageDisplay && emptyMessageDisplay
    ] });
  };
  const DataGridProvider = ({ children }) => {
    const minWidthByColumn = T$1(() => /* @__PURE__ */ new Map(), []);
    const registerCells = q$1(
      ({ column, width }) => {
        if (minWidthByColumn.has(column)) {
          const existingWidth = minWidthByColumn.get(column);
          if (width > existingWidth) {
            minWidthByColumn.set(column, width);
          }
        } else {
          minWidthByColumn.set(column, width);
        }
      },
      [minWidthByColumn]
    );
    const getMinWidthByColumn = q$1(
      (column) => {
        return minWidthByColumn.get(column);
      },
      [minWidthByColumn]
    );
    return /* @__PURE__ */ u$1(DataGridContext.Provider, { value: { registerCells, getMinWidthByColumn }, children: H$1(children) });
  };
  const TableHeaderCell = ({ cellKey, position, label }) => {
    const { registerCells } = useDataGridContext();
    const ref = A$1(null);
    y(() => {
      var _a2;
      if (ref.current) {
        registerCells({
          column: cellKey,
          width: (_a2 = ref.current) == null ? void 0 : _a2.getBoundingClientRect().width
        });
      }
    }, [cellKey, registerCells]);
    return /* @__PURE__ */ u$1(
      "div",
      {
        role: "columnheader",
        id: String(cellKey),
        className: cx("adyen-pe-data-grid__cell adyen-pe-data-grid__cell--heading", {
          "adyen-pe-data-grid__cell--right": position === "right",
          "adyen-pe-data-grid__cell--center": position === "center"
        }),
        children: /* @__PURE__ */ u$1("div", { ref, className: "adyen-pe-data-grid__cell--heading-content", children: label })
      }
    );
  };
  const INITIAL_STATE = Object.freeze({
    activeIndex: -1,
    index: -1
  });
  function DataGrid({ errorDisplay, ...props }) {
    return /* @__PURE__ */ u$1("div", { style: { width: "100%" }, children: /* @__PURE__ */ u$1(DataGridProvider, { children: /* @__PURE__ */ u$1(DataGridTable, { ...props, errorDisplay }) }) });
  }
  function DataGridTable({ autoFitColumns, errorDisplay, ...props }) {
    var _a2, _b2;
    const children = T$1(() => H$1(props.children), [props.children]);
    const footer = T$1(() => children.find((child) => (child == null ? void 0 : child["type"]) === DataGridFooter), [children]);
    const emptyBody = T$1(() => {
      var _a3;
      return ((_a3 = props.data) == null ? void 0 : _a3.length) === 0;
    }, [props.data]);
    const showMessage = T$1(() => !props.loading && (emptyBody || props.error), [emptyBody, props.error, props.loading]);
    const { getMinWidthByColumn } = useDataGridContext();
    const { getImageAsset } = useCoreContext();
    const visibleCols = props.columns.filter((column) => column.visible !== false).map((column) => ({ ...column, minWidth: getMinWidthByColumn(column.key) }));
    const cellWidths = visibleCols.map((col) => `minmax(${(col.minWidth || 100) + 40}px, ${col.flex || 1}fr)`).join(" ");
    return /* @__PURE__ */ u$1(
      "div",
      {
        className: cx("adyen-pe-data-grid", {
          "adyen-pe-data-grid--condensed": props.condensed,
          "adyen-pe-data-grid--outline": props.outline,
          "adyen-pe-data-grid--scrollable": props.scrollable,
          "adyen-pe-data-grid--loading": props.loading,
          "adyen-pe-data-grid--empty": emptyBody || props.error
        }),
        style: autoFitColumns ? void 0 : {
          "--adyen-pe-data-grid-cols": visibleCols.length,
          "--adyen-pe-data-grid-cells": cellWidths
        },
        children: [
          /* @__PURE__ */ u$1("div", { className: "adyen-pe-data-grid__table-wrapper", children: [
            /* @__PURE__ */ u$1("div", { role: "table", className: "adyen-pe-data-grid__table", children: [
              /* @__PURE__ */ u$1("div", { className: "adyen-pe-data-grid__head", role: "rowgroup", children: /* @__PURE__ */ u$1("div", { role: "rowheader", className: "adyen-pe-data-grid__header", style: props.loading ? { width: "100%" } : {}, children: visibleCols.map((item) => /* @__PURE__ */ u$1(TableHeaderCell, { label: item.label, position: item.position, cellKey: item.key }, item.key)) }) }),
              /* @__PURE__ */ u$1(DataGridBody, { ...props, columns: visibleCols, emptyBody })
            ] }),
            showMessage && (emptyBody && !props.error ? /* @__PURE__ */ u$1(
              ErrorMessageDisplay,
              {
                title: ((_a2 = props.emptyTableMessage) == null ? void 0 : _a2.title) ?? "thereAreNoResults",
                message: (_b2 = props.emptyTableMessage) == null ? void 0 : _b2.message,
                imageDesktop: getImageAsset == null ? void 0 : getImageAsset({ name: "no-data-female" }),
                centered: true
              }
            ) : props.error && errorDisplay ? errorDisplay() : null)
          ] }),
          footer
        ]
      }
    );
  }
  function DataGridBody(props) {
    const showSkeleton = T$1(() => props.loading || props.emptyBody || props.error, [props.emptyBody, props.error, props.loading]);
    return /* @__PURE__ */ u$1(
      "div",
      {
        role: "rowgroup",
        className: cx("adyen-pe-data-grid__body"),
        style: showSkeleton && { display: "grid", gridTemplateColumns: "1fr" },
        children: showSkeleton ? /* @__PURE__ */ u$1(SkeletonBody, { columnsNumber: props.columns.length, loading: props.loading }) : props.onRowClick ? /* @__PURE__ */ u$1(
          InteractiveBody,
          {
            onRowHover: props.onRowHover,
            data: props.data,
            columns: props.columns,
            onRowClick: props.onRowClick,
            customCells: props.customCells
          }
        ) : /* @__PURE__ */ u$1(
          TableBody,
          {
            onRowHover: props.onRowHover,
            data: props.data,
            customCells: props.customCells,
            columns: props.columns
          }
        )
      }
    );
  }
  DataGrid.Footer = DataGridFooter;
  function DataGridFooter({ children }) {
    return /* @__PURE__ */ u$1("div", { className: "adyen-pe-data-grid__footer", children });
  }
  DataGrid.defaultProps = {
    condensed: false,
    outline: true,
    scrollable: true
  };
  const ARIA_ERROR_SUFFIX = "-ariaError";
  var CommitAction = /* @__PURE__ */ ((CommitAction2) => {
    CommitAction2[CommitAction2["NONE"] = 0] = "NONE";
    CommitAction2[CommitAction2["APPLY"] = 1] = "APPLY";
    CommitAction2[CommitAction2["CLEAR"] = 2] = "CLEAR";
    return CommitAction2;
  })(CommitAction || {});
  const useCommitAction = ({ applyDisabled, applyTitle, resetDisabled, resetTitle } = EMPTY_OBJECT) => {
    const { i18n } = useCoreContext();
    const [commitAction, setCommitAction] = d(CommitAction.NONE);
    const applyAction = q$1(() => setCommitAction(CommitAction.APPLY), [setCommitAction]);
    const resetAction = q$1(() => setCommitAction(CommitAction.CLEAR), [setCommitAction]);
    const resetCommitAction = q$1(() => setCommitAction(CommitAction.NONE), [setCommitAction]);
    const applyButtonAction = T$1(
      () => ({
        disabled: boolOrFalse(applyDisabled),
        event: applyAction,
        title: (applyTitle == null ? void 0 : applyTitle.trim()) || i18n.get("apply"),
        variant: ButtonVariant.PRIMARY
      }),
      [i18n, applyAction, applyDisabled, applyTitle]
    );
    const resetButtonAction = T$1(
      () => ({
        disabled: boolOrFalse(resetDisabled),
        event: resetAction,
        title: (resetTitle == null ? void 0 : resetTitle.trim()) || i18n.get("reset"),
        variant: ButtonVariant.SECONDARY
      }),
      [i18n, resetAction, resetDisabled, resetTitle]
    );
    const commitActionButtons = T$1(() => [applyButtonAction, resetButtonAction], [applyButtonAction, resetButtonAction]);
    const committing = T$1(() => commitAction !== CommitAction.NONE, [commitAction]);
    y(() => {
      switch (commitAction) {
        case CommitAction.APPLY:
        case CommitAction.CLEAR:
          resetCommitAction();
          break;
      }
    }, [commitAction, resetCommitAction]);
    return { commitAction, commitActionButtons, committing, resetCommitAction };
  };
  function Img(props) {
    const { backgroundUrl = "", className = "", classNameModifiers = [], src = "", alt = "", showOnError = false } = props;
    const [loaded, setLoaded] = d(false);
    const imageRef = A$1(null);
    const handleLoad = () => {
      setLoaded(true);
    };
    const handleError = () => {
      setLoaded(showOnError);
    };
    const classNames = cx(
      [className],
      "adyen-pe-image",
      { "adyen-pe-image--loaded": loaded },
      ...classNameModifiers.map((modifier) => `adyen-pe-image--${modifier}`)
    );
    y(() => {
      const image = backgroundUrl ? new Image() : imageRef.current;
      if (image) {
        image.src = backgroundUrl || src;
        image.onload = handleLoad;
      }
      setLoaded(!!(image == null ? void 0 : image.complete));
    }, []);
    if (backgroundUrl) {
      return /* @__PURE__ */ u$1("div", { style: { backgroundUrl }, ...props, className: classNames });
    }
    return /* @__PURE__ */ u$1("img", { ...props, alt, ref: imageRef, className: classNames, onError: handleError });
  }
  const DROPDOWN_BASE_CLASS = "adyen-pe-dropdown";
  const DROPDOWN_BUTTON_CLASSNAME = getModifierClasses(DEFAULT_BUTTON_CLASSNAME, [ButtonVariant.SECONDARY], [DEFAULT_BUTTON_CLASSNAME]);
  const DROPDOWN_BUTTON_CLASS = `${DROPDOWN_BASE_CLASS}__button`;
  const DROPDOWN_BUTTON_ACTIVE_CLASS = `${DROPDOWN_BUTTON_CLASS}--active`;
  const DROPDOWN_BUTTON_COLLAPSE_INDICATOR_CLASS = `${DROPDOWN_BUTTON_CLASS}-collapse-indicator`;
  const DROPDOWN_BUTTON_HAS_SELECTION_CLASS = `${DROPDOWN_BUTTON_CLASS}--has-selection`;
  const DROPDOWN_BUTTON_ICON_CLASS = `${DROPDOWN_BUTTON_CLASS}-icon`;
  const DROPDOWN_BUTTON_MULTI_SELECT_COUNTER_CLASS = `${DROPDOWN_BUTTON_CLASS}-multiselect-counter`;
  const DROPDOWN_BUTTON_READONLY_CLASS = `${DROPDOWN_BUTTON_CLASS}--readonly`;
  const DROPDOWN_BUTTON_TEXT_CLASS = `${DROPDOWN_BUTTON_CLASS}-text`;
  const DROPDOWN_BUTTON_VALID_CLASS = `${DROPDOWN_BUTTON_CLASS}--valid`;
  const DROPDOWN_BUTTON_INVALID_CLASS = `${DROPDOWN_BUTTON_CLASS}--invalid`;
  const DROPDOWN_ELEMENT_CLASS = `${DROPDOWN_BASE_CLASS}__element`;
  const DROPDOWN_ELEMENT_ACTIVE_CLASS = `${DROPDOWN_ELEMENT_CLASS}--active`;
  const DROPDOWN_ELEMENT_CHECKBOX_CLASS = `${DROPDOWN_ELEMENT_CLASS}-checkbox`;
  const DROPDOWN_ELEMENT_CHECKMARK_CLASS = `${DROPDOWN_ELEMENT_CLASS}-checkmark`;
  const DROPDOWN_ELEMENT_CONTENT_CLASS = `${DROPDOWN_ELEMENT_CLASS}-content`;
  const DROPDOWN_ELEMENT_DISABLED_CLASS = `${DROPDOWN_ELEMENT_CLASS}--disabled`;
  const DROPDOWN_ELEMENT_ICON_CLASS = `${DROPDOWN_ELEMENT_CLASS}-icon`;
  const DROPDOWN_ELEMENT_NO_OPTION_CLASS = `${DROPDOWN_ELEMENT_CLASS}--no-option`;
  const DROPDOWN_LIST_CLASS = `${DROPDOWN_BASE_CLASS}__list`;
  const DROPDOWN_LIST_ACTIVE_CLASS = `${DROPDOWN_LIST_CLASS}--active`;
  const DROPDOWN_MULTI_SELECT_CLASS = `${DROPDOWN_BASE_CLASS}--multiselect`;
  const SelectButtonElement = ({
    active,
    disabled,
    className,
    filterable,
    toggleButtonRef,
    ...props
  }) => {
    const baseClassName = T$1(() => filterable ? cx(DROPDOWN_BUTTON_CLASSNAME, className) : className, [className, filterable]);
    return filterable ? /* @__PURE__ */ u$1("div", { ...props, className: baseClassName, ref: toggleButtonRef }) : /* @__PURE__ */ u$1(
      Button$1,
      {
        ...props,
        className: baseClassName,
        disabled,
        variant: ButtonVariant.SECONDARY,
        ref: toggleButtonRef
      }
    );
  };
  const SelectButton = (props) => {
    var _a2, _b2;
    const { i18n } = useCoreContext();
    const { active, filterable, multiSelect, placeholder, readonly, showList, withoutCollapseIndicator } = props;
    const placeholderText = T$1(() => (placeholder == null ? void 0 : placeholder.trim()) || i18n.get("select.filter.placeholder"), [i18n, placeholder]);
    const buttonActiveItem = T$1(() => boolOrFalse(multiSelect) ? void 0 : active[0], [active, multiSelect]);
    const buttonTitleText = T$1(() => {
      var _a3;
      return ((_a3 = buttonActiveItem == null ? void 0 : buttonActiveItem.name) == null ? void 0 : _a3.trim()) || placeholderText;
    }, [buttonActiveItem, placeholderText]);
    return /* @__PURE__ */ u$1(
      SelectButtonElement,
      {
        active,
        disabled: readonly,
        "aria-disabled": readonly,
        "aria-expanded": showList,
        "aria-haspopup": "listbox",
        className: cx(DROPDOWN_BUTTON_CLASS, {
          [DROPDOWN_BUTTON_ACTIVE_CLASS]: showList,
          [DROPDOWN_BUTTON_HAS_SELECTION_CLASS]: !!active.length,
          [DROPDOWN_BUTTON_READONLY_CLASS]: readonly,
          [DROPDOWN_BUTTON_INVALID_CLASS]: props.isInvalid,
          [DROPDOWN_BUTTON_VALID_CLASS]: props.isValid
        }),
        filterable,
        onClick: !readonly ? props.toggleList : void 0,
        onKeyDown: !readonly ? props.onButtonKeyDown : void 0,
        role: filterable ? "button" : void 0,
        tabIndex: 0,
        title: buttonTitleText,
        toggleButtonRef: props.toggleButtonRef,
        type: !filterable ? "button" : void 0,
        "aria-describedby": props.ariaDescribedBy,
        id: props.id ?? "",
        children: [
          showList && filterable ? /* @__PURE__ */ u$1(
            "input",
            {
              "aria-autocomplete": "list",
              "aria-controls": props.selectListId,
              "aria-expanded": showList,
              "aria-owns": props.selectListId,
              autoComplete: "off",
              className: "adyen-pe-filter-input",
              onInput: props.onInput,
              placeholder: placeholderText,
              ref: props.filterInputRef,
              role: "combobox",
              type: "text"
            }
          ) : /* @__PURE__ */ u$1(k$1, { children: [
            (buttonActiveItem == null ? void 0 : buttonActiveItem.icon) && /* @__PURE__ */ u$1(Img, { className: DROPDOWN_BUTTON_ICON_CLASS, src: buttonActiveItem.icon, alt: ((_a2 = buttonActiveItem == null ? void 0 : buttonActiveItem.name) == null ? void 0 : _a2.trim()) ?? "" }),
            /* @__PURE__ */ u$1("span", { className: DROPDOWN_BUTTON_TEXT_CLASS, children: ((_b2 = buttonActiveItem == null ? void 0 : buttonActiveItem.selectedOptionName) == null ? void 0 : _b2.trim()) || buttonTitleText }),
            multiSelect && props.appliedFilterNumber > 0 && /* @__PURE__ */ u$1("div", { className: DROPDOWN_BUTTON_MULTI_SELECT_COUNTER_CLASS, children: /* @__PURE__ */ u$1(Typography$1, { el: TypographyElement.SPAN, variant: TypographyVariant.BODY, stronger: true, children: props.appliedFilterNumber }) })
          ] }),
          !withoutCollapseIndicator && /* @__PURE__ */ u$1("span", { className: DROPDOWN_BUTTON_COLLAPSE_INDICATOR_CLASS, children: /* @__PURE__ */ u$1(Icon$1, { name: "chevron-down" }) })
        ]
      }
    );
  };
  const useContainerQuery = (query) => {
    var _a2;
    const { componentRef } = useCoreContext();
    const [width, setWidth] = d(((_a2 = componentRef.current) == null ? void 0 : _a2.offsetWidth) || 0);
    const [type2, breakpoint, minMax] = query;
    let queryMatch = false;
    switch (type2) {
      case "up":
        queryMatch = width >= breakpoint;
        break;
      case "down":
        queryMatch = width <= breakpoint;
        break;
      case "only":
        if (minMax) {
          const { min: min2, max: max2 } = minMax;
          queryMatch = max2 ? width <= max2 : min2 ? width >= min2 : false;
        } else {
          queryMatch = width === breakpoint;
        }
        break;
    }
    y(() => {
      const containerElement = componentRef.current;
      if (!containerElement) return;
      const resizeObserver = new ResizeObserver((entries) => {
        for (const entry of entries) {
          if (entry.target === containerElement) {
            setWidth(containerElement.offsetWidth);
          }
        }
      });
      resizeObserver.observe(containerElement);
      return () => {
        resizeObserver.unobserve(containerElement);
        resizeObserver.disconnect();
      };
    }, [componentRef]);
    return queryMatch;
  };
  const containerQueries = {
    up: {
      sm: ["up", BREAKPOINTS.sm],
      md: ["up", BREAKPOINTS.md]
    },
    down: {
      xs: ["down", BREAKPOINTS.sm - 1],
      sm: ["down", BREAKPOINTS.md - 1]
    },
    only: {
      xs: ["only", BREAKPOINTS.sm - 1, { max: BREAKPOINTS.sm - 1 }],
      sm: ["only", BREAKPOINTS.sm, { max: BREAKPOINTS.md - 1 }],
      md: ["only", BREAKPOINTS.md, { max: BREAKPOINTS.lg - 1 }]
    }
  };
  const useResponsiveContainer = useContainerQuery;
  function PopoverContainer(props) {
    var _a2;
    const [_2, setLastScrollCallbackTimestamp] = d(performance.now());
    const [popoverStyle, setPopoverStyle] = d();
    const shouldTrackVerticalScrolling = q$1(
      (element) => element && props.fixedPositioning ? element.scrollHeight > element.offsetHeight : false,
      [props.fixedPositioning]
    );
    const scrollElement = (_a2 = props.targetElement.current) == null ? void 0 : _a2.offsetParent;
    y(() => {
      if (!shouldTrackVerticalScrolling(scrollElement)) return;
      const { height: scrollElementHeight, y: scrollElementY } = scrollElement.getBoundingClientRect();
      setPopoverStyle({
        minY: scrollElementY,
        maxY: scrollElementY + scrollElementHeight
      });
      let rafId = null;
      const delayedCallback = () => {
        rafId && cancelAnimationFrame(rafId);
        rafId = requestAnimationFrame(() => {
          rafId = null;
          setLastScrollCallbackTimestamp(performance.now());
        });
      };
      scrollElement.addEventListener("scroll", delayedCallback, { passive: true });
      return () => {
        scrollElement.removeEventListener("scroll", delayedCallback);
        rafId && cancelAnimationFrame(rafId);
        rafId = null;
      };
    }, [scrollElement, shouldTrackVerticalScrolling]);
    return props.fixedPositioning ? (
      // TODO: - Consider using same position from parent element
      //       - Consider adding position prop to components using Popover
      /* @__PURE__ */ u$1(Popover, { ...props, position: PopoverContainerPosition.BOTTOM, additionalStyle: popoverStyle })
    ) : /* @__PURE__ */ u$1(Popover, { ...props });
  }
  const renderDefaultMultiSelectionCheckedness = (data) => data.multiSelect ? /* @__PURE__ */ u$1("span", { className: DROPDOWN_ELEMENT_CHECKBOX_CLASS, children: data.selected ? /* @__PURE__ */ u$1(Icon$1, { name: "checkmark-square-fill" }) : /* @__PURE__ */ u$1(Icon$1, { name: "square" }) }) : null;
  const renderDefaultSingleSelectionCheckedness = (data) => data.multiSelect ? null : /* @__PURE__ */ u$1("span", { className: DROPDOWN_ELEMENT_CHECKMARK_CLASS, children: data.selected && /* @__PURE__ */ u$1(Icon$1, { name: "checkmark" }) });
  const renderListItemDefault = (data) => /* @__PURE__ */ u$1(k$1, { children: [
    renderDefaultMultiSelectionCheckedness(data),
    /* @__PURE__ */ u$1("div", { className: data.contentClassName, children: [
      data.item.icon && /* @__PURE__ */ u$1(Img, { className: data.iconClassName, alt: data.item.name, src: data.item.icon }),
      /* @__PURE__ */ u$1("span", { children: data.item.name })
    ] }),
    renderDefaultSingleSelectionCheckedness(data)
  ] });
  const SelectListItem = ({ item, multiSelect, onKeyDown, onSelect, renderListItem, selected }) => {
    const disabled = !!item.disabled;
    const dataDisabled = boolOrFalse(item.disabled) || null;
    const itemClassName = cx(DROPDOWN_ELEMENT_CLASS, {
      [DROPDOWN_ELEMENT_ACTIVE_CLASS]: selected,
      [DROPDOWN_ELEMENT_DISABLED_CLASS]: disabled
    });
    return /* @__PURE__ */ u$1(
      "li",
      {
        "aria-disabled": disabled,
        "aria-selected": selected,
        className: itemClassName,
        "data-disabled": dataDisabled,
        "data-value": item.id,
        onClick: onSelect,
        onKeyDown,
        title: item.name,
        role: "option",
        tabIndex: -1,
        children: renderListItem({
          item,
          multiSelect,
          selected,
          contentClassName: DROPDOWN_ELEMENT_CONTENT_CLASS,
          iconClassName: DROPDOWN_ELEMENT_ICON_CLASS
        })
      }
    );
  };
  const SelectListItem$1 = M(SelectListItem);
  const SelectList = fixedForwardRef(
    ({
      active,
      commitActions,
      items,
      multiSelect,
      onKeyDown,
      onSelect,
      renderListItem,
      selectListId,
      showList,
      textFilter,
      toggleButtonRef,
      dismissPopover,
      setToTargetWidth,
      popoverClassNameModifiers,
      showOverlay,
      fitPosition,
      fixedPopoverPositioning
    }, ref) => {
      const { i18n } = useCoreContext();
      const isSmContainer = useResponsiveContainer(containerQueries.down.xs);
      const filteredItems = items.filter((item) => !textFilter || item.name.toLowerCase().includes(textFilter));
      const listClassName = cx(DROPDOWN_LIST_CLASS, { [DROPDOWN_LIST_ACTIVE_CLASS]: showList });
      const noOptionsClassName = cx(DROPDOWN_ELEMENT_CLASS, DROPDOWN_ELEMENT_NO_OPTION_CLASS);
      const renderSelectOption = T$1(() => isFunction(renderListItem) ? renderListItem : renderListItemDefault, [renderListItem]);
      const multipleSelection = T$1(() => boolOrFalse(multiSelect), [multiSelect]);
      return showList ? /* @__PURE__ */ u$1(
        PopoverContainer,
        {
          classNameModifiers: popoverClassNameModifiers,
          actions: multipleSelection ? commitActions : void 0,
          disableFocusTrap: true,
          divider: true,
          dismiss: dismissPopover,
          dismissible: false,
          open: showList,
          setToTargetWidth,
          containerSize: PopoverContainerSize.MEDIUM,
          variant: PopoverContainerVariant.POPOVER,
          targetElement: toggleButtonRef,
          withContentPadding: false,
          position: PopoverContainerPosition.BOTTOM,
          showOverlay: showOverlay && isSmContainer,
          fitPosition,
          fixedPositioning: fixedPopoverPositioning,
          children: /* @__PURE__ */ u$1("ul", { className: listClassName, id: selectListId, ref, role: "listbox", "aria-multiselectable": multipleSelection, children: filteredItems.length ? filteredItems.map((item) => {
            return /* @__PURE__ */ u$1(
              SelectListItem$1,
              {
                item,
                multiSelect: multipleSelection,
                onKeyDown,
                onSelect,
                renderListItem: renderSelectOption,
                selected: active.includes(item)
              },
              item.id
            );
          }) : /* @__PURE__ */ u$1("div", { className: noOptionsClassName, children: i18n.get("select.noOptionsFound") }) })
        }
      ) : null;
    }
  );
  const SelectList$1 = M(SelectList);
  const useSelect = ({ items, multiSelect, selected }) => {
    const getSelectedItems = q$1(
      (selectedItems = EMPTY_ARRAY) => {
        const _selected = EMPTY_ARRAY.concat(selectedItems ?? EMPTY_ARRAY).filter(Boolean);
        const _selectedItems = items.filter((item) => _selected.includes(item.id));
        const selection2 = multiSelect ? _selectedItems : _selectedItems.slice(0, 1);
        return selection2.length ? Object.freeze(selection2) : EMPTY_ARRAY;
      },
      [items, multiSelect]
    );
    const [selection, setSelection] = d(getSelectedItems(selected));
    const resetSelection = q$1(
      (selection2 = EMPTY_ARRAY) => {
        const nextSelection = selection2.filter((item) => items.includes(item));
        setSelection(nextSelection.length ? Object.freeze(nextSelection) : EMPTY_ARRAY);
      },
      [items, setSelection]
    );
    const select = q$1(
      (item) => {
        setSelection((currentSelection) => {
          const index = currentSelection.indexOf(item);
          if (index < 0) return Object.freeze((multiSelect ? currentSelection : EMPTY_ARRAY).concat(item));
          if (!multiSelect) return currentSelection;
          const nextSelection = [...currentSelection];
          nextSelection.splice(index, 1);
          return nextSelection.length ? Object.freeze(nextSelection) : EMPTY_ARRAY;
        });
      },
      [multiSelect, setSelection]
    );
    y(() => setSelection(getSelectedItems(selected)), [getSelectedItems, selected, setSelection]);
    return { resetSelection, select, selection };
  };
  const Select = ({
    className,
    classNameModifiers = EMPTY_ARRAY,
    popoverClassNameModifiers,
    items = EMPTY_ARRAY,
    filterable = false,
    multiSelect = false,
    readonly = false,
    onChange = noop,
    selected,
    name,
    isInvalid,
    isValid,
    placeholder,
    uniqueId: uniqueId2,
    renderListItem,
    isCollatingErrors,
    setToTargetWidth,
    withoutCollapseIndicator = false,
    showOverlay = false,
    fitPosition,
    fixedPopoverPositioning
  }) => {
    const { resetSelection, select, selection } = useSelect({ items, multiSelect, selected });
    const [showList, setShowList] = d(false);
    const [textFilter, setTextFilter] = d("");
    const filterInputRef = A$1(null);
    const selectListRef = A$1(null);
    const toggleButtonRef = A$1(null);
    const selectListId = A$1(`select-${uuid()}`);
    const autoFocusAnimFrame = A$1();
    const pendingClickOutsideTriggeredHideList = A$1(true);
    const clearSelectionInProgress = A$1(false);
    const cachedSelectedItems = A$1(selection);
    const selectedItems = A$1(selection);
    const appliedFilterNumber = T$1(() => selection.length, [selection]);
    const dismissPopover = q$1(() => {
      setTextFilter("");
      setShowList(false);
      if (showList) {
        resetSelection(cachedSelectedItems.current);
        pendingClickOutsideTriggeredHideList.current = true;
      }
    }, [resetSelection, setShowList, setTextFilter, showList]);
    const dropdownClassName = T$1(
      () => cx([
        DROPDOWN_BASE_CLASS,
        { [DROPDOWN_MULTI_SELECT_CLASS]: boolOrFalse(multiSelect) },
        ...classNameModifiers.map((mod2) => `${DROPDOWN_BASE_CLASS}--${mod2}`),
        className
      ]),
      [className, classNameModifiers, multiSelect]
    );
    const { commitAction, commitActionButtons, committing, resetCommitAction } = useCommitAction({
      resetDisabled: !selection.length
    });
    const closeList = q$1(() => {
      var _a2;
      setTextFilter("");
      setShowList(false);
      resetCommitAction();
      if (!pendingClickOutsideTriggeredHideList.current) {
        (_a2 = toggleButtonRef.current) == null ? void 0 : _a2.focus();
      } else pendingClickOutsideTriggeredHideList.current = false;
    }, [resetCommitAction, setShowList, setTextFilter]);
    const commitSelection = q$1(() => {
      cachedSelectedItems.current = selection;
      const value2 = `${selection.map(({ id: id2 }) => id2)}`;
      onChange({ target: { value: value2, name } });
    }, [name, onChange, selection]);
    y(() => {
      switch (commitAction) {
        case CommitAction.APPLY:
          commitSelection();
          break;
        case CommitAction.CLEAR:
          resetSelection();
          clearSelectionInProgress.current = true;
          break;
      }
    }, [commitAction, commitSelection, resetSelection]);
    const handleSelect = q$1(
      (e2) => {
        var _a2;
        e2.preventDefault();
        const target = e2.currentTarget && ((_a2 = selectListRef == null ? void 0 : selectListRef.current) == null ? void 0 : _a2.contains(e2.currentTarget)) ? e2.currentTarget : null;
        if (target && !target.getAttribute("data-disabled")) {
          const value2 = target.getAttribute("data-value");
          const item = items.find((item2) => item2.id === value2);
          select(item);
        }
      },
      [items, select]
    );
    y(() => {
      if (selectedItems.current !== selection) {
        selectedItems.current = selection;
        if (!multiSelect || clearSelectionInProgress.current) {
          commitSelection();
          closeList();
        }
      }
      clearSelectionInProgress.current = false;
    }, [closeList, commitSelection, multiSelect, selection]);
    y(() => {
      if (committing) closeList();
    }, [committing, closeList]);
    const handleButtonKeyDown = q$1(
      (evt) => {
        switch (evt.code) {
          case InteractionKeyCode.ESCAPE:
          case InteractionKeyCode.TAB:
            showList && closeList();
            pendingClickOutsideTriggeredHideList.current = evt.key === InteractionKeyCode.TAB;
            return;
          case InteractionKeyCode.ENTER:
          case InteractionKeyCode.SPACE:
            if (filterable && showList) {
              if (evt.key === InteractionKeyCode.ENTER) {
                if (textFilter) handleSelect(evt);
                else break;
              }
              return;
            }
            break;
          case InteractionKeyCode.ARROW_DOWN:
          case InteractionKeyCode.ARROW_UP:
            break;
          default:
            return;
        }
        evt.preventDefault();
        setShowList(true);
      },
      [closeList, filterable, handleSelect, showList, setShowList, textFilter]
    );
    y(() => {
      if (showList) {
        cancelAnimationFrame(autoFocusAnimFrame.current);
        autoFocusAnimFrame.current = requestAnimationFrame(() => {
          var _a2;
          focus: {
            let item = (_a2 = selectListRef.current) == null ? void 0 : _a2.firstElementChild;
            let firstAvailableItem;
            while (item) {
              if (!(item.dataset.disabled && item.dataset.disabled === "true")) {
                if (item.getAttribute("aria-selected") === "true") {
                  item.focus();
                  break focus;
                }
                firstAvailableItem = firstAvailableItem || item;
              }
              item = item.nextElementSibling;
            }
            if (firstAvailableItem) firstAvailableItem.focus();
          }
        });
      }
    }, [showList]);
    const handleListKeyDown = q$1(
      (evt) => {
        const target = evt.target;
        switch (evt.code) {
          case InteractionKeyCode.ESCAPE:
            evt.preventDefault();
            closeList();
            break;
          case InteractionKeyCode.ENTER:
          case InteractionKeyCode.SPACE:
            handleSelect(evt);
            break;
          case InteractionKeyCode.ARROW_DOWN: {
            evt.preventDefault();
            let item = target.nextElementSibling;
            while (item) {
              if (!(item.dataset.disabled && item.dataset.disabled === "true")) {
                item.focus();
                break;
              }
              item = item.nextElementSibling;
            }
            break;
          }
          case InteractionKeyCode.ARROW_UP: {
            evt.preventDefault();
            focus: {
              let item = target.previousElementSibling;
              while (item) {
                if (!(item.dataset.disabled && item.dataset.disabled === "true")) {
                  item.focus();
                  break focus;
                }
                item = item.previousElementSibling;
              }
              if (filterable && filterInputRef.current) {
                filterInputRef.current.focus();
              }
            }
            break;
          }
          case InteractionKeyCode.TAB:
            closeList();
            break;
        }
      },
      [closeList, filterable, handleSelect]
    );
    const handleTextFilter = q$1(
      (e2) => {
        const value2 = e2.target.value;
        setTextFilter(value2.toLowerCase());
      },
      [setTextFilter]
    );
    const toggleList = q$1(
      (e2) => {
        e2.preventDefault();
        setShowList((showList2) => !showList2);
        showList && resetSelection(cachedSelectedItems.current);
      },
      [setShowList, showList, resetSelection]
    );
    y(() => {
      var _a2;
      if (showList && filterable) {
        (_a2 = filterInputRef.current) == null ? void 0 : _a2.focus();
      }
    }, [filterable, showList]);
    return /* @__PURE__ */ u$1("div", { className: dropdownClassName, children: [
      /* @__PURE__ */ u$1(
        SelectButton,
        {
          id: uniqueId2 ?? void 0,
          appliedFilterNumber,
          active: selection,
          filterInputRef,
          filterable,
          isInvalid,
          isValid,
          onButtonKeyDown: handleButtonKeyDown,
          onInput: handleTextFilter,
          multiSelect,
          placeholder,
          readonly,
          selectListId: selectListId.current,
          showList,
          toggleButtonRef,
          toggleList,
          withoutCollapseIndicator,
          ariaDescribedBy: !isCollatingErrors && uniqueId2 ? `${uniqueId2}${ARIA_ERROR_SUFFIX}` : void 0
        }
      ),
      /* @__PURE__ */ u$1(
        SelectList$1,
        {
          popoverClassNameModifiers,
          setToTargetWidth,
          dismissPopover,
          active: selection,
          commitActions: commitActionButtons,
          items,
          multiSelect,
          onKeyDown: handleListKeyDown,
          onSelect: handleSelect,
          selectListId: selectListId.current,
          ref: selectListRef,
          toggleButtonRef,
          renderListItem,
          showList,
          showOverlay,
          textFilter,
          fitPosition,
          fixedPopoverPositioning
        }
      )
    ] });
  };
  function Pagination({ next, hasNext, hasPrev, prev, limit, limitOptions, onLimitSelection }) {
    const { i18n } = useCoreContext();
    const _limitOptions = T$1(
      () => limitOptions && Object.freeze(limitOptions.map((option) => ({ id: `${option}`, name: `${option}` }))),
      [limitOptions]
    );
    const _onLimitChanged = q$1(
      ({ target }) => {
        if (isNullish(target == null ? void 0 : target.value)) return;
        onLimitSelection == null ? void 0 : onLimitSelection(+target.value);
      },
      [onLimitSelection]
    );
    return /* @__PURE__ */ u$1("div", { "aria-label": i18n.get("paginatedNavigation"), className: `adyen-pe-pagination ${cx({})}`, children: [
      /* @__PURE__ */ u$1("div", { className: "adyen-pe-pagination__context", children: _limitOptions && onLimitSelection && /* @__PURE__ */ u$1(k$1, { children: [
        /* @__PURE__ */ u$1("span", { children: i18n.get("pagination.showing") }),
        /* @__PURE__ */ u$1("div", { className: "adyen-pe-pagination__limit-selector", children: /* @__PURE__ */ u$1(
          Select,
          {
            setToTargetWidth: true,
            filterable: false,
            multiSelect: false,
            items: _limitOptions,
            onChange: _onLimitChanged,
            selected: `${limit ?? ""}`
          }
        ) })
      ] }) }),
      /* @__PURE__ */ u$1("div", { className: "adyen-pe-pagination__controls", children: [
        /* @__PURE__ */ u$1(
          Button$1,
          {
            variant: ButtonVariant.TERTIARY,
            disabled: !hasPrev,
            iconButton: true,
            classNameModifiers: ["circle"].concat(hasPrev ? EMPTY_ARRAY : "disabled"),
            onClick: prev,
            children: [
              /* @__PURE__ */ u$1(Icon$1, { name: "chevron-left" }),
              /* @__PURE__ */ u$1("span", { className: "adyen-pe-visually-hidden", children: i18n.get("pagination.previousPage") })
            ]
          }
        ),
        /* @__PURE__ */ u$1(
          Button$1,
          {
            variant: ButtonVariant.TERTIARY,
            disabled: !hasNext,
            iconButton: true,
            classNameModifiers: ["circle"].concat(hasNext ? EMPTY_ARRAY : "disabled"),
            onClick: next,
            children: [
              /* @__PURE__ */ u$1("span", { className: "adyen-pe-visually-hidden", children: i18n.get("pagination.nextPage") }),
              /* @__PURE__ */ u$1(Icon$1, { name: "chevron-right" })
            ]
          }
        )
      ] })
    ] });
  }
  const BASE_CLASS$n = "adyen-pe-transactions-table";
  const AMOUNT_CLASS$1 = BASE_CLASS$n + "__amount";
  const PAYMENT_METHOD_CLASS = BASE_CLASS$n + "__payment-method";
  const PAYMENT_METHOD_LOGO_CONTAINER_CLASS = BASE_CLASS$n + "__payment-method-logo-container";
  const PAYMENT_METHOD_LOGO_CLASS = BASE_CLASS$n + "__payment-method-logo";
  const DATE_AND_PAYMENT_METHOD_CLASS = BASE_CLASS$n + "__date-and-payment-method";
  const DATE_METHOD_CLASS = BASE_CLASS$n + "__date-and-payment-method--date";
  const FALLBACK_CDN_CONTEXT = "https://cdf6519016.cdn.adyen.com/checkoutshopper/";
  const returnImage = ({
    name,
    resourceContext,
    imageFolder = "logos/",
    parentFolder = "",
    extension = "svg",
    size = "",
    subFolder = ""
  }) => {
    const path = `/images/${imageFolder}/${subFolder}/${parentFolder}/${name}${size}.${extension}`.replace(/\/+/g, "/");
    return `${resourceContext}${path}`;
  };
  const useImageUrl = ({ options = EMPTY_OBJECT, name }) => {
    const { loadingContext } = useCoreContext();
    const image = T$1(
      () => returnImage({
        resourceContext: FALLBACK_CDN_CONTEXT,
        name,
        ...options
      }),
      [loadingContext, name, options]
    );
    return image;
  };
  const Image$1 = ({ folder = "components/", className, alt, name, extension }) => {
    const imageUrl = useImageUrl({
      options: T$1(() => ({ imageFolder: folder, extension }), [extension, folder]),
      name
    });
    return /* @__PURE__ */ u$1("img", { className: cx("adyen-pe__image", className), alt, src: imageUrl });
  };
  const PaymentMethodCell = ({
    paymentMethod: paymentMethod2,
    bankAccount
  }) => {
    const { i18n } = useCoreContext();
    const isSmContainer = useResponsiveContainer(containerQueries.down.xs);
    return /* @__PURE__ */ u$1("div", { className: PAYMENT_METHOD_CLASS, children: paymentMethod2 || bankAccount ? /* @__PURE__ */ u$1(k$1, { children: [
      /* @__PURE__ */ u$1("div", { className: PAYMENT_METHOD_LOGO_CONTAINER_CLASS, children: /* @__PURE__ */ u$1(
        Image$1,
        {
          name: paymentMethod2 ? paymentMethod2.type : "bankTransfer",
          alt: paymentMethod2 ? paymentMethod2.type : "bankTransfer",
          folder: "logos/",
          className: PAYMENT_METHOD_LOGO_CLASS
        }
      ) }),
      /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.BODY, stronger: isSmContainer, children: paymentMethod2 ? parsePaymentMethodType(paymentMethod2) : bankAccount == null ? void 0 : bankAccount.accountNumberLastFourDigits })
    ] }) : /* @__PURE__ */ u$1(Tag, { label: i18n.get("noData"), variant: TagVariant.LIGHT_WITH_OUTLINE }) });
  };
  const labels = {
    id: "paymentId",
    transactionType: "transactionType",
    createdAt: "date",
    balanceAccountId: "balanceAccount",
    accountHolderId: "account",
    amount: "txAmount",
    description: "description",
    status: "status",
    category: "category",
    paymentMethod: "paymentMethod",
    currency: "currency",
    fundsCapturedAmount: "fundsCaptured",
    payoutAmount: "netPayout",
    adjustmentAmount: "adjustments",
    dateAndPaymentMethod: "date",
    dateAndReportType: "date",
    reportType: "report",
    reportFile: "file"
  };
  const getLabel = (key) => {
    return labels[key] || key;
  };
  function removeUndefinedProperties(obj) {
    let result = {};
    for (const key of Object.keys(obj)) {
      if (!isUndefined(obj[key])) {
        result = { ...result, [key]: obj[key] };
      }
    }
    return result;
  }
  const useTableColumns = ({
    fields,
    customColumns,
    columnConfig,
    fieldsKeys
  }) => {
    const { i18n } = useCoreContext();
    const tableColumns = T$1(() => fields.map((field) => ({ key: field })), [fields]);
    const isSmAndUpContainer = useResponsiveContainer(containerQueries.up.sm);
    const columns = T$1(() => {
      const newFields = (customColumns == null ? void 0 : customColumns.filter((cc) => !(fields == null ? void 0 : fields.some((field) => field === cc.key))).map((colum) => colum.key)) || [];
      const mergedColumns = [...tableColumns, ...(customColumns == null ? void 0 : customColumns.filter((col) => col == null ? void 0 : col.key)) || []];
      const customColumnsMap = (customColumns == null ? void 0 : customColumns.reduce((acc, col) => {
        acc[col.key] = col;
        return acc;
      }, {})) || {};
      const columnMap = /* @__PURE__ */ new Map();
      mergedColumns.forEach((current) => {
        const hiddenColumn = customColumnsMap[current.key];
        if ((hiddenColumn == null ? void 0 : hiddenColumn.visibility) === "hidden") return;
        if (columnMap.has(current.key)) {
          const existing = columnMap.get(current.key);
          columnMap.set(current.key, {
            ...existing,
            ...current,
            visible: current.visibility !== "hidden",
            position: current.align || existing.position
          });
        } else {
          const { key, flex, align } = current;
          const label = i18n.get(getLabel((fieldsKeys == null ? void 0 : fieldsKeys[key]) || key));
          const config = removeUndefinedProperties((columnConfig == null ? void 0 : columnConfig[key]) || EMPTY_OBJECT);
          columnMap.set(current.key, {
            key,
            label,
            visible: newFields.includes(current.key) ? isSmAndUpContainer : true,
            flex,
            position: align,
            ...config
          });
        }
      });
      return Array.from(columnMap.values());
    }, [columnConfig, customColumns, fields, i18n, isSmAndUpContainer, tableColumns]);
    return columns;
  };
  const TRANSACTION_FIELDS = ["createdAt", "paymentMethod", "transactionType", "amount"];
  const TransactionsTable = ({
    activeBalanceAccount,
    availableCurrencies,
    error,
    hasMultipleCurrencies,
    loading: loading2,
    onContactSupport,
    onRowClick,
    showDetails,
    showPagination,
    transactions: transactions2,
    customColumns,
    ...paginationProps
  }) => {
    const { i18n } = useCoreContext();
    const { dateFormat } = useTimezoneAwareDateFormatting(activeBalanceAccount == null ? void 0 : activeBalanceAccount.timeZone);
    const [hoveredRow, setHoveredRow] = d();
    const isSmAndUpContainer = useResponsiveContainer(containerQueries.up.sm);
    const isMdAndUpContainer = useResponsiveContainer(containerQueries.up.md);
    const isXsAndDownContainer = useResponsiveContainer(containerQueries.down.xs);
    const amountLabel = i18n.get("amount");
    const columns = useTableColumns({
      fields: TRANSACTION_FIELDS,
      customColumns,
      columnConfig: {
        amount: {
          label: hasMultipleCurrencies ? void 0 : `${amountLabel} ${availableCurrencies && availableCurrencies[0] ? `(${getCurrencyCode(availableCurrencies[0])})` : ""}`,
          position: "right",
          flex: isSmAndUpContainer ? 1.5 : void 0
        },
        transactionType: { visible: isMdAndUpContainer },
        paymentMethod: { visible: isSmAndUpContainer }
      }
    });
    const EMPTY_TABLE_MESSAGE = {
      title: "noTransactionsFound",
      message: ["tryDifferentSearchOrResetYourFiltersAndWeWillTryAgain"]
    };
    const onHover = q$1(
      (index) => {
        setHoveredRow(index ?? void 0);
      },
      [setHoveredRow]
    );
    const errorDisplay = T$1(
      () => () => /* @__PURE__ */ u$1(DataOverviewError, { error, onContactSupport, errorMessage: "weCouldNotLoadYourTransactions" }),
      [error, onContactSupport]
    );
    return /* @__PURE__ */ u$1("div", { className: BASE_CLASS$n, children: /* @__PURE__ */ u$1(
      DataGrid,
      {
        errorDisplay,
        error,
        columns,
        data: transactions2,
        loading: loading2,
        outline: false,
        onRowClick: { callback: onRowClick },
        onRowHover: onHover,
        emptyTableMessage: EMPTY_TABLE_MESSAGE,
        customCells: {
          // Remove status column temporarily
          /* status: ({ value }) => {
              return (
                  <Tag
                      label={i18n.get(value)}
                      variant={value === 'Booked' ? TagVariant.SUCCESS : value === 'Reversed' ? TagVariant.ERROR : TagVariant.DEFAULT}
                  />
              );
          },*/
          transactionType: ({ item, rowIndex }) => {
            const tooltipKey = `tooltip.${item.category}`;
            return item.category ? i18n.has(tooltipKey) ? /* @__PURE__ */ u$1(Category, { isContainerHovered: rowIndex === hoveredRow, value: item.category }) : /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.BODY, children: i18n.has(`txType.${item.category}`) ? i18n.get(`txType.${item.category}`) : `${item.category}` }) : null;
          },
          amount: ({ value: value2 }) => {
            const amount2 = i18n.amount(value2.value, value2.currency, { hideCurrency: !hasMultipleCurrencies });
            return /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.BODY, className: AMOUNT_CLASS$1, children: amount2 });
          },
          createdAt: ({ item, value: value2 }) => {
            if (isXsAndDownContainer) {
              return /* @__PURE__ */ u$1("div", { className: DATE_AND_PAYMENT_METHOD_CLASS, children: [
                /* @__PURE__ */ u$1(PaymentMethodCell, { paymentMethod: item.paymentMethod, bankAccount: item.bankAccount }),
                /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.BODY, className: DATE_METHOD_CLASS, children: dateFormat(item.createdAt, DATE_FORMAT_TRANSACTIONS_MOBILE) })
              ] });
            }
            return /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.BODY, children: dateFormat(value2, DATE_FORMAT_TRANSACTIONS) });
          },
          paymentMethod: ({ item }) => /* @__PURE__ */ u$1(PaymentMethodCell, { paymentMethod: item.paymentMethod, bankAccount: item.bankAccount })
        },
        children: showPagination && /* @__PURE__ */ u$1(DataGrid.Footer, { children: /* @__PURE__ */ u$1(Pagination, { ...paginationProps }) })
      }
    ) });
  };
  const TX_DATA_CLASS = "adyen-pe-transaction-data";
  const TX_DATA_AMOUNT = `${TX_DATA_CLASS}__amount`;
  const TX_DATA_ACTION_BAR = `${TX_DATA_CLASS}__action-bar`;
  const TX_DATA_CONTAINER = `${TX_DATA_CLASS}__container`;
  const TX_DATA_HEAD_CONTAINER = `${TX_DATA_CLASS}__head-container`;
  const TX_DATA_INPUT = `${TX_DATA_CLASS}__input`;
  const TX_DATA_INPUT_CONTAINER = `${TX_DATA_INPUT}-container`;
  const TX_DATA_INPUT_CONTAINER_SHORT = `${TX_DATA_INPUT_CONTAINER}--short`;
  const TX_DATA_INPUT_CONTAINER_TEXT = `${TX_DATA_INPUT_CONTAINER}--text-input`;
  const TX_DATA_INPUT_CONTAINER_WITH_ERROR = `${TX_DATA_INPUT_CONTAINER}--with-error`;
  const TX_DATA_INPUT_HEAD = `${TX_DATA_INPUT}-head`;
  const TX_DATA_LABEL = `${TX_DATA_CLASS}__label`;
  const TX_DATA_LIST = `${TX_DATA_CLASS}__list`;
  const TX_DATA_TAGS = `${TX_DATA_CLASS}__tags`;
  const TX_STATUS_BOX = `${TX_DATA_CLASS}__status-box`;
  const TX_REFUND_RESPONSE = `${TX_DATA_CLASS}__refund-response`;
  const TX_REFUND_RESPONSE_ICON = `${TX_DATA_CLASS}__refund-response-icon`;
  const TX_REFUND_RESPONSE_SUCCESS_ICON = `${TX_REFUND_RESPONSE_ICON}--success`;
  const TX_REFUND_RESPONSE_ERROR_ICON = `${TX_REFUND_RESPONSE_ICON}--error`;
  const TX_REFUND_STATUSES_CONTAINER = `${TX_DATA_CLASS}__refund-statuses-container`;
  const TX_DETAILS_RESERVED_FIELDS_SET = /* @__PURE__ */ new Set([
    ...["status", "category", "paymentMethod", "bankAccount", "balanceAccount", "id", "balanceAccountId"],
    ...TRANSACTION_FIELDS,
    "deductedAmount",
    "lineItems",
    "originalAmount",
    "paymentPspReference",
    "refundDetails",
    "refundMetadata"
  ]);
  const TransactionDataProperties = () => {
    var _a2;
    const { i18n } = useCoreContext();
    const { transaction, extraFields, dataCustomization } = useTransactionDetailsContext();
    return T$1(() => {
      const { balanceAccount: balanceAccount2, category: category2, id: id2, paymentPspReference, refundMetadata } = transaction;
      const isRefundTransaction = category2 === "Refund";
      const SKIP_ITEM = null;
      const getFormattedAmount = (amount2) => {
        if (isNullish(amount2)) return null;
        const { value: value2, currency: currency2 } = amount2;
        return i18n.amount(value2, currency2);
      };
      const deductedAmount = getFormattedAmount(transaction.deductedAmount);
      const originalAmount = getFormattedAmount(transaction.originalAmount);
      const deductedAmountKey = isRefundTransaction ? "refund.refundFee" : "refund.fee";
      const originalAmountKey = isRefundTransaction ? "refund.originalPayment" : "refund.originalAmount";
      const paymentReferenceKey = isRefundTransaction ? "refund.paymentPspReference" : "refund.pspReference";
      const listItems = [
        // amounts
        originalAmount ? { key: originalAmountKey, value: originalAmount, id: "originalAmount" } : SKIP_ITEM,
        deductedAmount ? { key: deductedAmountKey, value: deductedAmount, id: "deductedAmount" } : SKIP_ITEM,
        // balance account
        (balanceAccount2 == null ? void 0 : balanceAccount2.description) ? { key: "account", value: balanceAccount2.description, id: "description" } : SKIP_ITEM,
        // refund reason
        isRefundTransaction && (refundMetadata == null ? void 0 : refundMetadata.refundReason) ? {
          key: "refundReason",
          value: i18n.has(`refundReason.${refundMetadata.refundReason}`) ? i18n.get(`refundReason.${refundMetadata.refundReason}`) : refundMetadata.refundReason,
          id: "refundReason"
        } : SKIP_ITEM,
        // reference id
        { key: "referenceID", value: /* @__PURE__ */ u$1(CopyText, { type: "Default", textToCopy: id2, showCopyTextTooltip: false }), id: "id" },
        isRefundTransaction && (refundMetadata == null ? void 0 : refundMetadata.refundPspReference) ? { key: "refund.refundPspReference", value: refundMetadata.refundPspReference, id: "refundPspReference" } : SKIP_ITEM,
        // psp reference
        paymentPspReference ? { key: paymentReferenceKey, value: paymentPspReference, id: "paymentPspReference" } : SKIP_ITEM
      ].filter(Boolean).filter((val) => {
        var _a3, _b2;
        return !((_b2 = (_a3 = dataCustomization == null ? void 0 : dataCustomization.details) == null ? void 0 : _a3.fields) == null ? void 0 : _b2.some((field) => field.key === val.id && field.visibility === "hidden"));
      });
      const itemsWithExtraFields = [
        ...listItems,
        ...Object.entries(extraFields || {}).filter(([key, value2]) => !TX_DETAILS_RESERVED_FIELDS_SET.has(key) && value2.type !== "button" && value2.visibility !== "hidden").map(([key, value2]) => ({
          key,
          value: isCustomDataObject(value2) ? value2.value : value2,
          type: isCustomDataObject(value2) ? value2.type : "text",
          config: isCustomDataObject(value2) ? value2.config : void 0
        })) || {}
      ];
      return /* @__PURE__ */ u$1(
        StructuredList,
        {
          classNames: TX_DATA_LIST,
          items: itemsWithExtraFields,
          layout: "5-7",
          align: "start",
          renderLabel: (label) => /* @__PURE__ */ u$1("div", { className: TX_DATA_LABEL, children: label }),
          renderValue: (val, key, type2, config) => {
            if (type2 === "link" && config) {
              return /* @__PURE__ */ u$1(Link, { classNames: [cx(config == null ? void 0 : config.className)], href: config.href, target: config.target || "_blank", children: val });
            }
            if (type2 === "icon" && config) {
              const icon = { url: config == null ? void 0 : config.src, alt: config.alt || val };
              return /* @__PURE__ */ u$1("div", { className: cx("adyen-pe-transaction-data__list-icon-value", config == null ? void 0 : config.className), children: [
                /* @__PURE__ */ u$1(Icon, { ...icon }),
                /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.BODY, children: [
                  " ",
                  val,
                  " "
                ] })
              ] });
            }
            return /* @__PURE__ */ u$1(Typography$1, { className: cx(config == null ? void 0 : config.className), variant: TypographyVariant.BODY, children: val });
          }
        }
      );
    }, [(_a2 = dataCustomization == null ? void 0 : dataCustomization.details) == null ? void 0 : _a2.fields, extraFields, i18n, transaction]);
  };
  const TransactionDetailsDataContainer = ({ children, className }) => /* @__PURE__ */ u$1("div", { className: cx(TX_DATA_CONTAINER, className), children });
  const STATUS_BOX_CLASS = "adyen-pe-status-box";
  const STATUS_BOX_DATA_AMOUNT = `${STATUS_BOX_CLASS}__amount`;
  const STATUS_BOX_DATA_LABEL = `${STATUS_BOX_CLASS}__label`;
  const STATUS_BOX_DATA_PAY_METHOD = `${STATUS_BOX_CLASS}__payment-method`;
  const STATUS_BOX_DATA_PAY_METHOD_DETAIL = `${STATUS_BOX_DATA_PAY_METHOD}-detail`;
  const STATUS_BOX_DATA_PAY_METHOD_LOGO = `${STATUS_BOX_DATA_PAY_METHOD}-logo`;
  const STATUS_BOX_DATA_PAY_METHOD_LOGO_CONTAINER = `${STATUS_BOX_DATA_PAY_METHOD_LOGO}-container`;
  const STATUS_BOX_DATA_TAGS = `${STATUS_BOX_CLASS}__tags`;
  const StatusBox = ({ tag, amount: amount2, paymentMethod: paymentMethod2, paymentMethodType, date: date2, classNames }) => {
    return /* @__PURE__ */ u$1("div", { className: STATUS_BOX_CLASS, children: [
      tag && /* @__PURE__ */ u$1("div", { className: STATUS_BOX_DATA_TAGS, children: tag }),
      amount2 && /* @__PURE__ */ u$1("div", { className: cx(STATUS_BOX_DATA_AMOUNT, classNames == null ? void 0 : classNames.amount), children: amount2 }),
      paymentMethodType && /* @__PURE__ */ u$1("div", { className: STATUS_BOX_DATA_PAY_METHOD, children: [
        /* @__PURE__ */ u$1("div", { className: STATUS_BOX_DATA_PAY_METHOD_LOGO_CONTAINER, children: /* @__PURE__ */ u$1(Image$1, { className: STATUS_BOX_DATA_PAY_METHOD_LOGO, name: paymentMethodType, alt: paymentMethodType, folder: "logos/" }) }),
        /* @__PURE__ */ u$1("div", { className: STATUS_BOX_DATA_PAY_METHOD_DETAIL, children: paymentMethod2 })
      ] }),
      date2 && /* @__PURE__ */ u$1("div", { className: STATUS_BOX_DATA_LABEL, children: date2 })
    ] });
  };
  const StatusBox$1 = M(StatusBox);
  function InputBase({ onInput, onKeyUp, trimOnBlur, onBlurHandler, onBlur, onFocusHandler, errorMessage, ...props }, ref) {
    const { autoCorrect, classNameModifiers, isInvalid, isValid, readonly = false, spellCheck, type: type2, uniqueId: uniqueId2, isCollatingErrors, disabled } = props;
    if (hasOwnProperty(props, "onChange")) {
      console.error("Error: Form fields that rely on InputBase may not have an onChange property");
    }
    const handleInput = q$1(
      (event) => {
        onInput == null ? void 0 : onInput(event);
      },
      [onInput]
    );
    const handleKeyUp = q$1(
      (event) => {
        if (onKeyUp) onKeyUp(event);
      },
      [onKeyUp]
    );
    const handleBlur = q$1(
      (event) => {
        onBlurHandler == null ? void 0 : onBlurHandler(event);
        if (trimOnBlur) {
          event.target.value = event.target.value.trim();
        }
        onBlur == null ? void 0 : onBlur(event);
      },
      [onBlur, onBlurHandler, trimOnBlur]
    );
    const handleFocus = q$1(
      (event) => {
        onFocusHandler == null ? void 0 : onFocusHandler(event);
      },
      [onFocusHandler]
    );
    const inputClassNames = cx(
      "adyen-pe-input",
      [`adyen-pe-input--${type2}`],
      props.className,
      {
        "adyen-pe-input--invalid": isInvalid,
        "adyen-pe-input--valid": isValid
      },
      classNameModifiers == null ? void 0 : classNameModifiers.map((m2) => `adyen-pe-input--${m2}`)
    );
    const { classNameModifiers: cnm, uniqueId: uid, isInvalid: iiv, isValid: iv, isCollatingErrors: ce, ...newProps } = props;
    return /* @__PURE__ */ u$1(k$1, { children: [
      /* @__PURE__ */ u$1(
        "input",
        {
          id: uniqueId2,
          ...newProps,
          type: type2,
          className: inputClassNames,
          readOnly: readonly,
          "aria-describedby": isCollatingErrors ? void 0 : `${uniqueId2}${ARIA_ERROR_SUFFIX}`,
          "aria-invalid": isInvalid,
          onInput: handleInput,
          onBlurCapture: handleBlur,
          onFocus: handleFocus,
          onKeyUp: handleKeyUp,
          disabled,
          ref
        }
      ),
      isInvalid && errorMessage && /* @__PURE__ */ u$1("span", { className: "adyen-pe-input__invalid-value", id: `${uniqueId2}${ARIA_ERROR_SUFFIX}`, children: errorMessage })
    ] });
  }
  InputBase.defaultProps = {
    type: "text",
    classNameModifiers: [],
    onInput: () => {
    }
  };
  const InputBase$1 = D(InputBase);
  const formatAmount = (amount2, currency2) => getDecimalAmount(amount2, currency2).toFixed(getCurrencyExponent(currency2));
  const getCurrencyExponent = (currency2) => Math.log10(getDivider(currency2));
  const _BaseRefundAmountInput = ({
    currency: currency2,
    disabled,
    errorMessage,
    errorMessageArg,
    onInput,
    value: value2
  }) => {
    const { i18n } = useCoreContext();
    const inputIdentifier = A$1(uniqueId());
    const labelIdentifier = A$1(uniqueId());
    const error = errorMessage ? errorMessageArg ? i18n.get(errorMessage, { values: { amount: errorMessageArg } }) : i18n.get(errorMessage) : "";
    return /* @__PURE__ */ u$1("div", { className: TX_DATA_CONTAINER, children: [
      /* @__PURE__ */ u$1("div", { className: TX_DATA_INPUT_HEAD, children: /* @__PURE__ */ u$1("div", { id: labelIdentifier.current, children: /* @__PURE__ */ u$1(Typography$1, { el: TypographyElement.SPAN, variant: TypographyVariant.BODY, stronger: true, children: i18n.get("refundAmount") }) }) }),
      /* @__PURE__ */ u$1(
        "div",
        {
          className: cx({
            [TX_DATA_INPUT_CONTAINER]: true,
            [TX_DATA_INPUT_CONTAINER_SHORT]: true,
            [TX_DATA_INPUT_CONTAINER_TEXT]: true,
            [TX_DATA_INPUT_CONTAINER_WITH_ERROR]: !!errorMessage
          }),
          children: [
            /* @__PURE__ */ u$1("label", { htmlFor: inputIdentifier.current, "aria-labelledby": labelIdentifier.current, children: [
              currency2 && /* @__PURE__ */ u$1(Tag, { label: currency2, variant: TagVariant.DEFAULT }),
              /* @__PURE__ */ u$1(
                InputBase$1,
                {
                  min: 0,
                  type: "number",
                  className: TX_DATA_INPUT,
                  disabled: boolOrFalse(disabled),
                  lang: i18n.locale,
                  onInput,
                  value: value2,
                  uniqueId: inputIdentifier.current
                }
              )
            ] }),
            errorMessage && /* @__PURE__ */ u$1("div", { className: "adyen-pe-input__refund-invalid-value", id: `${inputIdentifier.current}${ARIA_ERROR_SUFFIX}`, children: [
              /* @__PURE__ */ u$1(Icon$1, { name: "cross-circle-fill" }),
              /* @__PURE__ */ u$1(Typography$1, { el: TypographyElement.SPAN, variant: TypographyVariant.BODY, children: error })
            ] })
          ]
        }
      )
    ] });
  };
  const TransactionRefundFullAmountInput = () => {
    const { availableAmount, currency: currency2 } = useTransactionRefundContext();
    return /* @__PURE__ */ u$1(_BaseRefundAmountInput, { currency: currency2, errorMessage: null, value: formatAmount(availableAmount, currency2), disabled: true });
  };
  const TransactionRefundPartialAmountInput = ({ locale }) => {
    const { availableAmount, currency: currency2, interactionsDisabled, setAmount } = useTransactionRefundContext();
    const [errorMessage, setErrorMessage] = d(null);
    const [refundAmount2, setRefundAmount] = d(`${formatAmount(availableAmount, currency2)}`);
    const { i18n } = useCoreContext();
    const computeRefundAmount = T$1(() => {
      const exponent = getCurrencyExponent(currency2);
      return (value2) => Math.trunc(+`${parseFloat(value2)}e${exponent}`) || 0;
    }, [currency2]);
    const onInput = (evt) => {
      var _a2;
      let value2 = evt.currentTarget.value.trim();
      const amount2 = computeRefundAmount(value2);
      let message = null;
      if (amount2 || value2) {
        if (amount2 < 0) message = "noNegativeNumbersAllowed";
        if (amount2 > availableAmount) message = "refundAmount.excess";
      } else message = "refundAmount.required";
      const decimalSeparator = ((_a2 = 1.1.toLocaleString(locale).match(/\d(.*?)\d/)) == null ? void 0 : _a2[1]) || ".";
      const parts = value2.split(decimalSeparator);
      if (parts.length === 2) {
        const exponent = getCurrencyExponent(currency2);
        const integerPart = parts[0];
        let decimalPart = parts[1];
        if (decimalPart.length >= exponent) {
          decimalPart = decimalPart.substring(0, exponent);
          value2 = integerPart + decimalSeparator + decimalPart;
          evt.currentTarget.value = value2;
        }
      }
      setRefundAmount(value2);
      setErrorMessage(message);
      setAmount(message ? 0 : amount2);
    };
    return /* @__PURE__ */ u$1(
      _BaseRefundAmountInput,
      {
        currency: currency2,
        errorMessage,
        errorMessageArg: i18n.amount(availableAmount, currency2),
        onInput,
        value: refundAmount2,
        disabled: interactionsDisabled
      }
    );
  };
  const TransactionRefundNotice = () => {
    const { i18n } = useCoreContext();
    return T$1(
      () => /* @__PURE__ */ u$1("div", { className: `${TX_DATA_CONTAINER} ${TX_DATA_HEAD_CONTAINER}`, children: [
        /* @__PURE__ */ u$1(Typography$1, { el: TypographyElement.DIV, variant: TypographyVariant.SUBTITLE, stronger: true, children: i18n.get("refundAction") }),
        /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.BODY, children: i18n.get("refundNotice") })
      ] }),
      [i18n]
    );
  };
  const TransactionRefundReason = () => {
    const { i18n } = useCoreContext();
    const { interactionsDisabled, refundReason: refundReason2, setRefundReason } = useTransactionRefundContext();
    const refundReasons = T$1(
      () => Object.freeze(
        REFUND_REASONS.map((reason) => ({ id: reason, name: i18n.has(`refundReason.${reason}`) ? i18n.get(`refundReason.${reason}`) : reason }))
      ),
      [i18n]
    );
    const onReasonChanged = q$1(
      (evt) => {
        var _a2;
        const reason = (_a2 = evt.target) == null ? void 0 : _a2.value;
        reason && setRefundReason(reason);
      },
      [setRefundReason]
    );
    return /* @__PURE__ */ u$1("div", { className: TX_DATA_CONTAINER, children: [
      /* @__PURE__ */ u$1("div", { className: TX_DATA_INPUT_HEAD, children: /* @__PURE__ */ u$1(Typography$1, { el: TypographyElement.SPAN, variant: TypographyVariant.BODY, stronger: true, children: i18n.get("refundReason") }) }),
      /* @__PURE__ */ u$1("div", { className: `${TX_DATA_INPUT_CONTAINER} ${TX_DATA_INPUT_CONTAINER_SHORT}`, children: /* @__PURE__ */ u$1(
        Select,
        {
          items: refundReasons,
          readonly: interactionsDisabled,
          filterable: false,
          multiSelect: false,
          onChange: onReasonChanged,
          selected: refundReason2
        }
      ) })
    ] });
  };
  const getAmountStyleForTransaction = (transaction) => {
    switch (transaction == null ? void 0 : transaction.status) {
      case "Booked":
        return "default";
      case "Reversed":
        return "error";
      default:
        return "pending";
    }
  };
  const getRefundTypeForTransaction = (transaction) => {
    if (transaction.category === "Refund") {
      const { refundType } = transaction.refundMetadata ?? EMPTY_OBJECT;
      switch (refundType) {
        case RefundType.FULL:
          return RefundType.FULL;
        case RefundType.PARTIAL:
          return RefundType.PARTIAL;
      }
    }
  };
  const TransactionStatusTag = ({ transaction, refundedState }) => {
    const { i18n } = useCoreContext();
    const { category: category2 } = transaction;
    const refundType = getRefundTypeForTransaction(transaction);
    return /* @__PURE__ */ u$1("div", { className: TX_DATA_TAGS, children: [
      category2 && /* @__PURE__ */ u$1(Tag, { label: i18n.get(`txType.${category2}`), variant: TagVariant.DEFAULT }),
      refundType && /* @__PURE__ */ u$1(k$1, { children: [
        refundType === RefundType.FULL && /* @__PURE__ */ u$1(Tag, { label: i18n.get("full"), variant: TagVariant.SUCCESS }),
        refundType === RefundType.PARTIAL && /* @__PURE__ */ u$1(Tag, { label: i18n.get("partial"), variant: TagVariant.BLUE })
      ] }),
      refundedState === RefundedState.FULL && /* @__PURE__ */ u$1(Tag, { label: i18n.get("refunded.full"), variant: TagVariant.SUCCESS }),
      refundedState === RefundedState.PARTIAL && /* @__PURE__ */ u$1(Tag, { label: i18n.get("refunded.partial"), variant: TagVariant.BLUE })
    ] });
  };
  const _TransactionDataContentViewWrapper = ({
    children,
    renderViewActionButtons,
    renderViewMessageBox
  }) => {
    return /* @__PURE__ */ u$1("div", { className: TX_DATA_CLASS, children: [
      children,
      renderViewMessageBox && renderViewMessageBox(),
      renderViewActionButtons()
    ] });
  };
  const _RefundResponseViewWrapper = ({
    action,
    title,
    renderIcon,
    subtitle
  }) => /* @__PURE__ */ u$1("div", { className: TX_REFUND_RESPONSE, children: [
    renderIcon && renderIcon(),
    /* @__PURE__ */ u$1(Typography$1, { className: TypographyModifier.MEDIUM, variant: TypographyVariant.TITLE, children: title }),
    /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.BODY, children: subtitle }),
    action && action()
  ] });
  const TransactionDataContent = ({ transaction: initialTransaction, extraFields, dataCustomization }) => {
    var _a2, _b2;
    const [activeView, _setActiveView] = d(ActiveView.DETAILS);
    const [primaryAction, _setPrimaryAction] = d();
    const [secondaryAction, _setSecondaryAction] = d();
    const [locked, setLocked] = d(false);
    const { fetchingTransaction, refreshTransaction, transaction, transactionNavigator } = useTransaction(initialTransaction);
    const {
      refundable,
      refundableAmount,
      refundableAmountLabel,
      refundAvailable,
      refundCurrency,
      refundDisabled: refundDisabledMetaData,
      refundedState,
      refundStatuses,
      refundMode,
      refundLocked
    } = useTransactionRefundMetadata(transaction);
    const refundDisabled = T$1(() => refundDisabledMetaData || locked, [refundDisabledMetaData, locked]);
    const { i18n } = useCoreContext();
    const lineItems = Object.freeze((transaction == null ? void 0 : transaction.lineItems) ?? EMPTY_ARRAY);
    const setPrimaryAction = q$1((action) => _setPrimaryAction(action), []);
    const setSecondaryAction = q$1((action) => _setSecondaryAction(action), []);
    const shouldPreventActiveViewIfRefund = q$1(
      (activeView2) => activeView2 === ActiveView.REFUND && refundDisabled,
      [refundDisabled]
    );
    const { getBalanceAccounts: balanceAccountEndpointCall } = useConfigContext().endpoints;
    const { data: balanceAccounts } = useFetch(
      T$1(
        () => ({
          fetchOptions: {
            enabled: !!balanceAccountEndpointCall && !transaction.balanceAccount && !!transaction.balanceAccountId,
            keepPrevData: true
          },
          queryFn: async () => balanceAccountEndpointCall == null ? void 0 : balanceAccountEndpointCall(EMPTY_OBJECT)
        }),
        [transaction.balanceAccountId, transaction.balanceAccount, balanceAccountEndpointCall]
      )
    );
    const setActiveView = q$1(
      (activeView2) => void (shouldPreventActiveViewIfRefund(activeView2) || _setActiveView(activeView2)),
      [shouldPreventActiveViewIfRefund]
    );
    const renderViewActionButtons = q$1(() => {
      const extraActions = extraFields ? Object.values(extraFields).filter((field) => field.type === "button").map((action) => {
        var _a3, _b3;
        return {
          title: action.value,
          variant: ButtonVariant.SECONDARY,
          event: (_a3 = action.config) == null ? void 0 : _a3.action,
          classNames: ((_b3 = action.config) == null ? void 0 : _b3.className) ? [action.config.className] : []
        };
      }) : [];
      const actions = [primaryAction, secondaryAction, ...extraActions].filter(Boolean);
      return actions.length ? /* @__PURE__ */ u$1(TransactionDetailsDataContainer, { className: TX_DATA_ACTION_BAR, children: /* @__PURE__ */ u$1(ButtonActions$1, { actions, layout: ButtonActionsLayoutBasic.BUTTONS_END }) }) : null;
    }, [extraFields, primaryAction, secondaryAction]);
    const onRefundSuccess = q$1(() => {
      refreshTransaction();
      setLocked(true);
    }, [setLocked, refreshTransaction]);
    const statusBoxProps = {
      timezone: (_a2 = transaction.balanceAccount) == null ? void 0 : _a2.timeZone,
      createdAt: transaction.createdAt,
      amountData: transaction.amount,
      paymentMethodData: transaction.paymentMethod,
      bankAccount: transaction.bankAccount
    };
    const statusBoxOptions = useStatusBoxData(statusBoxProps);
    const renderMessages = q$1(() => {
      return (refundStatuses == null ? void 0 : refundStatuses.length) || refundLocked || locked ? /* @__PURE__ */ u$1("div", { className: TX_REFUND_STATUSES_CONTAINER, children: [
        (refundLocked || locked) && /* @__PURE__ */ u$1(
          Alert,
          {
            type: AlertTypeOption.HIGHLIGHT,
            variant: AlertVariantOption.TIP,
            description: `${i18n.get("refund.theRefundIsBeingProcessed")} ${i18n.get("pleaseComeBackLater")}`
          }
        ),
        refundStatuses.map((status2, index) => /* @__PURE__ */ u$1(
          Alert,
          {
            variant: AlertVariantOption.TIP,
            type: (status2 == null ? void 0 : status2.type) ?? AlertTypeOption.HIGHLIGHT,
            description: status2 == null ? void 0 : status2.label
          },
          `${Math.random()}-${index}`
        ))
      ] }) : null;
    }, [i18n, refundStatuses, refundLocked, locked]);
    const balanceAccountData = transaction.balanceAccount ?? ((_b2 = balanceAccounts == null ? void 0 : balanceAccounts.data) == null ? void 0 : _b2.find((account2) => account2.id === transaction.balanceAccountId));
    _(() => {
      _setActiveView(ActiveView.DETAILS);
    }, [transaction]);
    _(() => {
      if (refundDisabled) _setActiveView(ActiveView.DETAILS);
    }, [refundDisabled]);
    if (fetchingTransaction) {
      return /* @__PURE__ */ u$1(DataOverviewDetailsSkeleton$1, { skeletonRowNumber: 5 });
    }
    if (shouldPreventActiveViewIfRefund(activeView)) return null;
    const commonContextProviderProps = {
      lineItems,
      refundAvailable,
      refundDisabled,
      setActiveView,
      setPrimaryAction,
      setSecondaryAction
    };
    switch (activeView) {
      case ActiveView.DETAILS:
        return /* @__PURE__ */ u$1(_TransactionDataContentViewWrapper, { renderViewActionButtons, renderViewMessageBox: renderMessages, children: /* @__PURE__ */ u$1(
          TransactionDetailsProvider,
          {
            ...commonContextProviderProps,
            transaction: !transaction.balanceAccount && !!balanceAccountData ? { ...transaction, balanceAccount: balanceAccountData } : { ...transaction },
            transactionNavigator,
            extraFields,
            dataCustomization,
            children: [
              /* @__PURE__ */ u$1(TransactionDetailsDataContainer, { className: TX_STATUS_BOX, children: /* @__PURE__ */ u$1(
                StatusBox$1,
                {
                  ...statusBoxOptions,
                  tag: /* @__PURE__ */ u$1(TransactionStatusTag, { transaction, refundedState }),
                  classNames: { amount: `${TX_DATA_AMOUNT}--${getAmountStyleForTransaction(transaction)}` }
                }
              ) }),
              /* @__PURE__ */ u$1(TransactionDataProperties, {})
            ]
          }
        ) });
      case ActiveView.REFUND:
        return /* @__PURE__ */ u$1(_TransactionDataContentViewWrapper, { renderViewActionButtons, children: /* @__PURE__ */ u$1(
          TransactionRefundProvider,
          {
            ...commonContextProviderProps,
            availableAmount: refundableAmount,
            currency: refundCurrency,
            refundMode,
            refreshTransaction,
            transactionId: transaction.id,
            children: [
              /* @__PURE__ */ u$1(TransactionRefundNotice, {}),
              refundable && /* @__PURE__ */ u$1(TransactionRefundReason, {}),
              refundMode === RefundMode.FULL_AMOUNT && /* @__PURE__ */ u$1(TransactionRefundFullAmountInput, {}),
              (refundMode === RefundMode.PARTIAL_AMOUNT || refundMode === RefundMode.PARTIAL_LINE_ITEMS) && /* @__PURE__ */ u$1(TransactionRefundPartialAmountInput, { locale: i18n.locale }),
              refundableAmountLabel && /* @__PURE__ */ u$1(
                Alert,
                {
                  variant: AlertVariantOption.TIP,
                  type: refundableAmountLabel.type,
                  description: refundableAmountLabel.description
                }
              )
            ]
          }
        ) });
      case ActiveView.REFUND_SUCCESS:
        return /* @__PURE__ */ u$1(
          _RefundResponseViewWrapper,
          {
            renderIcon: () => /* @__PURE__ */ u$1(Icon$1, { name: "checkmark-circle-fill", className: cx(TX_REFUND_RESPONSE_ICON, TX_REFUND_RESPONSE_SUCCESS_ICON) }),
            title: i18n.get("refundActionSuccessTitle"),
            subtitle: i18n.get("refundActionSuccessSubtitle"),
            action: () => /* @__PURE__ */ u$1(Button$1, { variant: ButtonVariant.SECONDARY, onClick: onRefundSuccess, children: i18n.get("goBack") })
          }
        );
      case ActiveView.REFUND_ERROR:
        return /* @__PURE__ */ u$1(
          _RefundResponseViewWrapper,
          {
            renderIcon: () => /* @__PURE__ */ u$1(Icon$1, { name: "cross-circle-fill", className: cx(TX_REFUND_RESPONSE_ICON, TX_REFUND_RESPONSE_ERROR_ICON) }),
            title: i18n.get("refundActionErrorTitle"),
            subtitle: i18n.get("refundActionErrorSubtitle"),
            action: () => /* @__PURE__ */ u$1(Button$1, { variant: ButtonVariant.SECONDARY, onClick: refreshTransaction, children: i18n.get("goBack") })
          }
        );
      default:
        return null;
    }
  };
  const TransactionData = ({ error, isFetching, transaction, extraFields, dataCustomization }) => {
    const isLoading = boolOrFalse(isFetching);
    const isWithoutContent = !(transaction || error);
    const showLoadingIndicator = isLoading || isWithoutContent;
    if (showLoadingIndicator) {
      return /* @__PURE__ */ u$1(DataOverviewDetailsSkeleton$1, { skeletonRowNumber: 5 });
    }
    if (transaction) {
      return /* @__PURE__ */ u$1(TransactionDataContent, { dataCustomization, transaction, extraFields });
    }
    return null;
  };
  const useBalanceAccounts = (balanceAccountId2, enabled) => {
    const { getBalanceAccounts: balanceAccountEndpointCall } = useConfigContext().endpoints;
    const { data, isFetching, error } = useFetch(
      T$1(
        () => ({
          fetchOptions: { enabled: !!balanceAccountEndpointCall && (enabled ?? true), keepPrevData: true },
          queryFn: async () => balanceAccountEndpointCall == null ? void 0 : balanceAccountEndpointCall(EMPTY_OBJECT)
        }),
        [balanceAccountEndpointCall]
      )
    );
    const balanceAccounts = T$1(
      () => data == null ? void 0 : data.data.filter((account2) => balanceAccountId2 ? account2.id === balanceAccountId2 : true),
      [data == null ? void 0 : data.data, balanceAccountId2]
    );
    const isBalanceAccountIdWrong = T$1(
      () => !!balanceAccountId2 && !!(data == null ? void 0 : data.data.length) && (balanceAccounts == null ? void 0 : balanceAccounts.length) === 0,
      [balanceAccounts == null ? void 0 : balanceAccounts.length, data == null ? void 0 : data.data.length, balanceAccountId2]
    );
    return { balanceAccounts, isBalanceAccountIdWrong, isFetching, error };
  };
  const ModalContext = K$1({ withinModal: false });
  const useModalContext = () => x(ModalContext);
  function Modal({
    title,
    children,
    classNameModifiers = [],
    isOpen,
    onClose,
    isDismissible = true,
    headerWithBorder = true,
    size = "fluid",
    ...props
  }) {
    const isSmContainer = useResponsiveContainer(containerQueries.down.xs);
    const { i18n } = useCoreContext();
    const targetElement = useClickOutside(null, onClose);
    const handleEscKey = q$1(
      (e2) => {
        if (e2.key === "Escape" && isOpen && isDismissible) {
          onClose();
        }
      },
      [isOpen, isDismissible, onClose]
    );
    y(() => {
      if (isOpen) {
        window.addEventListener("keydown", handleEscKey);
      } else {
        window.removeEventListener("keydown", handleEscKey);
      }
      return () => window.removeEventListener("keydown", handleEscKey);
    }, [isOpen, handleEscKey]);
    return /* @__PURE__ */ u$1(k$1, { children: isOpen && /* @__PURE__ */ u$1(
      "div",
      {
        className: cx(
          "adyen-pe-modal-wrapper",
          classNameModifiers.map((m2) => `adyen-pe-modal-wrapper--${m2}`),
          { "adyen-pe-modal-wrapper--open": isOpen, "adyen-pe-modal-wrapper--dismissible": isDismissible }
        ),
        role: "dialog",
        "aria-modal": "true",
        "aria-hidden": !open,
        ...props,
        children: /* @__PURE__ */ u$1(ModalContext.Provider, { value: { withinModal: true }, children: /* @__PURE__ */ u$1(
          "div",
          {
            className: cx("adyen-pe-modal", {
              "adyen-pe-modal--fluid": size === "fluid",
              "adyen-pe-modal--small": size === "small",
              "adyen-pe-modal--large": size === "large",
              "adyen-pe-modal--extra-large": size === "extra-large",
              "adyen-pe-modal--full-screen": size === "full-screen" || isSmContainer
            }),
            ref: targetElement,
            children: [
              /* @__PURE__ */ u$1(
                "div",
                {
                  className: cx("adyen-pe-modal__header", {
                    "adyen-pe-modal__header--with-title": title,
                    "adyen-pe-modal__header--with-border-bottom": headerWithBorder
                  }),
                  children: [
                    title && /* @__PURE__ */ u$1("div", { className: `adyen-pe-modal__header__title`, children: title }),
                    isDismissible && /* @__PURE__ */ u$1(
                      Button$1,
                      {
                        onClick: onClose,
                        variant: ButtonVariant.TERTIARY,
                        iconButton: true,
                        classNameModifiers: ["circle"],
                        className: `adyen-pe-modal__header-icon`,
                        "aria-label": i18n.get("dismiss"),
                        children: /* @__PURE__ */ u$1(Icon$1, { name: "cross" })
                      }
                    )
                  ]
                }
              ),
              /* @__PURE__ */ u$1("div", { className: "adyen-pe-modal__content", children })
            ]
          }
        ) })
      }
    ) });
  }
  const TITLES_BY_TYPE = {
    transaction: "transactionDetails",
    payout: "payoutDetails"
  };
  const useDataOverviewDetailsTitle = ({ hideTitle: _hideTitle, type: type2 }) => {
    const { i18n } = useCoreContext();
    const { withinModal } = useModalContext();
    const [forcedHideTitle, setForcedHideTitle] = d(false);
    const hideTitle = T$1(() => forcedHideTitle || boolOrFalse(_hideTitle), [forcedHideTitle, _hideTitle]);
    const title = T$1(() => i18n.get(TITLES_BY_TYPE[type2]), [i18n, type2]);
    y(() => {
      setForcedHideTitle(withinModal);
    }, [withinModal]);
    return { hideTitle, title };
  };
  const BASE_CLASS$m = "adyen-pe-payouts-table";
  const NET_PAYOUT_CLASS = `${BASE_CLASS$m}__net-payout`;
  const AMOUNT_FIELDS = ["fundsCapturedAmount", "adjustmentAmount", "payoutAmount"];
  const PAYOUT_TABLE_FIELDS = ["createdAt", ...AMOUNT_FIELDS];
  const _isAmountFieldKey = (key) => {
    return AMOUNT_FIELDS.includes(key);
  };
  const PayoutsTable = ({
    error,
    loading: loading2,
    onContactSupport,
    onRowClick,
    showDetails,
    showPagination,
    data,
    customColumns,
    ...paginationProps
  }) => {
    const { i18n } = useCoreContext();
    const { dateFormat } = useTimezoneAwareDateFormatting("UTC");
    const { refreshing } = useConfigContext();
    const isLoading = T$1(() => loading2 || refreshing, [loading2, refreshing]);
    const isSmAndUpContainer = useResponsiveContainer(containerQueries.up.sm);
    const getAmountFieldConfig = q$1(
      (key) => {
        var _a2, _b2, _c2, _d2;
        const label = i18n.get(getLabel(key));
        if (_isAmountFieldKey(key)) {
          return {
            label: ((_b2 = (_a2 = data == null ? void 0 : data[0]) == null ? void 0 : _a2[key]) == null ? void 0 : _b2.currency) ? `${label} (${getCurrencyCode((_d2 = (_c2 = data == null ? void 0 : data[0]) == null ? void 0 : _c2[key]) == null ? void 0 : _d2.currency)})` : label,
            position: "right"
          };
        }
      },
      [data, i18n]
    );
    const columns = useTableColumns({
      fields: PAYOUT_TABLE_FIELDS,
      customColumns,
      columnConfig: T$1(
        () => ({
          fundsCapturedAmount: { ...getAmountFieldConfig("fundsCapturedAmount"), visible: isSmAndUpContainer },
          adjustmentAmount: { ...getAmountFieldConfig("adjustmentAmount"), visible: isSmAndUpContainer },
          payoutAmount: getAmountFieldConfig("payoutAmount")
        }),
        [getAmountFieldConfig, isSmAndUpContainer]
      )
    });
    const EMPTY_TABLE_MESSAGE = {
      title: "noPayoutsFound",
      message: ["tryDifferentSearchOrResetYourFiltersAndWeWillTryAgain"]
    };
    const errorDisplay = T$1(
      () => () => /* @__PURE__ */ u$1(DataOverviewError, { error, errorMessage: "weCouldNotLoadYourPayouts", onContactSupport }),
      [error, onContactSupport]
    );
    return /* @__PURE__ */ u$1("div", { className: BASE_CLASS$m, children: /* @__PURE__ */ u$1(
      DataGrid,
      {
        errorDisplay,
        error,
        columns,
        data,
        loading: isLoading,
        outline: false,
        onRowClick: { callback: onRowClick },
        emptyTableMessage: EMPTY_TABLE_MESSAGE,
        customCells: {
          createdAt: ({ value: value2 }) => {
            if (!value2) return null;
            if (!isSmAndUpContainer) return dateFormat(value2, DATE_FORMAT_PAYOUTS_MOBILE);
            return value2 && /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.BODY, children: dateFormat(value2, DATE_FORMAT_PAYOUTS) });
          },
          fundsCapturedAmount: ({ value: value2 }) => {
            return value2 && /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.BODY, children: i18n.amount(value2.value, value2.currency, { hideCurrency: true }) });
          },
          adjustmentAmount: ({ value: value2 }) => {
            return value2 && /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.BODY, children: i18n.amount(value2.value, value2.currency, { hideCurrency: true }) });
          },
          payoutAmount: ({ value: value2 }) => {
            return value2 && /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.BODY, className: cx({ [`${NET_PAYOUT_CLASS}--strong`]: !isSmAndUpContainer }), children: i18n.amount(value2.value, value2.currency, { hideCurrency: isSmAndUpContainer }) });
          }
        },
        children: showPagination && /* @__PURE__ */ u$1(DataGrid.Footer, { children: /* @__PURE__ */ u$1(Pagination, { ...paginationProps }) })
      }
    ) });
  };
  const ENDPOINTS_BY_TYPE = {
    transaction: "getTransaction",
    payout: "getPayout",
    dispute: "getDisputeDetail"
  };
  const isDetailsWithId = (props) => !("data" in props);
  function DataOverviewDetails(props) {
    var _a2;
    const details = T$1(() => isDetailsWithId(props) ? null : props.data, [props]);
    const dataId = T$1(() => isDetailsWithId(props) ? props.id : null, [props]);
    const getDetail = useConfigContext().endpoints[ENDPOINTS_BY_TYPE[props.type]];
    const { hideTitle, title } = useDataOverviewDetailsTitle(props);
    const { data, error, isFetching } = useFetch(
      T$1(
        () => ({
          fetchOptions: { enabled: !!dataId && !!getDetail },
          queryFn: async () => {
            let queryParam = null;
            switch (props.type) {
              case "transaction":
                queryParam = { path: { transactionId: dataId } };
                break;
              case "payout":
                queryParam = { query: { balanceAccountId: dataId, createdAt: props.date } };
                break;
              default:
                break;
            }
            return getDetail(EMPTY_OBJECT, { ...queryParam });
          }
        }),
        [dataId, getDetail, props]
      )
    );
    const balanceAccountId2 = props.type === "payout" ? props.id : data == null ? void 0 : data.balanceAccountId;
    const hasBalanceAccountDetail = props.type === "payout" ? props == null ? void 0 : props.balanceAccountDescription : props == null ? void 0 : props.balanceAccount;
    const { balanceAccounts } = useBalanceAccounts(balanceAccountId2, !hasBalanceAccountDetail);
    const errorProps = T$1(() => {
      if (error) {
        return getErrorMessage(error, "weCouldNotLoadYourTransactions", props.onContactSupport);
      }
    }, [error, props.onContactSupport]);
    const detailsData = details ?? data;
    const [extraFields, setExtraFields] = d();
    const getExtraFields = q$1(async () => {
      var _a3, _b2, _c2, _d2, _e;
      if (data && (isDetailsWithId(props) && props.type === "transaction" || props.type === "payout")) {
        const detailsData2 = await ((_c2 = (_b2 = (_a3 = props.dataCustomization) == null ? void 0 : _a3.details) == null ? void 0 : _b2.onDataRetrieve) == null ? void 0 : _c2.call(_b2, data));
        setExtraFields(
          (_e = (_d2 = props.dataCustomization) == null ? void 0 : _d2.details) == null ? void 0 : _e.fields.reduce((acc, field) => {
            return TX_DETAILS_RESERVED_FIELDS_SET.has(field.key) || PAYOUT_TABLE_FIELDS.includes(field.key) || (field == null ? void 0 : field.visibility) === "hidden" ? acc : { ...acc, ...(detailsData2 == null ? void 0 : detailsData2[field.key]) ? { [field.key]: detailsData2[field.key] } : {} };
          }, {})
        );
      }
    }, [data, props]);
    const dataCustomization = isDetailsWithId(props) && props.type === "transaction" || props.type === "payout" ? props.dataCustomization : void 0;
    y(() => {
      void getExtraFields();
    }, [getExtraFields]);
    return /* @__PURE__ */ u$1("div", { className: "adyen-pe-overview-details", children: [
      !hideTitle && /* @__PURE__ */ u$1("div", { className: "adyen-pe-overview-details--title", children: /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.TITLE, medium: true, children: title }) }),
      error && errorProps && /* @__PURE__ */ u$1("div", { className: "adyen-pe-overview-details--error-container", children: /* @__PURE__ */ u$1(ErrorMessageDisplay, { withImage: true, ...errorProps }) }),
      props.type === "transaction" && /* @__PURE__ */ u$1(
        TransactionData,
        {
          transaction: detailsData ? {
            ...detailsData || EMPTY_OBJECT,
            balanceAccount: (props == null ? void 0 : props.balanceAccount) || (balanceAccounts == null ? void 0 : balanceAccounts[0])
          } : void 0,
          error: !!(error && errorProps),
          isFetching,
          extraFields,
          dataCustomization
        }
      ),
      props.type === "payout" && detailsData && /* @__PURE__ */ u$1(
        PayoutData,
        {
          balanceAccountId: dataId,
          payout: detailsData,
          balanceAccountDescription: (props == null ? void 0 : props.balanceAccountDescription) || ((_a2 = balanceAccounts == null ? void 0 : balanceAccounts[0]) == null ? void 0 : _a2.description),
          isFetching,
          extraFields,
          dataCustomization
        }
      )
    ] });
  }
  class PayoutElement extends UIElement {
    constructor(props) {
      super(props);
      __publicField(this, "componentToRender", () => {
        return /* @__PURE__ */ u$1(DataOverviewDetails, { ...this.props, type: "payout", ref: (ref) => void (this.componentRef = ref) });
      });
      this.componentToRender = this.componentToRender.bind(this);
    }
  }
  __publicField(PayoutElement, "type", "payoutDetails");
  const WITH_ERROR_CLASS = "adyen-pe-data-overview-container--with-error";
  function DataOverviewContainer({
    balanceAccountsError,
    children,
    className,
    errorMessage,
    isBalanceAccountIdWrong,
    onContactSupport
  }) {
    const { hasError } = useConfigContext();
    return /* @__PURE__ */ u$1("div", { className: cx(className, { [WITH_ERROR_CLASS]: hasError }), children: hasError ? /* @__PURE__ */ u$1(
      ErrorMessageDisplay,
      {
        withImage: true,
        centered: true,
        title: "somethingWentWrong",
        message: [errorMessage, "tryRefreshingThePageOrComeBackLater"],
        refreshComponent: true
      }
    ) : balanceAccountsError ? /* @__PURE__ */ u$1(
      ErrorMessageDisplay,
      {
        withImage: true,
        centered: true,
        ...getErrorMessage(balanceAccountsError, "weCouldNotLoadYourBalanceAccounts", onContactSupport)
      }
    ) : isBalanceAccountIdWrong ? /* @__PURE__ */ u$1(
      ErrorMessageDisplay,
      {
        withImage: true,
        centered: true,
        title: "somethingWentWrong",
        message: [errorMessage, "theSelectedBalanceAccountIsIncorrect"]
      }
    ) : /* @__PURE__ */ u$1(k$1, { children }) });
  }
  const BASE_CLASS$l = "adyen-pe-payouts-overview";
  const BASE_CLASS_DETAILS$1 = "adyen-pe-payouts-details";
  const EARLIEST_PAYOUT_SINCE_DATE$1 = (/* @__PURE__ */ new Date("2024-04-16T00:00:00.000Z")).toString();
  const MOBILE_SWITCH_CLASS = "adyen-pe-filter-bar-mobile-switch";
  const useFilterBarState = () => {
    const isMobileContainer = useResponsiveContainer(containerQueries.down.xs);
    const [showingFilters, setShowingFilters] = d(!isMobileContainer);
    y(() => {
      setShowingFilters(!isMobileContainer);
    }, [isMobileContainer]);
    return { isMobileContainer, showingFilters, setShowingFilters };
  };
  const FilterBarMobileSwitch = ({ isMobileContainer, showingFilters, setShowingFilters }) => {
    return isMobileContainer ? /* @__PURE__ */ u$1("div", { className: MOBILE_SWITCH_CLASS, children: /* @__PURE__ */ u$1(
      Button$1,
      {
        iconButton: true,
        className: `${MOBILE_SWITCH_CLASS}__button`,
        disabled: !isFunction(setShowingFilters),
        onClick: () => setShowingFilters == null ? void 0 : setShowingFilters(!showingFilters),
        variant: ButtonVariant.SECONDARY,
        children: /* @__PURE__ */ u$1(Icon$1, { name: showingFilters ? "cross" : "filter" })
      }
    ) }) : null;
  };
  const FilterBar = (props) => {
    const { i18n } = useCoreContext();
    return props.showingFilters ? /* @__PURE__ */ u$1(
      "div",
      {
        "aria-label": i18n.get("filterBar"),
        className: cx("adyen-pe-filter-bar", { "adyen-pe-filter-bar__content--mobile": props.isMobileContainer }),
        children: [
          props.children,
          props.canResetFilters && !!props.resetFilters && /* @__PURE__ */ u$1(Button$1, { variant: ButtonVariant.TERTIARY, onClick: props.resetFilters, children: i18n.get("button.clearAll") })
        ]
      }
    ) : null;
  };
  const ALL_BALANCE_ACCOUNTS_SELECTION_ID = uniqueId();
  const useBalanceAccountSelection = (balanceAccounts, allowAllSelection = false) => {
    const { i18n } = useCoreContext();
    const [selectedBalanceAccountIndex, setSelectedBalanceAccountIndex] = d(0);
    const resetBalanceAccountSelection = q$1(() => setSelectedBalanceAccountIndex(0), []);
    const allBalanceAccounts = T$1(
      () => balanceAccounts && [
        ...balanceAccounts,
        ...allowAllSelection ? [
          {
            ...balanceAccounts[0] ?? {},
            id: ALL_BALANCE_ACCOUNTS_SELECTION_ID,
            description: void 0
          }
        ] : []
      ],
      [allowAllSelection, balanceAccounts]
    );
    const activeBalanceAccount = T$1(() => {
      return allBalanceAccounts == null ? void 0 : allBalanceAccounts[selectedBalanceAccountIndex];
    }, [allBalanceAccounts, selectedBalanceAccountIndex]);
    const balanceAccountSelectionOptions = T$1(
      () => balanceAccounts && balanceAccounts.length > 1 ? Object.freeze(
        allBalanceAccounts == null ? void 0 : allBalanceAccounts.map(({ description: description2, id: id2 }) => {
          const name = id2 === ALL_BALANCE_ACCOUNTS_SELECTION_ID ? i18n.get("balanceAccounts.all") : capitalize(description2);
          return { id: id2, name };
        })
      ) : void 0,
      [allBalanceAccounts, balanceAccounts, i18n]
    );
    const onBalanceAccountSelection = q$1(
      ({ target }) => {
        const balanceAccountId2 = target == null ? void 0 : target.value;
        const index = allBalanceAccounts == null ? void 0 : allBalanceAccounts.findIndex(({ id: id2 }) => id2 === balanceAccountId2);
        if (index >= 0) setSelectedBalanceAccountIndex(index);
      },
      [allBalanceAccounts]
    );
    return { activeBalanceAccount, balanceAccountSelectionOptions, onBalanceAccountSelection, resetBalanceAccountSelection };
  };
  const BA_SELECTOR_CLASS = "adyen-pe-balance-account-selector";
  const BA_SELECTOR_ACCOUNT_ID_CLASS = `${BA_SELECTOR_CLASS}__account-id`;
  const BA_SELECTOR_ACCOUNT_LABEL_CLASS = `${BA_SELECTOR_CLASS}__account-label`;
  const BalanceAccountSelector = M(
    ({
      activeBalanceAccount,
      balanceAccountSelectionOptions,
      onBalanceAccountSelection
    }) => {
      const isSmContainer = useResponsiveContainer(containerQueries.down.xs);
      const { i18n } = useCoreContext();
      const renderListItem = q$1(
        (data) => /* @__PURE__ */ u$1(k$1, { children: [
          /* @__PURE__ */ u$1("div", { className: data.contentClassName, children: [
            data.item.name && /* @__PURE__ */ u$1("span", { className: BA_SELECTOR_ACCOUNT_LABEL_CLASS, children: data.item.name }),
            data.item.id !== ALL_BALANCE_ACCOUNTS_SELECTION_ID && /* @__PURE__ */ u$1("span", { className: data.item.name ? BA_SELECTOR_ACCOUNT_ID_CLASS : BA_SELECTOR_ACCOUNT_LABEL_CLASS, children: data.item.id })
          ] }),
          renderDefaultSingleSelectionCheckedness(data)
        ] }),
        []
      );
      return balanceAccountSelectionOptions && balanceAccountSelectionOptions.length > 1 ? /* @__PURE__ */ u$1(
        Select,
        {
          popoverClassNameModifiers: [BA_SELECTOR_CLASS],
          onChange: onBalanceAccountSelection,
          filterable: false,
          multiSelect: false,
          placeholder: (activeBalanceAccount == null ? void 0 : activeBalanceAccount.id) || i18n.get("balanceAccount"),
          selected: activeBalanceAccount == null ? void 0 : activeBalanceAccount.id,
          withoutCollapseIndicator: true,
          items: balanceAccountSelectionOptions,
          renderListItem,
          showOverlay: isSmContainer
        }
      ) : null;
    }
  );
  const LIMIT_OPTIONS = Object.freeze([10, 20]);
  const MAX_PAGE_LIMIT = 100;
  const DEFAULT_PAGE_LIMIT = 10;
  const getClampedPageLimit = (pageLimit) => {
    const limit = ~~pageLimit;
    return limit === pageLimit && limit > 0 ? Math.min(limit, MAX_PAGE_LIMIT) : Math.max(limit, 0);
  };
  const getNearestFromSortedUniqueNums = (nums, target) => {
    const lastindex = nums.length - 1;
    if (lastindex < 0) return target;
    if (target <= nums[0]) return nums[0];
    if (target >= nums[lastindex]) return nums[lastindex];
    let index = 0, lo = 0, hi = lastindex;
    while (true) {
      const current = nums[index = mid(lo, hi)];
      if (lo > hi || target === current) return current;
      target > current ? lo = index + 1 : hi = index - 1;
    }
  };
  const usePageLimit = ({
    preferredLimit = DEFAULT_PAGE_LIMIT,
    preferredLimitOptions
  }) => {
    const cachedLimitOptions = A$1();
    const cachedLimit = A$1();
    const options = T$1(() => {
      try {
        const uniqueOptions = /* @__PURE__ */ new Set();
        for (const option of preferredLimitOptions) {
          const limit2 = getClampedPageLimit(option);
          if (limit2 > 0) uniqueOptions.add(limit2);
        }
        return Object.freeze([...uniqueOptions].sort((a2, b2) => a2 - b2));
      } catch {
      }
    }, [preferredLimitOptions]);
    const limit = T$1(() => {
      let limit2 = getClampedPageLimit(preferredLimit) || DEFAULT_PAGE_LIMIT;
      parsing: try {
        if (cachedLimitOptions.current === options) break parsing;
        const uniqueOptions = new Set(cachedLimitOptions.current = options);
        if (uniqueOptions.size === 0) {
          cachedLimitOptions.current = void 0;
          break parsing;
        }
        if (cachedLimit.current !== limit2) {
          selection: {
            if (uniqueOptions.size === uniqueOptions.add(limit2).size) {
              break selection;
            } else uniqueOptions.delete(limit2);
            if (uniqueOptions.size === uniqueOptions.add(cachedLimit.current).size) {
              if (isNumber(cachedLimit.current)) {
                limit2 = cachedLimit.current;
                break selection;
              }
            } else uniqueOptions.delete(cachedLimit.current);
            limit2 = getNearestFromSortedUniqueNums(cachedLimitOptions.current, limit2);
          }
        }
      } catch {
      }
      return cachedLimit.current = limit2;
    }, [options, preferredLimit]);
    return { limit, limitOptions: options };
  };
  const useMounted = (beforeUnmount) => {
    const $mounted = A$1(false);
    const unmount = T$1(() => beforeUnmount, [beforeUnmount]);
    y(() => {
      $mounted.current = true;
      return () => {
        $mounted.current = false;
        unmount && unmount();
      };
    }, [unmount]);
    return $mounted;
  };
  const usePagination = (paginationSetupConfig, requestPageCallback, pageLimit) => {
    const $controller = A$1();
    const $maxVisitedPage = A$1();
    const $maxVisitedPageSize = A$1();
    const $page = A$1();
    const $mounted = useMounted(
      q$1(() => {
        var _a2;
        (_a2 = $controller.current) == null ? void 0 : _a2.abort();
        $controller.current = void 0;
      }, [])
    );
    const [page, setCurrentPage] = d($page.current);
    const [paginationChanged, updatePaginationChanged] = useBooleanState(false);
    const limit = T$1(() => getClampedPageLimit(pageLimit), [pageLimit]);
    const { getPageCount, getPageParams, resetPageCount, updatePagination } = paginationSetupConfig;
    const goto = T$1(() => {
      return requestPageCallback ? (page2) => {
        var _a2;
        if (!(limit && Number.isInteger(page2))) return;
        const PAGES = getPageCount();
        const requestedPage = page2 < 0 ? page2 + PAGES + 1 : page2;
        const isValidPageRequest = requestedPage > 0 && (PAGES ? requestedPage <= PAGES : requestedPage === 1);
        if (!isValidPageRequest) return;
        (_a2 = $controller.current) == null ? void 0 : _a2.abort();
        $controller.current = new AbortController();
        if (!$mounted.current) return;
        if (($page.current = requestedPage) > 1 || PAGES) {
          setCurrentPage($page.current);
        }
        (async () => {
          const { signal } = $controller.current;
          const params = { ...getPageParams(requestedPage, limit), limit, page: requestedPage };
          try {
            const data = await requestPageCallback(params, signal);
            if (!data || !$mounted.current) return;
            const { size: size2, ...paginationData } = data;
            updatePagination(requestedPage, limit, paginationData);
            $maxVisitedPage.current = $page.current && Math.max($page.current, $maxVisitedPage.current || -Infinity);
            if ($page.current && $page.current === $maxVisitedPage.current) $maxVisitedPageSize.current = size2;
            if ($page.current === 1 && size2 > 0) setCurrentPage($page.current);
            $page.current = void 0;
            updatePaginationChanged(true);
          } catch (ex) {
            if (signal.aborted) return;
            console.error(ex);
          }
        })();
      } : noop;
    }, [limit, requestPageCallback]);
    const next = q$1(() => {
      page && goto(Math.min(page + 1, getPageCount()));
    }, [goto, page]);
    const prev = q$1(() => {
      page && goto(Math.max(page - 1, 1));
    }, [goto, page]);
    const pages = T$1(() => getPageCount() || page || void 0, [goto, paginationChanged]);
    const hasNext = T$1(() => !!(page && pages) && page < pages, [page, pages]);
    const hasPrev = T$1(() => !!page && page > 1, [page]);
    const size = T$1(
      () => $maxVisitedPage.current ? ($maxVisitedPage.current - 1) * limit + ($maxVisitedPageSize.current || 0) : 0,
      [goto, paginationChanged]
    );
    const pageSize = T$1(() => limit && Math.min(limit, size || Infinity) % limit, [limit, size]);
    const resetPagination = q$1(() => {
      resetPageCount();
      $maxVisitedPage.current = $maxVisitedPageSize.current = $page.current = void 0;
      $mounted.current && setCurrentPage($page.current);
    }, [resetPageCount]);
    y(() => {
      if ($mounted.current && paginationChanged) {
        updatePaginationChanged(false);
      }
    }, [paginationChanged]);
    return { goto, hasNext, hasPrev, limit, next, page, pages, pageSize, prev, resetPagination, size };
  };
  const hasNextPage$1 = (value2) => isString$1(value2.next);
  const hasPrevPage = (value2) => isString$1(value2.prev);
  const useCursorPagination = (requestPageCallback, pageLimit) => {
    const paginationSetupConfig = T$1(() => {
      const cursors = [];
      const getPageCount = () => cursors.length;
      const resetPageCount = () => {
        cursors.length = 0;
      };
      const getPageParams = (page) => ({ cursor: cursors[page - 1] });
      const updateCursor = (cursor, page) => {
        const currentCursor = cursors[page - 1];
        if ((page === 1 || page === (cursors.length || 1) + 1) && isUndefined(currentCursor)) {
          cursors[page - 1] = cursor ? decodeURIComponent(cursor) : void 0;
        }
      };
      const updatePagination = (page, limit, paginationData) => {
        if (hasNextPage$1(paginationData)) updateCursor(paginationData.next, page + 1);
        if (hasPrevPage(paginationData)) updateCursor(paginationData.prev, page - 1);
      };
      return { getPageCount, getPageParams, resetPageCount, updatePagination };
    }, []);
    return usePagination(paginationSetupConfig, requestPageCallback, pageLimit);
  };
  const hasNextPage = (value2) => value2.next;
  const useOffsetPagination = (requestPageCallback, pageLimit) => {
    const paginationSetupConfig = T$1(() => {
      let currentPage = 0;
      const getPageCount = () => currentPage;
      const resetPageCount = () => {
        currentPage = 0;
      };
      const getPageParams = (page, limit) => ({ offset: (page - 1) * limit });
      const updatePagination = (page, limit, paginationData) => {
        if (hasNextPage(paginationData) && paginationData.next) {
          currentPage = Math.max(currentPage, page + 1);
        }
      };
      return { getPageCount, getPageParams, resetPageCount, updatePagination };
    }, []);
    return usePagination(paginationSetupConfig, requestPageCallback, pageLimit);
  };
  const useReactiveState = (params = EMPTY_OBJECT, initialStateSameAsDefault = true) => {
    const $hasDefaultState = A$1(initialStateSameAsDefault);
    const $defaultState = A$1(Object.freeze({ ...params }));
    const $stateParams = A$1(new Set(Object.keys($defaultState.current)));
    const $changedParams = A$1(/* @__PURE__ */ new Set());
    const $mounted = useMounted();
    const [resetState, updateState] = T$1(() => {
      const requestStateUpdate = (stateUpdateRequest) => {
        if (!$mounted.current) return;
        dispatch(stateUpdateRequest);
      };
      return [
        () => requestStateUpdate("reset"),
        (stateUpdateRequest) => requestStateUpdate(stateUpdateRequest)
      ];
    }, [$mounted]);
    const [state, dispatch] = h((state2, stateUpdateRequest) => {
      if (stateUpdateRequest === "reset") {
        $changedParams.current.clear();
        return $defaultState.current;
      }
      const stateUpdate = { ...stateUpdateRequest };
      const stateUpdateFlags = [0];
      Object.keys(stateUpdate).forEach((key, index) => {
        if (!$stateParams.current.has(key)) return;
        const currentValue = state2[key] ?? void 0;
        const defaultValue = $defaultState.current[key] ?? void 0;
        const updateValue = stateUpdate[key] ?? defaultValue;
        if (updateValue === currentValue) return;
        const flagIndex = Math.floor(index / 32);
        const updateFlag = 1 << index % 32;
        stateUpdate[key] = updateValue;
        stateUpdateFlags[flagIndex] |= updateFlag;
        $changedParams.current[updateValue === defaultValue ? "delete" : "add"](key);
      });
      const STATE = stateUpdateFlags.some((flag) => flag) ? $hasDefaultState.current && $changedParams.current.size === 0 ? $defaultState.current : Object.freeze({ ...state2, ...stateUpdate }) : state2;
      if (!$hasDefaultState.current) {
        $defaultState.current = STATE;
        $hasDefaultState.current = true;
      }
      return STATE;
    }, $defaultState.current);
    const canResetState = T$1(() => !!$changedParams.current.size, []);
    y(() => {
      $defaultState.current = Object.freeze({ ...params });
      $stateParams.current = new Set(Object.keys($defaultState.current));
      $hasDefaultState.current = initialStateSameAsDefault;
      resetState();
    }, [initialStateSameAsDefault, params, resetState]);
    return { canResetState, defaultState: $defaultState.current, resetState, state, updateState };
  };
  const usePaginatedRecordsFilters = (filterParams = EMPTY_OBJECT, initialFiltersSameAsDefault) => {
    const {
      canResetState: canResetFilters,
      defaultState: defaultFilters,
      resetState: resetFilters,
      state: filters,
      updateState: updateFilters
    } = useReactiveState(filterParams, initialFiltersSameAsDefault);
    return { canResetFilters, defaultFilters, filters, resetFilters, updateFilters };
  };
  var PageNeighbour = /* @__PURE__ */ ((PageNeighbour2) => {
    PageNeighbour2["NEXT"] = "next";
    PageNeighbour2["PREV"] = "prev";
    return PageNeighbour2;
  })(PageNeighbour || {});
  var PaginationType = /* @__PURE__ */ ((PaginationType2) => {
    PaginationType2["CURSOR"] = "cursor";
    PaginationType2["OFFSET"] = "offset";
    return PaginationType2;
  })(PaginationType || {});
  const offsetPaginatedResponseFields = ["hasNext", "hasPrevious"];
  const isCursorPaginatedResponseData = (data) => {
    const dataProperties = Object.getOwnPropertyNames(data);
    return !offsetPaginatedResponseFields.some((prop) => dataProperties.includes(prop));
  };
  const parseCursorPaginatedResponseData = (data, dataField = "data") => {
    const records = data[dataField];
    if (isCursorPaginatedResponseData(data)) {
      const paginationData = Object.fromEntries(
        Object.entries(data._links).map(([key, value2]) => [key, value2.cursor])
      );
      return { records, paginationData };
    }
    throw new TypeError("MALFORMED_PAGINATED_DATA");
  };
  const parseOffsetPaginatedResponseData = (data, dataField = "data") => {
    const records = data[dataField];
    if (!isCursorPaginatedResponseData(data)) {
      const { hasNext, hasPrevious } = data;
      const paginationData = {
        [PageNeighbour.NEXT]: boolOrFalse(hasNext),
        [PageNeighbour.PREV]: boolOrFalse(hasPrevious)
      };
      return { records, paginationData };
    }
    throw new TypeError("MALFORMED_PAGINATED_DATA");
  };
  const usePaginatedRecords = ({
    dataField = "data",
    fetchRecords,
    filterParams = EMPTY_OBJECT,
    initialFiltersSameAsDefault = true,
    initialize,
    onFiltersChanged,
    pagination,
    preferredLimit,
    preferredLimitOptions,
    enabled
  }) => {
    const [records, setRecords] = d([]);
    const [fetching, updateFetching] = useBooleanState(true);
    const [error, setError] = d();
    const [preferredPageLimit, setPreferredPageLimit] = d(preferredLimit);
    const $mounted = useMounted();
    const $initialFetchInProgress = A$1(true);
    const $lastRequestedPage = A$1(1);
    const $recordsFilters = usePaginatedRecordsFilters(filterParams, initialFiltersSameAsDefault);
    const { limit, limitOptions } = usePageLimit({ preferredLimit: preferredPageLimit, preferredLimitOptions });
    const { defaultFilters, filters, updateFilters, ...filtersProps } = $recordsFilters;
    const [parsePaginatedResponseData, usePagination2] = T$1(
      () => pagination === PaginationType.CURSOR ? [parseCursorPaginatedResponseData, useCursorPagination] : [parseOffsetPaginatedResponseData, useOffsetPagination],
      []
    );
    const updateLimit = q$1((limit2) => setPreferredPageLimit(limit2), []);
    const { goto, page, pages, resetPagination, ...paginationProps } = usePagination2(
      q$1(
        async ({ page: page2, ...pageRequestParams }, signal) => {
          try {
            setError(void 0);
            $lastRequestedPage.current = page2;
            if (!$mounted.current || updateFetching(true)) return;
            const res = await fetchRecords({ ...pageRequestParams, ...filters }, signal);
            const { records: records2, paginationData } = parsePaginatedResponseData(res, dataField);
            if ($initialFetchInProgress.current) {
              initialize == null ? void 0 : initialize([records2, paginationData], $recordsFilters);
              $initialFetchInProgress.current = false;
            }
            if ($mounted.current) {
              setRecords(records2);
              updateFetching(false);
            }
            return { ...paginationData, size: records2 == null ? void 0 : records2.length };
          } catch (err) {
            if (signal == null ? void 0 : signal.aborted) return;
            updateFetching(false);
            setError(err);
            console.error(err);
          }
        },
        [fetchRecords, filters, limit]
      ),
      limit
    );
    T$1(() => {
      $initialFetchInProgress.current = true;
    }, [filterParams]);
    T$1(() => {
      resetPagination();
      $lastRequestedPage.current = 1;
    }, [filters, limit, resetPagination]);
    y(() => {
      if (enabled) goto($lastRequestedPage.current);
    }, [goto, enabled]);
    y(() => {
      onFiltersChanged == null ? void 0 : onFiltersChanged(filters);
    }, [filters]);
    return { error, fetching, filters, goto, limitOptions, page, pages, records, updateFilters, updateLimit, ...filtersProps, ...paginationProps };
  };
  const useCursorPaginatedRecords = (initOptions) => {
    return usePaginatedRecords({
      ...initOptions,
      pagination: PaginationType.CURSOR
    });
  };
  const { getTimezoneTime, getUsedTimezone } = (() => {
    const REGEX_CLOCK_TIME_MATCHER = /\d{2}:\d{2}(?=:\d{2}(?:\.\d+)?\s+([AP]M))/i;
    const REGEX_GMT_OFFSET_UNWANTED_SUBSTRINGS2 = /^GMT|0(?=\d:00)|:00/g;
    const $restamper = restamper();
    const getTimezoneTime2 = (timezone2, timestamp = Date.now()) => {
      $restamper.tz = timezone2;
      const { formatted } = $restamper(timestamp);
      const [time = "", meridian = ""] = (formatted == null ? void 0 : formatted.match(REGEX_CLOCK_TIME_MATCHER)) ?? EMPTY_ARRAY;
      const offset = getTimezoneOffsetFromFormattedDateString(formatted);
      const clockTime = `${time}${meridian && ` ${meridian}`}`;
      const GMTOffsetString = getGMTSuffixForTimezoneOffset(offset).replace(REGEX_GMT_OFFSET_UNWANTED_SUBSTRINGS2, "");
      return [clockTime, GMTOffsetString];
    };
    const getUsedTimezone2 = (timezone2) => {
      $restamper.tz = timezone2;
      return $restamper.tz.current;
    };
    return { getTimezoneTime: getTimezoneTime2, getUsedTimezone: getUsedTimezone2 };
  })();
  const useTimezone = ({ timezone: tz, withClock = false } = EMPTY_OBJECT) => {
    const shouldWatchClock = T$1(() => boolOrFalse(withClock), [withClock]);
    const timezone2 = T$1(() => getUsedTimezone(tz), [tz]);
    const unwatchClock = A$1(noop);
    const [timestamp, setTimestamp] = d(Date.now());
    const [clockTime, GMTOffset] = T$1(() => getTimezoneTime(timezone2, timestamp), [timestamp, timezone2]);
    T$1(() => {
      unwatchClock.current();
      unwatchClock.current = shouldWatchClock ? clock.subscribe((snapshot) => {
        if (!isWatchlistUnsubscribeToken(snapshot)) setTimestamp(snapshot.now);
      }) : noop;
    }, [setTimestamp, shouldWatchClock]);
    return { clockTime, GMTOffset, timestamp, timezone: timezone2 };
  };
  const createRangeTimestampsConfigRestampingContext = (restamper2) => Object.freeze({
    systemToTimezone: enumerable((time) => systemToTimezone(restamper2, time)),
    timezoneToSystem: enumerable((time) => timezoneToSystem(restamper2, time)),
    timezoneOffset: enumerable((time) => restamper2(time).offset)
  });
  const getRangeTimestampsContextIntegerPropertyFactory = (minInteger, maxInteger, defaultInteger = minInteger) => {
    const _getNormalizedValue = (value2, fallbackValue) => {
      let normalizedValue = value2;
      if (isNullish(value2)) normalizedValue = defaultInteger;
      else if (!isBitSafeInteger(value2)) normalizedValue = fallbackValue ?? defaultInteger;
      const clampedValue = clamp(minInteger, normalizedValue, maxInteger);
      return clampedValue === normalizedValue ? clampedValue : fallbackValue ?? defaultInteger;
    };
    return (initialValue) => {
      const valueGetter = getter(() => normalizedValue);
      let normalizedValue = _getNormalizedValue(initialValue);
      return struct({
        value: valueGetter,
        descriptor: enumerable({
          ...valueGetter,
          set(value2) {
            const currentValue = normalizedValue;
            normalizedValue = _getNormalizedValue(value2, normalizedValue);
            if (currentValue !== normalizedValue) this.now = this.now;
          }
        })
      });
    };
  };
  const getRangeTimestampsConfigParameterUnwrapper = (config, context) => (value2) => isFunction(value2) ? value2.call(config, context) : value2;
  const isRangeTimestampsConfigWithoutOffsets = (config) => !hasOwnProperty(config, "offsets");
  const isRangeTimestampsConfigWithFromOffsets = (config) => hasOwnProperty(config, "from");
  const nowTimestamp = ({ now }) => now;
  const offsetsForNDays = /* @__PURE__ */ (() => {
    const _cache = /* @__PURE__ */ new Map();
    return (numberOfDays) => {
      let offsets = _cache.get(numberOfDays);
      if (isUndefined(offsets)) {
        offsets = Object.freeze([0, 0, numberOfDays, 0, 0, 0, -1]);
        _cache.set(numberOfDays, offsets);
      }
      return offsets;
    };
  })();
  const parseRangeTimestamp = (timestamp) => {
    try {
      const normalizedTimestamp = timestamp instanceof Date || +timestamp === timestamp ? timestamp : void 0;
      const parsedTimestamp = new Date(normalizedTimestamp).getTime();
      return isNaN(parsedTimestamp) ? void 0 : parsedTimestamp;
    } catch {
    }
  };
  const createRangeTimestampsFactory = (config = EMPTY_OBJECT, additionalContext = EMPTY_OBJECT) => {
    const _config2 = asPlainObject(config);
    const _additionalContext = asPlainObject(additionalContext);
    return () => {
      const _restamper = restamper();
      const nowDescriptor = getter(() => NOW);
      const tzDescriptor = getter(() => _restamper.tz.current);
      const configContext = struct({
        now: nowDescriptor,
        timezone: tzDescriptor,
        ...createRangeTimestampsConfigRestampingContext(_restamper)
      });
      const unwrap2 = getRangeTimestampsConfigParameterUnwrapper(_config2, configContext);
      let { from: from2, to: to2, now: NOW } = EMPTY_OBJECT;
      const nowSetter = (timestamp) => {
        NOW = parseRangeTimestamp(timestamp ?? Date.now()) ?? NOW;
        parsing: {
          if (isRangeTimestampsConfigWithoutOffsets(_config2)) {
            from2 = parseRangeTimestamp(unwrap2(_config2.from)) ?? NOW;
            to2 = parseRangeTimestamp(unwrap2(_config2.to)) ?? NOW;
            break parsing;
          }
          let date2;
          let direction;
          let withRangeFrom;
          if (withRangeFrom = isRangeTimestampsConfigWithFromOffsets(_config2)) {
            date2 = new Date(from2 = parseRangeTimestamp(unwrap2(_config2.from)) ?? NOW);
            direction = 1;
          } else {
            date2 = new Date(to2 = parseRangeTimestamp(unwrap2(_config2.to)) ?? NOW);
            direction = -1;
          }
          date2 = new Date(configContext.timezoneToSystem(date2));
          const [years = 0, months = 0, days = 0, hours = 0, minutes = 0, seconds = 0, ms = 0] = unwrap2(_config2.offsets);
          date2.setFullYear(date2.getFullYear() + years * direction, date2.getMonth() + months * direction, date2.getDate() + days * direction);
          date2.setHours(
            date2.getHours() + hours * direction,
            date2.getMinutes() + minutes * direction,
            date2.getSeconds() + seconds * direction,
            date2.getMilliseconds() + ms * direction
          );
          const timestamp2 = parseRangeTimestamp(configContext.systemToTimezone(date2)) ?? NOW;
          withRangeFrom ? to2 = timestamp2 : from2 = timestamp2;
        }
        if (from2 > to2) [from2, to2] = [to2, from2];
      };
      const tzSetter = (timezone2) => {
        const tz = _restamper.tz;
        const currentTimezone = tz.current;
        _restamper.tz = timezone2;
        if (tz.current !== currentTimezone) nowSetter(NOW);
      };
      nowSetter();
      return struct({
        ..._additionalContext,
        from: getter(() => from2),
        now: { ...nowDescriptor, set: nowSetter },
        timezone: { ...tzDescriptor, set: tzSetter },
        to: getter(() => to2)
      });
    };
  };
  const DATE_PARTS_REGEX = /^(\d{2})\/(\d{2})\/(-?\d+),\s+(\d{2}):(\d{2}):(\d{2}).(\d{3})/;
  const _startTimestamp = (adjustDate = identity) => (timestamp, timezone2, ...args) => {
    const restamper2 = withTimezone(timezone2);
    const restampedDate = new Date(timezoneToSystem(restamper2, timestamp));
    restampedDate.setHours(0, 0, 0, 0);
    return systemToTimezone(restamper2, adjustDate(restampedDate, ...args));
  };
  const startOfDay = _startTimestamp();
  const startOfMonth = _startTimestamp((date2) => date2.setDate(1));
  const startOfYear = _startTimestamp((date2) => date2.setMonth(0, 1));
  const startOfWeek = _startTimestamp((date2, firstWeekDay) => {
    const dateOffset = getWeekDayIndex(date2.getDay(), firstWeekDay ?? 0);
    return date2.setDate(date2.getDate() - dateOffset);
  });
  const isLeapYear = (year) => (year % 100 ? year % 4 : year % 400) === 0;
  const getMonthDays = (month, year, offset = 0) => {
    const nextMonth = month + offset;
    const monthIndex = mod(nextMonth, 12);
    const nextYear = year + Math.floor(nextMonth / 12);
    let days = 31;
    switch (monthIndex) {
      case 1:
        days = isLeapYear(nextYear) ? 29 : 28;
        break;
      case 3:
      case 5:
      case 8:
      case 10:
        days = 30;
        break;
    }
    return [days, monthIndex, nextYear];
  };
  const getWeekDayIndex = (weekDay, firstWeekDay = 0) => (7 - firstWeekDay + weekDay) % 7;
  const computeTimestampOffset = (timestamp, timezone2) => isInfinity(timestamp) ? 0 : timestamp - startOfDay(timestamp, timezone2);
  const getDateObjectFromTimestamp = (timestamp) => isUndefined(timestamp) ? timestamp : new Date(timestamp);
  const getTimezoneDateString = (date2, options = EMPTY_OBJECT) => {
    const restamper2 = withTimezone(options.timeZone);
    const dateOptions = { ...DEFAULT_DATETIME_FORMAT, ...options, timeZone: restamper2.tz.current };
    return new Date(date2).toLocaleDateString(BASE_LOCALE, dateOptions);
  };
  const getTimezoneDateParts = (date2, timeZone) => {
    const dateString = getTimezoneDateString(date2, { ...BASE_FORMAT_OPTIONS, ...DEFAULT_DATETIME_FORMAT, timeZone, hour12: false });
    const [, month = "", day = "", year = "", hours = "", minutes = "", seconds = "", ms = ""] = dateString.match(DATE_PARTS_REGEX) ?? EMPTY_ARRAY;
    return [+year, +month - 1, +day, +hours % 24, +minutes, +seconds, +ms];
  };
  const getEdgesDistance = (fromTime, toTime, timezone2) => {
    if (isInfinity(fromTime) || isInfinity(toTime)) return Infinity;
    const [fromYear, fromMonth] = getTimezoneDateParts(fromTime, timezone2);
    const [toYear, toMonth] = getTimezoneDateParts(toTime, timezone2);
    return Math.abs(toMonth - fromMonth + (toYear - fromYear) * 12);
  };
  const withTimezone = (() => {
    const _restamper = restamper();
    return (timezone2) => {
      _restamper.tz = void 0;
      _restamper.tz = timezone2;
      return _restamper;
    };
  })();
  const DEFAULT_FIRST_WEEK_DAY = 1;
  const ONE_WEEK_OFFSETS = offsetsForNDays(7);
  const _getFirstWeekDayContext = getRangeTimestampsContextIntegerPropertyFactory(0, 6, DEFAULT_FIRST_WEEK_DAY);
  const offsetWeek = (weekCount = 0) => {
    const weeks = ~~clamp(0, weekCount, Infinity) || 0;
    return (firstWeekDay = DEFAULT_FIRST_WEEK_DAY) => {
      const restConfig = weeks ? { offsets: ONE_WEEK_OFFSETS } : { to: nowTimestamp };
      const firstWeekDayContext = _getFirstWeekDayContext(firstWeekDay);
      return createRangeTimestampsFactory(
        {
          from: ({ now, timezone: timezone2, systemToTimezone: systemToTimezone2, timezoneToSystem: timezoneToSystem2 }) => {
            const date2 = new Date(timezoneToSystem2(startOfWeek(now, timezone2, firstWeekDayContext.value)));
            date2.setDate(date2.getDate() - weeks * 7);
            return systemToTimezone2(date2);
          },
          ...restConfig
        },
        { firstWeekDay: firstWeekDayContext.descriptor }
      )();
    };
  };
  const ONE_MONTH_OFFSETS = Object.freeze([0, 1, 0, 0, 0, 0, -1]);
  const offsetMonth = (monthCount = 0) => {
    const months = ~~clamp(0, monthCount, Infinity) || 0;
    const restConfig = months ? { offsets: ONE_MONTH_OFFSETS } : { to: nowTimestamp };
    return createRangeTimestampsFactory({
      from: ({ now, timezone: timezone2, systemToTimezone: systemToTimezone2, timezoneToSystem: timezoneToSystem2 }) => {
        const date2 = new Date(timezoneToSystem2(startOfMonth(now, timezone2)));
        date2.setMonth(date2.getMonth() - months);
        return systemToTimezone2(date2);
      },
      ...restConfig
    });
  };
  const lastMonth = offsetMonth(1);
  const MAX_NUM_DAYS = 365;
  const MIN_NUM_DAYS = 1;
  const DEFAULT_NUM_DAYS = 1;
  const _getNumberOfDaysContext = getRangeTimestampsContextIntegerPropertyFactory(MIN_NUM_DAYS, MAX_NUM_DAYS, DEFAULT_NUM_DAYS);
  const lastNDays = (numberOfDays) => {
    const numberOfDaysContext = _getNumberOfDaysContext(numberOfDays);
    return createRangeTimestampsFactory(
      {
        from: ({ now, timezone: timezone2, systemToTimezone: systemToTimezone2, timezoneToSystem: timezoneToSystem2 }) => {
          const date2 = new Date(timezoneToSystem2(startOfDay(now, timezone2)));
          date2.setDate(date2.getDate() - numberOfDaysContext.value + 1);
          return systemToTimezone2(date2);
        },
        to: nowTimestamp
      },
      { numberOfDays: numberOfDaysContext.descriptor }
    )();
  };
  const lastWeek = offsetWeek(1);
  const thisMonth = offsetMonth(0);
  const thisWeek = offsetWeek(0);
  const yearToDate = createRangeTimestampsFactory({
    from: ({ now, timezone: timezone2 }) => startOfYear(now, timezone2),
    to: nowTimestamp
  });
  const getTimeRangeSelectionDefaultPresetOptions = () => Object.freeze({
    "rangePreset.last7Days": lastNDays(7),
    "rangePreset.last30Days": lastNDays(30),
    "rangePreset.thisWeek": thisWeek(),
    "rangePreset.lastWeek": lastWeek(),
    "rangePreset.thisMonth": thisMonth(),
    "rangePreset.lastMonth": lastMonth(),
    "rangePreset.yearToDate": yearToDate()
  });
  const useTimeRangeSelection = ({
    now = Date.now(),
    options: presetOptions,
    selectedOption: selectedPresetOption,
    timezone: timezone2
  }) => {
    const { i18n } = useCoreContext();
    const [from2, setFrom] = d();
    const [to2, setTo] = d();
    const [selectedOption, setSelectedOption] = d();
    const NOW = A$1();
    const TZ = A$1();
    const [customOption, getRangesForOption, selectionOptions] = T$1(() => {
      const customOption2 = i18n.get("rangePreset.custom");
      const optionKeys = Object.keys(presetOptions);
      const selectionOptions2 = Object.freeze(optionKeys.map((key) => i18n.get(key)));
      const getRangesForOption2 = (option, options2 = selectionOptions2) => {
        const optionIndex = options2.findIndex((currentOption) => currentOption === option);
        return presetOptions[optionKeys[optionIndex]];
      };
      return [customOption2, getRangesForOption2, selectionOptions2];
    }, [i18n, presetOptions]);
    const [isCustomSelection, setIsCustomSelection] = d(selectedPresetOption === customOption);
    const selectionOptionsWithCustomOption = T$1(() => Object.freeze([...selectionOptions, customOption]), [customOption, selectionOptions]);
    const options = T$1(
      () => isCustomSelection ? selectionOptionsWithCustomOption : selectionOptions,
      [isCustomSelection, selectionOptions, selectionOptionsWithCustomOption]
    );
    const onSelection = q$1(
      (option) => {
        const ranges = getRangesForOption(option, selectionOptions);
        if (!ranges) return;
        setFrom(ranges.from);
        setTo(ranges.to);
        setIsCustomSelection(false);
        setSelectedOption(option);
      },
      [customOption, getRangesForOption, selectedOption, selectionOptions]
    );
    const customSelection = q$1(() => {
      setFrom(void 0);
      setTo(void 0);
      setIsCustomSelection(true);
      setSelectedOption(customOption);
    }, [customOption]);
    T$1(() => {
      selectedPresetOption === customOption ? setSelectedOption(customOption) : onSelection(selectedPresetOption);
    }, []);
    T$1(() => {
      var _a2;
      if (NOW.current !== now || TZ.current !== timezone2) {
        const options2 = Object.values(presetOptions);
        options2.forEach((ranges) => {
          ranges.now = now;
          ranges.timezone = timezone2;
        });
        NOW.current = now;
        TZ.current = (_a2 = options2[0]) == null ? void 0 : _a2.timezone;
        onSelection(selectedOption);
      }
    }, [now, timezone2, presetOptions]);
    return {
      customSelection,
      from: from2,
      onSelection,
      options,
      selectedOption,
      to: to2
    };
  };
  const TimeRangeSelector = ({
    calendarRef,
    onTimeRangeSelected,
    timestamp,
    ...useTimeRangeSelectionConfig
  }) => {
    const { customSelection, from: from2, onSelection, options, selectedOption, to: to2 } = useTimeRangeSelection(useTimeRangeSelectionConfig);
    const selectOptions = T$1(() => Object.freeze(options.map((id2) => ({ id: id2, name: id2 }))), [options]);
    const onSelectedOptionChanged = q$1(({ target }) => onSelection(target == null ? void 0 : target.value), [onSelection]);
    const rangeSelectionInProgress = A$1(true);
    const cachedTimestamp = A$1(timestamp);
    y(() => {
      if ((calendarRef == null ? void 0 : calendarRef.current) && from2 && to2) {
        rangeSelectionInProgress.current = true;
        calendarRef.current.from = new Date(from2);
        calendarRef.current.to = new Date(to2);
      }
    }, [calendarRef, from2, to2]);
    y(() => {
      if (cachedTimestamp.current !== timestamp) {
        cachedTimestamp.current = timestamp;
        if (rangeSelectionInProgress.current) {
          rangeSelectionInProgress.current = false;
        } else customSelection();
      }
    }, [customSelection, timestamp]);
    y(() => {
      selectedOption && (onTimeRangeSelected == null ? void 0 : onTimeRangeSelected(selectedOption));
    }, [selectedOption, onTimeRangeSelected]);
    return /* @__PURE__ */ u$1(
      Select,
      {
        setToTargetWidth: true,
        items: selectOptions,
        filterable: false,
        multiSelect: false,
        onChange: onSelectedOptionChanged,
        selected: selectedOption
      }
    );
  };
  const property = (() => {
    const descriptor = (descriptor2) => Object.freeze(
      structFrom(EMPTY_OBJECT, Object.fromEntries(Object.entries(descriptor2).map(([field, value2]) => [field, { value: value2 }])))
    );
    const isPropDescriptor = (value2) => {
      try {
        return Object.getPrototypeOf(value2) === EMPTY_OBJECT;
      } catch {
        return false;
      }
    };
    const prop = (setter, value2) => {
      if (!setter) return descriptor(enumerable(value2, boolOrTrue(setter)));
      let currentValue = value2;
      return descriptor({
        enumerable: true,
        get: () => currentValue,
        set: (value22) => {
          currentValue = setter(value22);
        }
      });
    };
    return Object.defineProperties(prop, {
      is: { value: isPropDescriptor },
      isObject: { value: isPlainObject },
      immutable: { value: (value2) => prop(false, value2) },
      mutable: { value: (value2) => prop(void 0, value2) },
      restricted: { value: () => prop(false) }
    });
  })();
  const propsProperty = (() => {
    const propsProperty2 = (props = {}, deepImmutable = false) => {
      const $props = struct();
      for (const [prop, maybeDescriptor] of Object.entries(props)) {
        try {
          const isDescriptor = property.is(maybeDescriptor);
          const isPlainObject2 = property.isObject(maybeDescriptor);
          if (isDescriptor || isPlainObject2) {
            Object.defineProperty($props, prop, isDescriptor ? maybeDescriptor : propsProperty2(maybeDescriptor, deepImmutable));
            continue;
          } else if (deepImmutable) {
            Object.defineProperty($props, prop, property.immutable(maybeDescriptor));
            continue;
          }
        } catch {
        }
        $props[prop] = maybeDescriptor;
      }
      return property((props2 = {}) => Object.assign($props, props2), $props);
    };
    const unwrapped = (props = {}, deepImmutable = false) => {
      const P2 = propsProperty2(props, deepImmutable);
      return struct({ P: P2 }).P;
    };
    return Object.defineProperties(propsProperty2, {
      unwrapped: { value: unwrapped }
    });
  })();
  var CalendarGridRenderToken = /* @__PURE__ */ ((CalendarGridRenderToken2) => {
    CalendarGridRenderToken2[CalendarGridRenderToken2["DATE"] = 0] = "DATE";
    CalendarGridRenderToken2[CalendarGridRenderToken2["DAY_OF_WEEK"] = 1] = "DAY_OF_WEEK";
    CalendarGridRenderToken2[CalendarGridRenderToken2["MONTH_HEADER"] = 2] = "MONTH_HEADER";
    return CalendarGridRenderToken2;
  })(CalendarGridRenderToken || {});
  const DEFAULT_DATE_CELL_CLASSNAME = "adyen-pe-calendar__cell adyen-pe-calendar__cell--date";
  const DEFAULT_DATE_TIME_CLASSNAME = "adyen-pe-calendar__date";
  const getGridDateRenderProps = (computedProps = EMPTY_OBJECT, prepare) => {
    const renderProps = propsProperty.unwrapped(
      {
        childClassName: property.mutable(DEFAULT_DATE_TIME_CLASSNAME),
        childProps: {
          children: property.restricted(),
          className: ""
        },
        className: property.mutable(DEFAULT_DATE_CELL_CLASSNAME),
        props: {
          ...computedProps,
          children: property.restricted(),
          className: ""
        }
      },
      true
    );
    prepare == null ? void 0 : prepare(CalendarGridRenderToken.DATE, renderProps);
    return renderProps;
  };
  const CalendarGridDate = fixedForwardRef(
    ({ grid, prepare, datetime, flags, index, label, onlyCellsWithin }, cursorElementRef) => {
      const withinMonth = flags.WITHIN_BLOCK;
      const props = {
        "data-cursor-position": index,
        "data-within-month": withinMonth,
        tabIndex: -1
      };
      if (withinMonth) {
        const withinRange = flags.WITHIN_RANGE;
        props["data-today"] = flags.CURRENT;
        props["data-first-week-day"] = flags.LINE_START;
        props["data-last-week-day"] = flags.LINE_END;
        props["data-weekend"] = flags.WEEKEND;
        props["data-first-month-day"] = flags.BLOCK_START;
        props["data-last-month-day"] = flags.BLOCK_END;
        props["data-within-range"] = withinRange;
        if (withinRange) {
          props["data-range-end"] = flags.RANGE_END;
          props["data-range-start"] = flags.RANGE_START;
          props["data-selection-end"] = flags.SELECTION_END;
          props["data-selection-start"] = flags.SELECTION_START;
          props["data-within-selection"] = flags.WITHIN_SELECTION;
          props["aria-selected"] = `${!!(flags.SELECTION_END || flags.SELECTION_START || flags.WITHIN_SELECTION)}`;
        }
        if (index === +grid.cursor) props.ref = cursorElementRef;
      }
      const renderProps = getGridDateRenderProps(props, prepare);
      const { children: _2, className, ...extendedProps } = renderProps.props || EMPTY_OBJECT;
      const classes2 = getClassName(renderProps.className, DEFAULT_DATE_CELL_CLASSNAME, className);
      return /* @__PURE__ */ u$1("td", { ...extendedProps, ...props, className: classes2, children: (!onlyCellsWithin || withinMonth) && (() => {
        const {
          children: _22,
          className: className2,
          ...extendedProps2
        } = renderProps.childProps || EMPTY_OBJECT;
        const classes22 = getClassName(renderProps.childClassName, DEFAULT_DATE_TIME_CLASSNAME, className2);
        return /* @__PURE__ */ u$1("time", { ...extendedProps2, className: classes22, dateTime: datetime, children: label });
      })() });
    }
  );
  const CalendarGridDate$1 = M(
    CalendarGridDate,
    memoComparator({
      block: memoComparator.exclude,
      flags: (value2) => +value2
    })
  );
  const DEFAULT_CELL_CLASSNAME = "adyen-pe-calendar__cell adyen-pe-calendar__cell--day-of-week";
  const DEFAULT_CELL_ABBR_CLASSNAME = "adyen-pe-calendar__day-of-week";
  const getGridDayOfWeekRenderProps = (computedProps = EMPTY_OBJECT, prepare) => {
    const renderProps = propsProperty.unwrapped(
      {
        childClassName: property.mutable(DEFAULT_CELL_ABBR_CLASSNAME),
        childProps: {
          children: property.restricted(),
          className: ""
        },
        className: property.mutable(DEFAULT_CELL_CLASSNAME),
        props: {
          ...computedProps,
          children: property.restricted(),
          className: ""
        }
      },
      true
    );
    prepare == null ? void 0 : prepare(CalendarGridRenderToken.DAY_OF_WEEK, renderProps);
    return renderProps;
  };
  const CalendarGridDayOfWeek = ({ prepare, flags, labels: { long: longLabel, short: shortLabel } }) => {
    const props = {
      "aria-label": longLabel,
      "data-first-week-day": flags.LINE_START,
      "data-last-week-day": flags.LINE_END,
      "data-weekend": flags.WEEKEND,
      scope: "col"
    };
    const renderProps = getGridDayOfWeekRenderProps(props, prepare);
    const { children: _2, className, onCommand, ...extendedProps } = renderProps.props || EMPTY_OBJECT;
    const classes2 = getClassName(renderProps.className, DEFAULT_CELL_CLASSNAME, className);
    const {
      children: __,
      className: childClassName,
      ...extendedChildProps
    } = renderProps.childProps || EMPTY_OBJECT;
    const childClasses = getClassName(renderProps.childClassName, DEFAULT_CELL_ABBR_CLASSNAME, childClassName);
    return /* @__PURE__ */ u$1("th", { ...extendedProps, ref: extendedProps.ref, ...props, className: classes2, children: /* @__PURE__ */ u$1("abbr", { ...extendedChildProps, className: childClasses, children: shortLabel }) });
  };
  const CalendarGridDayOfWeek$1 = M(
    CalendarGridDayOfWeek,
    memoComparator({
      block: memoComparator.exclude,
      flags: (value2) => +value2
    })
  );
  const CalendarGrid = D(({ cursorRootProps, onlyCellsWithin, prepare, grid }, cursorElementRef) => /* @__PURE__ */ u$1("ol", { className: "adyen-pe-calendar", role: "none", ...cursorRootProps, children: grid.map((block) => /* @__PURE__ */ u$1("li", { className: "adyen-pe-calendar__month", role: "none", children: [
    /* @__PURE__ */ u$1("div", { className: "adyen-pe-calendar__month-name", role: "none", children: /* @__PURE__ */ u$1("time", { dateTime: block.datetime, "aria-hidden": "true", children: block.label }) }),
    /* @__PURE__ */ u$1(
      "table",
      {
        role: "grid",
        "aria-multiselectable": true,
        "aria-label": `${block.label} calendar`,
        className: "adyen-pe-calendar__grid",
        style: { "--adyen-pe-calendar-rowspan": grid.rowspan },
        children: [
          /* @__PURE__ */ u$1("thead", { children: /* @__PURE__ */ u$1("tr", { className: "adyen-pe-calendar__row", children: grid.weekdays.map((data, index) => /* @__PURE__ */ u$1(CalendarGridDayOfWeek$1, { grid, block, prepare, cell: index, ...data }, data.labels["long"])) }) }),
          /* @__PURE__ */ u$1("tbody", { children: block.map((row, rowindex) => /* @__PURE__ */ u$1("tr", { className: "adyen-pe-calendar__row", children: row.map((data, index) => /* @__PURE__ */ u$1(
            CalendarGridDate$1,
            {
              ref: cursorElementRef,
              grid,
              block,
              prepare,
              cell: index,
              onlyCellsWithin,
              row: rowindex,
              ...data
            },
            `${block.month}:${data.timestamp}`
          )) }, `${block.month}:${rowindex}`)) })
        ]
      }
    )
  ] }, block.datetime)) }));
  const CalendarGrid$1 = M(CalendarGrid);
  const DAY_MS = 864e5;
  const DAY_OF_WEEK_FORMATS = ["narrow", "short", "long"];
  const FIRST_WEEK_DAYS = [0, 1, 6];
  const FRAME_SIZES = [1, 2, 3, 4, 6, 12];
  const MAXIMUM_MONTH_UNITS = 42;
  const WEEKEND_DAYS_SEED = [0, 1];
  const CONTROLS_ALL = Symbol();
  const CONTROLS_MINIMAL = Symbol();
  const CONTROLS_NONE = Symbol();
  const CALENDAR_CONTROLS = [CONTROLS_NONE, CONTROLS_MINIMAL, CONTROLS_ALL];
  const SELECT_MANY = Symbol();
  const SELECT_NONE = Symbol();
  const SELECT_ONE = Symbol();
  const CALENDAR_SELECTIONS = [SELECT_NONE, SELECT_ONE, SELECT_MANY];
  const CURSOR_BACKWARD = Symbol();
  const CURSOR_BLOCK_END = Symbol();
  const CURSOR_BLOCK_START = Symbol();
  const CURSOR_DOWNWARD = Symbol();
  const CURSOR_FORWARD = Symbol();
  const CURSOR_LINE_END = Symbol();
  const CURSOR_LINE_START = Symbol();
  const CURSOR_NEXT_BLOCK = Symbol();
  const CURSOR_PREV_BLOCK = Symbol();
  const CURSOR_UPWARD = Symbol();
  const RANGE_FROM = Symbol();
  const RANGE_TO = Symbol();
  const SELECTION_COLLAPSE = Symbol();
  const SELECTION_FARTHEST = Symbol();
  const SELECTION_FROM = Symbol();
  const SELECTION_NEAREST = Symbol();
  const SELECTION_TO = Symbol();
  const SHIFT_BLOCK = Symbol();
  const SHIFT_FRAME = Symbol();
  const SHIFT_PERIOD = Symbol();
  const downsizeTimeFrame = (size, maxsize) => {
    if (maxsize >= size) return size;
    let i2 = Math.max(1, FRAME_SIZES.indexOf(size));
    while (--i2 && maxsize < FRAME_SIZES[i2]) {
    }
    return FRAME_SIZES[i2];
  };
  const resolveTimeFrameBlockSize = (size) => FRAME_SIZES[Math.max(FRAME_SIZES.indexOf(size), 0)];
  const getWeekendDays = (firstWeekDay = 0) => (
    // [TODO]: Derive weekend days based on locale
    Object.freeze(WEEKEND_DAYS_SEED.map((seed) => mod(6 - firstWeekDay + seed, 7)))
  );
  class __TimeSlice__ {
    constructor(...args) {
      __privateAdd(this, _numberOfMonths, Infinity);
      __privateAdd(this, _endTimestamp, Infinity);
      __privateAdd(this, _startTimestamp2, -Infinity);
      __privateAdd(this, _endTimestampOffset, 0);
      __privateAdd(this, _startTimestampOffset, 0);
      if (args.length >= 3) {
        let timestamp = new Date(args[1]).getTime();
        if (typeof args[2] !== "symbol") {
          __privateSet(this, _startTimestamp2, timestamp || __privateGet(this, _startTimestamp2));
          __privateSet(this, _endTimestamp, new Date(args[2]).getTime() || __privateGet(this, _endTimestamp));
          if (__privateGet(this, _endTimestamp) < __privateGet(this, _startTimestamp2)) {
            [__privateWrapper(this, _endTimestamp)._, __privateWrapper(this, _startTimestamp2)._] = [__privateGet(this, _startTimestamp2), __privateGet(this, _endTimestamp)];
          }
          __privateSet(this, _startTimestampOffset, computeTimestampOffset(__privateGet(this, _startTimestamp2), args[0]));
          __privateSet(this, _endTimestampOffset, computeTimestampOffset(__privateGet(this, _endTimestamp), args[0]));
          __privateSet(this, _numberOfMonths, getEdgesDistance(__privateGet(this, _startTimestamp2), __privateGet(this, _endTimestamp), args[0]) + 1);
        } else if (!isNaN(timestamp)) {
          switch (args[2]) {
            case RANGE_TO:
              __privateSet(this, _endTimestamp, timestamp);
              __privateSet(this, _endTimestampOffset, computeTimestampOffset(__privateGet(this, _endTimestamp), args[0]));
              break;
            case RANGE_FROM:
            default:
              __privateSet(this, _startTimestamp2, timestamp);
              __privateSet(this, _startTimestampOffset, computeTimestampOffset(__privateGet(this, _startTimestamp2), args[0]));
              break;
          }
        }
      }
    }
    get numberOfMonths() {
      return __privateGet(this, _numberOfMonths);
    }
    get endTimestamp() {
      return __privateGet(this, _endTimestamp);
    }
    get endTimestampOffset() {
      return __privateGet(this, _endTimestampOffset);
    }
    get startTimestamp() {
      return __privateGet(this, _startTimestamp2);
    }
    get startTimestampOffset() {
      return __privateGet(this, _startTimestampOffset);
    }
  }
  _numberOfMonths = new WeakMap();
  _endTimestamp = new WeakMap();
  _startTimestamp2 = new WeakMap();
  _endTimestampOffset = new WeakMap();
  _startTimestampOffset = new WeakMap();
  const factory = (...args) => {
    let tz = withTimezone().tz.current;
    let slice = new __TimeSlice__(tz, ...args);
    return struct({
      from: getter(() => slice.startTimestamp, false),
      to: getter(() => slice.endTimestamp, false),
      offsets: {
        value: struct({
          from: getter(() => slice.startTimestampOffset, false),
          to: getter(() => slice.endTimestampOffset, false)
        })
      },
      span: getter(() => slice.numberOfMonths, false),
      timezone: {
        ...getter(() => tz, false),
        set: (timezone2) => {
          const currentTimezone = tz;
          tz = withTimezone(timezone2 ?? void 0).tz.current;
          if (tz !== currentTimezone) {
            slice = new __TimeSlice__(tz, ...args);
          }
        }
      }
    });
  };
  const UNBOUNDED_SLICE = factory();
  const sinceNow = () => factory(Date.now(), RANGE_FROM);
  const untilNow = () => factory(Date.now(), RANGE_TO);
  const timeslice = (...args) => args.length === 0 ? UNBOUNDED_SLICE : factory(...args);
  var TimeFlag = /* @__PURE__ */ ((TimeFlag2) => {
    TimeFlag2[TimeFlag2["CURRENT"] = 1] = "CURRENT";
    TimeFlag2[TimeFlag2["CURSOR"] = 2] = "CURSOR";
    TimeFlag2[TimeFlag2["WEEKEND"] = 4] = "WEEKEND";
    TimeFlag2[TimeFlag2["LINE_START"] = 8] = "LINE_START";
    TimeFlag2[TimeFlag2["LINE_END"] = 16] = "LINE_END";
    TimeFlag2[TimeFlag2["WITHIN_BLOCK"] = 32] = "WITHIN_BLOCK";
    TimeFlag2[TimeFlag2["BLOCK_START"] = 64] = "BLOCK_START";
    TimeFlag2[TimeFlag2["BLOCK_END"] = 128] = "BLOCK_END";
    TimeFlag2[TimeFlag2["WITHIN_RANGE"] = 256] = "WITHIN_RANGE";
    TimeFlag2[TimeFlag2["RANGE_START"] = 512] = "RANGE_START";
    TimeFlag2[TimeFlag2["RANGE_END"] = 1024] = "RANGE_END";
    TimeFlag2[TimeFlag2["WITHIN_SELECTION"] = 2048] = "WITHIN_SELECTION";
    TimeFlag2[TimeFlag2["SELECTION_START"] = 4096] = "SELECTION_START";
    TimeFlag2[TimeFlag2["SELECTION_END"] = 8192] = "SELECTION_END";
    TimeFlag2[TimeFlag2["ALL"] = 16383] = "ALL";
    return TimeFlag2;
  })(TimeFlag || {});
  var CalendarShiftControlFlag = /* @__PURE__ */ ((CalendarShiftControlFlag2) => {
    CalendarShiftControlFlag2[CalendarShiftControlFlag2["PREV"] = 1] = "PREV";
    CalendarShiftControlFlag2[CalendarShiftControlFlag2["BLOCK"] = 0] = "BLOCK";
    CalendarShiftControlFlag2[CalendarShiftControlFlag2["FRAME"] = 2] = "FRAME";
    CalendarShiftControlFlag2[CalendarShiftControlFlag2["PERIOD"] = 4] = "PERIOD";
    return CalendarShiftControlFlag2;
  })(CalendarShiftControlFlag || {});
  var CalendarShiftControlsFlag = /* @__PURE__ */ ((CalendarShiftControlsFlag2) => {
    CalendarShiftControlsFlag2[CalendarShiftControlsFlag2["PREV_PERIOD"] = 5] = "PREV_PERIOD";
    CalendarShiftControlsFlag2[CalendarShiftControlsFlag2["PREV_FRAME"] = 3] = "PREV_FRAME";
    CalendarShiftControlsFlag2[CalendarShiftControlsFlag2["PREV"] = 1] = "PREV";
    CalendarShiftControlsFlag2[
      CalendarShiftControlsFlag2["NEXT"] = 0
      /* BLOCK */
    ] = "NEXT";
    CalendarShiftControlsFlag2[
      CalendarShiftControlsFlag2["NEXT_FRAME"] = 2
      /* FRAME */
    ] = "NEXT_FRAME";
    CalendarShiftControlsFlag2[
      CalendarShiftControlsFlag2["NEXT_PERIOD"] = 4
      /* PERIOD */
    ] = "NEXT_PERIOD";
    return CalendarShiftControlsFlag2;
  })(CalendarShiftControlsFlag || {});
  const createFlagsRecord = (() => {
    const CACHE = {};
    const FLAG_PROPS = Object.keys(TimeFlag).filter((prop) => isNaN(+prop));
    const isFlagProp = (property2) => property2 !== "ALL" && isString$1(property2) && FLAG_PROPS.includes(property2);
    return (flags) => {
      const flagsTruncated = flags & TimeFlag.ALL;
      if (!CACHE[flagsTruncated]) {
        CACHE[flagsTruncated] = new Proxy(
          struct({
            valueOf: { value: () => flagsTruncated }
          }),
          withFreezeProxyHandlers({
            get: (target, property2) => {
              switch (property2) {
                case "valueOf":
                  return target.valueOf;
                case Symbol.toStringTag:
                  return "_";
                default:
                  if (!isFlagProp(property2)) return;
              }
              return flagsTruncated & TimeFlag[property2] ? 1 : void 0;
            }
          })
        );
      }
      return CACHE[flagsTruncated];
    };
  })();
  const indexedProxyGetTrap = (getter2) => (target, property2, receiver) => {
    if (isString$1(property2)) {
      const index = +property2;
      if (index >= 0 && index < target.length) {
        return getter2(index);
      }
    }
    return Reflect.get(target, property2, receiver);
  };
  const mapIteratorFactory = function* (callback = identity, thisArg) {
    for (let i2 = 0; i2 < this.length; i2++) {
      yield callback.call(thisArg, this[i2], i2, this);
    }
  };
  const __INDEXED_PROTO__ = Object.freeze(
    struct({
      [Symbol.iterator]: {
        value() {
          return mapIteratorFactory.call(this);
        }
      },
      map: {
        value(callback, thisArg) {
          return [...mapIteratorFactory.call(this, callback, thisArg)];
        }
      }
    })
  );
  const createIndexed = (iterablePropertyDescriptorsOrSize, iteratorValueGetter) => {
    if (isFunction(iterablePropertyDescriptorsOrSize)) {
      return createIndexed(
        {
          length: { get: iterablePropertyDescriptorsOrSize }
        },
        iteratorValueGetter
      );
    }
    if (isNumber(iterablePropertyDescriptorsOrSize)) {
      return createIndexed(
        {
          length: { value: iterablePropertyDescriptorsOrSize }
        },
        iteratorValueGetter
      );
    }
    return new Proxy(structFrom(__INDEXED_PROTO__, iterablePropertyDescriptorsOrSize), {
      get: indexedProxyGetTrap(iteratorValueGetter),
      set: truthify
    });
  };
  const today = (() => {
    const timezones = /* @__PURE__ */ new Map();
    const restamper$1 = restamper();
    const getTimestampWithTomorrowOffset = (withTimestamp = Date.now()) => {
      const restampedDate = new Date(timezoneToSystem(restamper$1, withTimestamp));
      const currentTimestamp = systemToTimezone(restamper$1, restampedDate.setHours(0, 0, 0, 0));
      const nextTimestamp = systemToTimezone(restamper$1, restampedDate.setDate(restampedDate.getDate() + 1));
      return [currentTimestamp, nextTimestamp - currentTimestamp];
    };
    return (timezone2) => {
      restamper$1.tz = timezone2;
      const tz = restamper$1.tz.current;
      return timezones.get(tz) ?? (() => {
        let timestamp = null;
        let tomorrowOffset = null;
        let unsubscribeClock = null;
        const getTimestamp = () => {
          restamper$1.tz = tz;
          return timestamp ?? getTimestampWithTomorrowOffset()[0];
        };
        const refreshTimestamps = (withTimestamp = Date.now()) => {
          restamper$1.tz = tz;
          [timestamp, tomorrowOffset] = getTimestampWithTomorrowOffset(withTimestamp);
        };
        const { cancelSubscriptions, requestNotification, subscribe, on: on2 } = createWatchlist({
          timestamp: getTimestamp
        });
        on2.resume = () => {
          unsubscribeClock = clock.subscribe((snapshot) => {
            if (isWatchlistUnsubscribeToken(snapshot)) return;
            const { now } = snapshot;
            if (isNull(timestamp) || isNull(tomorrowOffset)) return refreshTimestamps(now);
            if (now - timestamp < tomorrowOffset) return;
            refreshTimestamps(now);
            requestNotification();
          });
        };
        on2.idle = () => {
          unsubscribeClock == null ? void 0 : unsubscribeClock();
          timestamp = tomorrowOffset = unsubscribeClock = null;
        };
        const instance = struct({
          cancelSubscriptions: enumerable(cancelSubscriptions),
          timestamp: getter(getTimestamp),
          timezone: enumerable(tz),
          subscribe: enumerable(subscribe)
        });
        timezones.set(tz, instance);
        return instance;
      })();
    };
  })();
  const _TimeFrame = class _TimeFrame {
    constructor() {
      __privateAdd(this, _TimeFrame_instances);
      __privateAdd(this, _cursorBlockIndex, 0);
      __privateAdd(this, _cursorBlockStartIndex);
      __privateAdd(this, _cursorBlockEndIndex);
      __privateAdd(this, _cursorStartIndex, -1);
      __privateAdd(this, _cursorEndIndex, -1);
      __privateAdd(this, _cursorIndex);
      __privateAdd(this, _cursorOffset);
      __privateAdd(this, _cursorTimestamp);
      __privateAdd(this, _dynamicBlockHeight, false);
      __privateAdd(this, _effect);
      __privateAdd(this, _firstWeekDay, 0);
      __privateAdd(this, _frameBlocksCached, []);
      __privateAdd(this, _locale2, __privateGet(_TimeFrame, _DEFAULT_LOCALE));
      __privateAdd(this, _maxFrameSize, 12);
      __privateAdd(this, _selectionStartTimestamp);
      __privateAdd(this, _selectionEndTimestamp);
      __privateAdd(this, _size, 1);
      __privateAdd(this, __timeslice);
      __privateAdd(this, _timeslice);
      __privateAdd(this, _timezone);
      __privateAdd(this, _today, today());
      __privateAdd(this, _unwatchCurrentDay);
      __privateAdd(this, _fromTimestamp, -Infinity);
      __privateAdd(this, _toTimestamp, Infinity);
      __privateAdd(this, _fromBlockOffsetFromOrigin, -Infinity);
      __privateAdd(this, _toBlockOffsetFromOrigin, Infinity);
      __privateAdd(this, _numberOfBlocks, Infinity);
      __privateAdd(this, _numberOfUnits, 0);
      __publicField(this, "daysInWeek", 0);
      __publicField(this, "origin");
      __publicField(this, "originTimestamp");
      __privateAdd(this, _daysOfWeek, createIndexed(() => this.daysInWeek, this.getDayOfWeekAtIndex.bind(this)));
      __privateAdd(this, _frameBlocks, createIndexed(() => __privateGet(this, _size), __privateMethod(this, _TimeFrame_instances, getFrameBlockAtIndex_fn).bind(this)));
    }
    get fromTimestamp() {
      return __privateGet(this, _fromTimestamp);
    }
    get toTimestamp() {
      return __privateGet(this, _toTimestamp);
    }
    get numberOfBlocks() {
      return __privateGet(this, _numberOfBlocks);
    }
    get blankSelection() {
      return __privateGet(this, _selectionStartTimestamp) === __privateGet(this, _selectionEndTimestamp) && isUndefined(__privateGet(this, _selectionEndTimestamp));
    }
    get cursor() {
      return __privateGet(this, _cursorIndex) ?? -1;
    }
    get daysOfWeek() {
      return __privateGet(this, _daysOfWeek);
    }
    get dynamicBlockHeight() {
      return __privateGet(this, _dynamicBlockHeight);
    }
    set dynamicBlockHeight(bool) {
      if (isNullish(bool)) __privateSet(this, _dynamicBlockHeight, !!bool);
      else if (isBoolean(bool)) __privateSet(this, _dynamicBlockHeight, bool);
    }
    set effect(effect) {
      if (isNullish(effect)) __privateSet(this, _effect, void 0);
      else if (isFunction(effect)) __privateSet(this, _effect, effect);
    }
    get firstWeekDay() {
      return __privateGet(this, _firstWeekDay);
    }
    set firstWeekDay(day) {
      if (!isNullish(day)) {
        if (!FIRST_WEEK_DAYS.includes(day)) return;
        if (__privateGet(this, _firstWeekDay) === __privateSet(this, _firstWeekDay, day)) return;
      } else this.firstWeekDay = 0;
    }
    get frameBlocks() {
      return __privateGet(this, _frameBlocks);
    }
    get isAtEnd() {
      return !isInfinity(__privateGet(this, _toBlockOffsetFromOrigin)) && __privateGet(this, _toBlockOffsetFromOrigin) === __privateGet(this, _size) - 1;
    }
    get isAtStart() {
      return !isInfinity(__privateGet(this, _fromBlockOffsetFromOrigin)) && __privateGet(this, _fromBlockOffsetFromOrigin) === 0;
    }
    get locale() {
      return __privateGet(this, _locale2);
    }
    set locale(locale) {
      const currentLocale = __privateGet(this, _locale2);
      if (isNullish(locale)) {
        __privateSet(this, _locale2, __privateGet(_TimeFrame, _DEFAULT_LOCALE));
      } else if (typeof Intl !== "undefined") {
        try {
          __privateSet(this, _locale2, new Intl.Locale(locale).toString());
        } catch {
          __privateSet(this, _locale2, __privateGet(_TimeFrame, _DEFAULT_LOCALE));
        }
      }
      if (__privateGet(this, _locale2) !== currentLocale) this.refreshFrame(true);
    }
    get selectionStart() {
      return __privateGet(this, _selectionStartTimestamp);
    }
    get selectionEnd() {
      return __privateGet(this, _selectionEndTimestamp);
    }
    get size() {
      return __privateGet(this, _size);
    }
    set size(size) {
      const nextFrameSize = Math.min(!isNullish(size) && resolveTimeFrameBlockSize(size) || 1, __privateGet(this, _maxFrameSize));
      if (__privateGet(this, _size) === __privateSet(this, _size, nextFrameSize)) return;
      __privateMethod(this, _TimeFrame_instances, shiftOriginIfNecessary_fn).call(this);
      this.refreshFrame();
    }
    get timeslice() {
      return __privateGet(this, _timeslice);
    }
    set timeslice(timeslice$1) {
      if (timeslice$1 === __privateGet(this, __timeslice) || isNullish(timeslice$1) && __privateGet(this, __timeslice) === UNBOUNDED_SLICE) return;
      const { from: from2, to: to2, timezone: timezone2 } = __privateSet(this, __timeslice, timeslice$1 ?? UNBOUNDED_SLICE);
      __privateSet(this, _timeslice, timeslice(from2, to2));
      this.timezone = timezone2;
    }
    get timezone() {
      return __privateGet(this, _timezone);
    }
    set timezone(timezone2) {
      __privateGet(this, _timeslice).timezone = timezone2;
      __privateSet(this, _timezone, __privateGet(this, _timeslice).timezone);
      __privateSet(this, _today, today(__privateGet(this, _timezone)));
      if (__privateGet(this, _unwatchCurrentDay)) {
        __privateGet(this, _unwatchCurrentDay).call(this);
        __privateSet(this, _unwatchCurrentDay, __privateGet(this, _today).subscribe(this.refreshFrame.bind(this, true)));
      }
      __privateMethod(this, _TimeFrame_instances, applyTimeSliceUpdate_fn).call(this);
    }
    set trackCurrentDay(bool) {
      if (isBoolean(bool)) {
        if (bool && !__privateGet(this, _unwatchCurrentDay)) {
          __privateSet(this, _unwatchCurrentDay, __privateGet(this, _today).subscribe(this.refreshFrame.bind(this, true)));
        } else if (!bool && __privateGet(this, _unwatchCurrentDay)) {
          __privateGet(this, _unwatchCurrentDay).call(this);
          __privateSet(this, _unwatchCurrentDay, void 0);
        }
      } else if (isNullish(bool)) this.trackCurrentDay = false;
    }
    get units() {
      return __privateGet(this, _numberOfUnits);
    }
    initialize() {
      this.timeslice = UNBOUNDED_SLICE;
    }
    refreshFrame(skipCursorRefresh = false) {
      var _a2;
      __privateGet(this, _frameBlocksCached).length = 0;
      if (!(isUndefined(__privateGet(this, _cursorOffset)) || skipCursorRefresh)) {
        const cursorBlock = this.getFrameBlockAtIndex(__privateGet(this, _cursorBlockIndex));
        const { from: startIndex, to: endIndex } = cursorBlock.inner;
        const [nextCursorTimestamp] = __privateMethod(this, _TimeFrame_instances, getContainedTimestamp_fn).call(this, this.getTimestampAtIndex(startIndex + __privateGet(this, _cursorOffset)), false);
        __privateSet(this, _cursorOffset, this.getUnitsOffsetForTimestamp(this.getTimestampAtIndex(startIndex), nextCursorTimestamp));
        const nextCursorOffset = startIndex + __privateGet(this, _cursorOffset);
        const clampedNextCursorOffset = clamp(startIndex, nextCursorOffset, endIndex);
        if (clampedNextCursorOffset > nextCursorOffset) {
          __privateSet(this, _cursorOffset, this.getUnitsForFrameBlockAtIndex(--__privateWrapper(this, _cursorBlockIndex)._) + nextCursorOffset - clampedNextCursorOffset);
          if (__privateGet(this, _cursorBlockIndex) >= 0) return this.refreshFrame();
          __privateSet(this, _cursorBlockIndex, __privateGet(this, _size) - 1);
          return this.shiftFrameByOffset(-1, SHIFT_FRAME);
        }
        if (clampedNextCursorOffset < nextCursorOffset) {
          __privateSet(this, _cursorOffset, nextCursorOffset - clampedNextCursorOffset - 1);
          if (++__privateWrapper(this, _cursorBlockIndex)._ < __privateGet(this, _size)) return this.refreshFrame();
          __privateSet(this, _cursorBlockIndex, 0);
          return this.shiftFrameByOffset(1, SHIFT_FRAME);
        }
        __privateSet(this, _cursorBlockStartIndex, startIndex);
        __privateSet(this, _cursorBlockEndIndex, endIndex);
        __privateSet(this, _cursorTimestamp, __privateMethod(this, _TimeFrame_instances, getContainedTimestamp_fn).call(this, this.getTimestampAtIndex(nextCursorOffset), false)[0]);
        __privateSet(this, _cursorOffset, this.getCursorBlockOriginTimestampOffset(__privateGet(this, _cursorTimestamp)));
        __privateSet(this, _cursorIndex, startIndex + __privateGet(this, _cursorOffset));
        const firstBlock = __privateGet(this, _cursorBlockIndex) > 0 ? this.getFrameBlockAtIndex(0) : cursorBlock;
        const lastBlock = __privateGet(this, _cursorBlockIndex) < __privateGet(this, _size) - 1 ? this.getFrameBlockAtIndex(__privateGet(this, _size) - 1) : cursorBlock;
        __privateSet(this, _cursorStartIndex, firstBlock.inner.from);
        __privateSet(this, _cursorEndIndex, lastBlock.inner.to);
        __privateSet(this, _numberOfUnits, lastBlock.outer.to + 1);
      }
      this.withCurrentDayTimestamp();
      (_a2 = __privateGet(this, _effect)) == null ? void 0 : _a2.call(this);
    }
    shiftFrameByOffset(offset, offsetType) {
      if (offset && isBitSafeInteger(offset)) {
        switch (offsetType) {
          case SHIFT_BLOCK:
            return __privateMethod(this, _TimeFrame_instances, shiftOrigin_fn).call(this, offset);
          case SHIFT_PERIOD:
            return __privateMethod(this, _TimeFrame_instances, shiftOrigin_fn).call(this, offset * 12);
          case SHIFT_FRAME:
          default:
            return __privateMethod(this, _TimeFrame_instances, shiftOrigin_fn).call(this, offset * __privateGet(this, _size));
        }
      }
    }
    shiftFrameCursor(nextCursorPosition) {
      switch (nextCursorPosition) {
        case CURSOR_BACKWARD:
          return __privateMethod(this, _TimeFrame_instances, shiftFrameCursorByOffset_fn).call(this, -1);
        case CURSOR_FORWARD:
          return __privateMethod(this, _TimeFrame_instances, shiftFrameCursorByOffset_fn).call(this, 1);
        case CURSOR_UPWARD:
          return __privateMethod(this, _TimeFrame_instances, shiftFrameCursorByOffset_fn).call(this, -this.rowspan);
        case CURSOR_DOWNWARD:
          return __privateMethod(this, _TimeFrame_instances, shiftFrameCursorByOffset_fn).call(this, this.rowspan);
        case CURSOR_BLOCK_START:
          return __privateMethod(this, _TimeFrame_instances, shiftFrameCursorByOffset_fn).call(this, __privateGet(this, _cursorBlockStartIndex) - __privateGet(this, _cursorIndex));
        case CURSOR_BLOCK_END:
          return __privateMethod(this, _TimeFrame_instances, shiftFrameCursorByOffset_fn).call(this, __privateGet(this, _cursorBlockEndIndex) - __privateGet(this, _cursorIndex));
        case CURSOR_LINE_START:
          return __privateMethod(this, _TimeFrame_instances, shiftFrameCursorByOffset_fn).call(this, -(__privateGet(this, _cursorIndex) % this.rowspan));
        case CURSOR_LINE_END:
          return __privateMethod(this, _TimeFrame_instances, shiftFrameCursorByOffset_fn).call(this, this.rowspan - (__privateGet(this, _cursorIndex) % this.rowspan + 1));
        case CURSOR_PREV_BLOCK:
          return __privateMethod(this, _TimeFrame_instances, shiftFrameCursorByOffset_fn).call(this, -this.getUnitsForFrameBlockAtIndex((__privateGet(this, _cursorBlockIndex) ?? 0) - 1));
        case CURSOR_NEXT_BLOCK:
          return __privateMethod(this, _TimeFrame_instances, shiftFrameCursorByOffset_fn).call(this, this.getUnitsForFrameBlockAtIndex(__privateGet(this, _cursorBlockIndex) ?? 0));
      }
      if (nextCursorPosition < 0) return;
      if (nextCursorPosition >= __privateGet(this, _cursorStartIndex) && nextCursorPosition <= __privateGet(this, _cursorEndIndex)) {
        return __privateMethod(this, _TimeFrame_instances, shiftFrameCursorByOffset_fn).call(this, nextCursorPosition - __privateGet(this, _cursorIndex));
      }
    }
    shiftFrameToTimestamp(timestamp) {
      __privateSet(this, _cursorTimestamp, this.originTimestamp = __privateMethod(this, _TimeFrame_instances, getContainedTimestamp_fn).call(this, timestamp, false).reduce((a2, b2) => a2 + b2));
      __privateSet(this, _cursorOffset, this.getCursorBlockOriginTimestampOffset(__privateGet(this, _cursorTimestamp)));
      this.reoriginate();
      [__privateWrapper(this, _fromBlockOffsetFromOrigin)._, __privateWrapper(this, _toBlockOffsetFromOrigin)._] = this.getEdgeBlockOffsetsFromOrigin();
      __privateMethod(this, _TimeFrame_instances, shiftOriginIfNecessary_fn).call(this);
      this.refreshFrame();
      __privateMethod(this, _TimeFrame_instances, shiftFrameCursorByOffset_fn).call(this, this.getUnitsOffsetForTimestamp(this.getTimestampAtIndex(__privateGet(this, _cursorIndex)), __privateGet(this, _cursorTimestamp)));
    }
    clearSelection() {
      if (this.blankSelection) return;
      __privateSet(this, _selectionStartTimestamp, __privateSet(this, _selectionEndTimestamp, void 0));
      this.refreshFrame(true);
    }
    updateSelection(time, selection) {
      const currentStart = __privateGet(this, _selectionStartTimestamp);
      const currentEnd = __privateGet(this, _selectionEndTimestamp);
      const timestamp = __privateMethod(this, _TimeFrame_instances, getContainedTimestamp_fn).call(this, time, false).reduce((a2, b2) => a2 + b2);
      if (selection === SELECTION_FARTHEST) {
        if (timestamp <= currentStart) selection = SELECTION_TO;
        else if (timestamp >= currentEnd) selection = SELECTION_FROM;
      }
      switch (selection) {
        case SELECTION_FROM:
          __privateSet(this, _selectionStartTimestamp, timestamp);
          __privateSet(this, _selectionEndTimestamp, Math.max(__privateGet(this, _selectionStartTimestamp), currentEnd ?? timestamp));
          break;
        case SELECTION_TO:
          __privateSet(this, _selectionEndTimestamp, timestamp);
          __privateSet(this, _selectionStartTimestamp, Math.min(currentStart ?? timestamp, __privateGet(this, _selectionEndTimestamp)));
          break;
        case SELECTION_FARTHEST:
        case SELECTION_NEAREST: {
          let startDistance = Math.abs(timestamp - (currentStart ?? timestamp));
          let endDistance = Math.abs(timestamp - (currentEnd ?? timestamp));
          if (selection === SELECTION_NEAREST) {
            [startDistance, endDistance] = [endDistance, startDistance];
          }
          if (startDistance > endDistance) {
            __privateSet(this, _selectionStartTimestamp, timestamp);
          } else __privateSet(this, _selectionEndTimestamp, timestamp);
          break;
        }
        case SELECTION_COLLAPSE:
        default:
          __privateSet(this, _selectionStartTimestamp, __privateSet(this, _selectionEndTimestamp, timestamp));
          break;
      }
      if (__privateGet(this, _selectionStartTimestamp) !== currentStart || __privateGet(this, _selectionEndTimestamp) !== currentEnd) {
        this.refreshFrame(true);
      }
    }
  };
  _DEFAULT_LOCALE = new WeakMap();
  _cursorBlockIndex = new WeakMap();
  _cursorBlockStartIndex = new WeakMap();
  _cursorBlockEndIndex = new WeakMap();
  _cursorStartIndex = new WeakMap();
  _cursorEndIndex = new WeakMap();
  _cursorIndex = new WeakMap();
  _cursorOffset = new WeakMap();
  _cursorTimestamp = new WeakMap();
  _dynamicBlockHeight = new WeakMap();
  _effect = new WeakMap();
  _firstWeekDay = new WeakMap();
  _frameBlocksCached = new WeakMap();
  _locale2 = new WeakMap();
  _maxFrameSize = new WeakMap();
  _selectionStartTimestamp = new WeakMap();
  _selectionEndTimestamp = new WeakMap();
  _size = new WeakMap();
  __timeslice = new WeakMap();
  _timeslice = new WeakMap();
  _timezone = new WeakMap();
  _today = new WeakMap();
  _unwatchCurrentDay = new WeakMap();
  _fromTimestamp = new WeakMap();
  _toTimestamp = new WeakMap();
  _fromBlockOffsetFromOrigin = new WeakMap();
  _toBlockOffsetFromOrigin = new WeakMap();
  _numberOfBlocks = new WeakMap();
  _numberOfUnits = new WeakMap();
  _daysOfWeek = new WeakMap();
  _frameBlocks = new WeakMap();
  _TimeFrame_instances = new WeakSet();
  applyTimeSliceUpdate_fn = function() {
    const { from: from2, to: to2, span, offsets } = __privateGet(this, _timeslice);
    __privateSet(this, _fromTimestamp, from2 - offsets.from);
    __privateSet(this, _toTimestamp, to2 - offsets.to);
    __privateSet(this, _numberOfBlocks, span);
    const selectionStartTimestamp = isUndefined(__privateGet(this, _selectionStartTimestamp)) ? __privateGet(this, _selectionStartTimestamp) : Math.max(__privateGet(this, _selectionStartTimestamp), from2);
    const selectionEndTimestamp = isUndefined(__privateGet(this, _selectionEndTimestamp)) ? __privateGet(this, _selectionEndTimestamp) : Math.min(__privateGet(this, _selectionEndTimestamp), to2);
    if (selectionStartTimestamp === __privateGet(this, _selectionStartTimestamp) || selectionEndTimestamp === __privateGet(this, _selectionEndTimestamp)) {
      __privateSet(this, _selectionStartTimestamp, selectionStartTimestamp);
      __privateSet(this, _selectionEndTimestamp, selectionEndTimestamp);
    } else __privateSet(this, _selectionStartTimestamp, __privateSet(this, _selectionEndTimestamp, void 0));
    this.reslice();
    __privateSet(this, _maxFrameSize, downsizeTimeFrame(12, this.numberOfBlocks));
    __privateSet(this, _size, downsizeTimeFrame(__privateGet(this, _size), this.numberOfBlocks));
    this.shiftFrameToTimestamp(__privateGet(this, _cursorTimestamp));
  };
  getClampedFrameOffset_fn = function(frameOffset) {
    return clamp(__privateGet(this, _fromBlockOffsetFromOrigin), frameOffset || 0, __privateGet(this, _toBlockOffsetFromOrigin) - __privateGet(this, _size) + 1);
  };
  getContainedTimestamp_fn = function(time, withMidRangeFallback = true) {
    let timestamp = new Date(time).getTime();
    if (isNaN(timestamp)) return __privateMethod(this, _TimeFrame_instances, getContainedTimestamp_fn).call(this, Date.now());
    const { from: from2, to: to2 } = __privateGet(this, _timeslice);
    const clampedTimestamp = clamp(from2, timestamp, to2);
    if (clampedTimestamp !== timestamp && withMidRangeFallback) {
      timestamp = mid(from2, to2);
      if (isNaN(timestamp) || isInfinity(timestamp)) {
        timestamp = clampedTimestamp;
      }
    } else timestamp = clampedTimestamp;
    const offset = computeTimestampOffset(timestamp, __privateGet(this, _timezone));
    return [timestamp - offset, offset];
  };
  getFrameBlockAtIndex_fn = function(index) {
    if (!(isBitSafeInteger(index) && index >= 0 && index < __privateGet(this, _size))) return;
    if (!__privateGet(this, _frameBlocksCached)[index]) {
      const block = this.getFrameBlockAtIndex(index);
      if (!block) return void 0;
      const [label, datetime] = this.getFormattedDataForFrameBlock(block[block.inner.from][0] + DAY_MS / 2);
      const blockStartIndex = block.outer.from;
      __privateGet(this, _frameBlocksCached)[index] = createIndexed(
        {
          datetime: enumerable(datetime),
          label: enumerable(label),
          length: enumerable(Math.ceil(block.outer.units / this.rowspan)),
          month: enumerable(block.month),
          year: enumerable(block.year)
        },
        (index2) => {
          const indexOffset = index2 * this.rowspan;
          return createIndexed(this.rowspan, (index3) => {
            const [timestamp, flags] = block[index3 + indexOffset];
            const [label2, datetime2] = this.getFormattedDataForBlockCell(timestamp + DAY_MS / 2);
            return struct({
              datetime: enumerable(datetime2),
              flags: enumerable(createFlagsRecord(flags)),
              index: enumerable(blockStartIndex + index3 + indexOffset),
              label: enumerable(label2),
              timestamp: enumerable(timestamp)
            });
          });
        }
      );
    }
    return __privateGet(this, _frameBlocksCached)[index];
  };
  shiftFrameCursorByOffset_fn = function(offset) {
    if (offset === 0) return;
    __privateSet(this, _cursorOffset, __privateGet(this, _cursorOffset) + offset);
    this.refreshFrame();
  };
  shiftOrigin_fn = function(offset) {
    const clampedOffset = __privateMethod(this, _TimeFrame_instances, getClampedFrameOffset_fn).call(this, offset);
    if (clampedOffset) {
      this.shiftOrigin(clampedOffset);
      __privateSet(this, _fromBlockOffsetFromOrigin, __privateGet(this, _fromBlockOffsetFromOrigin) - clampedOffset);
      __privateSet(this, _toBlockOffsetFromOrigin, __privateGet(this, _toBlockOffsetFromOrigin) - clampedOffset);
      __privateSet(this, _cursorBlockIndex, mod(__privateGet(this, _cursorBlockIndex) - clampedOffset, __privateGet(this, _size)));
      this.refreshFrame();
    }
  };
  shiftOriginIfNecessary_fn = function() {
    const size_1 = __privateGet(this, _size) - 1;
    const offset = Math.min(size_1 - this.origin % __privateGet(this, _size), __privateGet(this, _toBlockOffsetFromOrigin)) - size_1;
    if (offset) __privateMethod(this, _TimeFrame_instances, shiftOrigin_fn).call(this, offset);
  };
  __privateAdd(_TimeFrame, _DEFAULT_LOCALE, BASE_LOCALE);
  let TimeFrame = _TimeFrame;
  class MonthFrame extends TimeFrame {
    constructor() {
      super();
      __privateAdd(this, _MonthFrame_instances);
      __privateAdd(this, _daysInWeek, 7);
      __privateAdd(this, _daysOfWeekCached, []);
      __privateAdd(this, _daysOfWeekend, getWeekendDays(this.firstWeekDay));
      __privateAdd(this, _currentDayTimestamp);
      __privateAdd(this, _fromTimestamp2, -Infinity);
      __privateAdd(this, _toTimestamp2, Infinity);
      __privateAdd(this, _numberOfBlocks2, Infinity);
      __privateAdd(this, _originMonthStartOffset);
      __privateAdd(this, _originMonthStartTimestamp);
      __privateAdd(this, _originYear);
      __privateAdd(this, _selectionFromTimestamp);
      __privateAdd(this, _selectionToTimestamp);
      __publicField(this, "daysInWeek", __privateGet(this, _daysInWeek));
      this.initialize();
    }
    get fromTimestamp() {
      return __privateGet(this, _fromTimestamp2);
    }
    get toTimestamp() {
      return __privateGet(this, _toTimestamp2);
    }
    get numberOfBlocks() {
      return __privateGet(this, _numberOfBlocks2);
    }
    get currentDayTimestamp() {
      return __privateGet(this, _currentDayTimestamp);
    }
    get dynamicBlockHeight() {
      return super.dynamicBlockHeight;
    }
    set dynamicBlockHeight(bool) {
      const current = this.dynamicBlockHeight;
      super.dynamicBlockHeight = bool;
      if (this.dynamicBlockHeight !== current) this.refreshFrame(true);
    }
    get rowspan() {
      return __privateGet(this, _daysInWeek);
    }
    get firstWeekDay() {
      return super.firstWeekDay;
    }
    set firstWeekDay(day) {
      const current = this.firstWeekDay;
      super.firstWeekDay = day;
      if (this.firstWeekDay === current) return;
      __privateGet(this, _daysOfWeekCached).length = 0;
      __privateSet(this, _daysOfWeekend, getWeekendDays(this.firstWeekDay));
      this.reoriginate();
      this.refreshFrame();
    }
    getCursorBlockOriginTimestampOffset(timestamp) {
      return getTimezoneDateParts(timestamp, this.timezone)[2] - 1;
    }
    getDayOfWeekAtIndex(index) {
      if (!__privateGet(this, _daysOfWeekCached)[index]) {
        const date2 = new Date(this.getTimestampAtIndex(index));
        let flags = 0;
        if (__privateGet(this, _daysOfWeekend).includes(index)) flags |= TimeFlag.WEEKEND;
        if (index === 0) flags |= TimeFlag.LINE_START;
        else if (index === 6) flags |= TimeFlag.LINE_END;
        const labelDescriptors = {};
        for (const format of DAY_OF_WEEK_FORMATS) {
          labelDescriptors[format] = enumerable(
            date2.toLocaleDateString(this.locale, { weekday: format, timeZone: this.timezone })
          );
        }
        __privateGet(this, _daysOfWeekCached)[index] = struct({
          flags: enumerable(createFlagsRecord(flags)),
          labels: enumerable(struct(labelDescriptors))
        });
      }
      return __privateGet(this, _daysOfWeekCached)[index];
    }
    getEdgeBlockOffsetsFromOrigin() {
      return [__privateMethod(this, _MonthFrame_instances, getBlockTimestampOffsetFromOrigin_fn).call(this, __privateGet(this, _fromTimestamp2)), __privateMethod(this, _MonthFrame_instances, getBlockTimestampOffsetFromOrigin_fn).call(this, __privateGet(this, _toTimestamp2))];
    }
    getFormattedDataForBlockCell(time) {
      const [year, month, date2] = getTimezoneDateParts(time, this.timezone);
      return [Number(date2).toLocaleString(this.locale), `${year}-${`${month + 1}`.padStart(2, "0")}-${`${date2}`.padStart(2, "0")}`];
    }
    getFormattedDataForFrameBlock(time) {
      const [year, month] = getTimezoneDateParts(time, this.timezone);
      return [
        new Date(time).toLocaleDateString(this.locale, { month: "long", year: "numeric", timeZone: this.timezone }),
        `${year}-${`${month + 1}`.padStart(2, "0")}`
      ];
    }
    getFrameBlockAtIndex(index) {
      const [monthDays, month, year] = getMonthDays(this.origin, __privateGet(this, _originYear), index);
      const innerStartIndex = index > 0 ? this.getFrameBlockAtIndex(index - 1).inner.to + 1 : __privateGet(this, _originMonthStartOffset);
      const innerEndIndex = innerStartIndex + monthDays - 1;
      const outerStartIndex = Math.floor(innerStartIndex / 7) * 7;
      const outerEndAfterIndex = this.dynamicBlockHeight ? Math.ceil((innerEndIndex + 1) / 7) * 7 : outerStartIndex + MAXIMUM_MONTH_UNITS;
      const numberOfUnits = this.dynamicBlockHeight ? outerEndAfterIndex - outerStartIndex : MAXIMUM_MONTH_UNITS;
      const proxyForIndexPropertyAccess = new Proxy(
        struct(),
        withFreezeProxyHandlers({
          get: (target, property2, receiver) => {
            if (isString$1(property2)) {
              const offset = +property2;
              if (isBitSafeInteger(offset) && offset >= 0 && offset < numberOfUnits) {
                const index2 = outerStartIndex + offset;
                const timestamp = this.getTimestampAtIndex(index2);
                const weekDay = index2 % __privateGet(this, _daysInWeek);
                let flags = timestamp === this.currentDayTimestamp ? TimeFlag.CURRENT : 0;
                if (index2 === this.cursor) flags |= TimeFlag.CURSOR;
                if (__privateGet(this, _daysOfWeekend).includes(weekDay)) flags |= TimeFlag.WEEKEND;
                if (weekDay === 0) flags |= TimeFlag.LINE_START;
                else if (weekDay === __privateGet(this, _daysInWeek) - 1) flags |= TimeFlag.LINE_END;
                if (index2 >= innerStartIndex && index2 <= innerEndIndex) {
                  if (index2 === innerStartIndex) flags |= TimeFlag.BLOCK_START;
                  else if (index2 === innerEndIndex) flags |= TimeFlag.BLOCK_END;
                  flags |= TimeFlag.WITHIN_BLOCK;
                }
                if (timestamp >= this.fromTimestamp && timestamp <= this.toTimestamp) {
                  if (timestamp === this.fromTimestamp) flags |= TimeFlag.RANGE_START;
                  if (timestamp === this.toTimestamp) flags |= TimeFlag.RANGE_END;
                  flags |= TimeFlag.WITHIN_RANGE;
                }
                if (timestamp >= __privateGet(this, _selectionFromTimestamp) && timestamp <= __privateGet(this, _selectionToTimestamp)) {
                  if (timestamp === __privateGet(this, _selectionFromTimestamp)) flags |= TimeFlag.SELECTION_START;
                  if (timestamp === __privateGet(this, _selectionToTimestamp)) flags |= TimeFlag.SELECTION_END;
                  flags |= TimeFlag.WITHIN_SELECTION;
                }
                return [timestamp, flags];
              }
            }
            return Reflect.get(target, property2, receiver);
          }
        })
      );
      return structFrom(proxyForIndexPropertyAccess, {
        inner: {
          value: struct({
            from: { value: innerStartIndex },
            to: { value: innerEndIndex },
            units: { value: monthDays }
          })
        },
        month: { value: month },
        outer: {
          value: struct({
            from: { value: outerStartIndex },
            to: { value: outerEndAfterIndex - 1 },
            units: { value: numberOfUnits }
          })
        },
        year: { value: year }
      });
    }
    getUnitsForFrameBlockAtIndex(index) {
      return getMonthDays(this.origin, __privateGet(this, _originYear), index)[0];
    }
    getUnitsOffsetForTimestamp(startTimestamp, timestamp) {
      return Math.round((timestamp - startTimestamp) / DAY_MS);
    }
    reoriginate() {
      this.originTimestamp = startOfMonth(this.originTimestamp, this.timezone);
      const [originYear, originMonth] = getTimezoneDateParts(this.originTimestamp, this.timezone);
      const weekStartTimestamp = startOfWeek(this.originTimestamp, this.timezone, this.firstWeekDay);
      this.origin = originMonth;
      __privateSet(this, _originYear, originYear);
      __privateSet(this, _originMonthStartOffset, this.getUnitsOffsetForTimestamp(weekStartTimestamp, this.originTimestamp));
      __privateSet(this, _originMonthStartTimestamp, __privateMethod(this, _MonthFrame_instances, getDayOffsetTimestamp_fn).call(this, this.originTimestamp, -__privateGet(this, _originMonthStartOffset)));
    }
    reslice() {
      __privateMethod(this, _MonthFrame_instances, updateSelectionTimestamps_fn).call(this);
      __privateSet(this, _fromTimestamp2, __privateMethod(this, _MonthFrame_instances, getStartForTimestamp_fn).call(this, super.fromTimestamp));
      __privateSet(this, _toTimestamp2, __privateMethod(this, _MonthFrame_instances, getStartForTimestamp_fn).call(this, super.toTimestamp));
      __privateSet(this, _numberOfBlocks2, getEdgesDistance(super.fromTimestamp, super.toTimestamp, this.timezone) + 1);
    }
    shiftOrigin(offset) {
      const [year, month] = getTimezoneDateParts(this.originTimestamp, this.timezone);
      const [, offsetMonth2, offsetYear] = getMonthDays(month, year, offset);
      const restamper2 = withTimezone(this.timezone);
      const originTimestamp = new Date(timezoneToSystem(restamper2, this.originTimestamp)).setFullYear(offsetYear, offsetMonth2);
      this.originTimestamp = systemToTimezone(restamper2, originTimestamp);
      this.reoriginate();
    }
    clearSelection() {
      super.clearSelection();
      __privateMethod(this, _MonthFrame_instances, updateSelectionTimestamps_fn).call(this);
      this.refreshFrame(true);
    }
    getTimestampAtIndex(indexOffset) {
      return __privateMethod(this, _MonthFrame_instances, getDayOffsetTimestamp_fn).call(this, __privateGet(this, _originMonthStartTimestamp), indexOffset);
    }
    updateSelection(time, selection) {
      super.updateSelection(time, selection);
      __privateMethod(this, _MonthFrame_instances, updateSelectionTimestamps_fn).call(this);
      this.refreshFrame(true);
    }
    withCurrentDayTimestamp() {
      __privateSet(this, _currentDayTimestamp, __privateMethod(this, _MonthFrame_instances, getStartForTimestamp_fn).call(this, Date.now()));
    }
  }
  _daysInWeek = new WeakMap();
  _daysOfWeekCached = new WeakMap();
  _daysOfWeekend = new WeakMap();
  _currentDayTimestamp = new WeakMap();
  _fromTimestamp2 = new WeakMap();
  _toTimestamp2 = new WeakMap();
  _numberOfBlocks2 = new WeakMap();
  _originMonthStartOffset = new WeakMap();
  _originMonthStartTimestamp = new WeakMap();
  _originYear = new WeakMap();
  _selectionFromTimestamp = new WeakMap();
  _selectionToTimestamp = new WeakMap();
  _MonthFrame_instances = new WeakSet();
  getBlockTimestampOffsetFromOrigin_fn = function(timestamp) {
    const offset = getEdgesDistance(timestamp, this.originTimestamp, this.timezone);
    return timestamp < this.originTimestamp ? 0 - offset : offset;
  };
  getDayOffsetTimestamp_fn = function(fromTimestamp, dayOffset = 0) {
    const restamper2 = withTimezone(this.timezone);
    const restampedTimestamp = timezoneToSystem(restamper2, fromTimestamp);
    const timestamp = systemToTimezone(restamper2, restampedTimestamp + dayOffset * DAY_MS);
    let [, , , hrs, mins] = getTimezoneDateParts(timestamp, this.timezone);
    let timeOffset = 0;
    if (hrs > 0 || mins > 0) {
      hrs = (hrs > 12 ? 24 : 0) - hrs;
      mins = (hrs > 1 ? 1 : -1) * mins;
      timeOffset = hrs * 36e5 + mins * 6e4;
    }
    return timestamp + timeOffset;
  };
  getStartForTimestamp_fn = function(timestamp) {
    return isUndefined(timestamp) || isInfinity(timestamp) ? timestamp : timestamp - computeTimestampOffset(timestamp, this.timezone);
  };
  updateSelectionTimestamps_fn = function() {
    __privateSet(this, _selectionFromTimestamp, __privateMethod(this, _MonthFrame_instances, getStartForTimestamp_fn).call(this, this.selectionStart));
    __privateSet(this, _selectionToTimestamp, __privateMethod(this, _MonthFrame_instances, getStartForTimestamp_fn).call(this, this.selectionEnd));
  };
  const _NO_EXCEPTION = Symbol("<<NO_EXCEPTION>>");
  const createEffectStack = (effect) => {
    const _stack = [];
    const _bindFn = (fn2) => function(...args) {
      let exception = _NO_EXCEPTION;
      try {
        _stack.push(fn2);
        return fn2.call(this, ...args);
      } catch (ex) {
        throw exception = ex;
      } finally {
        _stack.pop();
        if (_stack.length === 0 && exception === _NO_EXCEPTION) effect();
      }
    };
    return struct({
      bind: enumerable(_bindFn),
      effect: enumerable(effect)
    });
  };
  let Calendar$2 = (_d = class {
    constructor() {
      __privateAdd(this, _Calendar_instances);
      __publicField(this, "grid");
      __publicField(this, "kill");
      __privateAdd(this, _config, EMPTY_OBJECT);
      __privateAdd(this, _destructed, false);
      __privateAdd(this, _frame);
      __privateAdd(this, _highlightFrom);
      __privateAdd(this, _highlightTo);
      __privateAdd(this, _highlightInProgress, false);
      __privateAdd(this, _highlightSelection, SELECT_NONE);
      __privateAdd(this, _pendingWatchNotification, false);
      __privateAdd(this, _rangeOffsets);
      __privateAdd(this, _lastHighlightRange, (_b = __privateGet(this, _rangeOffsets)) == null ? void 0 : _b.join(" "));
      __privateAdd(this, _cursorIndexFromEvent);
      __privateAdd(this, _shiftFactorFromEvent);
      __privateAdd(this, _watchCallback);
      __privateAdd(this, _watchableEffect);
      __privateAdd(this, _unwatch);
      __privateAdd(this, _today2, today());
      __privateAdd(this, _shiftControlsHandles, []);
      __privateAdd(this, _shiftControlsList);
      __privateAdd(this, _shiftControls, new Proxy(
        createIndexed(() => {
          var _a2;
          return ((_a2 = __privateGet(this, _shiftControlsList)) == null ? void 0 : _a2.length) ?? 0;
        }, __privateMethod(this, _Calendar_instances, getShiftControlRecordAtIndex_fn).bind(this)),
        withFreezeProxyHandlers({
          get: (target, property2, receiver) => {
            var _a2, _b2;
            const index = ((_a2 = __privateGet(this, _shiftControlsList)) == null ? void 0 : _a2.indexOf(property2)) ?? -1;
            return index >= 0 ? (_b2 = __privateMethod(this, _Calendar_instances, getShiftControlRecordAtIndex_fn).call(this, index)) == null ? void 0 : _b2[1] : Reflect.get(target, property2, receiver);
          }
        })
      ));
      __privateAdd(this, _watchlist, createWatchlist({
        blocks: () => {
          var _a2;
          return (_a2 = __privateGet(this, _frame)) == null ? void 0 : _a2.size;
        },
        cells: () => {
          var _a2;
          return (_a2 = __privateGet(this, _frame)) == null ? void 0 : _a2.units;
        },
        controls: () => pickFrom(CALENDAR_CONTROLS, __privateGet(this, _config).controls),
        cursor: () => {
          var _a2;
          return (_a2 = __privateGet(this, _frame)) == null ? void 0 : _a2.cursor;
        },
        from: () => {
          var _a2;
          return (_a2 = __privateGet(this, _frame)) == null ? void 0 : _a2.selectionStart;
        },
        highlight: () => __privateGet(this, _highlightSelection),
        locale: () => {
          var _a2;
          return (_a2 = __privateGet(this, _frame)) == null ? void 0 : _a2.locale;
        },
        minified: () => boolify(__privateGet(this, _config).minified),
        origin: () => {
          var _a2;
          return (_a2 = __privateGet(this, _frame)) == null ? void 0 : _a2.getTimestampAtIndex(0);
        },
        timezone: () => {
          var _a2;
          return (_a2 = __privateGet(this, _frame)) == null ? void 0 : _a2.timezone;
        },
        to: () => {
          var _a2;
          return (_a2 = __privateGet(this, _frame)) == null ? void 0 : _a2.selectionEnd;
        },
        today: () => __privateGet(this, _today2).timestamp
      }));
      __privateAdd(this, _lastWatchableSnapshot, (_c = __privateGet(this, _watchlist)) == null ? void 0 : _c.snapshot);
      __privateAdd(this, _chainedNotifyEffectStack, createEffectStack(() => {
        var _a2;
        return __privateGet(this, _watchCallback) && ((_a2 = __privateGet(this, _watchlist)) == null ? void 0 : _a2.requestNotification());
      }));
      __privateAdd(this, _chainedWatchEffectStack, createEffectStack(() => {
        var _a2;
        return (_a2 = __privateGet(this, _watchCallback)) == null ? void 0 : _a2.call(__privateGet(this, _Calendar_instances, currentConfig_get));
      }));
      __privateAdd(this, _grid, structFrom(
        createIndexed(
          () => {
            var _a2;
            return ((_a2 = __privateGet(this, _frame)) == null ? void 0 : _a2.size) ?? 0;
          },
          (index) => {
            var _a2;
            return (_a2 = __privateGet(this, _frame)) == null ? void 0 : _a2.frameBlocks[index];
          }
        ),
        {
          config: {
            value: Object.defineProperties(
              (config) => {
                config && __privateMethod(this, _Calendar_instances, configure_fn).call(this, config);
                return __privateGet(this, _Calendar_instances, currentConfig_get);
              },
              {
                cursorIndex: {
                  get: () => __privateGet(this, _cursorIndexFromEvent),
                  set: (fn2) => {
                    if (__privateGet(this, _destructed)) return;
                    if (isNullish(fn2)) __privateSet(this, _cursorIndexFromEvent, void 0);
                    else if (isFunction(fn2)) __privateSet(this, _cursorIndexFromEvent, fn2);
                  }
                },
                shiftFactor: {
                  get: () => __privateGet(this, _shiftFactorFromEvent),
                  set: (fn2) => {
                    if (__privateGet(this, _destructed)) return;
                    if (isNullish(fn2)) __privateSet(this, _shiftFactorFromEvent, void 0);
                    else if (isFunction(fn2)) __privateSet(this, _shiftFactorFromEvent, fn2);
                  }
                },
                watch: {
                  get: () => __privateGet(this, _watchCallback),
                  set: (fn2) => {
                    var _a2, _b2, _c2, _d2, _e;
                    if (__privateGet(this, _destructed)) return;
                    if (isFunction(fn2)) {
                      __privateSet(this, _watchCallback, fn2);
                      if (!__privateGet(this, _watchableEffect)) {
                        const watchCallback = (_a2 = __privateGet(this, _chainedNotifyEffectStack)) == null ? void 0 : _a2.bind(__privateGet(_d, _watchableEffectCallback).bind(this));
                        if (watchCallback) {
                          __privateSet(this, _watchableEffect, (_b2 = __privateGet(this, _chainedNotifyEffectStack)) == null ? void 0 : _b2.bind(noop));
                          __privateSet(this, _unwatch, (_d2 = __privateGet(this, _watchlist)) == null ? void 0 : _d2.subscribe((_c2 = __privateGet(this, _chainedWatchEffectStack)) == null ? void 0 : _c2.bind(watchCallback)));
                          __privateGet(this, _frame) && (__privateGet(this, _frame).effect = __privateGet(this, _watchableEffect));
                        }
                      }
                      if (!__privateGet(this, _pendingWatchNotification)) return;
                      __privateSet(this, _pendingWatchNotification, false);
                      (_e = __privateGet(this, _watchableEffect)) == null ? void 0 : _e.call(this);
                    } else if (isNullish(fn2)) __privateSet(this, _watchCallback, void 0);
                  }
                }
              }
            )
          },
          controls: { value: __privateGet(this, _shiftControls) },
          cursor: {
            value: Object.defineProperties(
              (evt) => __privateMethod(_d, _Calendar_static, withNotifyEffect_fn).call(this, (evt2) => !!(evt2 && __privateMethod(this, _Calendar_instances, cursorHandle_fn).call(this, evt2)))(evt),
              {
                valueOf: { value: () => {
                  var _a2;
                  return ((_a2 = __privateGet(this, _frame)) == null ? void 0 : _a2.cursor) ?? -1;
                } }
              }
            )
          },
          highlight: {
            value: (() => {
              const blank = () => __privateGet(this, _highlightFrom) === __privateGet(this, _highlightTo) && isUndefined(__privateGet(this, _highlightTo));
              const setter = (selection) => (time) => __privateMethod(_d, _Calendar_static, withNotifyEffect_fn).call(this, (time2) => {
                var _a2, _b2, _c2, _d2, _e;
                if (__privateGet(this, _destructed) || !__privateGet(this, _highlightSelection) || __privateGet(this, _highlightSelection) === SELECT_NONE) return;
                if (isNullish(time2)) return __privateMethod(this, _Calendar_instances, clearHighlight_fn).call(this);
                if (!blank()) {
                  (_a2 = __privateGet(this, _frame)) == null ? void 0 : _a2.updateSelection(time2, selection);
                  if (__privateGet(this, _highlightSelection) === SELECT_MANY && __privateGet(this, _rangeOffsets)) {
                    __privateMethod(this, _Calendar_instances, rangeHighlight_fn).call(this, time2, selection === SELECTION_FROM ? SELECTION_TO : SELECTION_FROM, __privateGet(this, _rangeOffsets));
                  }
                } else (_b2 = __privateGet(this, _frame)) == null ? void 0 : _b2.updateSelection(time2, SELECTION_COLLAPSE);
                __privateSet(this, _highlightFrom, (_c2 = __privateGet(this, _frame)) == null ? void 0 : _c2.selectionStart);
                __privateSet(this, _highlightTo, (_d2 = __privateGet(this, _frame)) == null ? void 0 : _d2.selectionEnd);
                (_e = __privateGet(this, _frame)) == null ? void 0 : _e.shiftFrameToTimestamp(selection === SELECTION_FROM ? __privateGet(this, _highlightFrom) : __privateGet(this, _highlightTo));
              })(time);
              return struct({
                blank: { get: blank },
                from: {
                  get: () => {
                    var _a2;
                    return ((_a2 = __privateGet(this, _frame)) == null ? void 0 : _a2.selectionStart) ?? __privateGet(this, _highlightFrom);
                  },
                  set: setter(SELECTION_FROM)
                },
                to: {
                  get: () => {
                    var _a2;
                    return ((_a2 = __privateGet(this, _frame)) == null ? void 0 : _a2.selectionEnd) ?? __privateGet(this, _highlightTo);
                  },
                  set: setter(SELECTION_TO)
                }
              });
            })()
          },
          rowspan: { get: () => {
            var _a2;
            return ((_a2 = __privateGet(this, _frame)) == null ? void 0 : _a2.rowspan) ?? 0;
          } },
          weekdays: { get: () => {
            var _a2;
            return ((_a2 = __privateGet(this, _frame)) == null ? void 0 : _a2.daysOfWeek) ?? __privateGet(_d, _DAYS_OF_WEEK_FALLBACK);
          } }
        }
      ));
      this.grid = __privateGet(this, _grid);
      this.kill = __privateMethod(this, _Calendar_instances, destruct_fn).bind(this);
    }
  }, _config = new WeakMap(), _destructed = new WeakMap(), _frame = new WeakMap(), _highlightFrom = new WeakMap(), _highlightTo = new WeakMap(), _highlightInProgress = new WeakMap(), _highlightSelection = new WeakMap(), _pendingWatchNotification = new WeakMap(), _rangeOffsets = new WeakMap(), _lastHighlightRange = new WeakMap(), _cursorIndexFromEvent = new WeakMap(), _shiftFactorFromEvent = new WeakMap(), _watchCallback = new WeakMap(), _watchableEffect = new WeakMap(), _unwatch = new WeakMap(), _today2 = new WeakMap(), _shiftControlsHandles = new WeakMap(), _shiftControlsList = new WeakMap(), _shiftControls = new WeakMap(), _watchlist = new WeakMap(), _lastWatchableSnapshot = new WeakMap(), _chainedNotifyEffectStack = new WeakMap(), _chainedWatchEffectStack = new WeakMap(), _grid = new WeakMap(), _RANGE_OFFSETS_FORMAT_REGEX = new WeakMap(), _CURSOR_POINTER_INTERACTION_EVENTS = new WeakMap(), _DAYS_OF_WEEK_FALLBACK = new WeakMap(), _SHIFT_ACTIVATION_KEYS = new WeakMap(), _SHIFT_ALL_CONTROLS = new WeakMap(), _SHIFT_MINIMAL_CONTROLS = new WeakMap(), _Calendar_static = new WeakSet(), getOffsetsFromRange_fn = function(range) {
    if (!isString$1(range)) return;
    if (!__privateGet(_d, _RANGE_OFFSETS_FORMAT_REGEX).test(range)) return;
    const offsets = range.split(/\s+/);
    return Array.from({ length: 6 }, (_2, index) => parseInt(offsets[index] ?? "0"));
  }, getShiftOffsetType_fn = function(flags) {
    switch (flags & ~CalendarShiftControlFlag.PREV) {
      case CalendarShiftControlFlag.FRAME:
        return SHIFT_FRAME;
      case CalendarShiftControlFlag.PERIOD:
        return SHIFT_PERIOD;
      case CalendarShiftControlFlag.BLOCK:
      default:
        return SHIFT_BLOCK;
    }
  }, getShiftOffsetUnit_fn = function(flags) {
    return flags & CalendarShiftControlFlag.PREV ? -1 : 1;
  }, _watchableEffectCallback = new WeakMap(), withNotifyEffect_fn = function(fn2) {
    var _a2;
    return ((_a2 = __privateGet(this, _chainedNotifyEffectStack)) == null ? void 0 : _a2.bind(fn2)) ?? fn2;
  }, _Calendar_instances = new WeakSet(), currentConfig_get = function() {
    return { ...__privateGet(this, _config) };
  }, timeframe_get = function() {
    return new MonthFrame();
  }, canShiftInDirection_fn = function(shiftDirection) {
    return !!__privateGet(this, _frame) && !(shiftDirection > 0 ? __privateGet(this, _frame).isAtEnd : __privateGet(this, _frame).isAtStart);
  }, configure_fn = function(config) {
    var _a2, _b2;
    if (__privateGet(this, _destructed)) return;
    __privateSet(this, _rangeOffsets, void 0);
    const highlight = config == null ? void 0 : config.highlight;
    const minified = boolify(__privateGet(this, _config).minified);
    if (!isString$1(highlight)) {
      __privateSet(this, _highlightSelection, pickFrom(CALENDAR_SELECTIONS, highlight, __privateGet(this, _highlightSelection)));
    } else if (__privateSet(this, _rangeOffsets, __privateMethod(_a2 = _d, _Calendar_static, getOffsetsFromRange_fn).call(_a2, highlight))) {
      __privateSet(this, _highlightSelection, SELECT_MANY);
    }
    __privateSet(this, _config, {
      ...__privateGet(this, _config),
      ...config,
      blocks: pickFrom(FRAME_SIZES, config == null ? void 0 : config.blocks, __privateGet(this, _config).blocks),
      controls: pickFrom(CALENDAR_CONTROLS, config == null ? void 0 : config.controls, __privateGet(this, _config).controls),
      firstWeekDay: pickFrom(FIRST_WEEK_DAYS, config == null ? void 0 : config.firstWeekDay, __privateGet(this, _config).firstWeekDay),
      fixedBlockHeight: boolify(config == null ? void 0 : config.fixedBlockHeight, __privateGet(this, _config).fixedBlockHeight),
      highlight: __privateGet(this, _highlightSelection),
      minified: boolify(config == null ? void 0 : config.minified, __privateGet(this, _config).minified),
      trackCurrentDay: boolify(config == null ? void 0 : config.trackCurrentDay, __privateGet(this, _config).trackCurrentDay)
    });
    if (!isFunction(__privateGet(this, _watchCallback))) {
      if (!__privateGet(this, _frame)) {
        __privateSet(this, _frame, __privateGet(this, _Calendar_instances, timeframe_get));
        __privateMethod(this, _Calendar_instances, reframe_fn).call(this);
        __privateMethod(this, _Calendar_instances, refreshShiftControls_fn).call(this);
        __privateMethod(this, _Calendar_instances, refreshHighlighting_fn).call(this);
      } else __privateSet(this, _pendingWatchNotification, true);
      return;
    }
    if (!__privateGet(this, _frame) || minified !== __privateGet(this, _config).minified) {
      __privateSet(this, _frame, __privateGet(this, _Calendar_instances, timeframe_get));
      __privateGet(this, _frame).effect = __privateGet(this, _watchableEffect);
    }
    __privateMethod(this, _Calendar_instances, reframe_fn).call(this);
    (_b2 = __privateGet(this, _watchableEffect)) == null ? void 0 : _b2.call(this);
  }, cursorHandle_fn = function(evt) {
    if (!(evt && __privateGet(this, _frame) && isFunction(__privateGet(this, _watchCallback)))) return;
    if (evt instanceof KeyboardEvent) {
      switch (evt.code) {
        case InteractionKeyCode.ARROW_LEFT:
          __privateGet(this, _frame).shiftFrameCursor(CURSOR_BACKWARD);
          break;
        case InteractionKeyCode.ARROW_RIGHT:
          __privateGet(this, _frame).shiftFrameCursor(CURSOR_FORWARD);
          break;
        case InteractionKeyCode.ARROW_UP:
          __privateGet(this, _frame).shiftFrameCursor(CURSOR_UPWARD);
          break;
        case InteractionKeyCode.ARROW_DOWN:
          __privateGet(this, _frame).shiftFrameCursor(CURSOR_DOWNWARD);
          break;
        case InteractionKeyCode.HOME:
          __privateGet(this, _frame).shiftFrameCursor(evt.ctrlKey ? CURSOR_BLOCK_START : CURSOR_LINE_START);
          break;
        case InteractionKeyCode.END:
          __privateGet(this, _frame).shiftFrameCursor(evt.ctrlKey ? CURSOR_BLOCK_END : CURSOR_LINE_END);
          break;
        case InteractionKeyCode.PAGE_UP:
          evt.shiftKey ? __privateGet(this, _frame).shiftFrameByOffset(-1, SHIFT_PERIOD) : __privateGet(this, _frame).shiftFrameCursor(CURSOR_PREV_BLOCK);
          break;
        case InteractionKeyCode.PAGE_DOWN:
          evt.shiftKey ? __privateGet(this, _frame).shiftFrameByOffset(1, SHIFT_PERIOD) : __privateGet(this, _frame).shiftFrameCursor(CURSOR_NEXT_BLOCK);
          break;
        case InteractionKeyCode.SPACE:
        case InteractionKeyCode.ENTER:
          __privateMethod(this, _Calendar_instances, highlight_fn).call(this);
          return true;
        default:
          return;
      }
      __privateGet(this, _highlightInProgress) && __privateMethod(this, _Calendar_instances, highlight_fn).call(this, EMPTY_OBJECT);
      return true;
    }
    if (evt instanceof MouseEvent && __privateGet(_d, _CURSOR_POINTER_INTERACTION_EVENTS).includes(evt.type) && isFunction(__privateGet(this, _cursorIndexFromEvent))) {
      const cursorIndex = __privateGet(this, _cursorIndexFromEvent).call(__privateGet(this, _Calendar_instances, currentConfig_get), evt);
      if (!isBitSafeInteger(cursorIndex)) return;
      const isClick = evt.type === "click";
      if (!(isClick || __privateGet(this, _highlightInProgress))) return;
      __privateGet(this, _frame).shiftFrameCursor(cursorIndex);
      if (__privateGet(this, _frame).cursor === cursorIndex) {
        isClick ? __privateMethod(this, _Calendar_instances, highlight_fn).call(this) : __privateMethod(this, _Calendar_instances, highlight_fn).call(this, EMPTY_OBJECT);
        return true;
      }
    }
  }, destruct_fn = function() {
    var _a2;
    if (__privateGet(this, _destructed)) return;
    (_a2 = __privateGet(this, _unwatch)) == null ? void 0 : _a2.call(this);
    __privateSet(this, _chainedNotifyEffectStack, __privateSet(this, _chainedWatchEffectStack, __privateSet(this, _cursorIndexFromEvent, __privateSet(this, _frame, __privateSet(this, _highlightSelection, __privateSet(this, _lastHighlightRange, __privateSet(this, _lastWatchableSnapshot, __privateSet(this, _rangeOffsets, __privateSet(this, _shiftFactorFromEvent, __privateSet(this, _unwatch, __privateSet(this, _watchlist, __privateSet(this, _watchableEffect, __privateSet(this, _watchCallback, void 0)))))))))))));
    __privateSet(this, _config, EMPTY_OBJECT);
    __privateSet(this, _highlightInProgress, __privateSet(this, _pendingWatchNotification, false));
    __privateSet(this, _destructed, true);
  }, getShiftControlRecordAtIndex_fn = function(index) {
    var _a2, _b2;
    if (!__privateGet(this, _shiftControlsList) || index < 0 || index >= __privateGet(this, _shiftControlsList).length) return;
    const control = __privateGet(this, _shiftControlsList)[index];
    if (!__privateGet(this, _shiftControlsHandles)[index]) {
      const flags = CalendarShiftControlsFlag[control];
      const shiftOffsetType = __privateMethod(_a2 = _d, _Calendar_static, getShiftOffsetType_fn).call(_a2, flags);
      const shiftOffsetUnit = __privateMethod(_b2 = _d, _Calendar_static, getShiftOffsetUnit_fn).call(_b2, flags);
      __privateGet(this, _shiftControlsHandles)[index] = (...args) => __privateMethod(_d, _Calendar_static, withNotifyEffect_fn).call(this, (...args2) => {
        var _a3;
        const canShift = __privateMethod(this, _Calendar_instances, canShiftInDirection_fn).call(this, shiftOffsetUnit);
        if (!(canShift && args2.length)) return canShift;
        const shiftFactor = __privateMethod(this, _Calendar_instances, getShiftFactorFromEvent_fn).call(this, control, args2[0]);
        if (isUndefined(shiftFactor)) return false;
        (_a3 = __privateGet(this, _frame)) == null ? void 0 : _a3.shiftFrameByOffset(shiftOffsetUnit * shiftFactor, shiftOffsetType);
        return true;
      })(...args);
    }
    return [control, __privateGet(this, _shiftControlsHandles)[index]];
  }, getShiftFactorFromEvent_fn = function(target, evt) {
    if (!(__privateGet(this, _frame) && isFunction(__privateGet(this, _watchCallback)))) return;
    if (evt instanceof MouseEvent) {
      if (evt.type !== "click") return;
    } else if (evt instanceof KeyboardEvent) {
      if (!__privateGet(_d, _SHIFT_ACTIVATION_KEYS).includes(evt.code)) return;
    } else return;
    let shiftFactor = 1;
    if (isFunction(__privateGet(this, _shiftFactorFromEvent))) {
      const factor = Number(__privateGet(this, _shiftFactorFromEvent).call(__privateGet(this, _Calendar_instances, currentConfig_get), evt, target));
      shiftFactor = Number.isInteger(factor) && factor >= 1 ? factor : shiftFactor;
    }
    return shiftFactor;
  }, highlight_fn = function(secretFauxHighlightingHint) {
    if (__privateGet(this, _destructed) || !__privateGet(this, _frame)) return;
    switch (__privateGet(this, _highlightSelection)) {
      case SELECT_MANY:
      case SELECT_ONE:
        break;
      case SELECT_NONE:
      default:
        return;
    }
    const cursor = __privateGet(this, _frame).cursor;
    const fromTimestamp = Math.max(__privateGet(this, _frame).getTimestampAtIndex(cursor), __privateGet(this, _frame).timeslice.from);
    const toTimestamp = Math.min(__privateGet(this, _frame).getTimestampAtIndex(cursor + 1) - 1, __privateGet(this, _frame).timeslice.to);
    const range = __privateGet(this, _rangeOffsets);
    if (__privateGet(this, _highlightSelection) === SELECT_ONE || __privateGet(this, _frame).blankSelection || range) {
      __privateSet(this, _highlightInProgress, !(__privateGet(this, _highlightSelection) === SELECT_ONE || range));
      if (__privateGet(this, _highlightSelection) === SELECT_MANY && range) {
        const selectionDirection = toTimestamp >= __privateGet(this, _frame).selectionEnd ? SELECTION_FROM : SELECTION_TO;
        selectionDirection === SELECTION_FROM ? __privateGet(this, _frame).updateSelection(toTimestamp, SELECTION_TO) : __privateGet(this, _frame).updateSelection(fromTimestamp, SELECTION_FROM);
        __privateMethod(this, _Calendar_instances, rangeHighlight_fn).call(this, selectionDirection === SELECTION_FROM ? __privateGet(this, _frame).selectionEnd : __privateGet(this, _frame).selectionStart, selectionDirection, range);
      } else {
        __privateGet(this, _frame).updateSelection(fromTimestamp, SELECTION_FROM);
        __privateGet(this, _frame).updateSelection(toTimestamp, SELECTION_TO);
      }
    } else {
      const isFauxHighlighting = secretFauxHighlightingHint === EMPTY_OBJECT;
      const restamper2 = withTimezone(__privateGet(this, _frame).timezone);
      if (!isFauxHighlighting) __privateSet(this, _highlightInProgress, false);
      if (fromTimestamp <= __privateGet(this, _frame).selectionStart) {
        const selectionStartDay = new Date(timezoneToSystem(restamper2, __privateGet(this, _frame).selectionStart));
        const selectionStartDayEndTimestamp = Math.min(
          systemToTimezone(restamper2, selectionStartDay.setDate(selectionStartDay.getDate() + 1) - 1),
          __privateGet(this, _frame).timeslice.to
        );
        if (fromTimestamp === __privateGet(this, _frame).selectionStart && toTimestamp <= selectionStartDayEndTimestamp) {
          __privateGet(this, _frame).updateSelection(toTimestamp, SELECTION_TO);
        }
        __privateGet(this, _frame).updateSelection(fromTimestamp, SELECTION_FROM);
      } else {
        const selectionEndDay = new Date(timezoneToSystem(restamper2, __privateGet(this, _frame).selectionEnd));
        const selectionEndDayStartTimestamp = Math.max(
          systemToTimezone(restamper2, selectionEndDay.setHours(0, 0, 0, 0)),
          __privateGet(this, _frame).timeslice.from
        );
        if (fromTimestamp <= __privateGet(this, _frame).selectionEnd && fromTimestamp >= selectionEndDayStartTimestamp) {
          __privateGet(this, _frame).updateSelection(fromTimestamp, SELECTION_FROM);
        }
        __privateGet(this, _frame).updateSelection(toTimestamp, SELECTION_TO);
      }
      if (isFauxHighlighting) return;
    }
    __privateSet(this, _highlightFrom, __privateGet(this, _frame).selectionStart);
    __privateSet(this, _highlightTo, __privateGet(this, _frame).selectionEnd);
  }, clearHighlight_fn = function() {
    var _a2;
    (_a2 = __privateGet(this, _frame)) == null ? void 0 : _a2.clearSelection();
    __privateSet(this, _highlightInProgress, false);
    __privateSet(this, _highlightFrom, __privateSet(this, _highlightTo, void 0));
  }, rangeHighlight_fn = function(time, selectionDirection, rangeOffsets) {
    var _a2;
    if (!__privateGet(this, _frame)) return;
    const restamper2 = withTimezone((_a2 = __privateGet(this, _frame)) == null ? void 0 : _a2.timezone);
    const restampedDate = new Date(timezoneToSystem(restamper2, time));
    const direction = selectionDirection === SELECTION_FROM ? -1 : 1;
    const [years = 0, months = 0, days = 0, hours = 0, minutes = 0, seconds = 0] = rangeOffsets ?? [];
    restampedDate.setFullYear(
      restampedDate.getFullYear() + years * direction,
      restampedDate.getMonth() + months * direction,
      restampedDate.getDate() + days * direction
    );
    restampedDate.setHours(
      restampedDate.getHours() + hours * direction,
      restampedDate.getMinutes() + minutes * direction,
      restampedDate.getSeconds() + seconds * direction
    );
    __privateGet(this, _frame).updateSelection(systemToTimezone(restamper2, restampedDate.getTime() - direction), selectionDirection);
  }, restoreHighlight_fn = function() {
    var _a2, _b2;
    __privateGet(this, _highlightFrom) && ((_a2 = __privateGet(this, _frame)) == null ? void 0 : _a2.updateSelection(__privateGet(this, _highlightFrom), SELECTION_FROM));
    __privateGet(this, _highlightTo) && ((_b2 = __privateGet(this, _frame)) == null ? void 0 : _b2.updateSelection(__privateGet(this, _highlightTo), SELECTION_TO));
    __privateSet(this, _highlightInProgress, false);
  }, reframe_fn = function() {
    if (!__privateGet(this, _frame)) return;
    __privateGet(this, _frame).timeslice = __privateGet(this, _config).timeslice;
    __privateGet(this, _frame).dynamicBlockHeight = !__privateGet(this, _config).fixedBlockHeight;
    __privateGet(this, _frame).firstWeekDay = __privateGet(this, _config).firstWeekDay;
    __privateGet(this, _frame).locale = __privateGet(this, _config).locale;
    __privateGet(this, _frame).size = __privateGet(this, _config).blocks;
    __privateGet(this, _frame).timezone = __privateGet(this, _config).timezone;
    __privateGet(this, _frame).trackCurrentDay = __privateGet(this, _config).trackCurrentDay;
    __privateSet(this, _today2, today(__privateGet(this, _frame).timezone));
    __privateMethod(this, _Calendar_instances, restoreHighlight_fn).call(this);
  }, refreshHighlighting_fn = function() {
    var _a2, _b2, _c2, _d2, _e, _f;
    switch (__privateGet(this, _highlightSelection)) {
      case SELECT_MANY:
        if (!boolOrTrue((_a2 = __privateGet(this, _frame)) == null ? void 0 : _a2.blankSelection) && __privateGet(this, _rangeOffsets)) {
          __privateMethod(this, _Calendar_instances, rangeHighlight_fn).call(this, (_b2 = __privateGet(this, _frame)) == null ? void 0 : _b2.selectionStart, SELECTION_TO, __privateGet(this, _rangeOffsets));
        }
        break;
      case SELECT_ONE:
        if (!boolOrTrue((_c2 = __privateGet(this, _frame)) == null ? void 0 : _c2.blankSelection)) {
          const restamper2 = withTimezone((_d2 = __privateGet(this, _frame)) == null ? void 0 : _d2.timezone);
          const restampedDate = new Date(timezoneToSystem(restamper2, (_e = __privateGet(this, _frame)) == null ? void 0 : _e.selectionStart));
          (_f = __privateGet(this, _frame)) == null ? void 0 : _f.updateSelection(systemToTimezone(restamper2, restampedDate.setHours(23, 59, 59, 999)), SELECTION_TO);
        }
        break;
      case SELECT_NONE:
      default:
        __privateMethod(this, _Calendar_instances, clearHighlight_fn).call(this);
        return;
    }
  }, refreshShiftControls_fn = function() {
    var _a2, _b2;
    switch ((_a2 = __privateGet(this, _watchlist)) == null ? void 0 : _a2.snapshot.controls) {
      case CONTROLS_ALL:
        __privateSet(this, _shiftControlsList, __privateGet(_d, _SHIFT_ALL_CONTROLS));
        break;
      case CONTROLS_MINIMAL:
        __privateSet(this, _shiftControlsList, __privateGet(_d, _SHIFT_MINIMAL_CONTROLS));
        break;
      case CONTROLS_NONE:
      default:
        __privateSet(this, _shiftControlsList, void 0);
    }
    __privateGet(this, _shiftControlsHandles).length = 0;
    __privateGet(this, _shiftControlsHandles).length = ((_b2 = __privateGet(this, _shiftControlsList)) == null ? void 0 : _b2.length) ?? 0;
  }, __privateAdd(_d, _Calendar_static), __privateAdd(_d, _RANGE_OFFSETS_FORMAT_REGEX, /^(?:0|[1-9]\d*)(\s+(?:0|[1-9]\d*)?){0,5}?$/), __privateAdd(_d, _CURSOR_POINTER_INTERACTION_EVENTS, ["click", "mouseover", "pointerover"]), __privateAdd(_d, _DAYS_OF_WEEK_FALLBACK, createIndexed(0, noop)), __privateAdd(_d, _SHIFT_ACTIVATION_KEYS, [InteractionKeyCode.ENTER, InteractionKeyCode.SPACE]), __privateAdd(_d, _SHIFT_ALL_CONTROLS, Object.keys(CalendarShiftControlsFlag).filter((control) => isNaN(+control))), __privateAdd(_d, _SHIFT_MINIMAL_CONTROLS, ["PREV", "NEXT"]), __privateAdd(_d, _watchableEffectCallback, function(snapshot) {
    var _a2, _b2;
    if (isWatchlistUnsubscribeToken(snapshot)) return;
    let controlsChanged = false;
    let highlightChanged = false;
    let selectionChanged = false;
    const highlightRange = (_a2 = __privateGet(this, _rangeOffsets)) == null ? void 0 : _a2.join(" ");
    for (const key of Object.keys(snapshot)) {
      if (snapshot[key] === ((_b2 = __privateGet(this, _lastWatchableSnapshot)) == null ? void 0 : _b2[key])) continue;
      if (key === "controls") controlsChanged = true;
      else if (key === "highlight") highlightChanged = true;
      else if (key === "from" || key === "to") selectionChanged = true;
    }
    if (__privateGet(this, _lastHighlightRange) !== highlightRange) {
      __privateSet(this, _lastHighlightRange, highlightRange);
      highlightChanged = true;
    }
    __privateSet(this, _lastWatchableSnapshot, snapshot);
    if (__privateGet(this, _highlightInProgress) && !selectionChanged) __privateMethod(this, _Calendar_instances, restoreHighlight_fn).call(this);
    if (controlsChanged) __privateMethod(this, _Calendar_instances, refreshShiftControls_fn).call(this);
    if (highlightChanged) __privateMethod(this, _Calendar_instances, refreshHighlighting_fn).call(this);
  }), _d);
  const calendar = (() => {
    const calendar2 = (init) => {
      const { grid, kill } = new Calendar$2();
      if (isNumber(init)) grid.config({ blocks: init });
      else if (isFunction(init))
        ALREADY_RESOLVED_PROMISE.then(() => {
          grid.config.watch = init;
        });
      else grid.config(init);
      return struct({
        grid: enumerable(grid),
        kill: enumerable(kill)
      });
    };
    return Object.defineProperties(calendar2, {
      controls: {
        value: struct({
          ALL: { value: CONTROLS_ALL },
          MINIMAL: { value: CONTROLS_MINIMAL },
          NONE: { value: CONTROLS_NONE }
        })
      },
      highlight: {
        value: struct({
          ONE: { value: SELECT_ONE },
          MANY: { value: SELECT_MANY },
          NONE: { value: SELECT_NONE }
        })
      },
      slice: {
        value: Object.defineProperties(timeslice.bind(null), {
          FROM: { value: RANGE_FROM },
          TO: { value: RANGE_TO },
          UNBOUNDED: { value: UNBOUNDED_SLICE },
          SINCE_NOW: { get: sinceNow },
          UNTIL_NOW: { get: untilNow }
        })
      }
    });
  })();
  const CalendarControls = ({ config, grid: { controls }, renderer }) => {
    if (config.controls === calendar.controls.NONE || !isFunction(renderer)) return null;
    return /* @__PURE__ */ u$1(k$1, { children: controls.map(([control, handle]) => renderer(control, handle)) });
  };
  const CalendarControls$1 = M(CalendarControls);
  const useFocusCursor = (callback) => {
    const finallyCallback = q$1(
      (current, previous) => {
        if (previous instanceof Element) previous.setAttribute("tabindex", "-1");
        if (current instanceof Element) {
          current.setAttribute("tabindex", "0");
          ALREADY_RESOLVED_PROMISE.then(() => current == null ? void 0 : current.focus());
        }
      },
      []
    );
    return useReflex(
      q$1(
        (current, previous) => {
          try {
            callback == null ? void 0 : callback(current, previous);
          } finally {
            finallyCallback(current, previous);
          }
        },
        [callback]
      )
    );
  };
  const useCalendar = ({
    blocks,
    controls,
    dynamicBlockRows,
    firstWeekDay,
    highlight,
    locale,
    onHighlight,
    originDate,
    renderControl,
    sinceDate,
    timezone: timezone2,
    trackCurrentDay,
    untilDate,
    useYearView
  }, ref) => {
    const { i18n } = useCoreContext();
    const [lastMutationTimestamp, setLastMutationTimestamp] = d(performance.now());
    const timeslice2 = T$1(() => calendar.slice(sinceDate, untilDate), [sinceDate, untilDate]);
    const config = A$1(EMPTY_OBJECT);
    const activeControls = T$1(
      () => controls ?? (isFunction(renderControl) ? calendar.controls.MINIMAL : calendar.controls.NONE),
      [controls, renderControl]
    );
    const activeHighlight = T$1(
      () => highlight ?? (isFunction(onHighlight) ? calendar.highlight.ONE : calendar.highlight.NONE),
      [highlight, onHighlight]
    );
    const { grid, kill } = T$1(() => {
      const { grid: grid2, kill: kill2 } = calendar(function() {
        setLastMutationTimestamp(performance.now());
        config.current = this;
        if (highlightStart === grid2.highlight.from && highlightEnd === grid2.highlight.to) return;
        highlightStart = grid2.highlight.from;
        highlightEnd = grid2.highlight.to;
        onHighlight == null ? void 0 : onHighlight(highlightStart, highlightEnd);
      });
      let { from: highlightStart, to: highlightEnd } = grid2.highlight;
      grid2.config.cursorIndex = (evt) => {
        let element = evt.target;
        while (element && element !== evt.currentTarget) {
          const index = Number(element.dataset.cursorPosition);
          if (Number.isFinite(index)) return index;
          element = element.parentNode;
        }
      };
      grid2.config.shiftFactor = function(evt) {
        if (this.controls !== calendar.controls.MINIMAL) return;
        if (evt == null ? void 0 : evt.shiftKey) return 12;
        if (evt == null ? void 0 : evt.altKey) return this.blocks;
        return 1;
      };
      return { grid: grid2, kill: kill2 };
    }, []);
    const cursorRootProps = T$1(() => {
      const pointerHandle = (evt) => {
        grid.cursor(evt);
      };
      return {
        onClickCapture: pointerHandle,
        onMouseOverCapture: pointerHandle,
        onPointerOverCapture: pointerHandle,
        onKeyDownCapture: (evt) => {
          grid.cursor(evt) && evt.preventDefault();
        }
      };
    }, [grid]);
    const cursorElementRef = useFocusCursor(
      q$1(
        (current, previous) => {
          if (previous instanceof Element) previous.removeAttribute("aria-selected");
          if (current instanceof Element) current.setAttribute("aria-selected", "true");
        },
        []
      )
    );
    F$1(
      ref,
      () => {
        const { from: from2, to: to2 } = (grid == null ? void 0 : grid.highlight) || EMPTY_OBJECT;
        return {
          clear: () => {
            (grid == null ? void 0 : grid.highlight) && (grid.highlight.from = void 0);
          },
          get config() {
            return { ...config.current ?? EMPTY_OBJECT };
          },
          get from() {
            return getDateObjectFromTimestamp(from2);
          },
          set from(date2) {
            (grid == null ? void 0 : grid.highlight) && date2 && (grid.highlight.from = date2.getTime());
          },
          get to() {
            return getDateObjectFromTimestamp(to2);
          },
          set to(date2) {
            (grid == null ? void 0 : grid.highlight) && date2 && (grid.highlight.to = date2.getTime());
          }
        };
      },
      [grid, lastMutationTimestamp]
    );
    y(() => {
      grid.config({
        blocks,
        controls: activeControls,
        firstWeekDay,
        fixedBlockHeight: !dynamicBlockRows,
        highlight: activeHighlight,
        locale: locale ?? i18n.locale,
        minified: useYearView,
        timeslice: timeslice2,
        timezone: timezone2,
        trackCurrentDay
      });
    }, [
      activeControls,
      activeHighlight,
      blocks,
      dynamicBlockRows,
      firstWeekDay,
      grid,
      i18n,
      locale,
      timeslice2,
      timezone2,
      trackCurrentDay,
      useYearView
    ]);
    y(() => {
      const origins = [].concat(originDate).slice(0, 2).map(Number).filter(Boolean);
      if (origins[0]) grid.highlight.from = +origins[0];
      if (origins[1]) grid.highlight.to = +origins[1];
      return kill;
    }, []);
    return { cursorElementRef, cursorRootProps, grid };
  };
  const Calendar = D((props, ref) => {
    const calendar2 = useCalendar(props, ref);
    const config = calendar2.grid.config();
    return /* @__PURE__ */ u$1("div", { role: "none", children: [
      /* @__PURE__ */ u$1(CalendarControls$1, { config, grid: calendar2.grid, renderer: props.renderControl }),
      /* @__PURE__ */ u$1(
        CalendarGrid$1,
        {
          ref: calendar2.cursorElementRef,
          config,
          cursorRootProps: calendar2.cursorRootProps,
          grid: calendar2.grid,
          onlyCellsWithin: props.onlyCellsWithin,
          prepare: props.prepare
        }
      )
    ] });
  });
  const Calendar$1 = M(Calendar);
  const useDetachedRender = (callback, targetRef) => {
    const [render, setRender] = d();
    const renderTarget = useReflex(
      T$1(() => {
        const render2 = (targetElement) => (...args) => {
          const jsx = callback(targetElement, ...args);
          return jsx && $(jsx, targetElement);
        };
        setRender(void 0);
        return (targetElement) => setRender(targetElement instanceof Element ? () => render2(targetElement) : void 0);
      }, [callback, targetRef]),
      targetRef
    );
    return [render, renderTarget];
  };
  const useCalendarControlsRendering = (renderControl) => {
    const { i18n } = useCoreContext();
    return useDetachedRender(
      q$1(
        (targetElement, control, handle) => {
          if (!(targetElement instanceof HTMLElement)) return null;
          if (isFunction(renderControl)) return renderControl(control, handle);
          let directionModifier;
          let labelModifier;
          let iconName;
          switch (control) {
            case "PREV":
              directionModifier = "prev";
              labelModifier = "previous";
              iconName = "chevron-left";
              break;
            case "NEXT":
              directionModifier = labelModifier = "next";
              iconName = "chevron-right";
              break;
            default:
              return null;
          }
          const shouldRenderControl = handle();
          return shouldRenderControl ? /* @__PURE__ */ u$1(
            Button$1,
            {
              "aria-label": i18n.get(`calendar.${labelModifier}Month`),
              variant: ButtonVariant.TERTIARY,
              disabled: !shouldRenderControl,
              classNameModifiers: ["circle", directionModifier],
              iconButton: true,
              onClick: handle,
              children: /* @__PURE__ */ u$1(Icon$1, { name: iconName })
            },
            control
          ) : null;
        },
        [i18n, renderControl]
      )
    );
  };
  const DatePicker = D((props, ref) => {
    const { i18n } = useCoreContext();
    const [controlsRenderer, controlsContainerRef] = useCalendarControlsRendering(props.renderControl);
    const [lastUpdatedTimestamp, setLastUpdatedTimestamp] = d(performance.now());
    const withTimezone2 = T$1(() => boolOrTrue(props.showTimezoneInfo), [props.showTimezoneInfo]);
    const { clockTime: time, GMTOffset: offset } = useTimezone({ timezone: props.timezone, withClock: withTimezone2 });
    const datePickerClassName = T$1(() => cx([{ "adyen-pe-datepicker--with-timezone": withTimezone2 }, "adyen-pe-datepicker"]), [withTimezone2]);
    const timezoneI18nOptions = T$1(() => withTimezone2 ? { values: { offset, time } } : EMPTY_OBJECT, [offset, time, withTimezone2]);
    const calendarRef = useReflex(noop, ref);
    const onHighlight = q$1(() => {
      var _a2, _b2, _c2, _d2, _e;
      setLastUpdatedTimestamp(performance.now());
      if (((_a2 = calendarRef.current) == null ? void 0 : _a2.from) && ((_b2 = calendarRef.current) == null ? void 0 : _b2.to)) {
        (_e = props.onHighlight) == null ? void 0 : _e.call(props, +((_c2 = calendarRef.current) == null ? void 0 : _c2.from), +((_d2 = calendarRef.current) == null ? void 0 : _d2.to));
      }
    }, [setLastUpdatedTimestamp, props.onHighlight]);
    return /* @__PURE__ */ u$1("div", { className: datePickerClassName, children: [
      /* @__PURE__ */ u$1("div", { className: "adyen-pe-datepicker__selector-container", children: /* @__PURE__ */ u$1(
        TimeRangeSelector,
        {
          now: props.now,
          calendarRef,
          onTimeRangeSelected: props.onPresetOptionSelected,
          options: props.timeRangePresetOptions,
          selectedOption: props.selectedPresetOption,
          timestamp: lastUpdatedTimestamp,
          timezone: props.timezone
        }
      ) }),
      /* @__PURE__ */ u$1("div", { ref: controlsContainerRef, role: "group", className: "adyen-pe-datepicker__controls", "aria-label": i18n.get("calendar.controls") }),
      /* @__PURE__ */ u$1(
        Calendar$1,
        {
          ...props,
          ref: calendarRef,
          firstWeekDay: DEFAULT_FIRST_WEEK_DAY,
          dynamicBlockRows: true,
          onlyCellsWithin: true,
          controls: props.controls ?? calendar.controls.MINIMAL,
          highlight: props.highlight ?? calendar.highlight.MANY,
          onHighlight,
          renderControl: controlsRenderer,
          trackCurrentDay: true
        }
      ),
      withTimezone2 && /* @__PURE__ */ u$1("div", { className: "adyen-pe-datepicker__timezone", children: i18n.get("calendar.timezone", timezoneI18nOptions) })
    ] });
  });
  const DEFAULT_FILTER_BUTTON_CLASSNAME = "adyen-pe-filter-button";
  function FilterButton(props, ref) {
    const { className, classNameModifiers = [], children, disabled, onClick, ...restAttributes } = props;
    const classNameValue = T$1(() => parseClassName("", className) || "", [className]);
    const disabledValue = T$1(() => parseBooleanProp(disabled), [disabled]);
    const { classes: classes2, click } = useButton(classNameValue, classNameModifiers, DEFAULT_FILTER_BUTTON_CLASSNAME, disabledValue, props, onClick);
    return /* @__PURE__ */ u$1("button", { className: classes2, ref, onClick: click, ...restAttributes, children: /* @__PURE__ */ u$1(Typography$1, { el: TypographyElement.DIV, variant: TypographyVariant.BODY, stronger: true, children }) });
  }
  const FilterButton$1 = fixedForwardRef(FilterButton);
  const InputText = D(function InputText2(props, ref) {
    return /* @__PURE__ */ u$1(InputBase$1, { classNameModifiers: props.classNameModifiers, ...props, ref, "aria-required": props.required, type: "text" });
  });
  const isValueEmptyFallback = (value2) => {
    return !value2 || isEmptyString(value2);
  };
  const renderFallback = /* @__PURE__ */ (() => {
    const DefaultEditModalBody = (props) => {
      const { editAction, name, onChange, onValueUpdated } = props;
      const [currentValue, setCurrentValue] = d(props.value);
      const handleInput = q$1(
        (e2) => {
          const value2 = e2.target.value.trim();
          setCurrentValue(value2);
          onValueUpdated(value2);
        },
        [onValueUpdated]
      );
      y(() => {
        if (editAction === CommitAction.CLEAR) {
          const value2 = "";
          setCurrentValue(value2);
          onValueUpdated(value2);
          onChange(value2);
        }
        if (editAction === CommitAction.APPLY) {
          onChange(currentValue ?? "");
        }
      }, [currentValue, editAction, onChange, onValueUpdated]);
      return /* @__PURE__ */ u$1(InputText, { name, value: currentValue, onInput: handleInput });
    };
    return (props) => /* @__PURE__ */ u$1(DefaultEditModalBody, { ...props });
  })();
  const BaseFilter = ({ render, ...props }) => {
    var _a2;
    const isSmContainer = useResponsiveContainer(containerQueries.down.xs);
    const [editMode, _updateEditMode] = useBooleanState(false);
    const [editModalMounting, updateEditModalMounting] = useBooleanState(false);
    const isValueEmpty = T$1(() => props.isValueEmpty ?? isValueEmptyFallback, [props.isValueEmpty]);
    const [hasEmptyValue, updateHasEmptyValue] = useBooleanState(isValueEmpty(props.value));
    const [hasInitialValue, updateHasInitialValue] = useBooleanState(false);
    const [valueChanged, updateValueChanged] = useBooleanState(false);
    const [disabledApply, updateDisabledApply] = useBooleanState(isValueEmpty(props.value));
    const targetElement = useUniqueIdentifier();
    const renderModalBody = T$1(() => render ?? renderFallback, [render]);
    const onValueUpdated = q$1(
      (currentValue) => {
        const hasEmptyValue2 = isValueEmpty(currentValue ?? void 0);
        updateHasEmptyValue(hasEmptyValue2);
        updateDisabledApply(isNull(currentValue));
        updateValueChanged(hasInitialValue ? currentValue !== props.value : !hasEmptyValue2);
      },
      [isValueEmpty, updateHasEmptyValue, updateDisabledApply, updateValueChanged, hasInitialValue, props.value]
    );
    const { commitAction, commitActionButtons, committing, resetCommitAction } = useCommitAction({
      applyDisabled: disabledApply || !valueChanged,
      resetDisabled: hasEmptyValue
    });
    const [closeEditDialog, openEditDialog] = T$1(() => {
      const updateEditMode = (mode) => () => {
        if (mode === editMode) return;
        if (mode) {
          resetCommitAction();
          updateValueChanged(false);
          updateHasInitialValue(false);
        }
        _updateEditMode(mode);
        updateEditModalMounting(mode);
      };
      return [updateEditMode(false), updateEditMode(true)];
    }, [_updateEditMode, editMode, resetCommitAction, updateEditModalMounting, updateHasInitialValue, updateValueChanged]);
    y(() => {
      if (editModalMounting) {
        const hasEmptyValue2 = isValueEmpty(props.value);
        updateEditModalMounting(false);
        updateHasEmptyValue(hasEmptyValue2);
        updateHasInitialValue(!hasEmptyValue2);
      }
    }, [props.value, editModalMounting, isValueEmpty, updateEditModalMounting, updateHasEmptyValue, updateHasInitialValue]);
    y(() => {
      committing && closeEditDialog();
      updateHasEmptyValue(hasEmptyValue);
    }, [committing, closeEditDialog, updateHasEmptyValue, hasEmptyValue]);
    const isOnlySmContainer = useResponsiveContainer(containerQueries.only.sm);
    const isOnlyMdContainer = useResponsiveContainer(containerQueries.only.md);
    return /* @__PURE__ */ u$1(k$1, { children: [
      /* @__PURE__ */ u$1("div", { className: `adyen-pe-filter adyen-pe-filter--${props.type}`, children: T$1(
        () => /* @__PURE__ */ u$1(
          FilterButton$1,
          {
            classNameModifiers: [
              ...props.appliedFilterAmount ? ["with-counter"] : [],
              ...props.classNameModifiers ?? [],
              ...editMode ? ["active"] : [],
              ...hasEmptyValue ? [] : ["has-selection"]
            ],
            onClick: editMode ? closeEditDialog : openEditDialog,
            tabIndex: 0,
            ref: targetElement,
            children: /* @__PURE__ */ u$1("div", { className: "adyen-pe-filter-button__default-container", children: [
              /* @__PURE__ */ u$1(
                Typography$1,
                {
                  el: TypographyElement.SPAN,
                  variant: TypographyVariant.BODY,
                  stronger: true,
                  className: "adyen-pe-filter-button__label",
                  children: props.label
                }
              ),
              !!props.appliedFilterAmount && /* @__PURE__ */ u$1("div", { className: "adyen-pe-filter-button__counter-wrapper", children: /* @__PURE__ */ u$1(
                Typography$1,
                {
                  el: TypographyElement.SPAN,
                  variant: TypographyVariant.BODY,
                  stronger: true,
                  className: "adyen-pe-filter-button__counter",
                  children: props.appliedFilterAmount
                }
              ) })
            ] })
          }
        ),
        [
          props.appliedFilterAmount,
          props.classNameModifiers,
          props.label,
          editMode,
          hasEmptyValue,
          closeEditDialog,
          openEditDialog,
          targetElement
        ]
      ) }),
      editMode && /* @__PURE__ */ u$1(
        Popover,
        {
          actions: commitActionButtons,
          title: (_a2 = props.title) == null ? void 0 : _a2.trim(),
          variant: PopoverContainerVariant.POPOVER,
          modifiers: ["filter"],
          open: editMode,
          "aria-label": `${props.label}`,
          dismiss: closeEditDialog,
          dismissible: false,
          withContentPadding: props.withContentPadding ?? true,
          divider: true,
          targetElement,
          disableFocusTrap: false,
          position: PopoverContainerPosition.BOTTOM,
          containerSize: props.containerSize,
          showOverlay: isSmContainer,
          fitPosition: isOnlySmContainer || isOnlyMdContainer,
          children: renderModalBody({ ...props, editAction: commitAction, onValueUpdated })
        }
      )
    ] });
  };
  const BaseFilter$1 = M(BaseFilter);
  var DateRangeFilterParam = /* @__PURE__ */ ((DateRangeFilterParam2) => {
    DateRangeFilterParam2["FROM"] = "from";
    DateRangeFilterParam2["TO"] = "to";
    return DateRangeFilterParam2;
  })(DateRangeFilterParam || {});
  const formattingOptions = {
    month: "short",
    day: "numeric",
    year: "numeric"
  };
  const computeDateFilterValue = (i18n, fullDateFormat, fromDate, toDate) => {
    const from2 = fromDate && fullDateFormat(fromDate);
    const to2 = toDate && fullDateFormat(toDate);
    if (from2 && to2) return `${from2} - ${to2}`;
    if (from2) return i18n.get("filter.date.since", { values: { date: from2 } });
    if (to2) return i18n.get("filter.date.until", { values: { date: to2 } });
  };
  const resolveDate = (date2) => {
    try {
      return new Date(date2 || "").toISOString();
    } catch {
      return "";
    }
  };
  const renderDateFilterModalBody = /* @__PURE__ */ (() => {
    const DateFilterEditModalBody = ({
      editAction,
      from: from2,
      to: to2,
      now,
      onChange,
      onValueUpdated,
      showTimezoneInfo,
      selectedPresetOption,
      timeRangePresetOptions,
      timezone: timezone2,
      sinceDate,
      untilDate
    }) => {
      const { i18n } = useCoreContext();
      const { fullDateFormat } = useTimezoneAwareDateFormatting(timezone2);
      const [presetOption, setPresetOption] = d(selectedPresetOption);
      const originDate = T$1(() => [new Date(from2), new Date(to2)], [from2, to2]);
      const datePickerRef = A$1();
      const onHighlight = q$1(
        (from22, to22) => {
          onValueUpdated(computeDateFilterValue(i18n, fullDateFormat, resolveDate(from22), resolveDate(to22)));
        },
        [i18n, fullDateFormat, onValueUpdated]
      );
      y(() => {
        var _a2, _b2, _c2;
        switch (editAction) {
          case CommitAction.APPLY:
            onChange({
              selectedPresetOption: presetOption,
              [DateRangeFilterParam.FROM]: resolveDate((_a2 = datePickerRef.current) == null ? void 0 : _a2.from),
              [DateRangeFilterParam.TO]: resolveDate((_b2 = datePickerRef.current) == null ? void 0 : _b2.to)
            });
            break;
          case CommitAction.CLEAR:
            (_c2 = datePickerRef.current) == null ? void 0 : _c2.clear();
            onChange();
        }
      }, [editAction, onChange, presetOption]);
      return /* @__PURE__ */ u$1(
        DatePicker,
        {
          ref: datePickerRef,
          now,
          originDate,
          onHighlight,
          onPresetOptionSelected: setPresetOption,
          selectedPresetOption,
          timeRangePresetOptions,
          timezone: timezone2,
          showTimezoneInfo,
          sinceDate: resolveDate(sinceDate),
          untilDate: resolveDate(untilDate)
        }
      );
    };
    return (props) => /* @__PURE__ */ u$1(DateFilterEditModalBody, { ...props });
  })();
  const customDateRangeFormat = (formatter, fromDate, toDate) => {
    return formatter.formatRange(fromDate, toDate);
  };
  function DateFilterCore({
    title,
    from: from2,
    to: to2,
    selectedPresetOption,
    ...props
  }) {
    const { i18n } = useCoreContext();
    const { fullDateFormat } = useTimezoneAwareDateFormatting(props.timezone);
    const [selectedPresetOptionValue, setSelectedPresetOption] = d();
    const [fromValue, setFrom] = d();
    const [toValue, setTo] = d();
    const onChange = q$1(
      (params) => {
        const { from: from22, to: to22, selectedPresetOption: selectedPresetOption2 } = params ?? EMPTY_OBJECT;
        try {
          setSelectedPresetOption(selectedPresetOptionValue ?? selectedPresetOption2);
          setFrom(resolveDate(fromValue ?? from22));
          setTo(resolveDate(toValue ?? to22));
        } finally {
          props.onChange({ from: from22, to: to22, selectedPresetOption: selectedPresetOption2 });
        }
      },
      [selectedPresetOptionValue, fromValue, toValue, props]
    );
    const customSelection = T$1(() => i18n.get("rangePreset.custom"), [i18n]);
    const dateTimeFormatter = T$1(() => {
      const _formattingOptions = { ...formattingOptions, timeZone: props.timezone };
      let formatter = new Intl.DateTimeFormat(BASE_LOCALE, _formattingOptions);
      try {
        formatter = new Intl.DateTimeFormat(i18n.locale, _formattingOptions);
      } catch {
      }
      return formatter;
    }, [i18n, props.timezone]);
    y(() => setSelectedPresetOption(selectedPresetOption), [selectedPresetOption]);
    y(() => setFrom(resolveDate(from2 || Date.now())), [from2]);
    y(() => setTo(resolveDate(to2 || Date.now())), [to2]);
    const label = T$1(() => {
      if (selectedPresetOption === customSelection && fromValue && toValue) {
        return customDateRangeFormat(dateTimeFormatter, new Date(fromValue), new Date(toValue));
      }
      return selectedPresetOption ?? props.label;
    }, [customSelection, dateTimeFormatter, fromValue, toValue, selectedPresetOption, props.label]);
    return /* @__PURE__ */ u$1(
      BaseFilter$1,
      {
        ...props,
        from: from2,
        to: to2,
        type: "date",
        label,
        onChange,
        render: renderDateFilterModalBody,
        selectedPresetOption,
        value: computeDateFilterValue(i18n, fullDateFormat, from2, to2),
        withContentPadding: false
      }
    );
  }
  const DateFilter = ({
    timezone: timezone2,
    canResetFilters,
    defaultParams,
    filters,
    nowTimestamp: nowTimestamp2,
    refreshNowTimestamp,
    sinceDate,
    untilDate,
    updateFilters
  }) => {
    const { i18n } = useCoreContext();
    const defaultTimeRangePreset = T$1(() => i18n.get(defaultParams.current.defaultTimeRange), [i18n]);
    const [selectedTimeRangePreset, setSelectedTimeRangePreset] = d(defaultTimeRangePreset);
    const updateCreatedDateFilter = q$1(
      (params = EMPTY_OBJECT) => {
        for (const [param, value2] of Object.entries(params)) {
          switch (param) {
            case "selectedPresetOption":
              setSelectedTimeRangePreset(value2 || defaultTimeRangePreset);
              break;
            case DateRangeFilterParam.FROM:
              updateFilters({
                [FilterParam.CREATED_SINCE]: value2 || defaultParams.current.defaultFilterParams[FilterParam.CREATED_SINCE]
              });
              break;
            case DateRangeFilterParam.TO:
              updateFilters({
                [FilterParam.CREATED_UNTIL]: value2 || defaultParams.current.defaultFilterParams[FilterParam.CREATED_UNTIL]
              });
              break;
            default:
              return;
          }
          refreshNowTimestamp();
        }
      },
      [defaultTimeRangePreset, refreshNowTimestamp, updateFilters]
    );
    T$1(() => !canResetFilters && setSelectedTimeRangePreset(defaultTimeRangePreset), [canResetFilters, defaultTimeRangePreset]);
    return /* @__PURE__ */ u$1(
      DateFilterCore,
      {
        label: i18n.get("dateRange"),
        name: FilterParam.CREATED_SINCE,
        sinceDate,
        untilDate: untilDate ?? new Date(nowTimestamp2).toString(),
        from: filters[FilterParam.CREATED_SINCE],
        to: filters[FilterParam.CREATED_UNTIL],
        selectedPresetOption: selectedTimeRangePreset,
        timeRangePresetOptions: defaultParams.current.timeRangeOptions,
        timezone: timezone2,
        onChange: updateCreatedDateFilter,
        showTimezoneInfo: true,
        now: nowTimestamp2
      }
    );
  };
  function hasCallback(options) {
    return "callback" in options;
  }
  function useModalDetails(options) {
    const [selectedDetail, setSelectedDetail] = d(null);
    const updateDetails = q$1(
      (state) => {
        var _a2;
        if (state && hasCallback(options[state.selection.type])) {
          return {
            callback: ((_a2 = options == null ? void 0 : options[state.selection.type]) == null ? void 0 : _a2.callback) ? (args) => {
              var _a3, _b2;
              return (_b2 = (_a3 = options[state.selection.type]) == null ? void 0 : _a3.callback) == null ? void 0 : _b2.call(_a3, { showModal: () => setSelectedDetail(state), ...args });
            } : () => {
              var _a3;
              return ((_a3 = options[state.selection.type]) == null ? void 0 : _a3.showDetails) && setSelectedDetail(state);
            }
          };
        }
        setSelectedDetail(state);
        return {};
      },
      [options]
    );
    const resetDetails = q$1(() => setSelectedDetail(null), []);
    const detailsToShow = T$1(() => {
      const details = {};
      for (const detail in options) {
        const selectedDetail2 = options[detail];
        details[detail] = !(selectedDetail2 == null ? void 0 : selectedDetail2.showDetails) || !!selectedDetail2.callback;
      }
      return details;
    }, [options]);
    return {
      selectedDetail,
      updateDetails,
      detailsToShow,
      resetDetails
    };
  }
  const MultiSelectionFilter = M(
    ({
      placeholder,
      selection,
      selectionOptions,
      updateSelection
    }) => {
      const isSmContainer = useResponsiveContainer(containerQueries.down.xs);
      const isOnlySmContainer = useResponsiveContainer(containerQueries.only.sm);
      const isOnlyMdContainer = useResponsiveContainer(containerQueries.only.md);
      return selectionOptions && selectionOptions.length > 1 ? /* @__PURE__ */ u$1(
        Select,
        {
          onChange: updateSelection,
          filterable: false,
          multiSelect: true,
          placeholder,
          selected: selection,
          withoutCollapseIndicator: true,
          items: selectionOptions,
          showOverlay: isSmContainer,
          fitPosition: isOnlyMdContainer || isOnlySmContainer
        }
      ) : null;
    }
  );
  const selectionOptionsFor = (list, mapOptionName) => {
    const mapOption = isFunction(mapOptionName) ? mapOptionName : identity;
    return Object.freeze(list.map((id2) => ({ id: id2, name: mapOption(id2) ?? id2 })));
  };
  const useMultiSelectionFilter = ({
    filterParam,
    filterValues,
    filters,
    defaultFilters,
    updateFilters,
    mapFilterOptionName
  }) => {
    const selection = T$1(() => {
      return listFrom((filters == null ? void 0 : filters[filterParam]) ?? (defaultFilters == null ? void 0 : defaultFilters[filterParam]) ?? "");
    }, [defaultFilters, filters, filterParam]);
    const selectionOptions = T$1(
      () => filterValues && selectionOptionsFor(filterValues, mapFilterOptionName),
      [filterValues, mapFilterOptionName]
    );
    const updateSelection = q$1(
      ({ target }) => {
        updateFilters == null ? void 0 : updateFilters({ [filterParam]: (target == null ? void 0 : target.value) || "" });
      },
      [updateFilters, filterParam]
    );
    return { selection, selectionOptions, updateSelection };
  };
  const TRANSACTIONS_OVERVIEW_MULTI_SELECTION_FILTERS = [FilterParam.CURRENCIES, FilterParam.CATEGORIES, FilterParam.STATUSES];
  const DEFAULT_TRANSACTIONS_OVERVIEW_MULTI_SELECTION_FILTER_PARAMS = Object.freeze(
    Object.fromEntries(TRANSACTIONS_OVERVIEW_MULTI_SELECTION_FILTERS.map((param) => [param, ""]))
  );
  const TRANSACTION_CATEGORIES = [
    "ATM",
    "Capital",
    "Chargeback",
    "Correction",
    "Fee",
    "Payment",
    "Refund",
    "Transfer",
    "Other"
  ];
  const TRANSACTION_STATUSES = ["Booked", "Pending", "Reversed"];
  const getDefaultFilterParams = (type2) => {
    const timeRangeOptions = getTimeRangeSelectionDefaultPresetOptions();
    const defaultTimeRange = "rangePreset.last30Days";
    const { from: from2, to: to2 } = timeRangeOptions[defaultTimeRange];
    const defaultFilterParams = {
      ...type2 === "transactions" && {
        ...DEFAULT_TRANSACTIONS_OVERVIEW_MULTI_SELECTION_FILTER_PARAMS,
        [FilterParam.MIN_AMOUNT]: void 0,
        [FilterParam.MAX_AMOUNT]: void 0
      },
      [FilterParam.BALANCE_ACCOUNT]: void 0,
      [FilterParam.CREATED_SINCE]: new Date(from2).toISOString(),
      [FilterParam.CREATED_UNTIL]: new Date(to2).toISOString()
    };
    return { defaultFilterParams, defaultTimeRange, timeRangeOptions };
  };
  const useDefaultOverviewFilterParams = (filterType, balanceAccount2) => {
    const [nowTimestamp2, setNowTimestamp] = d(Date.now());
    const params = getDefaultFilterParams(filterType);
    const defaultParams = A$1(params);
    const refreshNowTimestamp = q$1(() => setNowTimestamp(Date.now()), [setNowTimestamp]);
    y(() => {
      refreshNowTimestamp();
    }, [balanceAccount2, refreshNowTimestamp]);
    return { defaultParams, nowTimestamp: nowTimestamp2, refreshNowTimestamp };
  };
  const BASE_CLASS$k = "adyen-pe-data-overview-header";
  const DataOverviewHeader = ({ baseClassName = BASE_CLASS$k, children, hideTitle, titleKey, descriptionKey }) => {
    const { i18n } = useCoreContext();
    return /* @__PURE__ */ u$1("header", { className: baseClassName, children: [
      /* @__PURE__ */ u$1("div", { className: `${baseClassName}__headings`, children: [
        !hideTitle && titleKey && /* @__PURE__ */ u$1("div", { className: `${baseClassName}__title`, children: /* @__PURE__ */ u$1(Typography$1, { el: TypographyElement.SPAN, variant: TypographyVariant.TITLE, medium: true, children: i18n.get(titleKey) }) }),
        descriptionKey && /* @__PURE__ */ u$1("p", { className: `${baseClassName}__description`, children: /* @__PURE__ */ u$1(Typography$1, { el: TypographyElement.SPAN, variant: TypographyVariant.BODY, children: i18n.get(descriptionKey) }) })
      ] }),
      children && /* @__PURE__ */ u$1("div", { className: `${baseClassName}__controls`, children })
    ] });
  };
  const CLASSNAMES = {
    base: "adyen-pe-modal-content"
  };
  function ModalContent({ type: type2, data, dataCustomization, ...restData }) {
    const detailProps = T$1(() => {
      switch (type2) {
        case "payout":
          return { ...data, type: type2, ...restData };
        case "transaction":
          return { id: data, type: type2, ...restData };
        default:
          return { data, type: type2 };
      }
    }, [data, restData, type2]);
    return /* @__PURE__ */ u$1(k$1, { children: detailProps && /* @__PURE__ */ u$1("div", { className: CLASSNAMES.base, children: /* @__PURE__ */ u$1(DataOverviewDetails, { ...detailProps, dataCustomization }) }) });
  }
  const DataDetailsModal = ({
    children,
    className,
    selectedDetail,
    resetDetails,
    dataCustomization
  }) => {
    const { i18n } = useCoreContext();
    const isModalOpen = !!selectedDetail;
    y(() => {
      if (isModalOpen) {
        popoverUtil.closeAll();
      }
    }, [isModalOpen]);
    return /* @__PURE__ */ u$1("div", { className, children: [
      children,
      selectedDetail && /* @__PURE__ */ u$1(
        Modal,
        {
          title: (selectedDetail == null ? void 0 : selectedDetail.title) ? i18n.get(selectedDetail.title) : void 0,
          isOpen: !!selectedDetail,
          "aria-label": i18n.get("payoutDetails"),
          onClose: resetDetails,
          isDismissible: true,
          headerWithBorder: false,
          size: (selectedDetail == null ? void 0 : selectedDetail.modalSize) ?? "large",
          children: selectedDetail && /* @__PURE__ */ u$1(ModalContent, { dataCustomization: { details: dataCustomization }, ...selectedDetail == null ? void 0 : selectedDetail.selection })
        }
      )
    ] });
  };
  const useCustomColumnsData = ({
    records,
    hasCustomColumn = false,
    onDataRetrieve,
    mergeCustomData
  }) => {
    const [customRecords, setCustomRecords] = d(records);
    const [loadingCustomRecords, setLoadingCustomRecords] = d(false);
    const mergedRecords = q$1(async () => {
      try {
        if (hasCustomColumn && isFunction(onDataRetrieve)) {
          const retrievedData = await onDataRetrieve(records);
          if (!Array.isArray(retrievedData)) throw new Error("Retrieved data should be an array");
          else setCustomRecords(mergeCustomData({ records, retrievedData: (retrievedData == null ? void 0 : retrievedData.filter(Boolean)) || [] }));
        } else {
          setCustomRecords(records);
        }
      } catch (error) {
        setCustomRecords(records);
        console.error(error);
      } finally {
        setLoadingCustomRecords(false);
      }
    }, [hasCustomColumn, onDataRetrieve, mergeCustomData, records]);
    y(() => {
      if (records.length) {
        setLoadingCustomRecords(true);
        void mergedRecords();
      }
    }, [mergedRecords, records]);
    return { customRecords, loadingCustomRecords };
  };
  const hasCustomField = (preferredFields, standardFields = EMPTY_ARRAY) => {
    var _a2;
    if (Array.isArray(preferredFields)) {
      for (const field of preferredFields) {
        try {
          const fieldName = typeof field === "object" ? (_a2 = field == null ? void 0 : field.key) == null ? void 0 : _a2.trim() : false;
          if (
            // `fieldName` is expected to be a string (except in a case of misconfiguration)
            typeof fieldName === "string" && // `fieldName` should not be an empty string (except in a case of misconfiguration)
            fieldName && // `field` is a custom field if `fieldName` is not in the `standardFields` list
            !standardFields.includes(fieldName)
          ) {
            return true;
          }
        } catch (ex) {
        }
      }
    }
    return false;
  };
  const mergeRecords = (originalRecords, modifiedRecords, matchRecordCallback) => {
    const mergedRecords = [];
    for (let i2 = 0; i2 < originalRecords.length; i2++) {
      const originalRecord = originalRecords[i2];
      const modifiedRecord = modifiedRecords.find((record) => matchRecordCallback(record, originalRecord, i2));
      mergedRecords[i2] = { ...modifiedRecord ?? EMPTY_OBJECT, ...originalRecord };
    }
    return mergedRecords;
  };
  const PayoutsOverview = ({
    onFiltersChanged,
    balanceAccounts,
    allowLimitSelection = true,
    preferredLimit = DEFAULT_PAGE_LIMIT,
    onRecordSelection,
    showDetails,
    isLoadingBalanceAccount,
    onContactSupport,
    hideTitle,
    dataCustomization
  }) => {
    var _a2, _b2, _c2, _d2;
    const { getPayouts: payoutsEndpointCall } = useConfigContext().endpoints;
    const { activeBalanceAccount, balanceAccountSelectionOptions, onBalanceAccountSelection } = useBalanceAccountSelection(balanceAccounts);
    const { defaultParams, nowTimestamp: nowTimestamp2, refreshNowTimestamp } = useDefaultOverviewFilterParams("payouts", activeBalanceAccount);
    const getPayouts = q$1(
      async (pageRequestParams, signal) => {
        const requestOptions = { signal, errorLevel: "error" };
        return payoutsEndpointCall(requestOptions, {
          query: {
            ...pageRequestParams,
            createdSince: pageRequestParams[FilterParam.CREATED_SINCE] ?? defaultParams.current.defaultFilterParams[FilterParam.CREATED_SINCE],
            createdUntil: pageRequestParams[FilterParam.CREATED_UNTIL] ?? defaultParams.current.defaultFilterParams[FilterParam.CREATED_UNTIL],
            balanceAccountId: (activeBalanceAccount == null ? void 0 : activeBalanceAccount.id) ?? ""
          }
        });
      },
      [activeBalanceAccount == null ? void 0 : activeBalanceAccount.id, defaultParams, payoutsEndpointCall]
    );
    const filterBarState = useFilterBarState();
    const _onFiltersChanged = T$1(() => isFunction(onFiltersChanged) ? onFiltersChanged : void 0, [onFiltersChanged]);
    const preferredLimitOptions = T$1(() => allowLimitSelection ? LIMIT_OPTIONS : void 0, [allowLimitSelection]);
    const { canResetFilters, error, fetching, filters, limit, limitOptions, records, resetFilters, updateFilters, updateLimit, ...paginationProps } = useCursorPaginatedRecords({
      fetchRecords: getPayouts,
      dataField: "data",
      filterParams: defaultParams.current.defaultFilterParams,
      initialFiltersSameAsDefault: true,
      onFiltersChanged: _onFiltersChanged,
      preferredLimit,
      preferredLimitOptions,
      enabled: !!(activeBalanceAccount == null ? void 0 : activeBalanceAccount.id) && !!payoutsEndpointCall
    });
    y(() => {
      refreshNowTimestamp();
    }, [filters, refreshNowTimestamp]);
    const payoutDetails2 = T$1(
      () => ({
        showDetails: showDetails ?? true,
        callback: onRecordSelection
      }),
      [showDetails, onRecordSelection]
    );
    const mergeCustomData = q$1(
      ({ records: records2, retrievedData }) => mergeRecords(records2, retrievedData, (modifiedRecord, record) => modifiedRecord.createdAt === record.createdAt),
      []
    );
    const hasCustomColumn = T$1(() => {
      var _a3;
      return hasCustomField((_a3 = dataCustomization == null ? void 0 : dataCustomization.list) == null ? void 0 : _a3.fields, PAYOUT_TABLE_FIELDS);
    }, [(_a2 = dataCustomization == null ? void 0 : dataCustomization.list) == null ? void 0 : _a2.fields]);
    const { customRecords, loadingCustomRecords } = useCustomColumnsData({
      records,
      hasCustomColumn,
      onDataRetrieve: (_b2 = dataCustomization == null ? void 0 : dataCustomization.list) == null ? void 0 : _b2.onDataRetrieve,
      mergeCustomData
    });
    const modalOptions = T$1(() => ({ payout: payoutDetails2 }), [payoutDetails2]);
    const { updateDetails, resetDetails, selectedDetail } = useModalDetails(modalOptions);
    const onRowClick = q$1(
      (value2) => {
        updateDetails({
          selection: {
            type: "payout",
            data: { id: activeBalanceAccount == null ? void 0 : activeBalanceAccount.id, balanceAccountDescription: (activeBalanceAccount == null ? void 0 : activeBalanceAccount.description) || "", date: value2.createdAt }
          },
          modalSize: "small"
        }).callback({ balanceAccountId: (activeBalanceAccount == null ? void 0 : activeBalanceAccount.id) || "", date: value2.createdAt });
      },
      [updateDetails, activeBalanceAccount == null ? void 0 : activeBalanceAccount.id, activeBalanceAccount == null ? void 0 : activeBalanceAccount.description]
    );
    return /* @__PURE__ */ u$1("div", { className: BASE_CLASS$l, children: [
      /* @__PURE__ */ u$1(DataOverviewHeader, { hideTitle, titleKey: "payoutsTitle", descriptionKey: "payoutsNotice", children: /* @__PURE__ */ u$1(FilterBarMobileSwitch, { ...filterBarState }) }),
      /* @__PURE__ */ u$1(FilterBar, { ...filterBarState, children: [
        /* @__PURE__ */ u$1(
          BalanceAccountSelector,
          {
            activeBalanceAccount,
            balanceAccountSelectionOptions,
            onBalanceAccountSelection
          }
        ),
        /* @__PURE__ */ u$1(
          DateFilter,
          {
            canResetFilters,
            defaultParams,
            filters,
            nowTimestamp: nowTimestamp2,
            refreshNowTimestamp,
            sinceDate: EARLIEST_PAYOUT_SINCE_DATE$1,
            timezone: "UTC",
            updateFilters
          }
        )
      ] }),
      /* @__PURE__ */ u$1(
        DataDetailsModal,
        {
          className: BASE_CLASS_DETAILS$1,
          onContactSupport,
          selectedDetail,
          resetDetails,
          dataCustomization: dataCustomization == null ? void 0 : dataCustomization.details,
          children: /* @__PURE__ */ u$1(
            PayoutsTable,
            {
              loading: fetching || isLoadingBalanceAccount || !balanceAccounts || loadingCustomRecords,
              data: ((_c2 = dataCustomization == null ? void 0 : dataCustomization.list) == null ? void 0 : _c2.onDataRetrieve) ? customRecords : records,
              showPagination: true,
              onRowClick,
              showDetails,
              limit,
              limitOptions,
              onContactSupport,
              onLimitSelection: updateLimit,
              error,
              customColumns: (_d2 = dataCustomization == null ? void 0 : dataCustomization.list) == null ? void 0 : _d2.fields,
              ...paginationProps
            }
          )
        }
      )
    ] });
  };
  const BASE_CLASS$j = "adyen-pe-payouts-overview-container";
  function PayoutsOverviewContainer({ ...props }) {
    const { balanceAccounts, isBalanceAccountIdWrong, isFetching, error } = useBalanceAccounts(props.balanceAccountId);
    return /* @__PURE__ */ u$1(
      DataOverviewContainer,
      {
        balanceAccountsError: error,
        className: BASE_CLASS$j,
        errorMessage: "weCouldNotLoadThePayoutsOverview",
        isBalanceAccountIdWrong,
        onContactSupport: props.onContactSupport,
        children: /* @__PURE__ */ u$1(PayoutsOverview, { ...props, balanceAccounts, isLoadingBalanceAccount: isFetching })
      }
    );
  }
  class PayoutsElement extends UIElement {
    constructor(props) {
      super(props);
      __publicField(this, "componentToRender", () => {
        return /* @__PURE__ */ u$1(
          PayoutsOverviewContainer,
          {
            ...this.props,
            balanceAccountId: this.props.balanceAccountId,
            ref: (ref) => void (this.componentRef = ref)
          }
        );
      });
      this.componentToRender = this.componentToRender.bind(this);
    }
  }
  __publicField(PayoutsElement, "type", "payouts");
  class TransactionElement extends UIElement {
    constructor(props) {
      super(props);
      __publicField(this, "componentToRender", () => {
        return /* @__PURE__ */ u$1(
          DataOverviewDetails,
          {
            ...this.props,
            type: "transaction",
            ref: (ref) => void (this.componentRef = ref)
          }
        );
      });
      this.componentToRender = this.componentToRender.bind(this);
    }
  }
  __publicField(TransactionElement, "type", "transactionDetails");
  const DIVIDER_CLASS_NAMES = {
    base: "adyen-pe-divider"
  };
  const Divider = ({ className }) => {
    return /* @__PURE__ */ u$1("hr", { className: cx(DIVIDER_CLASS_NAMES.base, className) });
  };
  const BASE_CLASS$i = "adyen-pe-header";
  const Header = ({ baseClassName = BASE_CLASS$i, children, hasDivider, hideTitle, titleKey, subtitleKey, subtitleConfig }) => {
    const { i18n } = useCoreContext();
    return /* @__PURE__ */ u$1("header", { className: baseClassName, children: [
      /* @__PURE__ */ u$1("div", { className: `${baseClassName}__headings`, children: [
        !hideTitle && titleKey && /* @__PURE__ */ u$1("div", { className: `${baseClassName}__title`, children: /* @__PURE__ */ u$1(Typography$1, { el: TypographyElement.SPAN, variant: TypographyVariant.TITLE, medium: true, children: i18n.get(titleKey) }) }),
        subtitleKey && /* @__PURE__ */ u$1("div", { className: cx(`${baseClassName}__subtitle`, subtitleConfig == null ? void 0 : subtitleConfig.classNames), children: /* @__PURE__ */ u$1(
          Typography$1,
          {
            el: (subtitleConfig == null ? void 0 : subtitleConfig.typographyEl) ?? TypographyElement.SPAN,
            variant: (subtitleConfig == null ? void 0 : subtitleConfig.variant) ?? TypographyVariant.BODY,
            children: i18n.get(subtitleKey)
          }
        ) }),
        hasDivider && /* @__PURE__ */ u$1(Divider, { className: `${baseClassName}__divider` })
      ] }),
      children && /* @__PURE__ */ u$1("div", { className: `${baseClassName}__controls`, children })
    ] });
  };
  const BASE_CLASS$h = "adyen-pe-transaction-totals";
  const ITEM_CLASS = "adyen-pe-transaction-totals__item";
  const DEFAULT_BASE_BUTTON_CLASSNAME = "adyen-pe-base-button";
  function BaseButton(props, ref) {
    const classNameValue = T$1(() => parseClassName("", props.className) || "", [props.className]);
    const disabledValue = T$1(() => parseBooleanProp(props.disabled || false), [props.disabled]);
    const { click, allProps } = useButton(
      classNameValue,
      [...props.classNameModifiers || [], ...props.fullWidth ? ["full-width"] : []],
      DEFAULT_BASE_BUTTON_CLASSNAME,
      disabledValue,
      props,
      props.onClick
    );
    return /* @__PURE__ */ u$1("button", { type: props.type || "button", onClick: click, ref, ...allProps, children: props.children });
  }
  const BaseButton$1 = fixedForwardRef(BaseButton);
  const NAMESPACE = "adyen-pe-expandable-card";
  const BASE_CLASS$g = NAMESPACE;
  const CONTAINER_CLASS = BASE_CLASS$g + "__container";
  const CONTENT_CLASS = BASE_CLASS$g + "__content";
  const CHEVRON_CLASS = BASE_CLASS$g + "__chevron";
  const CONTAINER_BUTTON_CLASS = CONTAINER_CLASS + "--button";
  const CONTAINER_FILLED_CLASS = CONTAINER_CLASS + "--filled";
  const CONTAINER_HIDDEN_CLASS = CONTAINER_CLASS + "--hidden";
  const CONTAINER_IN_FLOW_CLASS = CONTAINER_CLASS + "--in-flow";
  const CONTAINER_OVERLAY_CLASS = CONTAINER_CLASS + "--overlay";
  const CONTENT_EXPANDABLE_CLASS = CONTENT_CLASS + "--expandable";
  const CARD_HEIGHT_PROPERTY = `--${NAMESPACE}-height`;
  const CONTAINER_OVERLAY_ID = CONTAINER_OVERLAY_CLASS;
  const ExpandableCard = ({ renderHeader, children, filled, fullWidth, inFlow, ...listeners }) => {
    const { i18n } = useCoreContext();
    const [isOpen, setIsOpen] = d(false);
    const [collapsedCardHeight, setCollapsedCardHeight] = d(0);
    const inNormalFlow = T$1(() => inFlow === true, [inFlow]);
    const toggleIsOpen = q$1(() => setIsOpen((isOpen2) => !isOpen2), [setIsOpen]);
    const expandButtonRef = A$1(null);
    const expandableCardRef = A$1(null);
    const isClosedFromOutside = A$1(false);
    const isOpenRef = A$1(isOpen);
    const clickOutsideRef = useClickOutside(
      void 0,
      q$1(() => {
        if (isOpen) {
          toggleIsOpen();
          isClosedFromOutside.current = true;
        }
      }, [isOpen, toggleIsOpen])
    );
    _(() => {
      const cardElement = expandableCardRef.current;
      if (!cardElement) return;
      if (inNormalFlow) {
        cardElement.style.setProperty(CARD_HEIGHT_PROPERTY, `${collapsedCardHeight}px`);
      } else if (!isOpen) {
        cardElement.style.removeProperty(CARD_HEIGHT_PROPERTY);
      }
    }, [collapsedCardHeight, inNormalFlow, isOpen]);
    y(() => {
      if (!inNormalFlow) return void setCollapsedCardHeight(0);
      const element = expandButtonRef.current;
      if (!element) return;
      const resizeObserver = new ResizeObserver((entries) => {
        for (const entry of entries) {
          if (entry.target !== element) continue;
          setCollapsedCardHeight(element.offsetHeight || 0);
        }
      });
      resizeObserver.observe(element);
      return () => {
        resizeObserver.unobserve(element);
        resizeObserver.disconnect();
      };
    }, [inNormalFlow]);
    y(() => {
      var _a2, _b2;
      if (isOpen) {
        (_a2 = clickOutsideRef.current) == null ? void 0 : _a2.focus();
      } else {
        if (isOpenRef.current !== isOpen && !isClosedFromOutside.current) {
          (_b2 = expandButtonRef.current) == null ? void 0 : _b2.focus();
        }
        isClosedFromOutside.current = false;
      }
      isOpenRef.current = isOpen;
    }, [isOpen, clickOutsideRef]);
    return /* @__PURE__ */ u$1("div", { ref: expandableCardRef, className: BASE_CLASS$g, children: children ? /* @__PURE__ */ u$1(k$1, { children: [
      /* @__PURE__ */ u$1(
        BaseButton$1,
        {
          className: cx(CONTAINER_CLASS, CONTAINER_BUTTON_CLASS, { [CONTAINER_FILLED_CLASS]: filled }),
          disabled: isOpen,
          fullWidth,
          "aria-controls": CONTAINER_OVERLAY_ID,
          "aria-expanded": isOpen,
          "aria-hidden": isOpen,
          onClick: toggleIsOpen,
          ref: expandButtonRef,
          "data-testid": "expand-button",
          ...listeners,
          children: [
            /* @__PURE__ */ u$1("span", { className: "adyen-pe-visually-hidden", children: i18n.get("expandableCard.expand") }),
            /* @__PURE__ */ u$1("div", { className: cx(CONTENT_CLASS, CONTENT_EXPANDABLE_CLASS), children: renderHeader }),
            /* @__PURE__ */ u$1("div", { className: CHEVRON_CLASS, children: /* @__PURE__ */ u$1(Icon$1, { name: "chevron-down" }) })
          ]
        }
      ),
      /* @__PURE__ */ u$1(
        BaseButton$1,
        {
          id: CONTAINER_OVERLAY_ID,
          className: cx(CONTAINER_CLASS, CONTAINER_BUTTON_CLASS, CONTAINER_OVERLAY_CLASS, {
            [CONTAINER_FILLED_CLASS]: filled,
            [CONTAINER_HIDDEN_CLASS]: !isOpen,
            [CONTAINER_IN_FLOW_CLASS]: inNormalFlow
          }),
          disabled: !isOpen,
          fullWidth,
          "aria-controls": CONTAINER_OVERLAY_ID,
          "aria-expanded": isOpen,
          "aria-hidden": !isOpen,
          onClick: toggleIsOpen,
          ref: clickOutsideRef,
          "data-testid": "collapse-button",
          ...listeners,
          children: [
            /* @__PURE__ */ u$1("span", { className: "adyen-pe-visually-hidden", children: i18n.get("expandableCard.collapse") }),
            /* @__PURE__ */ u$1("div", { className: cx(CONTENT_CLASS, CONTENT_EXPANDABLE_CLASS), children: [
              renderHeader,
              /* @__PURE__ */ u$1("div", { children })
            ] }),
            /* @__PURE__ */ u$1("div", { className: CHEVRON_CLASS, children: /* @__PURE__ */ u$1(Icon$1, { name: "chevron-up" }) })
          ]
        }
      )
    ] }) : /* @__PURE__ */ u$1("div", { className: cx(CONTAINER_CLASS, { [CONTAINER_FILLED_CLASS]: filled }), ...listeners, children: /* @__PURE__ */ u$1("div", { className: CONTENT_CLASS, children: renderHeader }) }) });
  };
  const BASE_CLASS$f = "adyen-pe-amount-skeleton";
  const MARGIN_CLASS = BASE_CLASS$f + "--has-margin";
  const LOADING_CLASS = BASE_CLASS$f + "--loading";
  const AmountSkeleton = ({ hasMargin = false, isLoading = false, width }) => {
    return /* @__PURE__ */ u$1("span", { className: cx(BASE_CLASS$f, { [LOADING_CLASS]: isLoading, [MARGIN_CLASS]: hasMargin }), style: { width } });
  };
  const BASE_CLASS$e = "adyen-pe-summary-item";
  const LABEL_CONTAINER_CLASS = BASE_CLASS$e + "__label-container";
  const LABEL_CONTAINER_CLASS_LOADING = LABEL_CONTAINER_CLASS + "--loading";
  const BODY_CLASS = BASE_CLASS$e + "--body";
  const LABEL_CLASS = BASE_CLASS$e + "__label";
  const PLACEHOLDER_CLASS = BASE_CLASS$e + "__placeholder";
  const AMOUNT_CLASS = BASE_CLASS$e + "__amount";
  const SummaryItemLabel = fixedForwardRef(
    ({ config, i18n, isSkeletonVisible, className, ...restArgs }, ref) => {
      return /* @__PURE__ */ u$1(
        "span",
        {
          className: cx(LABEL_CONTAINER_CLASS, className, { [LABEL_CONTAINER_CLASS_LOADING]: isSkeletonVisible }),
          style: { cursor: "default" },
          ref,
          ...restArgs,
          children: config.labelKey && /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.CAPTION, className: LABEL_CLASS, children: i18n.get(config.labelKey) })
        }
      );
    }
  );
  const SummaryItem = ({
    columnConfigs,
    isHeader = false,
    isHovered = false,
    isSkeletonVisible = false,
    isLoading = false,
    widths,
    onWidthsSet,
    isEmpty
  }) => {
    const { i18n } = useCoreContext();
    y(() => {
      const newWidths = columnConfigs.map((config) => {
        var _a2, _b2;
        return ((_b2 = (_a2 = config.ref) == null ? void 0 : _a2.current) == null ? void 0 : _b2.getBoundingClientRect().width) ?? 0;
      });
      onWidthsSet(newWidths);
    }, [onWidthsSet]);
    const getColumnStyle = (index) => ({ width: widths && widths[index] ? widths[index] : "auto" });
    const isXsContainer = useResponsiveContainer(containerQueries.only.xs);
    const typographyVariant = q$1(
      (config, isLongValue) => {
        if (config.valueHasLabelStyle) {
          return TypographyVariant.CAPTION;
        }
        return isLongValue && !isXsContainer ? TypographyVariant.BODY : TypographyVariant.TITLE;
      },
      [isXsContainer]
    );
    return /* @__PURE__ */ u$1("div", { className: cx(BASE_CLASS$e, { [BODY_CLASS]: !isHeader }), children: columnConfigs.map((config, index) => {
      const value2 = config.getValue();
      const isLongValue = !!value2 && value2.length > 12;
      return /* @__PURE__ */ u$1("div", { children: [
        isHeader && (config.tooltipLabel ? /* @__PURE__ */ u$1(Tooltip, { content: i18n.get(`${config.tooltipLabel}`), isContainerHovered: isHovered, children: /* @__PURE__ */ u$1(SummaryItemLabel, { config, i18n, isSkeletonVisible }) }) : /* @__PURE__ */ u$1(SummaryItemLabel, { config, i18n, isSkeletonVisible })),
        isSkeletonVisible ? /* @__PURE__ */ u$1(AmountSkeleton, { isLoading, hasMargin: config.hasSkeletonMargin, width: config.skeletonWidth + "px" }) : isEmpty ? /* @__PURE__ */ u$1("span", { className: cx([BASE_CLASS$e, PLACEHOLDER_CLASS]) }) : /* @__PURE__ */ u$1("div", { ref: config.ref, style: getColumnStyle(index), children: /* @__PURE__ */ u$1(
          Typography$1,
          {
            variant: typographyVariant(config, isLongValue),
            className: cx({ [LABEL_CLASS]: config.valueHasLabelStyle, [AMOUNT_CLASS]: !config.valueHasLabelStyle }),
            children: value2
          }
        ) })
      ] }, index);
    }) });
  };
  const TransactionTotalItem = ({
    total,
    hiddenField,
    isHeader = false,
    isHovered = false,
    isSkeleton = false,
    isLoading = false,
    widths,
    onWidthsSet
  }) => {
    const { i18n } = useCoreContext();
    const incomingRef = A$1(null);
    const expenseRef = A$1(null);
    const currencyRef = A$1(null);
    const columnConfigs = T$1(() => {
      const incomingsConfig = {
        labelKey: "totalIncoming",
        ref: incomingRef,
        skeletonWidth: 80,
        getValue: () => total && i18n.amount(total.incomings, total.currency),
        tooltipLabel: "tooltip.totalIncoming"
      };
      const expensesConfig = {
        labelKey: "totalOutgoing",
        ref: expenseRef,
        skeletonWidth: 80,
        getValue: () => total && i18n.amount(total.expenses, total.currency),
        tooltipLabel: "tooltip.totalOutgoing"
      };
      return [
        ...hiddenField !== "incomings" ? [incomingsConfig] : [],
        ...hiddenField !== "expenses" ? [expensesConfig] : [],
        {
          ref: currencyRef,
          skeletonWidth: 40,
          valueHasLabelStyle: true,
          getValue: () => total == null ? void 0 : total.currency
        }
      ];
    }, [total, hiddenField, i18n]);
    return /* @__PURE__ */ u$1(
      SummaryItem,
      {
        isHovered,
        isEmpty: !total,
        columnConfigs,
        isHeader,
        isSkeletonVisible: isSkeleton,
        isLoading,
        widths,
        onWidthsSet
      }
    );
  };
  const BASE_CLASS$d = "adyen-pe-base-list";
  const BaseList = ({ children, classNames }) => {
    return /* @__PURE__ */ u$1("ul", { className: cx(BASE_CLASS$d, [classNames]), children });
  };
  const useMaxWidthsState = () => {
    const [maxWidths, setMaxWidths] = d([]);
    const setMaxWidthsConditionally = q$1((widths) => {
      setMaxWidths(
        (currentMaxWidths) => widths.every((width) => !width) ? widths : widths.map((width, index) => {
          const currentMaxWidth = currentMaxWidths[index];
          return !currentMaxWidth || width > currentMaxWidth ? width : currentMaxWidth;
        })
      );
    }, []);
    return [maxWidths, setMaxWidthsConditionally];
  };
  const TotalsCard = M(({ totals, isLoading, hiddenField, fullWidth }) => {
    const [maxWidths, setMaxWidths] = useMaxWidthsState();
    const [isHovered, setIsHovered] = d(false);
    const [firstTotal, ...restOfTotals] = T$1(() => {
      return totals.map((t2) => {
        t2["key"] = `${t2.currency}-${Math.random()}`;
        return t2;
      });
    }, [totals]);
    return /* @__PURE__ */ u$1(
      ExpandableCard,
      {
        renderHeader: /* @__PURE__ */ u$1(
          TransactionTotalItem,
          {
            isHovered,
            total: firstTotal,
            hiddenField,
            widths: maxWidths,
            isHeader: true,
            isSkeleton: isLoading,
            isLoading,
            onWidthsSet: setMaxWidths
          }
        ),
        fullWidth,
        onMouseEnter: () => setIsHovered(true),
        onFocus: () => setIsHovered(true),
        onMouseLeave: () => setIsHovered(false),
        onBlur: () => setIsHovered(false),
        children: !isLoading && restOfTotals.length && /* @__PURE__ */ u$1(BaseList, { children: restOfTotals.map((total) => /* @__PURE__ */ u$1("li", { children: /* @__PURE__ */ u$1(
          TransactionTotalItem,
          {
            isHovered,
            total,
            hiddenField,
            widths: maxWidths,
            onWidthsSet: setMaxWidths
          }
        ) }, total.key)) })
      }
    );
  });
  const TransactionTotals = M(
    ({
      availableCurrencies,
      isAvailableCurrenciesFetching,
      balanceAccountId: balanceAccountId2,
      createdSince,
      createdUntil,
      categories,
      statuses,
      maxAmount,
      minAmount,
      currencies,
      fullWidth
    }) => {
      const { getTransactionTotals } = useConfigContext().endpoints;
      const fetchCallback = q$1(async () => {
        return getTransactionTotals == null ? void 0 : getTransactionTotals(EMPTY_OBJECT, {
          query: {
            createdSince,
            createdUntil,
            categories,
            statuses,
            maxAmount,
            minAmount,
            currencies,
            balanceAccountId: balanceAccountId2
          }
        });
      }, [balanceAccountId2, categories, createdSince, createdUntil, currencies, getTransactionTotals, maxAmount, minAmount, statuses]);
      const { data, isFetching } = useFetch({
        fetchOptions: T$1(() => ({ enabled: !!balanceAccountId2 && !!getTransactionTotals }), [balanceAccountId2, getTransactionTotals]),
        queryFn: fetchCallback
      });
      const isLoading = !balanceAccountId2 || isFetching || isAvailableCurrenciesFetching;
      const getTotals = q$1(() => {
        if (!availableCurrencies || !data) {
          return data == null ? void 0 : data.data;
        }
        const partialTotals = availableCurrencies.map((currency2) => {
          const totalOfCurrency = data.data.find((total) => total.currency === currency2);
          return totalOfCurrency || { currency: currency2, incomings: 0, expenses: 0 };
        });
        return partialTotals.concat(data.data.filter((total) => !partialTotals.includes(total)));
      }, [availableCurrencies, data]);
      const totals = getTotals() ?? [];
      const isXsContainer = useResponsiveContainer(containerQueries.only.xs);
      return /* @__PURE__ */ u$1("div", { className: BASE_CLASS$h, children: isXsContainer ? /* @__PURE__ */ u$1(k$1, { children: [
        /* @__PURE__ */ u$1("div", { className: ITEM_CLASS, children: /* @__PURE__ */ u$1(TotalsCard, { totals, isLoading, hiddenField: "expenses", fullWidth }) }),
        /* @__PURE__ */ u$1("div", { className: ITEM_CLASS, children: /* @__PURE__ */ u$1(TotalsCard, { totals, isLoading, hiddenField: "incomings", fullWidth }) })
      ] }) : /* @__PURE__ */ u$1(TotalsCard, { totals, isLoading, fullWidth }) });
    }
  );
  const BASE_CLASS$c = "adyen-pe-balances";
  const BalanceItem = ({ balance, isHeader = false, isSkeleton = false, isLoading = false, widths, onWidthsSet, isEmpty }) => {
    const { i18n } = useCoreContext();
    const amountRef = A$1(null);
    const currencyRef = A$1(null);
    const columnConfigs = T$1(
      () => [
        {
          labelKey: "accountBalance",
          ref: amountRef,
          skeletonWidth: 80,
          getValue: () => balance && i18n.amount(balance.value, balance.currency)
        },
        {
          ref: currencyRef,
          skeletonWidth: 40,
          valueHasLabelStyle: true,
          getValue: () => balance == null ? void 0 : balance.currency
        }
      ],
      [balance, amountRef, i18n]
    );
    return /* @__PURE__ */ u$1(
      SummaryItem,
      {
        isEmpty,
        columnConfigs,
        isHeader,
        isSkeletonVisible: isSkeleton,
        isLoading,
        widths,
        onWidthsSet
      }
    );
  };
  const Balances = M(({ balanceAccountId: balanceAccountId2, defaultCurrencyCode, onCurrenciesChange, fullWidth }) => {
    const { getBalances: getAccountsBalance } = useConfigContext().endpoints;
    const fetchCallback = q$1(async () => {
      return getAccountsBalance == null ? void 0 : getAccountsBalance(EMPTY_OBJECT, {
        path: { balanceAccountId: balanceAccountId2 }
      });
    }, [balanceAccountId2, getAccountsBalance]);
    const { data, error, isFetching } = useFetch({
      fetchOptions: T$1(() => ({ enabled: !!balanceAccountId2 && !!getAccountsBalance }), [balanceAccountId2, getAccountsBalance]),
      queryFn: fetchCallback
    });
    const isLoading = !balanceAccountId2 || isFetching;
    const isEmpty = !!error || !(data == null ? void 0 : data.data.length);
    const balances = T$1(() => {
      return (data == null ? void 0 : data.data) && [...data.data].sort(({ currency: firstCurrency }, { currency: secondCurrency }) => {
        if (defaultCurrencyCode) {
          if (firstCurrency === defaultCurrencyCode) return -1;
          if (secondCurrency === defaultCurrencyCode) return 1;
        }
        return firstCurrency.localeCompare(secondCurrency);
      });
    }, [data == null ? void 0 : data.data, defaultCurrencyCode]);
    const [firstBalance, ...restOfBalances] = T$1(() => {
      return (balances == null ? void 0 : balances.map((t2) => {
        t2["key"] = `${t2.currency}-${Math.random()}`;
        return t2;
      })) ?? [];
    }, [balances]);
    const [maxWidths, setMaxWidths] = useMaxWidthsState();
    y(() => {
      const currencies = new Set((balances == null ? void 0 : balances.map(({ currency: currency2 }) => currency2)) || []);
      onCurrenciesChange(Array.from(currencies), isFetching);
    }, [balances, isFetching, onCurrenciesChange]);
    return /* @__PURE__ */ u$1("div", { className: BASE_CLASS$c, children: /* @__PURE__ */ u$1(
      ExpandableCard,
      {
        renderHeader: /* @__PURE__ */ u$1(
          BalanceItem,
          {
            isEmpty,
            balance: firstBalance,
            widths: maxWidths,
            isHeader: true,
            isSkeleton: isLoading,
            isLoading,
            onWidthsSet: setMaxWidths
          }
        ),
        filled: true,
        fullWidth,
        children: restOfBalances.length && /* @__PURE__ */ u$1(BaseList, { children: restOfBalances.map((balance) => /* @__PURE__ */ u$1("li", { children: /* @__PURE__ */ u$1(BalanceItem, { balance, widths: maxWidths, onWidthsSet: setMaxWidths }) }, balance.key)) })
      }
    ) });
  });
  const useTransactionsOverviewMultiSelectionFilters = (filtersConfig, currencies) => {
    const categoriesFilter = useMultiSelectionFilter({
      filterParam: FilterParam.CATEGORIES,
      filterValues: TRANSACTION_CATEGORIES,
      defaultFilters: DEFAULT_TRANSACTIONS_OVERVIEW_MULTI_SELECTION_FILTER_PARAMS,
      ...filtersConfig
    });
    const statusesFilter = useMultiSelectionFilter({
      filterParam: FilterParam.STATUSES,
      filterValues: TRANSACTION_STATUSES,
      defaultFilters: DEFAULT_TRANSACTIONS_OVERVIEW_MULTI_SELECTION_FILTER_PARAMS,
      ...filtersConfig
    });
    const currenciesFilter = useMultiSelectionFilter({
      filterParam: FilterParam.CURRENCIES,
      filterValues: currencies,
      defaultFilters: DEFAULT_TRANSACTIONS_OVERVIEW_MULTI_SELECTION_FILTER_PARAMS,
      ...filtersConfig
    });
    return {
      categoriesFilter,
      currenciesFilter,
      statusesFilter
    };
  };
  const AMOUNT_MULTIPLIER = 1e5;
  const RangeSelection = ({
    onChange,
    editAction,
    onValueUpdated,
    selectedCurrencies,
    availableCurrencies,
    value: value2,
    ...props
  }) => {
    const { i18n } = useCoreContext();
    const [minAmount, setMinAmount] = d(
      !isUndefined(props.minAmount) ? parseFloat(props.minAmount) / AMOUNT_MULTIPLIER : void 0
    );
    const [maxAmount, setMaxAmount] = d(
      !isUndefined(props.maxAmount) ? parseFloat(props.maxAmount) / AMOUNT_MULTIPLIER : void 0
    );
    const applyFilter = q$1(() => {
      onChange({ minAmount, maxAmount });
    }, [maxAmount, minAmount, onChange]);
    const clearFilter = q$1(() => {
      onChange({ minAmount: void 0, maxAmount: void 0 });
      setMaxAmount(void 0);
      setMinAmount(void 0);
    }, [onChange]);
    y(() => {
      if (editAction === CommitAction.APPLY) applyFilter();
      if (editAction === CommitAction.CLEAR) clearFilter();
    }, [applyFilter, clearFilter, editAction]);
    const filterValue = T$1(() => ({ minAmount: Number(minAmount), maxAmount: Number(maxAmount) }), [maxAmount, minAmount]);
    y(() => {
      const { maxAmount: maxAmount2, minAmount: minAmount2 } = filterValue;
      if (isUndefined(maxAmount2) && isUndefined(minAmount2) || minAmount2 > maxAmount2) {
        onValueUpdated(null);
      } else onValueUpdated(`${minAmount2}-${maxAmount2}`);
    }, [filterValue, onValueUpdated]);
    return /* @__PURE__ */ u$1("div", { className: "adyen-pe-range-selection-filter", children: [
      /* @__PURE__ */ u$1("div", { className: "adyen-pe-range-selection-filter__input", children: [
        /* @__PURE__ */ u$1("label", { htmlFor: "minValue", children: `${i18n.get("from")}:` }),
        /* @__PURE__ */ u$1(
          InputBase$1,
          {
            "data-testid": "minValueFilter",
            lang: i18n.locale,
            name: "minValue",
            type: "number",
            value: minAmount,
            onInput: (e2) => {
              e2.currentTarget && setMinAmount(e2.currentTarget.value !== "" ? e2.currentTarget.value : void 0);
            },
            min: 0,
            isInvalid: minAmount ? minAmount < 0 : false,
            errorMessage: i18n.get("noNegativeNumbersAllowed")
          }
        )
      ] }),
      /* @__PURE__ */ u$1("div", { className: "adyen-pe-range-selection-filter__input", children: [
        /* @__PURE__ */ u$1("label", { htmlFor: "maxValue", children: `${i18n.get("to")}:` }),
        /* @__PURE__ */ u$1(
          InputBase$1,
          {
            "data-testid": "maxValueFilter",
            lang: i18n.locale,
            name: "maxValue",
            type: "number",
            value: maxAmount,
            onInput: (e2) => {
              e2.currentTarget && setMaxAmount(e2.currentTarget.value !== "" ? e2.currentTarget.value : void 0);
            },
            min: minAmount,
            isInvalid: !isUndefined(maxAmount) && !isUndefined(minAmount) && maxAmount < minAmount,
            errorMessage: i18n.get("toValueShouldBeGreaterThanTheFromValue")
          }
        )
      ] })
    ] });
  };
  const AmountFilter = ({ updateFilters, selectedCurrencies, availableCurrencies, ...props }) => {
    const { i18n } = useCoreContext();
    const [value2, setValue] = d();
    const [formattedValue, setValueFormattedValue] = d();
    const showCurrencySymbol = T$1(() => {
      return (selectedCurrencies == null ? void 0 : selectedCurrencies.length) === 1 || (availableCurrencies == null ? void 0 : availableCurrencies.length) === 1;
    }, [availableCurrencies == null ? void 0 : availableCurrencies.length, selectedCurrencies == null ? void 0 : selectedCurrencies.length]);
    const formatAmount2 = q$1(
      (amount2, showSymbol) => {
        const currencyCode = (selectedCurrencies == null ? void 0 : selectedCurrencies[0]) || (availableCurrencies == null ? void 0 : availableCurrencies[0]);
        const options = showSymbol && currencyCode ? {
          style: "currency",
          currency: currencyCode,
          currencyDisplay: "symbol"
        } : void 0;
        return amount2.toLocaleString(i18n.locale, options);
      },
      [availableCurrencies, i18n, selectedCurrencies]
    );
    const onFilterChange = q$1(
      (params) => {
        const { minAmount, maxAmount } = params ?? EMPTY_OBJECT;
        setValue({ minAmount, maxAmount });
        if (isUndefined(minAmount) && isUndefined(maxAmount)) setValueFormattedValue(void 0);
        updateFilters({
          minAmount: !isUndefined(minAmount) ? String(Math.round(minAmount * AMOUNT_MULTIPLIER)) : void 0,
          maxAmount: !isUndefined(maxAmount) ? String(Math.round(maxAmount * AMOUNT_MULTIPLIER)) : void 0
        });
      },
      [updateFilters]
    );
    if (value2 && (value2.minAmount || value2.maxAmount)) {
      const { minAmount, maxAmount } = value2 ?? {};
      if (!isUndefined(minAmount) && !isUndefined(maxAmount) && minAmount <= maxAmount) {
        setValueFormattedValue(
          `${formatAmount2(minAmount, showCurrencySymbol)} ${i18n.get("to").toLowerCase()} ${formatAmount2(maxAmount, showCurrencySymbol)}`
        );
      } else if (!isUndefined(minAmount) && isUndefined(maxAmount) && minAmount >= 0) {
        setValueFormattedValue(`${i18n.get("from")} ${formatAmount2(minAmount, showCurrencySymbol)}`);
      } else if (isUndefined(minAmount) && !isUndefined(maxAmount)) {
        setValueFormattedValue(`${i18n.get("to")} ${formatAmount2(maxAmount, showCurrencySymbol)}`);
      } else {
        setValueFormattedValue(void 0);
      }
    }
    return /* @__PURE__ */ u$1(
      BaseFilter$1,
      {
        ...props,
        updateFilters,
        minAmount: props.minAmount,
        maxAmount: props.maxAmount,
        onChange: onFilterChange,
        value: formattedValue,
        label: formattedValue ? formattedValue : props.label,
        type: "text",
        containerSize: PopoverContainerSize.MEDIUM,
        selectedCurrencies,
        availableCurrencies,
        render: RangeSelection
      }
    );
  };
  const _BASE_CLASS = "adyen-pe-transactions";
  const BASE_CLASS$b = `${_BASE_CLASS}-overview`;
  const BASE_CLASS_DETAILS = `${_BASE_CLASS}-details`;
  const SUMMARY_CLASS = `${BASE_CLASS$b}__summary`;
  const SUMMARY_ITEM_CLASS = `${SUMMARY_CLASS}-item`;
  const MAX_TRANSACTIONS_DATE_RANGE_MONTHS = 24;
  const TransactionsOverview = ({
    onFiltersChanged,
    balanceAccounts,
    allowLimitSelection = true,
    preferredLimit = DEFAULT_PAGE_LIMIT,
    onRecordSelection,
    showDetails,
    isLoadingBalanceAccount,
    onContactSupport,
    hideTitle,
    dataCustomization
  }) => {
    var _a2, _b2, _c2, _d2;
    const { i18n } = useCoreContext();
    const { getTransactions: transactionsEndpointCall } = useConfigContext().endpoints;
    const { activeBalanceAccount, balanceAccountSelectionOptions, onBalanceAccountSelection } = useBalanceAccountSelection(balanceAccounts);
    const { defaultParams, nowTimestamp: nowTimestamp2, refreshNowTimestamp } = useDefaultOverviewFilterParams("transactions", activeBalanceAccount);
    const getTransactions = q$1(
      async ({ balanceAccount: balanceAccount2, ...pageRequestParams }, signal) => {
        const requestOptions = { signal, errorLevel: "error" };
        return transactionsEndpointCall(requestOptions, {
          query: {
            ...pageRequestParams,
            statuses: listFrom(pageRequestParams[FilterParam.STATUSES]),
            categories: listFrom(pageRequestParams[FilterParam.CATEGORIES]),
            currencies: listFrom(pageRequestParams[FilterParam.CURRENCIES]),
            createdSince: pageRequestParams[FilterParam.CREATED_SINCE] ?? defaultParams.current.defaultFilterParams[FilterParam.CREATED_SINCE],
            createdUntil: pageRequestParams[FilterParam.CREATED_UNTIL] ?? defaultParams.current.defaultFilterParams[FilterParam.CREATED_UNTIL],
            sortDirection: "desc",
            balanceAccountId: (activeBalanceAccount == null ? void 0 : activeBalanceAccount.id) ?? "",
            minAmount: !isUndefined(pageRequestParams.minAmount) ? parseFloat(pageRequestParams.minAmount) : void 0,
            maxAmount: !isUndefined(pageRequestParams.maxAmount) ? parseFloat(pageRequestParams.maxAmount) : void 0
          }
        });
      },
      [activeBalanceAccount == null ? void 0 : activeBalanceAccount.id, defaultParams, transactionsEndpointCall]
    );
    const filterBarState = useFilterBarState();
    const _onFiltersChanged = T$1(() => isFunction(onFiltersChanged) ? onFiltersChanged : void 0, [onFiltersChanged]);
    const preferredLimitOptions = T$1(() => allowLimitSelection ? LIMIT_OPTIONS : void 0, [allowLimitSelection]);
    const { canResetFilters, error, fetching, filters, limit, limitOptions, records, resetFilters, updateFilters, updateLimit, ...paginationProps } = useCursorPaginatedRecords({
      fetchRecords: getTransactions,
      dataField: "data",
      filterParams: defaultParams.current.defaultFilterParams,
      initialFiltersSameAsDefault: true,
      onFiltersChanged: _onFiltersChanged,
      preferredLimit,
      preferredLimitOptions,
      enabled: !!(activeBalanceAccount == null ? void 0 : activeBalanceAccount.id) && !!transactionsEndpointCall
    });
    const [availableCurrencies, setAvailableCurrencies] = d([]);
    const [isAvailableCurrenciesFetching, setIsAvailableCurrenciesFetching] = d(false);
    const handleCurrenciesChange = q$1((currencies, isFetching) => {
      setAvailableCurrencies(currencies);
      setIsAvailableCurrenciesFetching(isFetching);
    }, []);
    const { categoriesFilter, currenciesFilter, statusesFilter } = useTransactionsOverviewMultiSelectionFilters(
      {
        filters,
        updateFilters
      },
      availableCurrencies
    );
    y(() => {
      setAvailableCurrencies(void 0);
      updateFilters({
        [FilterParam.BALANCE_ACCOUNT]: activeBalanceAccount == null ? void 0 : activeBalanceAccount.id,
        [FilterParam.CURRENCIES]: void 0
      });
    }, [updateFilters, activeBalanceAccount == null ? void 0 : activeBalanceAccount.id]);
    y(() => {
      refreshNowTimestamp();
    }, [filters, refreshNowTimestamp]);
    y(() => {
      statusesFilter.updateSelection({ target: { value: "Booked", name: "status" } });
    }, [statusesFilter]);
    const isNarrowContainer = useResponsiveContainer(containerQueries.down.sm);
    const hasMultipleCurrencies = !!availableCurrencies && availableCurrencies.length > 1;
    const transactionDetails2 = T$1(
      () => ({
        showDetails: showDetails ?? true,
        callback: onRecordSelection
      }),
      [showDetails, onRecordSelection]
    );
    const modalOptions = T$1(() => ({ transaction: transactionDetails2 }), [transactionDetails2]);
    const mergeCustomData = q$1(
      ({ records: records2, retrievedData }) => mergeRecords(records2, retrievedData, (modifiedRecord, record) => modifiedRecord.id === record.id),
      []
    );
    const hasCustomColumn = T$1(() => {
      var _a3;
      return hasCustomField((_a3 = dataCustomization == null ? void 0 : dataCustomization.list) == null ? void 0 : _a3.fields, TRANSACTION_FIELDS);
    }, [(_a2 = dataCustomization == null ? void 0 : dataCustomization.list) == null ? void 0 : _a2.fields]);
    const { customRecords: transactions2, loadingCustomRecords } = useCustomColumnsData({
      records,
      hasCustomColumn,
      onDataRetrieve: (_b2 = dataCustomization == null ? void 0 : dataCustomization.list) == null ? void 0 : _b2.onDataRetrieve,
      mergeCustomData
    });
    const { updateDetails, resetDetails, selectedDetail } = useModalDetails(modalOptions);
    const onRowClick = q$1(
      ({ id: id2 }) => {
        updateDetails({
          selection: {
            type: "transaction",
            data: id2,
            balanceAccount: activeBalanceAccount || ""
          },
          modalSize: "small"
        }).callback({ id: id2 });
      },
      [activeBalanceAccount, updateDetails]
    );
    const sinceDate = T$1(() => {
      const date2 = new Date(nowTimestamp2);
      date2.setMonth(date2.getMonth() - MAX_TRANSACTIONS_DATE_RANGE_MONTHS);
      return date2.toString();
    }, [nowTimestamp2]);
    return /* @__PURE__ */ u$1("div", { className: BASE_CLASS$b, children: [
      /* @__PURE__ */ u$1(Header, { hideTitle, titleKey: "transactionsOverviewTitle", children: /* @__PURE__ */ u$1(FilterBarMobileSwitch, { ...filterBarState }) }),
      /* @__PURE__ */ u$1(FilterBar, { ...filterBarState, children: [
        /* @__PURE__ */ u$1(
          BalanceAccountSelector,
          {
            activeBalanceAccount,
            balanceAccountSelectionOptions,
            onBalanceAccountSelection
          }
        ),
        /* @__PURE__ */ u$1(
          DateFilter,
          {
            canResetFilters,
            defaultParams,
            filters,
            nowTimestamp: nowTimestamp2,
            refreshNowTimestamp,
            sinceDate,
            timezone: activeBalanceAccount == null ? void 0 : activeBalanceAccount.timeZone,
            updateFilters
          }
        ),
        /* @__PURE__ */ u$1(MultiSelectionFilter, { ...categoriesFilter, placeholder: i18n.get("filterPlaceholder.category") }),
        /* @__PURE__ */ u$1(
          AmountFilter,
          {
            availableCurrencies,
            selectedCurrencies: listFrom(filters[FilterParam.CURRENCIES]),
            name: "range",
            label: i18n.get("amount"),
            minAmount: filters[FilterParam.MIN_AMOUNT],
            maxAmount: filters[FilterParam.MAX_AMOUNT],
            updateFilters,
            onChange: updateFilters
          }
        ),
        /* @__PURE__ */ u$1(MultiSelectionFilter, { ...currenciesFilter, placeholder: i18n.get("filterPlaceholder.currency") })
      ] }),
      /* @__PURE__ */ u$1("div", { className: SUMMARY_CLASS, children: [
        /* @__PURE__ */ u$1("div", { className: SUMMARY_ITEM_CLASS, children: /* @__PURE__ */ u$1(
          TransactionTotals,
          {
            availableCurrencies,
            isAvailableCurrenciesFetching,
            balanceAccountId: activeBalanceAccount == null ? void 0 : activeBalanceAccount.id,
            statuses: statusesFilter.selection,
            categories: categoriesFilter.selection,
            createdUntil: filters[FilterParam.CREATED_UNTIL],
            createdSince: filters[FilterParam.CREATED_SINCE],
            currencies: currenciesFilter.selection,
            minAmount: filters[FilterParam.MIN_AMOUNT] ? parseFloat(filters[FilterParam.MIN_AMOUNT]) : void 0,
            maxAmount: filters[FilterParam.MAX_AMOUNT] ? parseFloat(filters[FilterParam.MAX_AMOUNT]) : void 0,
            fullWidth: isNarrowContainer
          }
        ) }),
        /* @__PURE__ */ u$1("div", { className: SUMMARY_ITEM_CLASS, children: /* @__PURE__ */ u$1(
          Balances,
          {
            balanceAccountId: activeBalanceAccount == null ? void 0 : activeBalanceAccount.id,
            onCurrenciesChange: handleCurrenciesChange,
            defaultCurrencyCode: activeBalanceAccount == null ? void 0 : activeBalanceAccount.defaultCurrencyCode,
            fullWidth: isNarrowContainer
          }
        ) })
      ] }),
      /* @__PURE__ */ u$1(
        DataDetailsModal,
        {
          dataCustomization: dataCustomization == null ? void 0 : dataCustomization.details,
          selectedDetail,
          resetDetails,
          className: BASE_CLASS_DETAILS,
          children: /* @__PURE__ */ u$1(
            TransactionsTable,
            {
              activeBalanceAccount,
              availableCurrencies,
              error,
              hasMultipleCurrencies,
              limit,
              limitOptions,
              loading: fetching || isLoadingBalanceAccount || !balanceAccounts || loadingCustomRecords,
              onContactSupport,
              onLimitSelection: updateLimit,
              onRowClick,
              showPagination: true,
              transactions: ((_c2 = dataCustomization == null ? void 0 : dataCustomization.list) == null ? void 0 : _c2.onDataRetrieve) ? transactions2 : records,
              customColumns: (_d2 = dataCustomization == null ? void 0 : dataCustomization.list) == null ? void 0 : _d2.fields,
              ...paginationProps
            }
          )
        }
      )
    ] });
  };
  const BASE_CLASS$a = "adyen-pe-transactions-overview-container";
  function TransactionsOverviewContainer({ ...props }) {
    const { balanceAccounts, isBalanceAccountIdWrong, isFetching, error } = useBalanceAccounts(props.balanceAccountId);
    return /* @__PURE__ */ u$1(
      DataOverviewContainer,
      {
        balanceAccountsError: error,
        className: BASE_CLASS$a,
        errorMessage: "weCouldNotLoadTheTransactionsOverview",
        isBalanceAccountIdWrong,
        onContactSupport: props.onContactSupport,
        children: /* @__PURE__ */ u$1(TransactionsOverview, { ...props, balanceAccounts, isLoadingBalanceAccount: isFetching })
      }
    );
  }
  class TransactionsElement extends UIElement {
    constructor(props) {
      super(props);
      __publicField(this, "componentToRender", () => {
        return /* @__PURE__ */ u$1(
          TransactionsOverviewContainer,
          {
            ...this.props,
            balanceAccountId: this.props.balanceAccountId,
            ref: (ref) => void (this.componentRef = ref)
          }
        );
      });
      this.componentToRender = this.componentToRender.bind(this);
    }
  }
  __publicField(TransactionsElement, "type", "transactions");
  var SupportedLocation = /* @__PURE__ */ ((SupportedLocation2) => {
    SupportedLocation2["AU"] = "AU";
    SupportedLocation2["EU"] = "EU";
    SupportedLocation2["GB"] = "GB";
    SupportedLocation2["US"] = "US";
    SupportedLocation2["CA"] = "CA";
    return SupportedLocation2;
  })(SupportedLocation || {});
  const supportedCountries = ["AU", "GB", "US", "CA"];
  const supportedRegions = ["EU"];
  const getCapitalRegion = (legalEntity) => {
    var _a2;
    const capitalRegion = (_a2 = legalEntity == null ? void 0 : legalEntity.regions) == null ? void 0 : _a2.find((region) => region.type === "capital");
    return (capitalRegion == null ? void 0 : capitalRegion.value) ?? "";
  };
  const getSubtitleByRegion = (region) => {
    switch (region) {
      case SupportedLocation.EU:
        return "capital.legalSubtitleEU";
      default:
        return null;
    }
  };
  const getSubtitleByCountry = (countryCode) => {
    switch (countryCode) {
      case SupportedLocation.AU:
        return "capital.legalSubtitleAU";
      case SupportedLocation.GB:
        return "capital.legalSubtitleGB";
      case SupportedLocation.US:
        return "capital.legalSubtitleUS";
      case SupportedLocation.CA:
        return "capital.legalSubtitleCA";
      default:
        return null;
    }
  };
  const getCapitalHeaderSubtitleByLegalEntity = (legalEntity) => {
    const region = getCapitalRegion(legalEntity);
    const countryCode = legalEntity == null ? void 0 : legalEntity.countryCode;
    return getSubtitleByCountry(countryCode) ?? getSubtitleByRegion(region);
  };
  const isCapitalRegionSupported = (legalEntity) => {
    const region = getCapitalRegion(legalEntity);
    const countryCode = (legalEntity == null ? void 0 : legalEntity.countryCode) ?? "";
    return supportedCountries.includes(countryCode) || supportedRegions.includes(region);
  };
  const COMMON_CAPITAL_ERROR_MESSAGE = {
    contactSupportForHelp: "contactSupportForHelp",
    couldNotLoadOffers: "capital.weCouldNotLoadFinancialOffers",
    tryRefreshingThePage: "tryRefreshingThePageOrComeBackLater",
    somethingWentWrong: "somethingWentWrong"
  };
  const UNKNOWN_ERROR = {
    title: COMMON_CAPITAL_ERROR_MESSAGE.somethingWentWrong,
    message: [COMMON_CAPITAL_ERROR_MESSAGE.couldNotLoadOffers, COMMON_CAPITAL_ERROR_MESSAGE.tryRefreshingThePage],
    refreshComponent: true
  };
  const getCapitalErrorMessage = (error, onContactSupport) => {
    if (!error) return UNKNOWN_ERROR;
    const commonError = getCommonErrorMessage(error, onContactSupport);
    if (commonError) return commonError;
    const errorCodeMessage = onContactSupport ? "theErrorCodeIs" : "contactSupportForHelpAndShareErrorCode";
    switch (error.errorCode) {
      case void 0:
        return { ...UNKNOWN_ERROR, ...onContactSupport ? { onContactSupport } : {} };
      case "30_016": {
        return {
          title: COMMON_CAPITAL_ERROR_MESSAGE.somethingWentWrong,
          message: [COMMON_CAPITAL_ERROR_MESSAGE.couldNotLoadOffers, errorCodeMessage],
          translationValues: {
            [errorCodeMessage]: error.requestId ? /* @__PURE__ */ u$1(CopyText, { textToCopy: error.requestId }) : null
          },
          onContactSupport
        };
      }
      case "30_011": {
        return {
          title: "capital.accountIsInactive",
          message: [COMMON_CAPITAL_ERROR_MESSAGE.couldNotLoadOffers, errorCodeMessage],
          translationValues: {
            [errorCodeMessage]: error.requestId ? /* @__PURE__ */ u$1(CopyText, { textToCopy: error.requestId }) : null
          },
          onContactSupport
        };
      }
      case "30_600": {
        return {
          title: COMMON_CAPITAL_ERROR_MESSAGE.somethingWentWrong,
          message: ["capital.weCouldNotContinueWithTheOffer", errorCodeMessage],
          translationValues: {
            [errorCodeMessage]: error.requestId ? /* @__PURE__ */ u$1(CopyText, { textToCopy: error.requestId }) : null
          },
          onContactSupport
        };
      }
      case "EMPTY_CONFIG": {
        return {
          title: COMMON_CAPITAL_ERROR_MESSAGE.somethingWentWrong,
          message: ["capital.weCouldNotContinueWithTheOffer", COMMON_CAPITAL_ERROR_MESSAGE.contactSupportForHelp]
        };
      }
      case "UNSUPPORTED_REGION": {
        return {
          title: "capital.unsupportedRegionTitle",
          message: "capital.unsupportedRegionDescription"
        };
      }
      default:
        return { ...UNKNOWN_ERROR, refreshComponent: true };
    }
  };
  const CapitalErrorMessageDisplay = ({
    emptyGrantOffer,
    error,
    onContactSupport,
    onBack,
    unsupportedRegion
  }) => {
    const { i18n } = useCoreContext();
    const renderSecondaryButton = q$1(
      () => /* @__PURE__ */ u$1(k$1, { children: onBack && /* @__PURE__ */ u$1(Button$1, { variant: ButtonVariant.SECONDARY, onClick: onBack, children: i18n.get("back") }) }),
      [i18n, onBack]
    );
    const capitalError = T$1(() => {
      if (unsupportedRegion) {
        return new AdyenPlatformExperienceError(ErrorTypes.ERROR, "UnsupportedRegion", "Unsupported Region Configuration", "UNSUPPORTED_REGION");
      }
      if (emptyGrantOffer) {
        return new AdyenPlatformExperienceError(ErrorTypes.ERROR, "EmptyConfig", "Empty Configuration", "EMPTY_CONFIG");
      }
      return error;
    }, [emptyGrantOffer, unsupportedRegion, error]);
    return /* @__PURE__ */ u$1(
      ErrorMessageDisplay,
      {
        absolutePosition: false,
        withImage: true,
        onContactSupport,
        renderSecondaryButton,
        outlined: false,
        ...getCapitalErrorMessage(capitalError, onContactSupport)
      }
    );
  };
  const CAPITAL_OFFER_CLASS_NAMES = {
    base: "adyen-pe-capital-offer",
    errorContainer: "adyen-pe-capital-offer__error-container"
  };
  const CapitalHeader = (props) => {
    var _a2;
    const legalEntity = (_a2 = useConfigContext().extraConfig) == null ? void 0 : _a2.legalEntity;
    const subtitle = T$1(() => {
      const subtitleKey = getCapitalHeaderSubtitleByLegalEntity(legalEntity);
      return subtitleKey ? { subtitleKey } : {};
    }, [legalEntity]);
    return /* @__PURE__ */ u$1(Header, { ...props, ...subtitle, subtitleConfig: { variant: TypographyVariant.CAPTION, classNames: "adyen-pe-capital-header__subtitle" } });
  };
  const InfoBox = ({ className, el: InfoBoxTag = "div", children }) => /* @__PURE__ */ u$1(InfoBoxTag, { className: cx("adyen-pe-info-box", className), children });
  const dateStartUTCTimestampOffset = (date2, numberOfDays = 0) => {
    return new Date(new Date(date2).setUTCHours(0, 0, 0, 0) + Math.floor(numberOfDays) * DAY_MS);
  };
  const getExpectedRepaymentDate = (expectedRepaymentPeriodDays) => {
    return parseDate(dateStartUTCTimestampOffset(/* @__PURE__ */ new Date(), expectedRepaymentPeriodDays));
  };
  const calculateMaximumRepaymentPeriodInMonths = (days) => days ? Math.ceil(days / 30) : null;
  const debounce = (func, delay) => {
    let timeoutId;
    let lastArgs;
    function debounced(...args) {
      clearTimeout(timeoutId);
      lastArgs = args;
      timeoutId = setTimeout(() => {
        func(lastArgs);
        lastArgs = void 0;
      }, delay);
    }
    debounced.cancel = () => {
      if (timeoutId) {
        clearTimeout(timeoutId);
        timeoutId = void 0;
        lastArgs = void 0;
      }
    };
    return debounced;
  };
  const getPercentage = (rate) => {
    return rate / 100;
  };
  function calculateProgress(currentValue, min2, max2, step) {
    if (min2 >= max2) return 0;
    const effectiveStep = step > 0 ? step : 1;
    if (effectiveStep > max2 - min2) return 0;
    const snappedValue = Math.round((currentValue - min2) / effectiveStep) * effectiveStep + min2;
    const percentage = (snappedValue - min2) * 100 / (max2 - min2);
    return Number(clamp(0, percentage, 100).toFixed(2));
  }
  function calculateSliderAdjustedMidValue(minValue, maxValue, step) {
    const mid2 = maxValue / 2;
    let adjustedMid = Math.round(mid2 / step) * step;
    if (adjustedMid < minValue) {
      adjustedMid = minValue;
    } else if (adjustedMid > maxValue) {
      adjustedMid = maxValue;
    }
    return adjustedMid;
  }
  const Slider = ({ min: min2 = 0, max: max2 = 100, step = 1, value: value2 = min2, onChange, className, ...restOfProps }) => {
    const progress = T$1(() => {
      return calculateProgress(value2, min2, max2, step);
    }, [value2, min2, max2, step]);
    return /* @__PURE__ */ u$1(
      "input",
      {
        type: "range",
        className: cx("adyen-pe-slider", className),
        min: min2,
        max: max2,
        step,
        value: value2,
        onChange,
        style: { backgroundSize: `${progress}% 100%` },
        ...restOfProps
      }
    );
  };
  const CapitalSlider = ({
    dynamicOffersConfig,
    value: value2 = dynamicOffersConfig.minAmount.value,
    onValueChange,
    onRelease,
    className
  }) => {
    const id2 = uniqueId();
    const { i18n } = useCoreContext();
    const handleValueChange = (event) => {
      const value22 = Number(event.target.value);
      onValueChange == null ? void 0 : onValueChange(value22);
    };
    const handleRelease = (event) => {
      const value22 = Number(event.target.value);
      onRelease == null ? void 0 : onRelease(value22);
    };
    return /* @__PURE__ */ u$1("div", { className: cx("adyen-pe-capital-slider", className), children: [
      /* @__PURE__ */ u$1("label", { htmlFor: id2, className: "adyen-pe-capital-slider__label", children: /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.BODY, stronger: true, children: i18n.get("capital.howMuchMoneyDoYouNeed") }) }),
      /* @__PURE__ */ u$1("div", { children: [
        /* @__PURE__ */ u$1("output", { htmlFor: id2, className: "adyen-pe-capital-slider__value", "aria-live": "polite", children: /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.TITLE, strongest: true, children: i18n.amount(value2, dynamicOffersConfig.minAmount.currency, { maximumFractionDigits: 0 }) }) }),
        /* @__PURE__ */ u$1(
          Slider,
          {
            id: id2,
            value: value2,
            min: dynamicOffersConfig.minAmount.value,
            max: dynamicOffersConfig.maxAmount.value,
            step: dynamicOffersConfig.step,
            onChange: handleValueChange,
            onMouseUp: handleRelease,
            onTouchEnd: handleRelease,
            onKeyUp: handleRelease,
            className: "adyen-pe-capital-slider__input"
          }
        )
      ] }),
      /* @__PURE__ */ u$1("div", { className: "adyen-pe-capital-slider__labels", children: [
        /* @__PURE__ */ u$1("label", { children: [
          /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.CAPTION, children: i18n.get("min") }),
          /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.BODY, children: i18n.amount(dynamicOffersConfig.minAmount.value, dynamicOffersConfig.minAmount.currency, { maximumFractionDigits: 0 }) })
        ] }),
        /* @__PURE__ */ u$1("label", { children: [
          /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.CAPTION, children: i18n.get("max") }),
          /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.BODY, children: i18n.amount(dynamicOffersConfig.maxAmount.value, dynamicOffersConfig.maxAmount.currency, { maximumFractionDigits: 0 }) })
        ] })
      ] })
    ] });
  };
  const CAPITAL_REPAYMENT_FREQUENCY = 30;
  const LoadingSkeleton = () => /* @__PURE__ */ u$1("div", { className: "adyen-pe-capital-offer-selection__loading-container", children: [...Array(4)].map((_2, index) => /* @__PURE__ */ u$1("div", { className: "adyen-pe-capital-offer-selection__loading-skeleton" }, index)) });
  const InformationDisplay = ({ data }) => {
    const { i18n } = useCoreContext();
    const expectedRepaymentDate = T$1(() => {
      const date2 = data.expectedRepaymentPeriodDays && getExpectedRepaymentDate(data.expectedRepaymentPeriodDays);
      if (date2) return i18n.date(date2, { month: "long" });
      return null;
    }, [data, i18n]);
    return /* @__PURE__ */ u$1("div", { className: "adyen-pe-capital-offer-selection__information", children: [
      /* @__PURE__ */ u$1(Typography$1, { el: TypographyElement.SPAN, variant: TypographyVariant.BODY, wide: true, children: expectedRepaymentDate && i18n.get("capital.youWillNeedToRepayAMinimumOfXEveryXDaysToPayOffTheFunds", {
        values: {
          amount: i18n.amount(data.thresholdAmount.value, data.thresholdAmount.currency),
          days: CAPITAL_REPAYMENT_FREQUENCY,
          date: expectedRepaymentDate
        }
      }) }),
      /* @__PURE__ */ u$1(
        StructuredList,
        {
          renderValue: (val) => /* @__PURE__ */ u$1(Typography$1, { el: TypographyElement.SPAN, stronger: true, variant: TypographyVariant.CAPTION, children: val }),
          renderLabel: (val) => /* @__PURE__ */ u$1(Typography$1, { el: TypographyElement.SPAN, variant: TypographyVariant.CAPTION, children: val }),
          items: [
            { key: "capital.fees", value: i18n.amount(data.feesAmount.value, data.feesAmount.currency) },
            {
              key: "capital.dailyRepaymentRate",
              value: `${i18n.get("capital.xPercent", {
                values: { percentage: getPercentage(data.repaymentRate) }
              })}`
            },
            {
              key: "capital.expectedRepaymentPeriod",
              value: i18n.get("capital.xDays", { values: { days: data.expectedRepaymentPeriodDays } })
            }
          ]
        }
      )
    ] });
  };
  const CapitalOfferSelection = ({
    dynamicOffersConfig,
    dynamicOffersConfigError,
    emptyGrantOffer,
    onContactSupport,
    onOfferDismiss,
    onOfferSelect,
    requestedAmount
  }) => {
    const { i18n } = useCoreContext();
    const initialValue = T$1(() => {
      if (dynamicOffersConfig)
        return calculateSliderAdjustedMidValue(
          dynamicOffersConfig.minAmount.value,
          dynamicOffersConfig.maxAmount.value,
          dynamicOffersConfig.step
        );
      return void 0;
    }, [dynamicOffersConfig]);
    const [requestedValue, setRequestedValue] = d(void 0);
    const currency2 = T$1(() => dynamicOffersConfig == null ? void 0 : dynamicOffersConfig.minAmount.currency, [dynamicOffersConfig == null ? void 0 : dynamicOffersConfig.minAmount.currency]);
    const { createGrantOffer, getDynamicGrantOffer } = useConfigContext().endpoints;
    const getDynamicGrantOfferMutation = useMutation({
      queryFn: getDynamicGrantOffer,
      options: {
        retry: 1,
        shouldRetry: q$1((error) => {
          return error.status === 500;
        }, []),
        onSettled: q$1(() => {
          setIsLoading(false);
        }, [])
      }
    });
    const reviewOfferMutation = useMutation({
      queryFn: createGrantOffer,
      options: {
        onSuccess: (data) => onOfferSelect(data)
      }
    });
    const onReview = q$1(() => {
      var _a2, _b2;
      void reviewOfferMutation.mutate({
        body: {
          amount: ((_a2 = getDynamicGrantOfferMutation.data) == null ? void 0 : _a2.grantAmount.value) || requestedValue,
          currency: ((_b2 = getDynamicGrantOfferMutation.data) == null ? void 0 : _b2.grantAmount.currency) || currency2
        },
        contentType: "application/json"
      });
    }, [currency2, getDynamicGrantOfferMutation.data, requestedValue, reviewOfferMutation]);
    const getOffer = q$1(
      (amount2) => getDynamicGrantOfferMutation.mutate({}, { query: { amount: amount2, currency: currency2 } }),
      [currency2, getDynamicGrantOfferMutation]
    );
    const [isLoading, setIsLoading] = d(false);
    const debouncedGetOfferCall = debounce(getOffer, 300);
    const onChangeHandler = q$1(
      (val) => {
        debouncedGetOfferCall.cancel();
        setIsLoading(true);
        setRequestedValue(val);
      },
      [debouncedGetOfferCall]
    );
    const handleSliderRelease = (val) => debouncedGetOfferCall(val);
    y(() => {
      if (dynamicOffersConfig && !getDynamicGrantOfferMutation.data && !requestedValue) {
        setRequestedValue(
          (prev) => !prev ? requestedAmount ? Number(requestedAmount) : initialValue || dynamicOffersConfig.minAmount.value : prev
        );
        void getOffer(requestedValue || initialValue || dynamicOffersConfig.minAmount.value);
      }
    }, [dynamicOffersConfig, getDynamicGrantOfferMutation.data, getOffer, initialValue, requestedAmount, requestedValue]);
    const loadingButtonState = T$1(
      () => reviewOfferMutation.isLoading || getDynamicGrantOfferMutation.isLoading || isLoading,
      [getDynamicGrantOfferMutation.isLoading, isLoading, reviewOfferMutation.isLoading]
    );
    return /* @__PURE__ */ u$1("div", { className: "adyen-pe-capital-offer-selection", children: reviewOfferMutation.error || getDynamicGrantOfferMutation.error || emptyGrantOffer || dynamicOffersConfigError ? /* @__PURE__ */ u$1(
      CapitalErrorMessageDisplay,
      {
        error: reviewOfferMutation.error || getDynamicGrantOfferMutation.error || dynamicOffersConfigError,
        onBack: onOfferDismiss,
        onContactSupport,
        emptyGrantOffer
      }
    ) : /* @__PURE__ */ u$1(k$1, { children: [
      dynamicOffersConfig && /* @__PURE__ */ u$1(
        CapitalSlider,
        {
          value: requestedValue,
          dynamicOffersConfig,
          onValueChange: onChangeHandler,
          onRelease: handleSliderRelease
        }
      ),
      /* @__PURE__ */ u$1(InfoBox, { className: "adyen-pe-capital-offer-selection__details", children: !getDynamicGrantOfferMutation.data || getDynamicGrantOfferMutation.isLoading || isLoading ? /* @__PURE__ */ u$1(LoadingSkeleton, {}) : getDynamicGrantOfferMutation.data ? /* @__PURE__ */ u$1(InformationDisplay, { data: getDynamicGrantOfferMutation.data }) : null }),
      /* @__PURE__ */ u$1("div", { className: "adyen-pe-capital-offer-selection__buttons", children: [
        onOfferDismiss && /* @__PURE__ */ u$1(Button$1, { variant: ButtonVariant.SECONDARY, onClick: onOfferDismiss, children: i18n.get("back") }),
        /* @__PURE__ */ u$1(
          Button$1,
          {
            variant: ButtonVariant.PRIMARY,
            state: loadingButtonState ? "loading" : void 0,
            onClick: onReview,
            disabled: reviewOfferMutation.isLoading || !(dynamicOffersConfig == null ? void 0 : dynamicOffersConfig.minAmount),
            children: i18n.get(loadingButtonState ? "loading" : "capital.reviewOffer")
          }
        )
      ] })
    ] }) });
  };
  const AnchorButton = (props, ref) => {
    const { variant = ButtonVariant.PRIMARY, disabled = false, onClick, classNameModifiers = [], className } = props;
    const classNameValue = T$1(() => parseClassName("", className) || "", [className]);
    const disabledValue = T$1(() => parseBooleanProp(disabled), [disabled]);
    const { click, allChildren, allProps } = useButton(
      classNameValue,
      [...classNameModifiers, variant],
      `${DEFAULT_BUTTON_CLASSNAME} ${BUTTON_ANCHOR_CLASSNAME}`,
      disabledValue,
      props,
      onClick
    );
    const restProps = T$1(() => ({ ...allProps, ...props.onClick && click ? { onClick: click } : {} }), [click, allProps, props.onClick]);
    return /* @__PURE__ */ u$1("a", { ...restProps, href: props.href, ref, children: allChildren });
  };
  const AnchorButton$1 = fixedForwardRef(AnchorButton);
  const normalizeFill = (fill) => {
    return isFunction(fill) ? fill : () => fill;
  };
  const Translation = ({ count, defaultFill, fills, translationKey }) => {
    const { i18n } = useCoreContext();
    const getFill = T$1(() => {
      const _defaultFill = normalizeFill(defaultFill);
      if (fills !== void 0) {
        return (...args) => {
          const [placeholder, index] = args;
          for (const lookupProperty of [placeholder, index]) {
            const fill = normalizeFill(fills[lookupProperty])(...args);
            if (fill != void 0) return fill;
          }
          return _defaultFill(...args);
        };
      }
      return _defaultFill;
    }, [fills, defaultFill]);
    return T$1(() => {
      const fills2 = [];
      const placeholderFill = uniqueId("translation");
      const values = (...args) => {
        fills2.push(getFill(...args) ?? null);
        return placeholderFill;
      };
      const [firstFragment, ...restFragments] = i18n.get(translationKey, { count, values }).split(placeholderFill);
      return /* @__PURE__ */ u$1(k$1, { children: [
        firstFragment,
        restFragments.map((fragment, index) => /* @__PURE__ */ u$1(k$1, { children: [
          fills2[index],
          fragment
        ] }, `${placeholderFill}__${index}`))
      ] });
    }, [i18n, count, getFill, translationKey]);
  };
  const SUMMARY_TEXT_EMAIL = "capital-support@adyen.com";
  const CapitalOfferLegalNotice = () => {
    var _a2, _b2, _c2;
    const countryCode = (_c2 = (_b2 = (_a2 = useConfigContext()) == null ? void 0 : _a2.extraConfig) == null ? void 0 : _b2.legalEntity) == null ? void 0 : _c2.countryCode;
    return countryCode === SupportedLocation.US ? /* @__PURE__ */ u$1(Card, { filled: true, noOutline: true, children: [
      /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.CAPTION, className: "adyen-pe-capital-offer-legal-notice--title", children: /* @__PURE__ */ u$1(Translation, { translationKey: "capital.offerLegalNoticeTitleUS", fills: { break: /* @__PURE__ */ u$1("br", {}) } }) }),
      /* @__PURE__ */ u$1("br", {}),
      /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.CAPTION, className: "adyen-pe-capital-offer-legal-notice--description", children: /* @__PURE__ */ u$1(
        Translation,
        {
          translationKey: "capital.offerLegalNoticeDescriptionUS",
          fills: {
            email: /* @__PURE__ */ u$1(
              AnchorButton$1,
              {
                href: `mailto:${SUMMARY_TEXT_EMAIL}`,
                variant: ButtonVariant.TERTIARY,
                className: "adyen-pe-capital-offer-summary__info--email",
                children: SUMMARY_TEXT_EMAIL
              }
            ),
            break: /* @__PURE__ */ u$1(k$1, { children: [
              /* @__PURE__ */ u$1("br", {}),
              /* @__PURE__ */ u$1("br", {})
            ] })
          }
        }
      ) })
    ] }) : null;
  };
  const errorMessageWithAlert = ["30_013"];
  const CapitalOfferSummary = ({
    grantOffer,
    onBack,
    onFundsRequest,
    onContactSupport
  }) => {
    const { i18n } = useCoreContext();
    const expectedRepaymentDate = T$1(() => {
      const date2 = getExpectedRepaymentDate(grantOffer.expectedRepaymentPeriodDays);
      return date2 ? i18n.date(date2, { month: "long" }) : null;
    }, [grantOffer, i18n]);
    const { requestFunds } = useConfigContext().endpoints;
    const requestFundsMutation = useMutation({
      queryFn: requestFunds,
      options: {
        onSuccess: (data) => onFundsRequest == null ? void 0 : onFundsRequest(data)
      }
    });
    const requestFundsCallback = q$1(
      (id2) => {
        void requestFundsMutation.mutate(EMPTY_OBJECT, { path: { grantOfferId: id2 } });
      },
      [requestFundsMutation]
    );
    const onRequestFundsHandler = q$1(() => {
      grantOffer.id && requestFundsCallback(grantOffer.id);
    }, [grantOffer.id, requestFundsCallback]);
    const maximumRepaymentPeriod = T$1(
      () => calculateMaximumRepaymentPeriodInMonths(grantOffer.maximumRepaymentPeriodDays),
      [grantOffer.maximumRepaymentPeriodDays]
    );
    const requestErrorAlert = T$1(() => {
      const err = requestFundsMutation.error ? requestFundsMutation.error : null;
      if (err && errorMessageWithAlert.includes(err.errorCode)) {
        switch (err.errorCode) {
          case "30_013":
            return {
              title: i18n.get("capital.thereIsNoPrimaryAccountConfigured"),
              message: i18n.get("capital.weCouldNotContinueWithTheOfferContactSupportForHelp"),
              errorCode: "30_013"
            };
          default:
            return {
              title: i18n.get("somethingWentWrong"),
              message: i18n.get("capital.weCouldNotLoadFinancialOffers")
            };
        }
      }
      return null;
    }, [i18n, requestFundsMutation.error]);
    const structuredListItems = T$1(() => {
      const summaryItems = [
        {
          key: "capital.fees",
          value: i18n.amount(grantOffer.feesAmount.value, grantOffer.feesAmount.currency)
        },
        {
          key: "capital.totalRepaymentAmount",
          value: i18n.amount(grantOffer.totalAmount.value, grantOffer.totalAmount.currency)
        },
        {
          key: "capital.repaymentThreshold",
          value: i18n.amount(grantOffer.thresholdAmount.value, grantOffer.thresholdAmount.currency)
        },
        {
          key: "capital.dailyRepaymentRate",
          value: i18n.get("capital.xPercent", { values: { percentage: getPercentage(grantOffer.repaymentRate) } })
        },
        {
          key: "capital.expectedRepaymentPeriod",
          value: i18n.get("capital.xDays", { values: { days: grantOffer.expectedRepaymentPeriodDays } })
        },
        { key: "account", value: i18n.get("capital.primaryAccount") }
      ];
      if (maximumRepaymentPeriod) {
        summaryItems.splice(4, 0, {
          key: "capital.maximumRepaymentPeriod",
          value: maximumRepaymentPeriod === 1 ? i18n.get("capital.oneMonth") : i18n.get("capital.xMonths", { values: { months: maximumRepaymentPeriod } })
        });
      }
      if (grantOffer.aprBasisPoints) {
        summaryItems.splice(1, 0, {
          key: "capital.annualPercentageRate",
          value: i18n.get("capital.xPercent", { values: { percentage: getPercentage(grantOffer.aprBasisPoints) } })
        });
      }
      return summaryItems;
    }, [grantOffer, i18n, maximumRepaymentPeriod]);
    return !requestErrorAlert && requestFundsMutation.error ? /* @__PURE__ */ u$1(CapitalErrorMessageDisplay, { error: requestFundsMutation.error, onBack, onContactSupport }) : /* @__PURE__ */ u$1("div", { className: "adyen-pe-capital-offer-summary", children: [
      /* @__PURE__ */ u$1(InfoBox, { className: "adyen-pe-capital-offer-summary__grant-summary", children: [
        /* @__PURE__ */ u$1(Typography$1, { el: TypographyElement.PARAGRAPH, variant: TypographyVariant.BODY, children: [
          i18n.get("capital.youAreRequestingFundingOf"),
          " ",
          /* @__PURE__ */ u$1("strong", { children: `${i18n.amount(grantOffer.grantAmount.value, grantOffer.grantAmount.currency, { minimumFractionDigits: 0 })}.` })
        ] }),
        /* @__PURE__ */ u$1(Typography$1, { el: TypographyElement.PARAGRAPH, variant: TypographyVariant.CAPTION, children: i18n.get("capital.youWillNeedToRepayAMinimumOfXEveryXDaysToPayOffTheFunds", {
          values: {
            amount: i18n.amount(grantOffer.thresholdAmount.value, grantOffer.thresholdAmount.currency),
            days: CAPITAL_REPAYMENT_FREQUENCY,
            date: expectedRepaymentDate ?? ""
          }
        }) })
      ] }),
      /* @__PURE__ */ u$1(
        StructuredList,
        {
          classNames: "adyen-pe-capital-offer-summary__details",
          renderLabel: (val, key) => {
            if (key === "capital.repaymentThreshold") {
              return /* @__PURE__ */ u$1(
                Tooltip,
                {
                  isContainerHovered: true,
                  content: i18n.get("capital.minimumRepaymentToRepayTheFinancingOnTime", {
                    values: { days: CAPITAL_REPAYMENT_FREQUENCY }
                  }),
                  children: /* @__PURE__ */ u$1("span", { children: /* @__PURE__ */ u$1(
                    Typography$1,
                    {
                      className: "adyen-pe-capital-offer-summary__list-label",
                      el: TypographyElement.SPAN,
                      variant: TypographyVariant.CAPTION,
                      children: val
                    }
                  ) })
                }
              );
            }
            if (key === "capital.annualPercentageRate") {
              return /* @__PURE__ */ u$1(Tooltip, { isContainerHovered: true, content: i18n.get("capital.annualPercentageRateIsTheCostOfBorrowingForALoan"), children: /* @__PURE__ */ u$1("span", { children: /* @__PURE__ */ u$1(
                Typography$1,
                {
                  className: "adyen-pe-capital-offer-summary__list-label",
                  el: TypographyElement.SPAN,
                  variant: TypographyVariant.CAPTION,
                  children: val
                }
              ) }) });
            }
            return /* @__PURE__ */ u$1(
              Typography$1,
              {
                className: "adyen-pe-capital-offer-summary__list-label",
                el: TypographyElement.SPAN,
                variant: TypographyVariant.CAPTION,
                children: val
              }
            );
          },
          renderValue: (val, key) => {
            const showWarningIcon = key === "account" && requestFundsMutation.error && requestErrorAlert && requestErrorAlert.errorCode === "30_013";
            return /* @__PURE__ */ u$1(
              Typography$1,
              {
                className: cx({
                  ["adyen-pe-capital-offer-summary__details--error"]: showWarningIcon
                }),
                el: TypographyElement.SPAN,
                variant: TypographyVariant.CAPTION,
                stronger: true,
                children: [
                  showWarningIcon ? /* @__PURE__ */ u$1(Icon$1, { name: "warning-filled", "data-testid": "primary-account-warning-icon" }) : null,
                  val
                ]
              }
            );
          },
          items: structuredListItems
        }
      ),
      requestErrorAlert && /* @__PURE__ */ u$1(
        Alert,
        {
          className: "adyen-pe-capital-offer-summary__error-alert",
          type: AlertTypeOption.WARNING,
          title: requestErrorAlert.title,
          description: requestErrorAlert.message,
          children: onContactSupport ? /* @__PURE__ */ u$1(Button$1, { className: "adyen-pe-capital-offer-summary__error-alert-button", onClick: onContactSupport, children: i18n.get("contactSupport") }) : null
        }
      ),
      /* @__PURE__ */ u$1(CapitalOfferLegalNotice, {}),
      /* @__PURE__ */ u$1("div", { className: "adyen-pe-capital-offer-summary__buttons", children: [
        requestFundsMutation.error && !requestErrorAlert ? null : /* @__PURE__ */ u$1(Button$1, { variant: ButtonVariant.SECONDARY, onClick: onBack, children: i18n.get("back") }),
        /* @__PURE__ */ u$1(
          Button$1,
          {
            variant: ButtonVariant.PRIMARY,
            state: requestFundsMutation.isLoading ? "loading" : void 0,
            onClick: onRequestFundsHandler,
            disabled: requestFundsMutation.isLoading || !!requestFundsMutation.error || !!requestFundsMutation.data,
            children: i18n.get(requestFundsMutation.isLoading ? "capital.requesting" : "capital.requestFunds")
          }
        )
      ] })
    ] });
  };
  const CapitalOffer = ({
    externalDynamicOffersConfig,
    hideTitle,
    onContactSupport,
    onFundsRequest,
    onOfferDismiss,
    onOfferSelect
  }) => {
    var _a2, _b2;
    const { getDynamicGrantOffersConfiguration } = useConfigContext().endpoints;
    const legalEntity = (_b2 = (_a2 = useConfigContext()) == null ? void 0 : _a2.extraConfig) == null ? void 0 : _b2.legalEntity;
    const isRegionSupported = T$1(() => isCapitalRegionSupported(legalEntity), [legalEntity]);
    const [emptyGrantOffer, setEmptyGrantOffer] = d(false);
    const onSuccess = q$1((data) => {
      if (data) {
        setEmptyGrantOffer(false);
      } else setEmptyGrantOffer(true);
    }, []);
    const { data: internalDynamicOffersConfig, error: dynamicOffersConfigError } = useFetch({
      fetchOptions: {
        enabled: !externalDynamicOffersConfig && !!getDynamicGrantOffersConfiguration && isRegionSupported,
        onSuccess
      },
      queryFn: q$1(async () => {
        return getDynamicGrantOffersConfiguration == null ? void 0 : getDynamicGrantOffersConfiguration(EMPTY_OBJECT);
      }, [getDynamicGrantOffersConfiguration])
    });
    const config = externalDynamicOffersConfig || internalDynamicOffersConfig;
    const [selectedOffer, setSelectedOffer] = d();
    const [requestedAmount, setRequestedAmount] = d();
    const onOfferSelectHandler = q$1(
      (data) => {
        if (onOfferSelect) {
          onOfferSelect(data);
        } else {
          setRequestedAmount(data == null ? void 0 : data.grantAmount.value);
          setSelectedOffer(data);
        }
      },
      [onOfferSelect]
    );
    const capitalOfferState = T$1(() => {
      if (selectedOffer) {
        return "OfferSummary";
      }
      return "OfferSelection";
    }, [selectedOffer]);
    if (!isRegionSupported) {
      return /* @__PURE__ */ u$1("div", { className: CAPITAL_OFFER_CLASS_NAMES.errorContainer, children: [
        /* @__PURE__ */ u$1(CapitalHeader, { hideTitle, titleKey: "capital.businessFinancing" }),
        /* @__PURE__ */ u$1(CapitalErrorMessageDisplay, { unsupportedRegion: true })
      ] });
    }
    return /* @__PURE__ */ u$1("div", { className: CAPITAL_OFFER_CLASS_NAMES.base, children: [
      /* @__PURE__ */ u$1(
        CapitalHeader,
        {
          hasDivider: true,
          hideTitle,
          titleKey: capitalOfferState === "OfferSummary" ? "capital.businessFinancingSummary" : "capital.businessFinancingOffer"
        }
      ),
      capitalOfferState === "OfferSelection" && /* @__PURE__ */ u$1(
        CapitalOfferSelection,
        {
          requestedAmount,
          dynamicOffersConfig: config,
          dynamicOffersConfigError,
          onOfferDismiss,
          onOfferSelect: onOfferSelectHandler,
          emptyGrantOffer,
          onContactSupport
        }
      ),
      capitalOfferState === "OfferSummary" && /* @__PURE__ */ u$1(
        CapitalOfferSummary,
        {
          grantOffer: selectedOffer,
          onBack: () => setSelectedOffer(void 0),
          onFundsRequest,
          onContactSupport
        }
      )
    ] });
  };
  class CapitalOfferElement extends UIElement {
    constructor(props) {
      super(props);
      __publicField(this, "componentToRender", () => {
        return /* @__PURE__ */ u$1(CapitalOffer, { ...this.props });
      });
      this.componentToRender = this.componentToRender.bind(this);
      this.customClassNames = "adyen-pe-capital-offer-component";
    }
  }
  __publicField(CapitalOfferElement, "type", "capitalOffer");
  const useFreezePeriod = (timeout = 1e3, initialState = false) => {
    const [frozen, setFrozen] = d(initialState);
    const rafId = A$1();
    const timeoutId = A$1();
    const freeze = q$1(() => {
      if (frozen) return;
      timeoutId.current = setTimeout(() => {
        rafId.current = requestAnimationFrame(() => setFrozen(false));
      }, timeout);
      setFrozen(true);
    }, [frozen, timeout]);
    y(() => {
      return () => {
        cancelAnimationFrame(rafId.current);
        clearTimeout(timeoutId.current);
        rafId.current = timeoutId.current = null;
      };
    }, [timeout]);
    return { freeze, frozen };
  };
  const useDownload = (endpointName, queryParam, enabled) => {
    const downloadEndpoint = useConfigContext().endpoints[endpointName];
    return useFetch({
      fetchOptions: { enabled: !!downloadEndpoint && enabled, keepPrevData: true },
      queryFn: async () => {
        return downloadEndpoint(EMPTY_OBJECT, { ...queryParam });
      }
    });
  };
  function downloadBlob({ blob, filename }) {
    const a2 = document.createElement("a");
    const url = URL.createObjectURL(blob);
    a2.href = url;
    a2.download = filename || "download";
    const clickHandler = () => {
      setTimeout(() => {
        URL.revokeObjectURL(url);
      }, 150);
    };
    a2.addEventListener("click", clickHandler, { once: true });
    a2.click();
  }
  function DownloadButton({
    className,
    disabled,
    endpointName,
    requestParams,
    setError,
    errorDisplay,
    onDownloadRequested,
    iconButton = false,
    errorMessage
  }) {
    const { i18n } = useCoreContext();
    const [fetchData, setFetchData] = d(false);
    const isSmContainer = useResponsiveContainer(containerQueries.down.xs);
    const { data, error, isFetching } = useDownload(endpointName, requestParams, fetchData);
    y(() => {
      if (fetchData) {
        setFetchData(false);
      }
    }, [fetchData]);
    y(() => {
      if (data) {
        downloadBlob(data);
      }
    }, [data]);
    y(() => {
      if (setError && error) {
        setError(error);
      }
    }, [error, setError]);
    const onClick = () => {
      setFetchData(true);
      onDownloadRequested == null ? void 0 : onDownloadRequested();
    };
    const buttonIcon = T$1(() => isFetching ? /* @__PURE__ */ u$1(Spinner, { size: "small" }) : /* @__PURE__ */ u$1(Icon$1, { name: "download" }), [isFetching]);
    const buttonLabel = T$1(() => {
      if (iconButton) {
        return buttonIcon;
      } else {
        return isFetching ? `${i18n.get("downloading")}..` : i18n.get("download");
      }
    }, [buttonIcon, i18n, isFetching, iconButton]);
    return /* @__PURE__ */ u$1(k$1, { children: [
      /* @__PURE__ */ u$1(
        "div",
        {
          className: cx("adyen-pe-download", {
            "adyen-pe-download-icon-button-container": iconButton
          }),
          children: [
            isSmContainer ? /* @__PURE__ */ u$1(Button$1, { iconButton: true, variant: ButtonVariant.TERTIARY, onClick, children: buttonIcon }) : /* @__PURE__ */ u$1(
              Button$1,
              {
                className: cx(
                  "adyen-pe-download__button",
                  { "adyen-pe-download__button--loading": isFetching, "adyen-pe-download__button--icon": iconButton },
                  className
                ),
                disabled: disabled || isFetching,
                variant: iconButton ? ButtonVariant.TERTIARY : ButtonVariant.SECONDARY,
                onClick,
                ...!iconButton && { iconLeft: buttonIcon },
                children: buttonLabel
              }
            ),
            error && errorDisplay && /* @__PURE__ */ u$1("div", { className: "adyen-pe-download__error", children: errorDisplay })
          ]
        }
      ),
      error && errorMessage && errorMessage(error)
    ] });
  }
  const DISABLED_BUTTONS_TIMEOUT = 1e3;
  const BASE_CLASS$9 = "adyen-pe-reports-table";
  const DATE_TYPE_CLASS = `${BASE_CLASS$9}-date-report-type`;
  const DATE_TYPE_DATE_SECTION_CLASS = `${DATE_TYPE_CLASS}--date`;
  const FIELDS$1 = ["createdAt", "dateAndReportType", "reportType", "reportFile"];
  const ReportsTable = ({
    error,
    loading: loading2,
    balanceAccountId: balanceAccountId2,
    onContactSupport,
    showPagination,
    data,
    customColumns,
    ...paginationProps
  }) => {
    const { i18n } = useCoreContext();
    const { dateFormat } = useTimezoneAwareDateFormatting("UTC");
    const { freeze, frozen } = useFreezePeriod(DISABLED_BUTTONS_TIMEOUT);
    const [alert, setAlert] = d(null);
    const { refreshing } = useConfigContext();
    const isLoading = T$1(() => loading2 || refreshing, [loading2, refreshing]);
    const isSmAndUpContainer = useResponsiveContainer(containerQueries.up.sm);
    const isXsAndDownContainer = useResponsiveContainer(containerQueries.down.xs);
    const columns = useTableColumns({
      fields: FIELDS$1,
      customColumns,
      columnConfig: T$1(
        () => ({
          dateAndReportType: { visible: isXsAndDownContainer },
          createdAt: { visible: isSmAndUpContainer },
          reportType: { visible: isSmAndUpContainer },
          reportFile: { visible: true, position: isXsAndDownContainer ? "right" : void 0 }
        }),
        [isSmAndUpContainer, isXsAndDownContainer]
      )
    });
    const removeAlert = q$1(() => {
      setAlert(null);
    }, []);
    const EMPTY_TABLE_MESSAGE = {
      title: "noReportsFound",
      message: ["tryDifferentSearchOrResetYourFiltersAndWeWillTryAgain"]
    };
    const errorDisplay = T$1(
      () => () => /* @__PURE__ */ u$1(DataOverviewError, { error, errorMessage: "weCouldNotLoadYourReports", onContactSupport }),
      [error, onContactSupport]
    );
    const errorIcon = T$1(() => /* @__PURE__ */ u$1(Icon$1, { name: "warning" }), []);
    const onDownloadErrorAlert = T$1(
      () => (error2) => {
        const alertDetails = {};
        switch (error2 == null ? void 0 : error2.errorCode) {
          case "999_429_001":
            alertDetails.title = i18n.get("error.somethingWentWrongWithDownload");
            alertDetails.description = i18n.get("reportsError.tooManyDownloads");
            break;
          case "00_500":
          default:
            alertDetails.title = i18n.get("error.somethingWentWrongWithDownload");
            alertDetails.description = i18n.get("error.pleaseTryAgainLater");
            break;
        }
        setAlert(alertDetails);
      },
      [i18n]
    );
    if (loading2) setAlert(null);
    return /* @__PURE__ */ u$1("div", { className: BASE_CLASS$9, children: [
      alert && /* @__PURE__ */ u$1(Alert, { onClose: removeAlert, type: AlertTypeOption.WARNING, className: "adyen-pe-reports-table-alert", ...alert }),
      /* @__PURE__ */ u$1(
        DataGrid,
        {
          errorDisplay,
          error,
          columns,
          data,
          loading: isLoading,
          outline: false,
          emptyTableMessage: EMPTY_TABLE_MESSAGE,
          customCells: {
            createdAt: ({ value: value2 }) => {
              if (!value2) return null;
              return value2 && /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.BODY, children: dateFormat(value2, DATE_FORMAT_REPORTS) });
            },
            dateAndReportType: ({ item }) => {
              return /* @__PURE__ */ u$1("div", { className: DATE_TYPE_CLASS, children: [
                /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.BODY, stronger: true, children: i18n.get(`reportType.${item == null ? void 0 : item["type"]}`) }),
                /* @__PURE__ */ u$1(Typography$1, { className: DATE_TYPE_DATE_SECTION_CLASS, variant: TypographyVariant.BODY, children: dateFormat(item.createdAt, DATE_FORMAT_REPORTS) })
              ] });
            },
            reportType: ({ item }) => {
              return (item == null ? void 0 : item["type"]) && /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.BODY, children: i18n.get(`reportType.${item == null ? void 0 : item["type"]}`) });
            },
            reportFile: ({ item }) => {
              const queryParam = {
                query: { balanceAccountId: balanceAccountId2, createdAt: item.createdAt, type: item.type }
              };
              return /* @__PURE__ */ u$1(
                DownloadButton,
                {
                  className: "adyen-pe-reports-table--download",
                  endpointName: "downloadReport",
                  disabled: frozen,
                  requestParams: queryParam,
                  onDownloadRequested: freeze,
                  setError: onDownloadErrorAlert,
                  errorDisplay: errorIcon
                }
              );
            }
          },
          children: showPagination && /* @__PURE__ */ u$1(DataGrid.Footer, { children: /* @__PURE__ */ u$1(Pagination, { ...paginationProps }) })
        }
      )
    ] });
  };
  const BASE_CLASS$8 = "adyen-pe-reports-overview";
  const EARLIEST_PAYOUT_SINCE_DATE = (/* @__PURE__ */ new Date("2024-04-16T00:00:00.000Z")).toString();
  const ReportsOverview = ({
    onFiltersChanged,
    balanceAccounts,
    allowLimitSelection = true,
    preferredLimit = DEFAULT_PAGE_LIMIT,
    isLoadingBalanceAccount,
    onContactSupport,
    hideTitle,
    dataCustomization
  }) => {
    var _a2, _b2, _c2, _d2;
    const { getReports: reportsEndpointCall } = useConfigContext().endpoints;
    const { activeBalanceAccount, balanceAccountSelectionOptions, onBalanceAccountSelection } = useBalanceAccountSelection(balanceAccounts);
    const { defaultParams, nowTimestamp: nowTimestamp2, refreshNowTimestamp } = useDefaultOverviewFilterParams("reports", activeBalanceAccount);
    const getReports = q$1(
      async (pageRequestParams, signal) => {
        const requestOptions = { signal, errorLevel: "error" };
        return reportsEndpointCall(requestOptions, {
          query: {
            ...pageRequestParams,
            type: "payout",
            createdSince: pageRequestParams[FilterParam.CREATED_SINCE] ?? defaultParams.current.defaultFilterParams[FilterParam.CREATED_SINCE],
            createdUntil: pageRequestParams[FilterParam.CREATED_UNTIL] ?? defaultParams.current.defaultFilterParams[FilterParam.CREATED_UNTIL],
            balanceAccountId: (activeBalanceAccount == null ? void 0 : activeBalanceAccount.id) ?? ""
          }
        });
      },
      [activeBalanceAccount == null ? void 0 : activeBalanceAccount.id, defaultParams, reportsEndpointCall]
    );
    const filterBarState = useFilterBarState();
    const _onFiltersChanged = T$1(() => isFunction(onFiltersChanged) ? onFiltersChanged : void 0, [onFiltersChanged]);
    const preferredLimitOptions = T$1(() => allowLimitSelection ? LIMIT_OPTIONS : void 0, [allowLimitSelection]);
    const { canResetFilters, error, fetching, filters, limit, limitOptions, records, resetFilters, updateFilters, updateLimit, ...paginationProps } = useCursorPaginatedRecords({
      fetchRecords: getReports,
      dataField: "data",
      filterParams: defaultParams.current.defaultFilterParams,
      initialFiltersSameAsDefault: true,
      onFiltersChanged: _onFiltersChanged,
      preferredLimit,
      preferredLimitOptions,
      enabled: !!(activeBalanceAccount == null ? void 0 : activeBalanceAccount.id) && !!reportsEndpointCall
    });
    const mergeCustomData = q$1(
      ({ records: records2, retrievedData }) => mergeRecords(records2, retrievedData, (modifiedRecord, record) => modifiedRecord.createdAt === record.createdAt),
      []
    );
    const hasCustomColumn = T$1(() => {
      var _a3;
      return hasCustomField((_a3 = dataCustomization == null ? void 0 : dataCustomization.list) == null ? void 0 : _a3.fields, FIELDS$1);
    }, [(_a2 = dataCustomization == null ? void 0 : dataCustomization.list) == null ? void 0 : _a2.fields]);
    const { customRecords: reports, loadingCustomRecords } = useCustomColumnsData({
      records,
      hasCustomColumn,
      onDataRetrieve: (_b2 = dataCustomization == null ? void 0 : dataCustomization.list) == null ? void 0 : _b2.onDataRetrieve,
      mergeCustomData
    });
    y(() => {
      refreshNowTimestamp();
    }, [filters, refreshNowTimestamp]);
    return /* @__PURE__ */ u$1("div", { className: BASE_CLASS$8, children: [
      /* @__PURE__ */ u$1(Header, { hideTitle, titleKey: "reportsTitle", subtitleKey: "reportsNotice", children: /* @__PURE__ */ u$1(FilterBarMobileSwitch, { ...filterBarState }) }),
      /* @__PURE__ */ u$1(FilterBar, { ...filterBarState, children: [
        /* @__PURE__ */ u$1(
          BalanceAccountSelector,
          {
            activeBalanceAccount,
            balanceAccountSelectionOptions,
            onBalanceAccountSelection
          }
        ),
        /* @__PURE__ */ u$1(
          DateFilter,
          {
            canResetFilters,
            defaultParams,
            filters,
            nowTimestamp: nowTimestamp2,
            refreshNowTimestamp,
            sinceDate: EARLIEST_PAYOUT_SINCE_DATE,
            timezone: "UTC",
            updateFilters
          }
        )
      ] }),
      /* @__PURE__ */ u$1(
        ReportsTable,
        {
          balanceAccountId: activeBalanceAccount == null ? void 0 : activeBalanceAccount.id,
          loading: fetching || isLoadingBalanceAccount || !balanceAccounts || !activeBalanceAccount || loadingCustomRecords,
          data: ((_c2 = dataCustomization == null ? void 0 : dataCustomization.list) == null ? void 0 : _c2.onDataRetrieve) ? reports : records,
          showPagination: true,
          limit,
          limitOptions,
          onContactSupport,
          onLimitSelection: updateLimit,
          error,
          customColumns: (_d2 = dataCustomization == null ? void 0 : dataCustomization.list) == null ? void 0 : _d2.fields,
          ...paginationProps
        }
      )
    ] });
  };
  const BASE_CLASS$7 = "adyen-pe-reports-overview-container";
  function ReportsOverviewContainer({ ...props }) {
    const { balanceAccounts, isBalanceAccountIdWrong, isFetching, error } = useBalanceAccounts(props.balanceAccountId);
    return /* @__PURE__ */ u$1(
      DataOverviewContainer,
      {
        balanceAccountsError: error,
        className: BASE_CLASS$7,
        errorMessage: "weCouldNotLoadTheReportsOverview",
        isBalanceAccountIdWrong,
        onContactSupport: props.onContactSupport,
        children: /* @__PURE__ */ u$1(ReportsOverview, { ...props, balanceAccounts, isLoadingBalanceAccount: isFetching })
      }
    );
  }
  class ReportsElement extends UIElement {
    constructor(props) {
      super(props);
      __publicField(this, "componentToRender", () => {
        return /* @__PURE__ */ u$1(
          ReportsOverviewContainer,
          {
            ...this.props,
            balanceAccountId: this.props.balanceAccountId,
            ref: (ref) => {
              this.componentRef = ref;
            }
          }
        );
      });
      this.componentToRender = this.componentToRender.bind(this);
    }
  }
  __publicField(ReportsElement, "type", "reports");
  const CAPITAL_OVERVIEW_CLASS_NAMES = {
    base: "adyen-pe-capital-overview",
    skeleton: "adyen-pe-capital-overview__skeleton",
    headerSkeleton: "adyen-pe-capital-overview__header-skeleton",
    skeletonContainer: "adyen-pe-capital-overview__header-skeleton-container",
    preQualifiedGrant: "adyen-pe-capital-overview__pre-qualified-grant",
    preQualifiedGrantButton: "adyen-pe-capital-overview__pre-qualified-grant-review-button",
    errorContainer: "adyen-pe-capital-overview__error-container"
  };
  const Unqualified = ({ hideTitle }) => {
    const { i18n, getImageAsset } = useCoreContext();
    return /* @__PURE__ */ u$1(k$1, { children: [
      /* @__PURE__ */ u$1(CapitalHeader, { hideTitle, titleKey: "capital.needSomeExtraMoney" }),
      /* @__PURE__ */ u$1("div", { className: "adyen-pe-capital-overview__unqualified-state", children: [
        /* @__PURE__ */ u$1("div", { className: "adyen-pe-capital-overview__unqualified-state-img", children: /* @__PURE__ */ u$1("img", { srcSet: getImageAsset == null ? void 0 : getImageAsset({ name: "generic-use-first-touch" }), alt: "" }) }),
        /* @__PURE__ */ u$1(Typography$1, { el: TypographyElement.PARAGRAPH, variant: TypographyVariant.BODY, large: true, children: i18n.get("capital.youWillSoonQualifyForAFinancialOffer") })
      ] })
    ] });
  };
  const PreQualifiedIntro = ({
    dynamicOfferConfig,
    hideTitle,
    onOfferOptionsRequest
  }) => {
    const { i18n } = useCoreContext();
    return /* @__PURE__ */ u$1(k$1, { children: [
      /* @__PURE__ */ u$1(CapitalHeader, { hideTitle, titleKey: "capital.needSomeExtraMoney" }),
      /* @__PURE__ */ u$1("div", { className: CAPITAL_OVERVIEW_CLASS_NAMES.preQualifiedGrant, children: [
        /* @__PURE__ */ u$1(InfoBox, { children: /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.BODY, children: [
          i18n.get("capital.youHaveBeenPrequalifiedForBusinessFinancingUpToX.part1"),
          /* @__PURE__ */ u$1("strong", { children: i18n.get("capital.youHaveBeenPrequalifiedForBusinessFinancingUpToX.part2", {
            values: {
              amount: i18n.amount(dynamicOfferConfig.maxAmount.value, dynamicOfferConfig.maxAmount.currency, {
                minimumFractionDigits: 0
              })
            }
          }) })
        ] }) }),
        /* @__PURE__ */ u$1(Button$1, { className: CAPITAL_OVERVIEW_CLASS_NAMES.preQualifiedGrantButton, onClick: onOfferOptionsRequest, children: i18n.get("capital.seeOptions") })
      ] })
    ] });
  };
  const PreQualified = ({
    hideTitle,
    dynamicOffer,
    skipPreQualifiedIntro,
    onOfferOptionsRequest,
    onFundsRequest,
    onOfferDismiss
  }) => {
    const [state, setState] = d(skipPreQualifiedIntro ? "capitalOffer" : "intro");
    const handleOfferOptionsRequest = q$1(() => {
      onOfferOptionsRequest ? onOfferOptionsRequest() : setState("capitalOffer");
    }, [onOfferOptionsRequest]);
    const isOfferDismissButtonVisible = T$1(() => !skipPreQualifiedIntro || !!onOfferDismiss, [onOfferDismiss, skipPreQualifiedIntro]);
    const handleOfferDismiss = q$1(() => {
      onOfferDismiss ? onOfferDismiss() : setState("intro");
    }, [onOfferDismiss]);
    return /* @__PURE__ */ u$1(k$1, { children: state === "intro" ? /* @__PURE__ */ u$1(PreQualifiedIntro, { hideTitle, dynamicOfferConfig: dynamicOffer, onOfferOptionsRequest: handleOfferOptionsRequest }) : /* @__PURE__ */ u$1(
      CapitalOffer,
      {
        onFundsRequest,
        onOfferDismiss: isOfferDismissButtonVisible ? handleOfferDismiss : void 0,
        externalDynamicOffersConfig: dynamicOffer
      }
    ) });
  };
  const ProgressBar = ({ max: max2 = 1, value: value2, labels: labels2, tooltips, className }) => {
    const percentage = T$1(() => clamp(0, value2 * 100 / max2, 100), [value2, max2]);
    const shouldDisplayLegend = !!((labels2 == null ? void 0 : labels2.current) || (labels2 == null ? void 0 : labels2.max));
    const ariaLabel = (labels2 == null ? void 0 : labels2.ariaLabel) ?? ((labels2 == null ? void 0 : labels2.current) ? `${labels2.current}: ${value2}` : `${value2}/${max2}`);
    return /* @__PURE__ */ u$1(
      "div",
      {
        role: "progressbar",
        "aria-valuenow": value2,
        "aria-valuemin": 0,
        "aria-valuemax": max2,
        "aria-valuetext": `${percentage}%`,
        "aria-label": ariaLabel,
        className: cx("adyen-pe-progress-bar", className),
        children: [
          /* @__PURE__ */ u$1("div", { className: "adyen-pe-progress-bar__track", children: [
            /* @__PURE__ */ u$1("div", { className: "adyen-pe-progress-bar__track-background" }),
            /* @__PURE__ */ u$1(
              ProgressBarSegment,
              {
                tooltipContent: tooltips == null ? void 0 : tooltips.progress,
                title: labels2 == null ? void 0 : labels2.current,
                percentage,
                className: "adyen-pe-progress-bar__track-fill"
              }
            ),
            /* @__PURE__ */ u$1(
              ProgressBarSegment,
              {
                tooltipContent: tooltips == null ? void 0 : tooltips.remaining,
                title: labels2 == null ? void 0 : labels2.max,
                percentage: 100 - percentage,
                className: "adyen-pe-progress-bar__track-remaining"
              }
            )
          ] }),
          shouldDisplayLegend && /* @__PURE__ */ u$1("div", { className: "adyen-pe-progress-bar__legend", "aria-hidden": "true", children: [
            labels2.current && /* @__PURE__ */ u$1(Typography$1, { el: TypographyElement.SPAN, variant: TypographyVariant.CAPTION, className: "adyen-pe-progress-bar__legend-label", children: labels2.current }),
            labels2.max && /* @__PURE__ */ u$1(Typography$1, { el: TypographyElement.SPAN, variant: TypographyVariant.CAPTION, className: "adyen-pe-progress-bar__legend-label", children: labels2.max })
          ] })
        ]
      }
    );
  };
  const ProgressBarSegment = ({ tooltipContent, title, percentage, className }) => {
    const getContent2 = (title2) => /* @__PURE__ */ u$1("div", { className, title: title2, style: { width: `${percentage}%` } });
    return tooltipContent ? /* @__PURE__ */ u$1(Tooltip, { content: tooltipContent, children: getContent2() }) : getContent2(title);
  };
  const GRANT_ITEM_CLASS_NAMES = {
    base: "adyen-pe-grant-item",
    actionsBar: "adyen-pe-grant-item__actions-bar",
    alert: "adyen-pe-grant-item__alert",
    cardContent: "adyen-pe-grant-item__card-content",
    grantID: "adyen-pe-grant-item__grant-id",
    mainActionBtn: "adyen-pe-grant-item__main-action-button",
    progressBar: "adyen-pe-grant-item__progress-bar",
    statusContainer: "adyen-pe-grant-item__status-container",
    textSecondary: "adyen-pe-grant-item__text--secondary"
  };
  const getHasDetails = (status2) => status2 === "Active";
  const getIsBackgroundFilled = (status2) => status2 === "Repaid";
  const getAmountLabelKey = (status2) => status2 === "Active" ? "capital.remaining" : "capital.requestedFunds";
  const getAmount = (grant) => grant.status === "Active" ? grant.remainingTotalAmount : grant.grantAmount;
  const getStatusKey = ({ status: status2, missingActions }) => {
    switch (status2) {
      case "Active":
        return void 0;
      case "Failed":
        return "capital.failed";
      case "Pending":
        return missingActions && missingActions.length ? "capital.actionNeeded" : "capital.pending";
      case "Repaid":
        return "capital.fullyRepaid";
      case "Revoked":
        return "capital.revoked";
      case "WrittenOff":
        return "capital.writtenOff";
    }
  };
  const getStatusTagVariant = ({ status: status2, missingActions }) => {
    switch (status2) {
      case "Failed":
        return TagVariant.ERROR;
      case "Pending":
        return (missingActions == null ? void 0 : missingActions.length) ? TagVariant.WARNING : TagVariant.DEFAULT;
      case "Repaid":
        return TagVariant.LIGHT;
      case "Revoked":
      case "WrittenOff":
        return TagVariant.WARNING;
      default:
        return TagVariant.DEFAULT;
    }
  };
  const getRepaymentPeriodEndDate = (repaymentPeriodLeft) => {
    const today2 = /* @__PURE__ */ new Date();
    const endDate = /* @__PURE__ */ new Date();
    endDate.setDate(today2.getDate() + repaymentPeriodLeft);
    return endDate;
  };
  const getStatusTooltipKey = (grant) => {
    var _a2, _b2;
    const pendingToS = ((_a2 = grant.missingActions) == null ? void 0 : _a2.some((action) => action.type === "signToS")) || false;
    switch (grant.status) {
      case "Pending":
        return ((_b2 = grant.missingActions) == null ? void 0 : _b2.length) ? pendingToS ? "capital.signTheTermsToReceiveYourFunds" : void 0 : "capital.youShouldGetTheFundsWithinOneBusinessDay";
      case "Failed":
        return "capital.weCouldNotProcessThisRequestTryAgain";
      case "WrittenOff":
        return "capital.youAcceptedTheseFundsButDidNotRepayThem";
      case "Revoked":
        return "capital.youAcceptedButThenReturnedTheseFunds";
      default:
        return void 0;
    }
  };
  const getGrantConfig = (grant) => {
    var _a2;
    const isGrantActive = grant.status === "Active";
    const isGrantPending = grant.status === "Pending";
    return {
      amount: getAmount(grant),
      amountLabelKey: getAmountLabelKey(grant.status),
      hasAlerts: isGrantPending,
      hasDetails: getHasDetails(grant.status),
      hasUnscheduledRepaymentDetails: isGrantActive && !!((_a2 = grant.unscheduledRepaymentAccounts) == null ? void 0 : _a2.length),
      // The grant revocation account details is currently not ready to be rendered.
      // A future iteration of this component might include revocation account details.
      // Only then should the following line be uncommented.
      //
      // hasRevocationDetails: isGrantActive && grant.revocationAccount !== undefined,
      isAmountColorSecondary: !isGrantActive,
      isBackgroundFilled: getIsBackgroundFilled(grant.status),
      isGrantIdVisible: !isGrantActive,
      isLabelColorSecondary: isGrantActive,
      isProgressBarVisible: isGrantActive,
      repaymentPeriodEndDate: getRepaymentPeriodEndDate(grant.repaymentPeriodLeft),
      statusKey: getStatusKey(grant),
      statusTagVariant: getStatusTagVariant(grant),
      statusTooltipKey: getStatusTooltipKey(grant)
    };
  };
  const GRANT_DETAILS_CLASS_NAMES = {
    base: "adyen-pe-grant-details",
    content: "adyen-pe-grant-details__content",
    header: "adyen-pe-grant-details__header",
    label: "adyen-pe-grant-details__label"
  };
  const GrantDetails = ({ grant }) => {
    const { i18n } = useCoreContext();
    const formatAmount2 = q$1((amount2) => i18n.amount(amount2.value, amount2.currency), [i18n]);
    const structuredListItems = T$1(() => {
      const maximumRepaymentPeriodMonths = grant.maximumRepaymentPeriodDays ? Math.ceil(grant.maximumRepaymentPeriodDays / 30) : null;
      const items = [
        {
          key: "capital.remainingAmount",
          value: i18n.amount(grant.remainingGrantAmount.value, grant.remainingGrantAmount.currency)
        },
        { key: "capital.remainingFees", value: formatAmount2(grant.remainingFeesAmount) },
        { key: "capital.repaidAmount", value: formatAmount2(grant.repaidGrantAmount) },
        { key: "capital.repaidFees", value: formatAmount2(grant.repaidFeesAmount) },
        {
          key: "capital.dailyRepaymentRate",
          value: `${i18n.get("capital.xPercent", {
            values: { percentage: getPercentage(grant.repaymentRate) }
          })}`
        },
        {
          key: "capital.expectedRepaymentPeriod",
          value: i18n.get("capital.daysAndDaysLeft", {
            values: {
              days: grant.expectedRepaymentPeriodDays,
              daysLeft: grant.repaymentPeriodLeft
            }
          })
        },
        { key: "capital.totalFees", value: formatAmount2(grant.feesAmount) },
        { key: "capital.totalRepaymentAmount", value: formatAmount2(grant.totalAmount) },
        { key: "capital.repaymentThreshold", value: formatAmount2(grant.thresholdAmount) },
        { key: "capital.grantID", value: grant.id },
        { key: "accountDescription", value: grant.balanceAccountDescription },
        { key: "accountID", value: grant.balanceAccountCode }
      ];
      if (maximumRepaymentPeriodMonths) {
        items.splice(5, 0, {
          key: "capital.maximumRepaymentPeriod",
          value: i18n.get("capital.xMonths", { values: { months: maximumRepaymentPeriodMonths } })
        });
      }
      return items;
    }, [grant, formatAmount2, i18n]);
    return /* @__PURE__ */ u$1("div", { className: GRANT_DETAILS_CLASS_NAMES.base, children: /* @__PURE__ */ u$1("div", { className: GRANT_DETAILS_CLASS_NAMES.content, children: [
      /* @__PURE__ */ u$1("div", { className: GRANT_DETAILS_CLASS_NAMES.header, children: [
        /* @__PURE__ */ u$1(Typography$1, { el: TypographyElement.SPAN, variant: TypographyVariant.BODY, children: i18n.get("capital.yourRequestedFundsWere") }),
        /* @__PURE__ */ u$1(Typography$1, { el: TypographyElement.SPAN, variant: TypographyVariant.BODY, strongest: true, children: i18n.amount(grant.grantAmount.value, grant.grantAmount.currency) })
      ] }),
      /* @__PURE__ */ u$1(
        StructuredList,
        {
          renderLabel: (val, key) => key === "capital.repaymentThreshold" ? /* @__PURE__ */ u$1(
            Tooltip,
            {
              isContainerHovered: true,
              content: i18n.get("capital.minimumRepaymentToRepayTheFinancingOnTime", {
                values: { days: CAPITAL_REPAYMENT_FREQUENCY }
              }),
              children: /* @__PURE__ */ u$1("span", { children: /* @__PURE__ */ u$1(
                Typography$1,
                {
                  className: GRANT_DETAILS_CLASS_NAMES.label,
                  el: TypographyElement.SPAN,
                  variant: TypographyVariant.CAPTION,
                  children: val
                }
              ) })
            }
          ) : /* @__PURE__ */ u$1(Typography$1, { className: GRANT_DETAILS_CLASS_NAMES.label, el: TypographyElement.SPAN, variant: TypographyVariant.CAPTION, children: val }),
          renderValue: (val) => /* @__PURE__ */ u$1(Typography$1, { el: TypographyElement.SPAN, stronger: true, variant: TypographyVariant.CAPTION, children: val }),
          items: structuredListItems
        }
      )
    ] }) });
  };
  const GRANT_ACTION_CLASS_NAMES = {
    button: "adyen-pe-grant-action__button",
    buttonLabel: "adyen-pe-grant-action__button-label",
    actionsContainer: "adyen-pe-grant-action__actions-container",
    actionsInformation: "adyen-pe-grant-action__actions-information"
  };
  const getTopWindowHref = () => {
    var _a2;
    return ((_a2 = window.top) == null ? void 0 : _a2.location.href) || window.location.href;
  };
  const setTopWindowHref = (href) => {
    if (window.top) {
      window.top.location.href = href;
    } else {
      window.location.href = href;
    }
  };
  const GrantActions = ({
    missingActions = [],
    offerExpiresAt,
    className
  }) => {
    const { i18n, updateCore } = useCoreContext();
    const { dateFormat } = useTimezoneAwareDateFormatting();
    const { endpoints } = useConfigContext();
    const ACTION_CONFIG = T$1(
      () => ({
        signToS: {
          getTitle: (formattedDate) => `${i18n.get("capital.signTermsAndConditionsToReceiveFunds")}${formattedDate ? ` ${i18n.get("capital.thisOfferExpiresOn", { values: { date: formattedDate } })}` : ""}`,
          buttonLabelKey: "capital.goToTermsAndConditions"
        },
        AnaCredit: {
          getTitle: (formattedDate) => formattedDate ? i18n.get("capital.weNeedABitMoreInformationToProcessYourFundsPleaseCompleteThisActionBy", {
            values: { date: formattedDate }
          }) : i18n.get("capital.weNeedABitMoreInformationToProcessYourFundsPleaseCompleteThisAction"),
          buttonLabelKey: "capital.submitInformation"
        }
      }),
      [i18n]
    );
    const [loadingAction, setLoadingAction] = d(null);
    const onRedirect = q$1((data) => {
      if (data == null ? void 0 : data.url) {
        setTopWindowHref(data.url);
      } else {
        setLoadingAction(null);
      }
    }, []);
    const actionMutation = useMutation({
      queryFn: (actionType) => {
        let endpointByAction = null;
        switch (actionType) {
          case "signToS":
            endpointByAction = endpoints.signToSActionDetails;
            break;
          case "AnaCredit":
            endpointByAction = endpoints.anaCreditActionDetails;
            break;
          default:
            break;
        }
        const endpoint = endpointByAction;
        const callbackQuery = {
          query: { redirectUrl: getTopWindowHref(), locale: i18n.locale }
        };
        return endpoint == null ? void 0 : endpoint(EMPTY_OBJECT, callbackQuery);
      },
      options: {
        onSuccess: onRedirect,
        // Reset the loading state when the mutation finishes (success or error)
        onError: () => {
          setLoadingAction(null);
        }
      }
    });
    const formattedExpiryDate = T$1(
      () => offerExpiresAt ? dateFormat(offerExpiresAt, DATE_FORMAT_MISSING_ACTION) : void 0,
      [dateFormat, offerExpiresAt]
    );
    if (actionMutation.error) {
      return /* @__PURE__ */ u$1(
        Alert,
        {
          className,
          type: AlertTypeOption.CRITICAL,
          title: i18n.get("somethingWentWrongTryRefreshingOrComeBackLater"),
          description: /* @__PURE__ */ u$1(Button$1, { className: GRANT_ACTION_CLASS_NAMES.button, onClick: updateCore, children: i18n.get("refresh") })
        }
      );
    }
    if (!missingActions.length) {
      return null;
    }
    if (missingActions.length > 1) {
      return /* @__PURE__ */ u$1(
        Alert,
        {
          className,
          type: AlertTypeOption.WARNING,
          title: i18n.get("capital.weNeedABitMoreInformationToProcessYourFundsPleaseCompleteTheseActions"),
          description: /* @__PURE__ */ u$1("div", { className: GRANT_ACTION_CLASS_NAMES.actionsInformation, children: [
            /* @__PURE__ */ u$1("ol", { className: GRANT_ACTION_CLASS_NAMES.actionsContainer, children: missingActions.map((action) => {
              const config2 = ACTION_CONFIG[action.type];
              const isLoading = loadingAction === action.type;
              return /* @__PURE__ */ u$1("li", { children: /* @__PURE__ */ u$1(
                Button$1,
                {
                  className: GRANT_ACTION_CLASS_NAMES.button,
                  onClick: () => {
                    setLoadingAction(action.type);
                    void actionMutation.mutate(action.type);
                  },
                  disabled: isLoading || actionMutation.isLoading,
                  state: isLoading ? "loading" : void 0,
                  variant: ButtonVariant.TERTIARY,
                  children: /* @__PURE__ */ u$1("span", { className: GRANT_ACTION_CLASS_NAMES.buttonLabel, children: i18n.get(config2.buttonLabelKey) })
                }
              ) }, action.type);
            }) }),
            formattedExpiryDate ? /* @__PURE__ */ u$1(Typography$1, { el: TypographyElement.SPAN, variant: TypographyVariant.BODY, strongest: true, children: i18n.get("capital.thisOfferExpiresOn", { values: { date: formattedExpiryDate } }) }) : null
          ] })
        }
      );
    }
    const singleAction = missingActions[0];
    const config = ACTION_CONFIG[singleAction.type];
    return /* @__PURE__ */ u$1(
      Alert,
      {
        className,
        type: AlertTypeOption.WARNING,
        title: config.getTitle(formattedExpiryDate),
        description: /* @__PURE__ */ u$1(
          Button$1,
          {
            className: GRANT_ACTION_CLASS_NAMES.button,
            onClick: () => {
              setLoadingAction(singleAction.type);
              void actionMutation.mutate(singleAction.type);
            },
            disabled: !!loadingAction,
            state: loadingAction ? "loading" : void 0,
            variant: ButtonVariant.TERTIARY,
            children: /* @__PURE__ */ u$1("span", { className: GRANT_ACTION_CLASS_NAMES.buttonLabel, children: i18n.get(config.buttonLabelKey) })
          }
        )
      }
    );
  };
  const GrantItem = ({ grant, showDetails }) => {
    const { i18n } = useCoreContext();
    const { dateFormat } = useTimezoneAwareDateFormatting();
    const grantConfig = T$1(() => getGrantConfig(grant), [grant]);
    const showUnscheduledRepaymentAccounts = q$1(() => showDetails == null ? void 0 : showDetails("unscheduledRepayment"), [showDetails]);
    const grantOverview = T$1(
      () => {
        var _a2, _b2;
        return /* @__PURE__ */ u$1("div", { className: GRANT_ITEM_CLASS_NAMES.cardContent, children: [
          /* @__PURE__ */ u$1("div", { className: GRANT_ITEM_CLASS_NAMES.statusContainer, children: [
            /* @__PURE__ */ u$1(
              Typography$1,
              {
                variant: TypographyVariant.CAPTION,
                className: cx({ [GRANT_ITEM_CLASS_NAMES.textSecondary]: grantConfig.isLabelColorSecondary }),
                testId: "grant-amount-label",
                children: i18n.get(grantConfig.amountLabelKey)
              }
            ),
            /* @__PURE__ */ u$1("div", { children: grant.status === "Active" ? /* @__PURE__ */ u$1(k$1, { children: [
              /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.CAPTION, el: TypographyElement.SPAN, children: i18n.get("capital.termEnds") }),
              /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.CAPTION, stronger: true, el: TypographyElement.SPAN, children: dateFormat(grantConfig.repaymentPeriodEndDate, DATE_FORMAT_CAPITAL_OVERVIEW) })
            ] }) : grantConfig.statusKey ? grantConfig.statusTooltipKey ? /* @__PURE__ */ u$1(Tooltip, { content: i18n.get(grantConfig.statusTooltipKey), children: /* @__PURE__ */ u$1("div", { children: /* @__PURE__ */ u$1(Tag, { label: i18n.get(grantConfig.statusKey), variant: grantConfig.statusTagVariant }) }) }) : /* @__PURE__ */ u$1(Tag, { label: i18n.get(grantConfig.statusKey), variant: grantConfig.statusTagVariant }) : null })
          ] }),
          /* @__PURE__ */ u$1(
            Typography$1,
            {
              variant: TypographyVariant.TITLE,
              medium: true,
              className: cx({
                [GRANT_ITEM_CLASS_NAMES.textSecondary]: grantConfig.isAmountColorSecondary
              }),
              children: i18n.amount(grantConfig.amount.value, grantConfig.amount.currency)
            }
          ),
          grantConfig.isProgressBarVisible && /* @__PURE__ */ u$1(
            ProgressBar,
            {
              className: GRANT_ITEM_CLASS_NAMES.progressBar,
              value: grant.repaidTotalAmount.value,
              max: grant.totalAmount.value,
              labels: { current: i18n.get("capital.repaid"), max: i18n.get("capital.remaining") },
              tooltips: {
                remaining: `${i18n.amount(grant.remainingTotalAmount.value, grant.remainingTotalAmount.currency)} ${(_a2 = i18n.get("capital.remaining")) == null ? void 0 : _a2.toLowerCase()}`,
                progress: `${i18n.amount(grant.repaidTotalAmount.value, grant.repaidTotalAmount.currency)} ${(_b2 = i18n.get("capital.repaid")) == null ? void 0 : _b2.toLowerCase()}`
              }
            }
          ),
          grantConfig.isGrantIdVisible ? /* @__PURE__ */ u$1("div", { className: GRANT_ITEM_CLASS_NAMES.grantID, children: /* @__PURE__ */ u$1(
            CopyText,
            {
              textToCopy: grant.id,
              buttonLabel: i18n.get("capital.grantID"),
              isHovered: true,
              type: "Text",
              "data-testid": "grant-id-copy-text"
            }
          ) }) : null,
          grantConfig.hasAlerts ? /* @__PURE__ */ u$1(k$1, { children: grant.missingActions && grant.missingActions.length ? /* @__PURE__ */ u$1(
            GrantActions,
            {
              missingActions: grant.missingActions,
              className: GRANT_ITEM_CLASS_NAMES.alert,
              offerExpiresAt: grant.offerExpiresAt
            }
          ) : /* @__PURE__ */ u$1(
            Alert,
            {
              className: GRANT_ITEM_CLASS_NAMES.alert,
              type: AlertTypeOption.HIGHLIGHT,
              title: i18n.get("capital.weReceivedYourRequestAndWeAreWorkingOnItNowCheckBackSoon")
            }
          ) }) : grantConfig.hasUnscheduledRepaymentDetails && /* @__PURE__ */ u$1("div", { className: GRANT_ITEM_CLASS_NAMES.actionsBar, children: /* @__PURE__ */ u$1(
            Button$1,
            {
              onClick: showUnscheduledRepaymentAccounts,
              className: GRANT_ITEM_CLASS_NAMES.mainActionBtn,
              variant: ButtonVariant.SECONDARY,
              fullWidth: true,
              children: i18n.get("capital.sendRepayment")
            }
          ) })
        ] });
      },
      [i18n, dateFormat, grant, grantConfig, showUnscheduledRepaymentAccounts]
    );
    return /* @__PURE__ */ u$1("div", { className: GRANT_ITEM_CLASS_NAMES.base, children: /* @__PURE__ */ u$1(ExpandableCard, { renderHeader: grantOverview, filled: grantConfig.isBackgroundFilled, inFlow: true, children: grantConfig.hasDetails && /* @__PURE__ */ u$1(GrantDetails, { grant }) }) });
  };
  const GRANT_ADJUSTMENT_DETAILS = {
    unscheduledRepayment: "unscheduledRepayment"
  };
  const AccountDetail = ({
    className,
    content,
    contentClassName,
    textToCopy,
    label,
    labelClassName
  }) => {
    const { i18n } = useCoreContext();
    return /* @__PURE__ */ u$1("div", { className, children: [
      /* @__PURE__ */ u$1("dt", { className: labelClassName, children: /* @__PURE__ */ u$1(Typography$1, { el: TypographyElement.SPAN, variant: TypographyVariant.CAPTION, children: i18n.get(label) }) }),
      /* @__PURE__ */ u$1("dd", { className: contentClassName, children: textToCopy ? /* @__PURE__ */ u$1(CopyText, { buttonLabel: content, textToCopy, showCopyTextTooltip: false, type: "Text" }) : /* @__PURE__ */ u$1(Typography$1, { el: TypographyElement.SPAN, variant: TypographyVariant.BODY, children: content }) })
    ] });
  };
  const getHumanReadableIban = (iban, useNonBreakingSpaces = true) => {
    const spaceSeparator = useNonBreakingSpaces ? " " : " ";
    const ibanWithoutSpaces = iban.replace(/\s+/g, "");
    return ibanWithoutSpaces.replace(/([A-Z\d]{4}(?!$))/gi, `$1${spaceSeparator}`);
  };
  const isCopyableAccountField = (field) => {
    switch (field) {
      // Explicit list of copyable account fields
      case "iban":
      case "accountNumber":
      case "routingNumber":
      case "sortCode":
        return true;
      // Explicit list of non-copyable account fields
      // Items can be moved from this list to the list of copyable fields if necessary
      // The `region` field and other unknown fields (default case) are also considered non-copyable
      case "region":
      default:
        return false;
    }
  };
  const getAccountFieldTextToCopy = (field, value2) => {
    return isCopyableAccountField(field) ? value2 : void 0;
  };
  const getAccountFieldFormattedValue = (field, value2) => {
    switch (field) {
      case "iban":
        return value2 && getHumanReadableIban(value2);
      default:
        return value2;
    }
  };
  const getAccountFieldTranslationKey = (field) => {
    switch (field) {
      case "region":
        return "capital.bankCountryOrRegion";
      case "iban":
        return "capital.bankAccountIban";
      case "accountNumber":
        return "capital.bankAccountNumber";
      case "routingNumber":
        return "capital.bankRoutingNumber";
      case "sortCode":
        return "capital.bankSortCode";
      default:
        return field;
    }
  };
  const BASE_CLASS$6 = "adyen-pe-capital-account-details";
  const CLASS_NAMES$1 = {
    detail: `${BASE_CLASS$6}__detail`,
    detailContent: `${BASE_CLASS$6}__detail-content`,
    detailLabel: `${BASE_CLASS$6}__detail-label`
  };
  const AccountDetails = ({ bankAccount, className }) => {
    const orderedBankAccountFields = T$1(() => {
      const { accountNumber, iban, order, region, ...accountDetails } = bankAccount;
      const accountFields = Object.keys({ iban, accountNumber, ...accountDetails, region });
      const orderedFields = Array.isArray(order) ? order.filter((field) => accountFields.includes(field)) : accountFields;
      return [...new Set(orderedFields)];
    }, [bankAccount]);
    return /* @__PURE__ */ u$1("dl", { className: cx(BASE_CLASS$6, className), children: orderedBankAccountFields.map((field) => {
      const fieldValue = bankAccount[field];
      return fieldValue ? /* @__PURE__ */ u$1(k$1, { children: /* @__PURE__ */ u$1(
        AccountDetail,
        {
          className: CLASS_NAMES$1.detail,
          contentClassName: CLASS_NAMES$1.detailContent,
          labelClassName: CLASS_NAMES$1.detailLabel,
          label: getAccountFieldTranslationKey(field),
          content: getAccountFieldFormattedValue(field, fieldValue),
          textToCopy: getAccountFieldTextToCopy(field, fieldValue)
        }
      ) }, field) : null;
    }) });
  };
  const GrantAdjustmentDetails = ({
    children,
    className,
    headerTitleKey,
    headerSubtitleKey,
    onDetailsClose
  }) => {
    const { i18n } = useCoreContext();
    return /* @__PURE__ */ u$1("div", { className: cx("adyen-pe-grant-adjustment-details", className), children: [
      /* @__PURE__ */ u$1(Header, { titleKey: headerTitleKey, subtitleKey: headerSubtitleKey, children: /* @__PURE__ */ u$1(
        Button$1,
        {
          onClick: onDetailsClose,
          variant: ButtonVariant.TERTIARY,
          iconButton: true,
          classNameModifiers: ["circle"],
          "aria-label": i18n.get("dismiss"),
          children: /* @__PURE__ */ u$1(Icon$1, { name: "cross" })
        }
      ) }),
      children
    ] });
  };
  const BASE_CLASS$5 = "adyen-pe-grant-repayment-details";
  const CLASS_NAMES = {
    balanceInfo: `${BASE_CLASS$5}__balance-info`,
    repaymentInfo: `${BASE_CLASS$5}__repayment-info`,
    repaymentAccount: `${BASE_CLASS$5}__repayment-account`,
    repaymentNotice: `${BASE_CLASS$5}__repayment-notice`
  };
  const GrantRepaymentDetails = ({ grant, onDetailsClose }) => {
    const { i18n } = useCoreContext();
    const bankAccount = T$1(() => {
      var _a2;
      return (_a2 = grant.unscheduledRepaymentAccounts) == null ? void 0 : _a2[0];
    }, [grant.unscheduledRepaymentAccounts]);
    const formattedRemainingAmount = T$1(() => {
      const { currency: currency2, value: value2 } = grant.remainingTotalAmount;
      return i18n.amount(value2, currency2);
    }, [i18n, grant.remainingTotalAmount]);
    return bankAccount ? /* @__PURE__ */ u$1(
      GrantAdjustmentDetails,
      {
        className: BASE_CLASS$5,
        onDetailsClose,
        headerTitleKey: "capital.sendRepayment",
        headerSubtitleKey: "capital.sendRepaymentSubtitle",
        children: [
          /* @__PURE__ */ u$1("div", { className: CLASS_NAMES.repaymentInfo, children: [
            /* @__PURE__ */ u$1("section", { className: CLASS_NAMES.repaymentAccount, children: [
              /* @__PURE__ */ u$1(Typography$1, { el: TypographyElement.SPAN, variant: TypographyVariant.BODY, stronger: true, children: i18n.get("capital.bankAccountDetails") }),
              /* @__PURE__ */ u$1(AccountDetails, { bankAccount })
            ] }),
            /* @__PURE__ */ u$1("section", { className: CLASS_NAMES.repaymentNotice, children: /* @__PURE__ */ u$1(Typography$1, { el: TypographyElement.PARAGRAPH, variant: TypographyVariant.CAPTION, children: i18n.get("capital.sendRepaymentNotice") }) })
          ] }),
          /* @__PURE__ */ u$1(InfoBox, { className: CLASS_NAMES.balanceInfo, children: /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.BODY, children: /* @__PURE__ */ u$1(
            Translation,
            {
              translationKey: "capital.repaymentBalanceInfo",
              fills: {
                amount: /* @__PURE__ */ u$1(Typography$1, { el: TypographyElement.SPAN, variant: TypographyVariant.BODY, strongest: true, children: formattedRemainingAmount })
              }
            }
          ) }) })
        ]
      }
    ) : null;
  };
  const isDisabledOption = (option) => (option == null ? void 0 : option.disabled) === true;
  const getNearestActiveOptionIndex = (options, index, direction) => {
    const numberOfOptions = options.length;
    if (numberOfOptions) {
      let nearestIndex = index;
      let unvisitedOptions = numberOfOptions;
      while (unvisitedOptions--) {
        while (nearestIndex < 0) nearestIndex += numberOfOptions;
        if (nearestIndex >= numberOfOptions) nearestIndex %= numberOfOptions;
        if (!isDisabledOption(options[nearestIndex])) return nearestIndex;
        nearestIndex += direction;
      }
    }
    return 0;
  };
  const findActiveOptionIndex = (options, activeOption, fallbackActiveOptionIndex = 0) => {
    if (!activeOption) return fallbackActiveOptionIndex;
    const index = options.findIndex((option) => option.id === activeOption);
    const activeOptionIndex = index === -1 ? fallbackActiveOptionIndex : index;
    const nearestActiveOptionIndex = getNearestActiveOptionIndex(
      options,
      activeOptionIndex,
      1
      /* FORWARD */
    );
    return activeOptionIndex === nearestActiveOptionIndex ? activeOptionIndex : fallbackActiveOptionIndex;
  };
  const useTabbedControl = ({
    options,
    activeOption: activeOptionFromProps,
    onChange
  }) => {
    const [focusPending, setFocusPending] = d(false);
    const [activeIndex, setActiveIndex] = d(findActiveOptionIndex(options, activeOptionFromProps));
    const activeOption = options[activeIndex];
    const activeOptionRef = A$1(activeOption);
    const optionElementsRef = A$1([]);
    const uniqueId$1 = A$1(uniqueId().replace(/.*?(?=\d+$)/, "")).current;
    const refs = T$1(() => {
      const refs2 = [];
      for (let i2 = 0; i2 < options.length; i2++) {
        refs2[i2] = (el) => optionElementsRef.current[i2] = el;
      }
      return refs2;
    }, [options]);
    const onClick = q$1((event) => {
      const clickedOptionIndex = optionElementsRef.current.findIndex((elem) => elem === event.currentTarget);
      if (!isDisabledOption(optionElementsRef.current[clickedOptionIndex])) {
        event.preventDefault();
        setActiveIndex(clickedOptionIndex);
      }
    }, []);
    const onKeyDown = T$1(() => {
      const keyMap = {
        [InteractionKeyCode.ARROW_LEFT]: () => setActiveIndex((activeIndex2) => getNearestActiveOptionIndex(
          optionElementsRef.current,
          activeIndex2 - 1,
          -1
          /* BACKWARD */
        )),
        [InteractionKeyCode.ARROW_RIGHT]: () => setActiveIndex((activeIndex2) => getNearestActiveOptionIndex(
          optionElementsRef.current,
          activeIndex2 + 1,
          1
          /* FORWARD */
        )),
        [InteractionKeyCode.HOME]: () => setActiveIndex(getNearestActiveOptionIndex(
          optionElementsRef.current,
          0,
          1
          /* FORWARD */
        )),
        [InteractionKeyCode.END]: () => setActiveIndex(getNearestActiveOptionIndex(
          optionElementsRef.current,
          -1,
          -1
          /* BACKWARD */
        ))
      };
      return (event) => {
        var _a2;
        if (keyMap[event.key]) {
          event.preventDefault();
          (_a2 = keyMap[event.key]) == null ? void 0 : _a2.call(keyMap);
          setFocusPending(true);
        }
      };
    }, []);
    y(() => {
      setActiveIndex((activeIndex2) => findActiveOptionIndex(options, activeOptionFromProps, activeIndex2));
    }, [options, activeOptionFromProps]);
    y(() => {
      if (focusPending) {
        const optionElement = optionElementsRef.current[activeIndex];
        if (!isDisabledOption(optionElement)) optionElement == null ? void 0 : optionElement.focus();
        setFocusPending(false);
      }
    }, [activeIndex, focusPending]);
    y(() => {
      if (activeOptionRef.current !== activeOption) {
        activeOptionRef.current = activeOption;
        onChange == null ? void 0 : onChange(activeOption);
      }
    }, [activeOption, onChange]);
    return { activeIndex, onClick, onKeyDown, refs, uniqueId: uniqueId$1 };
  };
  function SegmentedControl({ activeItem, items, onChange }) {
    const { activeIndex, onClick, onKeyDown, refs, uniqueId: uniqueId2 } = useTabbedControl({ onChange, options: items, activeOption: activeItem });
    const { i18n } = useCoreContext();
    return /* @__PURE__ */ u$1("div", { children: [
      /* @__PURE__ */ u$1("div", { role: "radiogroup", className: "adyen-pe-segmented-control", children: items.map((item, index) => {
        const isActive = activeIndex === index;
        return /* @__PURE__ */ u$1(
          "button",
          {
            role: "radio",
            name: item.id,
            ref: refs[index],
            id: `item:${uniqueId2}-${item.id}`,
            className: "adyen-pe-segmented-control__item",
            "aria-checked": isActive,
            "aria-controls": `segment:${uniqueId2}-${item.id}`,
            onClick: isActive ? void 0 : onClick,
            onKeyDown,
            disabled: item.disabled,
            tabIndex: isActive ? 0 : -1,
            children: /* @__PURE__ */ u$1(
              Typography$1,
              {
                el: TypographyElement.SPAN,
                variant: TypographyVariant.BODY,
                className: "adyen-pe-segmented-control__item-label",
                stronger: true,
                children: i18n.get(item.label)
              }
            )
          },
          `item:${uniqueId2}-${item.id}`
        );
      }) }),
      /* @__PURE__ */ u$1("div", { className: "adyen-pe-segmented-content-container", children: items.map((item, index) => /* @__PURE__ */ u$1(
        "section",
        {
          id: `segment:${uniqueId2}-${item.id}`,
          className: "adyen-pe-segmented-content",
          "aria-labelledby": `item:${uniqueId2}-${item.id}`,
          hidden: activeIndex !== index,
          children: item.content
        },
        `segment:${uniqueId2}-${item.id}`
      )) })
    ] });
  }
  const List = ({ grants, showDetails }) => {
    return /* @__PURE__ */ u$1(BaseList, { classNames: "adyen-pe-grant-list__items", children: grants.map((grant) => /* @__PURE__ */ u$1("li", { children: /* @__PURE__ */ u$1(GrantItem, { grant, showDetails: showDetails.bind(null, grant) }) }, grant.id)) });
  };
  const GrantsDisplay = ({ grantList, hideTitle, newOfferAvailable, onNewOfferRequest }) => {
    const [selectedGrantDetail, setSelectedGrantDetail] = d();
    const [selectedGrant, setSelectedGrant] = d();
    const { i18n } = useCoreContext();
    const [activeGrants, inactiveGrants] = T$1(() => {
      const active = [];
      const inactive = [];
      grantList == null ? void 0 : grantList.forEach((grant) => {
        if (grant.status === "Active" || grant.status === "Pending") {
          active.push(grant);
        } else {
          inactive.push(grant);
        }
      });
      return [active, inactive];
    }, [grantList]);
    const displayMode = T$1(() => {
      if (grantList.length > 1 && activeGrants.length && inactiveGrants.length) return "SegmentedGrants";
      return "UnifiedGrants";
    }, [activeGrants.length, grantList.length, inactiveGrants.length]);
    const showNewOfferButton = T$1(() => {
      return newOfferAvailable && !activeGrants.some((grant) => grant.status === "Pending");
    }, [activeGrants, newOfferAvailable]);
    const selectedGrantConfig = T$1(() => selectedGrant && getGrantConfig(selectedGrant), [selectedGrant]);
    const hideGrantDetails = q$1(() => setSelectedGrantDetail(void 0), []);
    const showGrantDetails = q$1((grant, detail) => {
      setSelectedGrantDetail(detail);
      setSelectedGrant(grant);
    }, []);
    if (selectedGrant) {
      switch (selectedGrantDetail) {
        case GRANT_ADJUSTMENT_DETAILS.unscheduledRepayment: {
          if (selectedGrantConfig == null ? void 0 : selectedGrantConfig.hasUnscheduledRepaymentDetails) {
            return /* @__PURE__ */ u$1(GrantRepaymentDetails, { grant: selectedGrant, onDetailsClose: hideGrantDetails });
          }
          break;
        }
      }
    }
    return /* @__PURE__ */ u$1("div", { className: "adyen-pe-grant-list", children: [
      /* @__PURE__ */ u$1("div", { className: "adyen-pe-grant-list__header-container", children: [
        /* @__PURE__ */ u$1(CapitalHeader, { hideTitle, titleKey: "capital.businessFinancing" }),
        showNewOfferButton ? /* @__PURE__ */ u$1(Button$1, { onClick: onNewOfferRequest, className: "adyen-pe-grant-list__offer-button", variant: ButtonVariant.SECONDARY, children: i18n.get("capital.seeNewOffer") }) : null
      ] }),
      displayMode === "UnifiedGrants" && /* @__PURE__ */ u$1(List, { grants: grantList, showDetails: showGrantDetails }),
      displayMode === "SegmentedGrants" && /* @__PURE__ */ u$1(
        SegmentedControl,
        {
          items: [
            {
              label: "capital.inProgress",
              content: /* @__PURE__ */ u$1(List, { grants: activeGrants, showDetails: showGrantDetails }),
              id: "active"
            },
            {
              label: "capital.closed",
              content: /* @__PURE__ */ u$1(List, { grants: inactiveGrants, showDetails: showGrantDetails }),
              id: "inactive"
            }
          ],
          activeItem: "active"
        }
      )
    ] });
  };
  const GrantList = ({
    externalDynamicOffersConfig,
    grantList,
    newOfferAvailable,
    onFundsRequest,
    onGrantListUpdateRequest,
    onOfferDismiss
  }) => {
    const [isCapitalOfferVisible, setIsCapitalOfferVisible] = d(false);
    const goBackToPreviousStep = q$1(() => setIsCapitalOfferVisible(false), []);
    const goToNextStep = q$1(() => setIsCapitalOfferVisible(true), []);
    const goBackToList = q$1(() => {
      onOfferDismiss ? onOfferDismiss(goBackToPreviousStep) : goBackToPreviousStep();
    }, [goBackToPreviousStep, onOfferDismiss]);
    const handleFundsRequest = q$1(
      (data) => {
        if (onFundsRequest) {
          onFundsRequest(data);
        } else {
          onGrantListUpdateRequest(data);
          setIsCapitalOfferVisible(false);
        }
      },
      [onFundsRequest, onGrantListUpdateRequest]
    );
    return /* @__PURE__ */ u$1(k$1, { children: isCapitalOfferVisible ? /* @__PURE__ */ u$1(
      CapitalOffer,
      {
        externalDynamicOffersConfig,
        onFundsRequest: handleFundsRequest,
        onOfferDismiss: goBackToList
      }
    ) : /* @__PURE__ */ u$1(GrantsDisplay, { grantList, newOfferAvailable, onNewOfferRequest: goToNextStep }) });
  };
  const CapitalOverview = ({
    hideTitle,
    onContactSupport,
    onFundsRequest,
    onOfferDismiss,
    onOfferOptionsRequest,
    skipPreQualifiedIntro
  }) => {
    var _a2, _b2, _c2;
    const legalEntity = (_b2 = (_a2 = useConfigContext()) == null ? void 0 : _a2.extraConfig) == null ? void 0 : _b2.legalEntity;
    const isRegionSupported = T$1(() => isCapitalRegionSupported(legalEntity), [legalEntity]);
    const { getGrants: grantsEndpointCall, getDynamicGrantOffersConfiguration: dynamicConfigurationEndpointCall } = useConfigContext().endpoints;
    const grantsQuery = useFetch({
      fetchOptions: { enabled: !!grantsEndpointCall && isRegionSupported },
      queryFn: q$1(async () => {
        return grantsEndpointCall == null ? void 0 : grantsEndpointCall(EMPTY_OBJECT);
      }, [grantsEndpointCall])
    });
    const dynamicOfferQuery = useFetch({
      fetchOptions: { enabled: !!dynamicConfigurationEndpointCall && isRegionSupported },
      queryFn: q$1(async () => {
        return dynamicConfigurationEndpointCall == null ? void 0 : dynamicConfigurationEndpointCall(EMPTY_OBJECT);
      }, [dynamicConfigurationEndpointCall])
    });
    const dynamicOffer = dynamicOfferQuery.data;
    const [requestedGrant, setRequestedGrant] = d();
    const grantList = T$1(
      () => {
        var _a3, _b3;
        return requestedGrant ? [requestedGrant, ...((_a3 = grantsQuery.data) == null ? void 0 : _a3.data) || []] : (_b3 = grantsQuery.data) == null ? void 0 : _b3.data;
      },
      [(_c2 = grantsQuery.data) == null ? void 0 : _c2.data, requestedGrant]
    );
    const handlePreQualifiedFundsRequest = q$1(
      (data) => {
        onFundsRequest ? onFundsRequest(data) : setRequestedGrant(data);
      },
      [onFundsRequest]
    );
    const showError = T$1(() => {
      if (dynamicOfferQuery.error && grantsQuery.error) return true;
      if (dynamicOfferQuery.error && !(grantList == null ? void 0 : grantList.length)) return true;
      return false;
    }, [dynamicOfferQuery.error, grantList == null ? void 0 : grantList.length, grantsQuery.error]);
    const state = T$1(() => {
      if (!isRegionSupported) {
        return "UnsupportedRegion";
      } else if (showError) {
        return "Error";
      } else if (!grantsEndpointCall && !dynamicConfigurationEndpointCall || !dynamicOffer && !grantList || grantsQuery.isFetching || dynamicOfferQuery.isFetching) {
        return "Loading";
      } else if (grantList == null ? void 0 : grantList.length) {
        return "GrantList";
      } else if ((dynamicOffer == null ? void 0 : dynamicOffer.maxAmount) && (dynamicOffer == null ? void 0 : dynamicOffer.minAmount)) {
        return "PreQualified";
      }
      return "Unqualified";
    }, [
      dynamicConfigurationEndpointCall,
      dynamicOffer,
      dynamicOfferQuery.isFetching,
      grantList,
      grantsEndpointCall,
      grantsQuery.isFetching,
      showError,
      isRegionSupported
    ]);
    const newOfferAvailable = T$1(() => !!(dynamicOffer && dynamicOffer.minAmount && dynamicOffer.maxAmount), [dynamicOffer]);
    return /* @__PURE__ */ u$1("div", { className: CAPITAL_OVERVIEW_CLASS_NAMES.base, children: (() => {
      switch (state) {
        case "Loading":
          return /* @__PURE__ */ u$1("div", { className: CAPITAL_OVERVIEW_CLASS_NAMES.skeletonContainer, children: [
            /* @__PURE__ */ u$1("div", { className: CAPITAL_OVERVIEW_CLASS_NAMES.headerSkeleton }),
            /* @__PURE__ */ u$1("div", { className: CAPITAL_OVERVIEW_CLASS_NAMES.skeleton })
          ] });
        case "Error":
          return /* @__PURE__ */ u$1("div", { className: CAPITAL_OVERVIEW_CLASS_NAMES.errorContainer, children: [
            /* @__PURE__ */ u$1(CapitalHeader, { hideTitle, titleKey: "capital.businessFinancing" }),
            /* @__PURE__ */ u$1(
              ErrorMessageDisplay,
              {
                absolutePosition: false,
                outlined: false,
                withImage: true,
                onContactSupport,
                ...getCapitalErrorMessage(dynamicOfferQuery.error, onContactSupport)
              }
            )
          ] });
        case "GrantList":
          return grantList && /* @__PURE__ */ u$1(
            GrantList,
            {
              externalDynamicOffersConfig: dynamicOffer,
              grantList,
              hideTitle,
              newOfferAvailable,
              onFundsRequest,
              onGrantListUpdateRequest: setRequestedGrant,
              onOfferDismiss
            }
          );
        case "PreQualified":
          return /* @__PURE__ */ u$1(
            PreQualified,
            {
              onOfferDismiss,
              onOfferOptionsRequest,
              skipPreQualifiedIntro,
              hideTitle,
              dynamicOffer,
              onFundsRequest: handlePreQualifiedFundsRequest
            }
          );
        case "Unqualified":
          return /* @__PURE__ */ u$1(Unqualified, { hideTitle });
        case "UnsupportedRegion":
          return /* @__PURE__ */ u$1("div", { className: CAPITAL_OVERVIEW_CLASS_NAMES.errorContainer, children: [
            /* @__PURE__ */ u$1(CapitalHeader, { hideTitle, titleKey: "capital.businessFinancing" }),
            /* @__PURE__ */ u$1(CapitalErrorMessageDisplay, { unsupportedRegion: true })
          ] });
        default:
          return null;
      }
    })() });
  };
  class CapitalOverviewElement extends UIElement {
    constructor(props) {
      super(props);
      __publicField(this, "componentToRender", () => {
        return /* @__PURE__ */ u$1(CapitalOverview, { ...this.props, ref: (ref) => void (this.componentRef = ref) });
      });
      this.customClassNames = "adyen-pe-capital-overview-component";
      this.componentToRender = this.componentToRender.bind(this);
    }
    async getState() {
      var _a2, _b2;
      const { session } = this.props.core;
      await sessionReady(session);
      const { getDynamicGrantOffersConfiguration, getGrants } = session.context.endpoints;
      const legalEntity = (_a2 = session.context.extraConfig) == null ? void 0 : _a2.legalEntity;
      if (!isCapitalRegionSupported(legalEntity)) {
        return { state: "isInUnsupportedRegion" };
      }
      const [config, grants] = await Promise.all([
        getDynamicGrantOffersConfiguration == null ? void 0 : getDynamicGrantOffersConfiguration(EMPTY_OBJECT).catch(noop),
        getGrants == null ? void 0 : getGrants(EMPTY_OBJECT).catch(noop)
      ]);
      let state = "isUnqualified";
      if (grants && ((_b2 = grants.data) == null ? void 0 : _b2.length) > 0) {
        state = "hasRequestedGrants";
      } else if (config && config.minAmount) {
        state = "isPreQualified";
      }
      return { state };
    }
  }
  __publicField(CapitalOverviewElement, "type", "capitalOverview");
  const BASE_CLASS$4 = "adyen-pe-disputes-overview";
  const BASE_XS_CLASS = `${BASE_CLASS$4}--xs`;
  const TABS_CONTAINER_CLASS = `${BASE_CLASS$4}__tabs-container`;
  const EARLIEST_DISPUTES_SINCE_DATE = "2025-05-22T00:00:00.000Z";
  const DISPUTE_ACTION_NEEDED_URGENTLY_THRESHOLD_DAYS = 10;
  const DISPUTE_PAYMENT_SCHEMES = {
    mc: "Mastercard",
    visa: "Visa",
    ach: "ACH Direct Debit",
    amex: "American Express",
    discover: "Discover",
    elo: "Elo",
    jcb: "JCB",
    pulse: "PULSE",
    sepadirectdebit: "SEPA Direct Debit",
    others: "Others"
  };
  const DISPUTE_REASON_CATEGORIES = {
    FRAUD: "disputes.reasonCategory.fraud",
    CONSUMER_DISPUTE: "disputes.reasonCategory.consumerDispute",
    PROCESSING_ERROR: "disputes.reasonCategory.processingError",
    REQUEST_FOR_INFORMATION: "disputes.reasonCategory.requestForInformation",
    AUTHORISATION_ERROR: "disputes.reasonCategory.authorisationError",
    ADJUSTMENT: "disputes.reasonCategory.adjustment",
    OTHER: "disputes.reasonCategory.other"
  };
  const DISPUTE_STATUS_GROUPS = {
    CHARGEBACKS: "disputes.statusGroup.chargebacks",
    FRAUD_ALERTS: "disputes.statusGroup.fraudAlerts",
    ONGOING_AND_CLOSED: "disputes.statusGroup.ongoingAndClosed"
  };
  const DISPUTE_STATUSES = {
    ACCEPTED: "disputes.status.accepted",
    EXPIRED: "disputes.status.expired",
    LOST: "disputes.status.lost",
    PENDING: "disputes.status.pending",
    RESPONDED: "disputes.status.responded",
    UNDEFENDED: "disputes.status.undefended",
    UNRESPONDED: "disputes.status.unresponded",
    WON: "disputes.status.won"
  };
  const DISPUTE_TYPES = {
    CHARGEBACK: "disputes.type.chargeback",
    NOTIFICATION_OF_FRAUD: "disputes.type.notificationOfFraud",
    REQUEST_FOR_INFORMATION: "disputes.type.requestForInformation"
  };
  const getDisputeActionNeededLevel = (disputeData) => {
    switch (disputeData.status) {
      case "UNDEFENDED":
      case "UNRESPONDED": {
        const deadlineTimestamp = parseDate(disputeData.dueDate);
        if (deadlineTimestamp != void 0) {
          const now = Date.now();
          const deadline = new Date(deadlineTimestamp);
          const actionNeededNowThresholdTimestamp = new Date(deadline).setHours(deadline.getHours() - 24);
          if (actionNeededNowThresholdTimestamp <= now) {
            return 7;
          }
          const actionNeededUrgentlyThresholdTimestamp = new Date(deadline).setDate(
            deadline.getDate() - DISPUTE_ACTION_NEEDED_URGENTLY_THRESHOLD_DAYS
          );
          if (actionNeededUrgentlyThresholdTimestamp <= now) {
            return 3;
          }
        }
        return 1;
      }
    }
    return 0;
  };
  const isDisputeActionNeeded = (disputeData) => {
    return getDisputeActionNeededLevel(disputeData) > 0;
  };
  const isDisputeActionNeededUrgently = (disputeData) => {
    return getDisputeActionNeededLevel(disputeData) > 1;
  };
  const BASE_CLASS$3 = "adyen-pe-disputes-table";
  const DisputeStatusTag = ({ dispute }) => {
    const { i18n } = useCoreContext();
    const disputeStatus = T$1(() => i18n.get(DISPUTE_STATUSES[dispute.status]), [i18n, dispute]);
    const variant = T$1(() => {
      if (dispute.status === "WON") return TagVariant.SUCCESS;
      if (isDisputeActionNeededUrgently(dispute)) return TagVariant.ERROR;
      return TagVariant.DEFAULT;
    }, [dispute]);
    return /* @__PURE__ */ u$1(Tag, { variant, label: disputeStatus });
  };
  const FIELD_KEYS = {
    status: "disputes.status",
    respondBy: "disputes.respondBy",
    createdAt: "disputes.openedOn",
    paymentMethod: "disputes.paymentMethod",
    disputeReason: "disputes.disputeReason",
    reason: "disputes.reason",
    currency: "disputes.currency",
    disputedAmount: "disputes.disputedAmount",
    totalPaymentAmount: "disputes.totalPaymentAmount"
  };
  const EMPTY_TABLE_MESSAGE_KEYS = {
    CHARGEBACKS: { title: "disputes.empty.noChargebacksFound", message: "disputes.empty.tryDifferentSearchOrCheckAgainLaterForNewChargebacks" },
    FRAUD_ALERTS: { title: "disputes.empty.noFraudAlertsFound", message: "disputes.empty.tryDifferentSearchOrCheckAgainLaterForNewFraudAlerts" },
    ONGOING_AND_CLOSED: { title: "disputes.empty.noDisputesFound", message: "disputes.empty.tryDifferentSearchOrCheckAgainLaterForNewDisputes" }
  };
  const FIELDS = Object.keys(FIELD_KEYS);
  const classes$4 = {
    cellContent: `${BASE_CLASS$3}__cell-content`,
    cellContentVStack: `${BASE_CLASS$3}__cell-content--vstack`,
    cellTextGrey: `${BASE_CLASS$3}__cell-text--grey`,
    statusContent: `${BASE_CLASS$3}__status-content`,
    statusContentUrgent: `${BASE_CLASS$3}__status-content--urgent`
  };
  const DisputesTable = ({
    error,
    loading: loading2,
    balanceAccountId: balanceAccountId2,
    onContactSupport,
    showPagination,
    onRowClick,
    data,
    customColumns,
    activeBalanceAccount,
    statusGroup,
    ...paginationProps
  }) => {
    const { i18n } = useCoreContext();
    const { refreshing } = useConfigContext();
    const { dateFormat } = useTimezoneAwareDateFormatting(activeBalanceAccount == null ? void 0 : activeBalanceAccount.timeZone);
    const [alert, setAlert] = d(null);
    const isLoading = T$1(() => loading2 || refreshing, [loading2, refreshing]);
    const isMobileContainer = useResponsiveContainer(containerQueries.down.xs);
    const columns = useTableColumns({
      fields: FIELDS,
      fieldsKeys: FIELD_KEYS,
      customColumns,
      columnConfig: T$1(
        () => ({
          status: {
            visible: statusGroup === "ONGOING_AND_CLOSED"
          },
          reason: {
            visible: statusGroup === "FRAUD_ALERTS" && !isMobileContainer,
            flex: 2
          },
          respondBy: {
            visible: statusGroup === "CHARGEBACKS"
          },
          currency: {
            visible: !isMobileContainer,
            flex: 0.5
          },
          disputedAmount: {
            visible: statusGroup !== "FRAUD_ALERTS",
            position: "right"
          },
          createdAt: {
            visible: !isMobileContainer || statusGroup === "FRAUD_ALERTS"
          },
          paymentMethod: {
            visible: !isMobileContainer
          },
          disputeReason: {
            visible: statusGroup !== "FRAUD_ALERTS" && !isMobileContainer
          },
          totalPaymentAmount: {
            visible: statusGroup === "FRAUD_ALERTS",
            position: "right"
          }
        }),
        [isMobileContainer, statusGroup]
      )
    });
    const removeAlert = q$1(() => setAlert(null), []);
    const EMPTY_TABLE_MESSAGE = {
      title: EMPTY_TABLE_MESSAGE_KEYS[statusGroup].title,
      message: [EMPTY_TABLE_MESSAGE_KEYS[statusGroup].message]
    };
    const errorDisplay = T$1(
      () => () => /* @__PURE__ */ u$1(DataOverviewError, { error, errorMessage: "disputes.error.weCouldNotLoadYourDisputes", onContactSupport }),
      [error, onContactSupport]
    );
    y(() => {
      if (isLoading) removeAlert();
    }, [isLoading, removeAlert]);
    return /* @__PURE__ */ u$1("div", { className: BASE_CLASS$3, children: [
      alert && /* @__PURE__ */ u$1(Alert, { onClose: removeAlert, type: AlertTypeOption.WARNING, className: "adyen-pe-disputes-table-alert", ...alert }),
      /* @__PURE__ */ u$1(
        DataGrid,
        {
          autoFitColumns: isMobileContainer,
          errorDisplay,
          error,
          columns,
          data,
          loading: isLoading,
          outline: false,
          onRowClick: { callback: onRowClick },
          emptyTableMessage: EMPTY_TABLE_MESSAGE,
          customCells: {
            status: ({ item }) => {
              return /* @__PURE__ */ u$1("div", { className: cx(classes$4.cellContent, { [classes$4.cellContentVStack]: isMobileContainer }), children: [
                /* @__PURE__ */ u$1(DisputeStatusTag, { dispute: item }),
                isMobileContainer && /* @__PURE__ */ u$1(PaymentMethodCell, { paymentMethod: item.paymentMethod })
              ] });
            },
            reason: ({ item }) => {
              return item.reason.title;
            },
            respondBy: ({ item }) => {
              const isUrgent = isDisputeActionNeededUrgently(item);
              const renderDueDate = () => /* @__PURE__ */ u$1(k$1, { children: [
                dateFormat(item.dueDate, DATE_FORMAT_DISPUTES),
                isUrgent && /* @__PURE__ */ u$1(Icon$1, { name: "warning-filled" })
              ] });
              return /* @__PURE__ */ u$1("div", { className: cx(classes$4.cellContent, { [classes$4.cellContentVStack]: isMobileContainer }), children: [
                item.dueDate ? /* @__PURE__ */ u$1(
                  Typography$1,
                  {
                    variant: TypographyVariant.BODY,
                    className: cx(classes$4.statusContent, {
                      [classes$4.cellTextGrey]: isMobileContainer && !isUrgent,
                      [classes$4.statusContentUrgent]: isUrgent
                    }),
                    children: isMobileContainer ? /* @__PURE__ */ u$1(Translation, { translationKey: "disputes.gridCell.dueDate", fills: { dueDate: renderDueDate } }) : renderDueDate()
                  }
                ) : null,
                isMobileContainer && /* @__PURE__ */ u$1(PaymentMethodCell, { paymentMethod: item.paymentMethod })
              ] });
            },
            currency: ({ item }) => {
              return /* @__PURE__ */ u$1(Tag, { children: item.amount.currency });
            },
            disputedAmount: ({ item }) => {
              return item.amount && /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.BODY, stronger: true, children: i18n.amount(item.amount.value, item.amount.currency, { hideCurrency: false }) });
            },
            createdAt: ({ item }) => {
              return /* @__PURE__ */ u$1("div", { className: cx(classes$4.cellContent, { [classes$4.cellContentVStack]: isMobileContainer }), children: [
                /* @__PURE__ */ u$1(
                  Typography$1,
                  {
                    variant: TypographyVariant.BODY,
                    className: cx(classes$4.statusContent, {
                      [classes$4.cellTextGrey]: isMobileContainer
                    }),
                    children: dateFormat(item.createdAt, DATE_FORMAT_DISPUTES)
                  }
                ),
                isMobileContainer && /* @__PURE__ */ u$1(PaymentMethodCell, { paymentMethod: item.paymentMethod })
              ] });
            },
            paymentMethod: ({ item }) => /* @__PURE__ */ u$1(PaymentMethodCell, { paymentMethod: item.paymentMethod }),
            disputeReason: ({ item }) => /* @__PURE__ */ u$1("span", { children: i18n.get(DISPUTE_REASON_CATEGORIES[item.reason.category]) }),
            totalPaymentAmount: ({ item }) => {
              return item && /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.BODY, stronger: true, children: i18n.amount(item.amount.value, item.amount.currency, { hideCurrency: false }) });
            }
          },
          children: showPagination && /* @__PURE__ */ u$1(DataGrid.Footer, { children: /* @__PURE__ */ u$1(Pagination, { ...paginationProps }) })
        }
      )
    ] });
  };
  const cloneFormData = (formData) => {
    const formDataClone = new FormData();
    for (const [field, value2] of formData.entries()) {
      if (value2 instanceof File) {
        formDataClone.set(field, value2, value2.name);
      } else formDataClone.set(field, value2);
    }
    return formDataClone;
  };
  const DisputeFlowContext = K$1(void 0);
  const DisputeContextProvider = M(({ dispute, setDispute, children }) => {
    const [flowState, setFlowState] = d("details");
    const [selectedDefenseReason, setSelectedDefenseReason] = d(null);
    const [applicableDocuments, setApplicableDocuments] = d([]);
    const [defendDisputePayload, setDefendDisputePayload] = d(null);
    const [defendResponse, setDefendResponse] = d(null);
    const clearFiles = q$1(() => {
      setDefendDisputePayload((previousFormData) => {
        if (previousFormData) {
          const fileFields = [...previousFormData.keys()].filter((field) => field !== "defenseReason");
          if (fileFields.length > 0) {
            const nextFormData = cloneFormData(previousFormData);
            fileFields.forEach((field) => nextFormData.delete(field));
            return nextFormData;
          }
        }
        return previousFormData;
      });
    }, []);
    const goBack2 = q$1(() => {
      switch (flowState) {
        case "defendReasonSelectionView":
          setFlowState("details");
          break;
        case "accept":
          setFlowState("details");
          break;
        case "uploadDefenseFilesView":
          clearFiles();
          setFlowState("defendReasonSelectionView");
          break;
        default:
          setFlowState("details");
          break;
      }
    }, [clearFiles, flowState]);
    const clearStates = q$1(() => {
      setSelectedDefenseReason(null);
      setApplicableDocuments(null);
      setDefendDisputePayload(null);
      setDefendResponse(null);
      setDispute(void 0);
    }, [setDispute]);
    const addFileToDefendPayload = q$1((field, file2) => {
      setDefendDisputePayload((previousFormData) => {
        const nextFormData = previousFormData ? cloneFormData(previousFormData) : new FormData();
        nextFormData.set(field, file2, file2.name);
        return nextFormData;
      });
    }, []);
    const moveFieldInDefendPayload = q$1((fromField, toField) => {
      setDefendDisputePayload((previousFormData) => {
        if (previousFormData && previousFormData.has(fromField)) {
          const fromFieldValue = previousFormData.get(fromField);
          const nextFormData = cloneFormData(previousFormData);
          nextFormData.delete(fromField);
          if (fromFieldValue instanceof File) {
            nextFormData.set(toField, fromFieldValue, fromFieldValue.name);
          } else nextFormData.set(toField, fromFieldValue);
          return nextFormData;
        }
        return previousFormData;
      });
    }, []);
    const removeFieldFromDefendPayload = q$1((field) => {
      setDefendDisputePayload((previousFormData) => {
        if (previousFormData && previousFormData.has(field)) {
          const nextFormData = cloneFormData(previousFormData);
          nextFormData.delete(field);
          return nextFormData;
        }
        return previousFormData;
      });
    }, []);
    const onDefendSubmit = q$1((response) => {
      setDefendResponse(response);
    }, []);
    y(() => {
      setDefendDisputePayload(() => {
        if (selectedDefenseReason) {
          const nextFormData = new FormData();
          nextFormData.set("defenseReason", selectedDefenseReason);
          return nextFormData;
        }
        return null;
      });
    }, [selectedDefenseReason]);
    return /* @__PURE__ */ u$1(
      DisputeFlowContext.Provider,
      {
        value: {
          addFileToDefendPayload,
          applicableDocuments,
          clearFiles,
          clearStates,
          defendResponse,
          dispute,
          flowState,
          goBack: goBack2,
          setApplicableDocuments,
          setFlowState,
          setDispute,
          selectedDefenseReason,
          setSelectedDefenseReason,
          defendDisputePayload,
          onDefendSubmit,
          moveFieldInDefendPayload,
          removeFieldFromDefendPayload
        },
        children
      }
    );
  });
  const useDisputeFlow = () => {
    const context = x(DisputeFlowContext);
    if (!context) throw new Error("useDisputeFlow must be used within DisputeFlowProvider");
    return context;
  };
  const AcceptDisputeFlow = ({ onDisputeAccept }) => {
    const { i18n } = useCoreContext();
    const { acceptDispute } = useConfigContext().endpoints;
    const { dispute, clearStates, goBack: goBack2 } = useDisputeFlow();
    const cachedDispute = A$1(dispute).current ?? dispute;
    const disputePspReference = cachedDispute == null ? void 0 : cachedDispute.dispute.pspReference;
    const disputeType = cachedDispute == null ? void 0 : cachedDispute.dispute.type;
    const isRequestForInformation = disputeType === "REQUEST_FOR_INFORMATION";
    const acceptedLabel = A$1("disputes.accept.disputeAccepted");
    const acceptDisclaimer = A$1("disputes.accept.disputeDisclaimer");
    const acceptTitle = A$1("disputes.accept.chargeback");
    const acceptButtonTitle = A$1("disputes.accept.chargeback");
    const isRFI = A$1(isRequestForInformation);
    if (isRFI.current || (isRFI.current = isRequestForInformation)) {
      acceptedLabel.current = "disputes.accept.requestForInformationAccepted";
      acceptDisclaimer.current = "disputes.accept.requestForInformationDisclaimer";
      acceptTitle.current = "disputes.accept.requestForInformation";
      acceptButtonTitle.current = "disputes.accept";
    }
    const [termsAgreed, setTermsAgreed] = d(false);
    const [disputeAccepted, setDisputeAccepted] = d(false);
    const acceptDisputeMutation = useMutation({
      queryFn: acceptDispute,
      options: {
        onSuccess: q$1(() => {
          clearStates();
          setDisputeAccepted(true);
        }, [clearStates])
      }
    });
    const interactionsDisabled = acceptDisputeMutation.isLoading || disputeAccepted;
    const canAcceptDispute = termsAgreed && !interactionsDisabled;
    const acceptDisputeCallback = q$1(() => {
      if (!canAcceptDispute) return;
      void acceptDisputeMutation.mutate(EMPTY_OBJECT, { path: { disputePspReference } });
    }, [canAcceptDispute, disputePspReference, acceptDisputeMutation]);
    const toggleTermsAgreement = q$1(() => {
      if (interactionsDisabled) return;
      setTermsAgreed((prev) => !prev);
    }, [interactionsDisabled]);
    const actionButtons = T$1(() => {
      return [
        {
          title: i18n.get(acceptButtonTitle.current),
          disabled: !canAcceptDispute,
          state: acceptDisputeMutation.isLoading ? "loading" : "default",
          variant: ButtonVariant.PRIMARY,
          event: acceptDisputeCallback,
          classNames: disputeAccepted ? ["adyen-pe-accept-dispute__accepted-btn"] : void 0,
          renderTitle: (title) => {
            if (disputeAccepted) {
              return /* @__PURE__ */ u$1(k$1, { children: [
                /* @__PURE__ */ u$1(Icon$1, { name: "checkmark-circle-fill", className: "adyen-pe-accept-dispute__accepted-icon" }),
                i18n.get("disputes.accept.accepted")
              ] });
            }
            return title;
          }
        },
        {
          title: i18n.get("disputes.goBack"),
          disabled: acceptDisputeMutation.isLoading,
          variant: ButtonVariant.SECONDARY,
          event: goBack2
        }
      ];
    }, [i18n, acceptDisputeCallback, acceptDisputeMutation.isLoading, canAcceptDispute, goBack2, disputeAccepted]);
    const acceptCallbackHasBeenCalled = A$1(false);
    const termsAgreementInputId = A$1(uniqueId()).current;
    y(() => {
      if (acceptCallbackHasBeenCalled.current) return;
      if (disputeAccepted && disputePspReference && isFunction(onDisputeAccept)) {
        acceptCallbackHasBeenCalled.current = true;
        onDisputeAccept({ id: disputePspReference });
      }
    }, [disputeAccepted, disputePspReference, onDisputeAccept]);
    return /* @__PURE__ */ u$1("div", { className: "adyen-pe-accept-dispute__container", children: disputeAccepted ? /* @__PURE__ */ u$1("div", { className: "adyen-pe-accept-dispute__success", children: [
      /* @__PURE__ */ u$1(Icon$1, { name: "checkmark-circle-fill", className: "adyen-pe-accept-dispute__success-icon" }),
      /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.TITLE, children: i18n.get(acceptedLabel.current) }),
      /* @__PURE__ */ u$1(Button$1, { variant: ButtonVariant.SECONDARY, onClick: goBack2, children: i18n.get("disputes.showDisputeDetails") })
    ] }) : /* @__PURE__ */ u$1(k$1, { children: [
      /* @__PURE__ */ u$1(Typography$1, { className: "adyen-pe-accept-dispute__title", variant: TypographyVariant.TITLE, medium: true, children: i18n.get(acceptTitle.current) }),
      /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.BODY, medium: true, children: i18n.get(acceptDisclaimer.current) }),
      /* @__PURE__ */ u$1("div", { className: "adyen-pe-accept-dispute__input", children: [
        /* @__PURE__ */ u$1(
          "input",
          {
            type: "checkbox",
            disabled: interactionsDisabled,
            className: "adyen-pe-visually-hidden",
            id: termsAgreementInputId,
            onInput: toggleTermsAgreement
          }
        ),
        /* @__PURE__ */ u$1("label", { className: "adyen-pe-accept-dispute__label", htmlFor: termsAgreementInputId, children: [
          termsAgreed ? /* @__PURE__ */ u$1(Icon$1, { name: "checkmark-square-fill" }) : /* @__PURE__ */ u$1(Icon$1, { name: "square" }),
          /* @__PURE__ */ u$1(Typography$1, { el: TypographyElement.SPAN, variant: TypographyVariant.BODY, children: i18n.get("disputes.accept.iAgree") })
        ] })
      ] }),
      /* @__PURE__ */ u$1("div", { className: "adyen-pe-accept-dispute__actions", children: /* @__PURE__ */ u$1(ButtonActions$1, { actions: actionButtons }) })
    ] }) });
  };
  const BASE_CLASS$2 = "adyen-pe-file-input";
  const DEFAULT_FILE_TYPES = ["application/pdf", "image/jpeg", "image/jpg", "image/png"];
  const DEFAULT_MAX_FILE_SIZE = 2097152;
  const validationErrors = {
    DISALLOWED_FILE_TYPE: "disallowed_file_type",
    FILE_REQUIRED: "file_required",
    TOO_MANY_FILES: "too_many_files",
    VERY_LARGE_FILE: "very_large_file"
  };
  const classes$3 = {
    fileBase: `${BASE_CLASS$2}__file`,
    fileButton: `${BASE_CLASS$2}__file-button`,
    fileDetails: `${BASE_CLASS$2}__file-details`,
    fileIcon: `${BASE_CLASS$2}__file-icon`,
    fileName: `${BASE_CLASS$2}__file-name`,
    fileSize: `${BASE_CLASS$2}__file-size`
  };
  function UploadedFile({ file: file2, deleteFile, disabled }) {
    const fileSize = T$1(() => getHumanReadableFileSize(file2.size), [file2.size]);
    return /* @__PURE__ */ u$1("div", { className: classes$3.fileBase, children: [
      /* @__PURE__ */ u$1("div", { className: classes$3.fileDetails, children: [
        /* @__PURE__ */ u$1(Icon$1, { name: "checkmark-circle-fill", className: classes$3.fileIcon }),
        /* @__PURE__ */ u$1("div", { className: classes$3.fileName, title: file2.name, children: /* @__PURE__ */ u$1(Typography$1, { el: TypographyElement.SPAN, variant: TypographyVariant.BODY, stronger: true, children: file2.name }) }),
        /* @__PURE__ */ u$1(Typography$1, { className: classes$3.fileSize, el: TypographyElement.SPAN, variant: TypographyVariant.BODY, children: fileSize })
      ] }),
      /* @__PURE__ */ u$1(Button$1, { className: classes$3.fileButton, disabled, variant: ButtonVariant.TERTIARY, onClick: deleteFile, children: [
        /* @__PURE__ */ u$1(Icon$1, { name: "trash-can" }),
        /* @__PURE__ */ u$1("span", { className: "adyen-pe-visually-hidden", children: /* @__PURE__ */ u$1(Translation, { translationKey: "uploadedFile.remove", fills: { filename: file2.name } }) })
      ] })
    ] });
  }
  const useTrackedRef = (ref) => {
    return T$1(() => {
      let currentInstance = (ref == null ? void 0 : ref.current) ?? null;
      let updateRef = noop;
      if (ref) {
        updateRef = isFunction(ref) ? ref : (instance) => void (ref.current = instance);
      }
      const trackedRef = (instance) => {
        currentInstance = instance;
        updateRef(instance);
      };
      return Object.defineProperty(trackedRef, "current", {
        enumerable: true,
        get: () => currentInstance,
        set: trackedRef
      });
    }, [ref]);
  };
  const classes$2 = {
    dropzone: `${BASE_CLASS$2}__dropzone`,
    dropzoneDisabled: `${BASE_CLASS$2}__dropzone--disabled`,
    dropzoneDragOver: `${BASE_CLASS$2}__dropzone--dragover`,
    dropzoneError: `${BASE_CLASS$2}__dropzone--error`,
    label: `${BASE_CLASS$2}__label`,
    labelDefault: `${BASE_CLASS$2}__label-default-content`,
    labelIcon: `${BASE_CLASS$2}__label-icon`,
    labelText: `${BASE_CLASS$2}__label-text`,
    error: `${BASE_CLASS$2}__error`,
    errorIcon: `${BASE_CLASS$2}__error-icon`,
    errorText: `${BASE_CLASS$2}__error-text`
  };
  const Dropzone = fixedForwardRef((props, ref) => {
    const {
      id: id2,
      name,
      children,
      disabled = false,
      required = false,
      maxFileSize = DEFAULT_MAX_FILE_SIZE,
      allowedFileTypes = DEFAULT_FILE_TYPES,
      mapError,
      uploadFiles
    } = props;
    const { i18n } = useCoreContext();
    const [inputError, setInputError] = d("");
    const [largeFileErrorContext, setLargeFileErrorContext] = d();
    const [dragOver, setDragOver] = d(false);
    const isInvalid = !!inputError;
    const inputName = name == null ? void 0 : name.trim();
    const inputId = T$1(() => id2 || uniqueId(), [id2]);
    const inputRef = useTrackedRef(ref);
    const handleDragOver = (event) => {
      var _a2;
      const hasFiles = Array.from(((_a2 = event.dataTransfer) == null ? void 0 : _a2.types) ?? []).some((type2) => type2 === "Files");
      if (hasFiles) {
        event.preventDefault();
        setDragOver(true);
      }
    };
    const handleDragLeave = (event) => {
      event.preventDefault();
      setDragOver(false);
    };
    const handleDrop = (event) => {
      event.preventDefault();
      setDragOver(false);
      updateFiles(event.dataTransfer);
    };
    const handleFileChange = (event) => {
      largeFileErrorContext && setLargeFileErrorContext(void 0);
      updateFiles(event.target);
    };
    const handleInputBlur = async (event) => {
      var _a2;
      if (event.target !== document.activeElement) {
        (_a2 = event.target) == null ? void 0 : _a2.checkValidity();
      }
    };
    const handleInputInvalid = async (event) => {
      if (!inputError && event.target.validity.valueMissing) {
        updateInputValidationError(validationErrors.FILE_REQUIRED);
      }
    };
    const updateInputValidationError = q$1(
      (error) => {
        const inputElement = inputRef.current;
        if (inputElement) {
          const currentRequired = inputElement.required;
          inputElement.required = false;
          inputElement.setCustomValidity(error);
          setInputError(inputElement.validationMessage ?? "");
          inputElement.required = currentRequired;
        }
      },
      [inputRef]
    );
    const updateFiles = q$1(
      (source) => {
        const uploadedFiles = getUploadedFilesFromSource(source);
        if (uploadedFiles.length > 1) {
          return updateInputValidationError(validationErrors.TOO_MANY_FILES);
        }
        try {
          const allowedFiles = uploadedFiles.filter((file2) => {
            if (!allowedFileTypes.includes(file2.type)) {
              throw validationErrors.DISALLOWED_FILE_TYPE;
            }
            const currentMaxFileSize = isFunction(maxFileSize) ? maxFileSize(file2.type) ?? DEFAULT_MAX_FILE_SIZE : maxFileSize;
            if (file2.size > currentMaxFileSize) {
              setLargeFileErrorContext({ type: file2.type, limit: currentMaxFileSize });
              throw validationErrors.VERY_LARGE_FILE;
            }
            return true;
          });
          updateInputValidationError("");
          uploadFiles(allowedFiles);
        } catch (ex) {
          switch (ex) {
            case validationErrors.DISALLOWED_FILE_TYPE:
            case validationErrors.VERY_LARGE_FILE:
              return updateInputValidationError(ex);
          }
        }
      },
      [allowedFileTypes, maxFileSize, updateInputValidationError, uploadFiles]
    );
    return /* @__PURE__ */ u$1(k$1, { children: [
      /* @__PURE__ */ u$1(
        "div",
        {
          role: "region",
          className: cx(classes$2.dropzone, {
            [classes$2.dropzoneDisabled]: disabled,
            [classes$2.dropzoneDragOver]: dragOver,
            [classes$2.dropzoneError]: isInvalid
          }),
          onDragOver: disabled ? void 0 : handleDragOver,
          onDragLeave: disabled ? void 0 : handleDragLeave,
          onDrop: disabled ? void 0 : handleDrop,
          children: [
            /* @__PURE__ */ u$1(
              "input",
              {
                type: "file",
                className: "adyen-pe-visually-hidden",
                id: inputId,
                ref: inputRef,
                name: inputName,
                disabled,
                required,
                accept: String(allowedFileTypes),
                onBlur: handleInputBlur,
                onChange: handleFileChange,
                onInvalid: handleInputInvalid,
                "aria-invalid": isInvalid,
                "data-testId": "dropzone-input"
              }
            ),
            /* @__PURE__ */ u$1("label", { className: classes$2.label, htmlFor: inputId, children: children ?? /* @__PURE__ */ u$1("div", {
              className: cx(classes$2.labelDefault),
              // prettier-ignore
              children: [
                isInvalid ? /* @__PURE__ */ u$1(Icon$1, { name: "warning-filled", className: classes$2.labelIcon }) : /* @__PURE__ */ u$1(Icon$1, { name: "upload", className: classes$2.labelIcon }),
                /* @__PURE__ */ u$1(Typography$1, { className: classes$2.labelText, el: TypographyElement.SPAN, variant: TypographyVariant.BODY, stronger: true, children: i18n.get("uploadFile.browse") })
              ]
            }) })
          ]
        }
      ),
      isInvalid && /* @__PURE__ */ u$1("div", { className: classes$2.error, children: [
        /* @__PURE__ */ u$1(Icon$1, { name: "cross-circle-fill", className: classes$2.errorIcon }),
        /* @__PURE__ */ u$1(Typography$1, { className: classes$2.errorText, el: TypographyElement.SPAN, variant: TypographyVariant.BODY, children: isFunction(mapError) ? mapError(
          inputError,
          largeFileErrorContext ? { size: largeFileErrorContext.limit, type: largeFileErrorContext.type } : void 0
        ) : i18n.get(inputError) })
      ] })
    ] });
  });
  const FileInput = fixedForwardRef(({ onChange, mapError, onDelete, ...restProps }, ref) => {
    const [files, setFiles] = d([]);
    const uploadedFiles = A$1(files);
    const uploadedFile = files[0];
    const { i18n } = useCoreContext();
    const { disabled } = restProps;
    const defaultMapError = q$1(
      (error) => {
        switch (error) {
          case validationErrors.DISALLOWED_FILE_TYPE:
            return i18n.get("inputError.disallowedFileType");
          case validationErrors.FILE_REQUIRED:
            return i18n.get("inputError.fileRequired");
          case validationErrors.TOO_MANY_FILES:
            return i18n.get("inputError.tooManyFiles");
          case validationErrors.VERY_LARGE_FILE:
            return i18n.get("inputError.veryLargeFile");
        }
      },
      [i18n]
    );
    const mapErrorWithFallback = T$1(() => isFunction(mapError) ? mapError : defaultMapError, [mapError]);
    const deleteFile = q$1(
      (fileToDelete) => {
        if (disabled) return;
        setFiles((currentFiles) => {
          const fileIndex = currentFiles.findIndex((file2) => file2 === fileToDelete);
          if (fileIndex < 0) {
            return currentFiles;
          }
          const [...currentFilesCopy] = currentFiles;
          currentFilesCopy.splice(fileIndex, 1);
          return currentFilesCopy;
        });
        onDelete == null ? void 0 : onDelete();
      },
      [disabled, onDelete]
    );
    const uploadFiles = q$1(
      (files2) => {
        if (disabled) return;
        setFiles((currentFiles) => {
          if (currentFiles.length === 0 && files2.length === 0) {
            return currentFiles;
          } else {
            return files2;
          }
        });
      },
      [disabled]
    );
    y(() => {
      if (uploadedFiles.current === files) return;
      uploadedFiles.current = files;
      onChange == null ? void 0 : onChange([...files]);
    }, [files, onChange]);
    return /* @__PURE__ */ u$1("div", {
      className: BASE_CLASS$2,
      // prettier-ignore
      children: uploadedFile ? /* @__PURE__ */ u$1(UploadedFile, { disabled, file: uploadedFile, deleteFile: () => deleteFile(uploadedFile) }) : /* @__PURE__ */ u$1(Dropzone, { ...restProps, ref, mapError: mapErrorWithFallback, uploadFiles })
    });
  });
  const AcquirerMemberMessageText = { "title": "clearingText", "help": "descriptionOfDisputeReason" };
  const AcquirerRecurringTransactionDetails = { "title": "latestRecurringTransactions", "help": "latestRecurringTransactions" };
  const AcquirerRepresentmentForm = { "title": "acquirerRepresentmentForm", "help": "acquirerRepresentmentFormAutomaticallyGenerated" };
  const AcquirerRetrievalFulfilmentForm = { "title": "acquirerRetrievalFulfilmentForm", "help": "acquirerRetrievalFulfilmentFormAutomaticallyGenerated" };
  const AcquirerRFItransactionDetails = { "title": "automaticallyGeneratedTransactionDetails", "help": "automaticallyGeneratedTransactionDetails" };
  const AddendumDocumentation = { "title": "proofOfAddendum", "help": "cardholderResponsibleForAddendumTransaction" };
  const AdditionalInformation$1 = { "title": "additionalInformation", "help": "docIdentifyTransaction" };
  const AdditionalTransactions = { "title": "additionalTransactions", "help": "additionalTransactionsConnectedWithDisputedFlight" };
  const AlternativeDefenseMaterial = { "title": "alternativeDefenseMaterial", "help": "docRemediesChargeback" };
  const AmexFaxCover = { "title": "amexFaxCover", "help": "coverPageForAmexDisputes" };
  const ARDnotProvided = { "title": "memberMessageText", "help": "memberMessageTextSentToSchemes" };
  const AuthorisedTransaction$1 = { "title": "memberMessageText", "help": "memberMessageTextSentToSchemes" };
  const CancellationNeverAccepted = { "title": "rebuttalCancellationNotAccepted", "help": "rebuttalStatingCancellationNotAccepted" };
  const CardholderIdentification = { "title": "evidenceCardHolderParticipation", "help": "docProvingCardHolderParticipated", "helpitems": ["receiptOrOther", "customerWrittenConfirmation", "writtenCorrespondenceExchanged"] };
  const CardholderRenewedMembership$1 = { "title": "proofRenewedMembership", "help": "proofShowingCardholderRenewedMembership" };
  const CardPresent = { "title": "proofCardPresence", "help": "proofCardAndCardholderSignature" };
  const ChargebackCodeNotApplicable = { "title": "docChargebackCodeNotApplicable" };
  const ChipLiabilityShift$1 = { "title": "memberMessageText", "help": "memberMessageTextSentToSchemes" };
  const ChipTransactionReportedToSAFE$1 = { "title": "defenseMaterial", "help": "docViaFraudReporter" };
  const CopyOfSalesDraft = { "title": "CopyOfSalesDraftTitle", "help": "CopyOfSalesDraftDetails" };
  const CompellingEvidence$1 = { "title": "memberMessageText", "help": "memberMessageTextSentToSchemes" };
  const CorrectTransactionCurrency$1 = { "title": "defenseMaterial", "help": "docCorrectCurrency" };
  const CreditPreviouslyIssued$1 = { "title": "memberMessageText", "help": "memberMessageTextSentToSchemes" };
  const DateMerchandiseShipped = { "title": "documentShipmentDate", "help": "documentContainingImportantShipmentData" };
  const DefenseMaterial = { "title": "defenseMaterial", "help": "docRemediesChargeback" };
  const DisclosureAtPointOfInteraction = { "title": "disclosureAtPointOfInteraction", "help": "rebuttalGivenToCardholder" };
  const DuplicateChargeback$1 = { "title": "firstChargebackNumberAndDate", "help": "numberAndDateOfOriginalChargeback" };
  const EvidenceOfCardholderParticipation = { "title": "compellingEvidence", "help": "evidenceProofingParticipationOfCardholder" };
  const FlightManifest = { "title": "flightManifest", "help": "flightManifestShowingCardholderName" };
  const FlightTicket = { "title": "flightTicket", "help": "flightTicketWithCardholderName" };
  const FlightTicketAtBillingAddress = { "title": "deliveryOfFlightTicketAtAddress", "help": "receiptOfFlightTicketAtBillingAddress" };
  const FlightTicketUsed = { "title": "flightTicketUsed", "help": "proofAirlineTicketsWereUsed" };
  const FligthTookPlace = { "title": "flightTookPlace", "help": "proofFlightTookPlace" };
  const FrequentFlyer = { "title": "frequentFlyerInformation", "help": "creditsOfMilesShowingConnectionToCardholder" };
  const GoodsNotReturned$1 = { "title": "merchantWrittenRebuttal", "help": "statementMerchantDidNotReceiveGoods" };
  const GoodsRepairedOrReplaced$1 = { "title": "merchantWrittenRebuttal", "help": "writtenRebutalGoodsRepairedOrReplaced" };
  const GoodsWereAsDescribed$1 = { "title": "merchantWrittenRebuttal", "help": "proofGoodsWereDeliveredAsDescribed" };
  const IncreasedTransactionAmount$1 = { "title": "proofValidIncreaseOfAmount", "help": "cardholderResponsibleForDisputedAmount" };
  const InvalidCancellationCode$1 = { "title": "explanation", "help": "explanationWhyCancellationCodeInvalid" };
  const InvalidChargeback$1 = { "title": "proofOfInvalidChargeback", "help": "chargebackRemediedOrInvalid" };
  const LiabilityShiftFullUCAF$1 = { "title": "memberMessageText", "help": "memberMessageTextSentToSchemes" };
  const LiabilityShiftMerchantUCAF$1 = { "title": "memberMessageText", "help": "memberMessageTextSentToSchemes" };
  const MerchandiseDescription = { "title": "merchandiseDescription", "help": "descriptionOfMerchandiseOrServices" };
  const MerchandiseNotCounterfeit$1 = { "title": "defenseMaterial", "help": "docMerchandiseNotCounterfeit" };
  const MerchantProofOfRecurringTransaction = { "title": "proofOfRecurringTransaction", "help": "docAllOfFollowing", "helpitems": ["evidenceTransactionWasRecurring", "moreThanOneTransactionProcessed", "previousTransactionsNotDisputed"] };
  const MPIdata = { "title": "mpiData", "help": "resultsOfMpiCalls" };
  const NotCancelled$1 = { "title": "proofOfNoCancellation", "help": "proofRecurringContractNotCancelledAtTimeOfSettlement" };
  const NotChargebacked$1 = { "title": "proofOfNoChargebackReceived", "help": "proofMerchantHadNotReceivedPreviousChargeback" };
  const NotChargebackedAuto$1 = { "title": "proofOfNoChargebackReceived", "help": "proofMerchantHadNotReceivedPreviousChargebackAutoGenerated" };
  const NotNotified$1 = { "title": "noNotification", "help": "proofMerchantNotNotifiedOfCancellation" };
  const OriginalAmount = { "title": "originalAmount", "help": "originalAmountIfDisputedRepresentsPartialShipment" };
  const PaperAirlineTicket = { "title": "paperAirlineTicket", "help": "docCardholderIssuedPaperAirlineTickets" };
  const PassengerIdentification = { "title": "passengerId", "help": "passengerIdLinkedToCardholder" };
  const PastChargebackTimeLimit$1 = { "title": "memberMessageText", "help": "memberMessageTextSentToSchemes" };
  const PaymentByOtherMeans$1 = { "title": "appropriateExplanation", "help": "appropriateExplanationAndDocTwoSeparateTransactions" };
  const PINTransaction$1 = { "title": "memberMessageText", "help": "memberMessageTextSentToSchemes" };
  const PositiveAVS = { "title": "avsDocumentation", "help": "documentationOfPositiveAvsResponseXOrY" };
  const PresentmentWithinTimeLimit$1 = { "title": "memberMessageText", "help": "memberMessageTextSentToSchemes" };
  const PrintedSignedTerminalReceipt = { "title": "signedTerminalReceipt", "help": "printedSignedReceipt" };
  const ProofOfAbilityToProvideServices = { "title": "proofOfDelayedDelivery", "help": "ifDelayedProofShowingMerchantAbleToProvideServices" };
  const ProofOfAccountTakeover = { "title": "proofOfAccountTakeover", "help": "provingTransactionResultedFromAccountTakeover" };
  const ProofOfAttendedPOSTerminal = { "title": "proofCardPresence", "help": "docTransactionOccurredOnPos" };
  const ProofOfCardPresenceAndSignatureChipNoPIN$1 = { "title": "memberMessageText", "help": "memberMessageTextSentToSchemes" };
  const ProofOfCardPresenceAndSignatureWithTerminalReceipt$1 = { "title": "memberMessageText", "help": "memberMessageTextSentToSchemes" };
  const ProofOfCardPresenceSignatureOrChipPIN = { "title": "signatureOrChipPinEvidence" };
  const ProofOfGoodsOrServicesProvided = { "title": "proofProvidedMerchandise", "help": "proofGoodsServicesWereProvided" };
  const ProofOfNoShow = { "title": "proofOfNoShow", "help": "merchantObtainedCardAtTimeReservationMade" };
  const ProofOfRecurringTransaction = { "title": "proofOfRecurringTransaction", "help": "docAllOfFollowing", "helpitems": ["evidenceTransactionWasRecurring", "moreThanOneTransactionProcessed", "previousTransactionsNotDisputed"] };
  const ProofOfRetailSaleRatherThanCredit = { "title": "proofOfRetailSale", "help": "copyOfTid" };
  const ReasonForReturn = { "title": "reasonForInvalidation", "help": "reasonForInvalidationOfChargeback" };
  const RetrievalRequestFulfilled$1 = { "title": "retrievalRequestFulfilled", "help": "autoGeneratedDocRetrievalRequestFulfilled" };
  const ReturnedMerchandiseNotReceived = { "title": "memberMessageText", "help": "memberMessageTextSentToSchemes" };
  const SaleTermsNotMisrepresented$1 = { "title": "defenseMaterial", "help": "docTermsOfSaleNotMisrepresented" };
  const ShippedToAVS$1 = { "title": "shipmentDocumentation", "help": "merchandiseSentToAvsConfirmedBillingAddress" };
  const ShipToAddress = { "title": "shipToAddress", "help": "shipToAddressIfApplicable" };
  const SupplementalDocuments = { "title": "SupplementalDocumentsTitle", "help": "SupplementalDocumentsDetails" };
  const TEDocument = { "title": "TEDocumentTitle", "help": "TEDocumentDetails" };
  const TIDorInvoice = { "title": "copyOfInvoice", "help": "copyOfInvoiceOrOtherRelevantTransactionDetails" };
  const TransactionNotPOS$1 = { "title": "memberMessageText", "help": "memberMessageTextSentToSchemes" };
  const TwoDifferentTIDs$1 = { "title": "docTwoDifferentTransactions", "help": "docsTwoTransactionsWithSameShopper" };
  const TwoPINTransactions$1 = { "title": "memberMessageText", "help": "memberMessageTextSentToSchemes" };
  const TwoPriorFraudChargebacks$1 = { "title": "memberMessageText", "help": "memberMessageTextSentToSchemes" };
  const UnreasonableAmount$1 = { "title": "reasonableAmount", "help": "cardholderAgreedToAmountRange" };
  const DuplicateProcessing = { "title": "duplicateProcessing", "help": "duplicateProcessingHelp" };
  const ChargeToWrongAccountNumber = { "title": "chargeToWrongAccountNumber", "help": "chargeToWrongAccountNumberHelp" };
  const SplitSales = { "title": "SplitSales", "help": "SplitSalesHelp" };
  const MissingSignature = { "title": "missingSignature", "help": "missingSignatureHelp" };
  const ProcessingError = { "title": "processingError", "help": "processingErrorHelp" };
  const ExpiredCard = { "title": "expiredCard", "help": "expiredCardHelp" };
  const LatePresentment = { "title": "latePresentment", "help": "latePresentmentgHelp" };
  const FalseTransaction = { "title": "falseTransaction", "help": "falseTransactionHelp" };
  const AuthorizationNotObtained = { "title": "authorizationNotObtained", "help": "authorizationNotObtainedHelp" };
  const TransactionNotRecognizedContactlessAndCardNotPresented = { "title": "transactionNotRecognizedContactlessAndCardNotPresented", "help": "transactionNotRecognizedContactlessAndCardNotPresentedHelp" };
  const TransactionNotRecognizedChipLiabilityShift = { "title": "transactionNotRecognizedChipLiabilityShift", "help": "transactionNotRecognizedChipLiabilityShiftHelp" };
  const DeffectiveMerchandise = { "title": "deffectiveMerchandise", "help": "deffectiveMerchandiseHelp" };
  const MerchandiseNotReceived = { "title": "merchandiseNotReceived", "help": "merchandiseNotReceivedHelp" };
  const ServiceNotRendered = { "title": "serviceNotRendered", "help": "serviceNotRenderedHelp" };
  const CardRecoveryBulletinOrExceptionFile = { "title": "cardRecoveryBulletinOrExceptionFile", "help": "cardRecoveryBulletinOrExceptionFileHelp" };
  const TransactionAfterReservationCancelled = { "title": "transactionAfterReservationCancelled", "help": "transactionAfterReservationCancelledHelp" };
  const DifferentSignature = { "title": "differentSignature", "help": "differentSignatureHelp" };
  const RetrievalRequestNotHonored = { "title": "retrievalRequestNotHonored", "help": "retrievalRequestNotHonoredHelp" };
  const CreditNotProcessed = { "title": "creditNotProcessed", "help": "creditNotProcessedHelp" };
  const PaidByOtherMeansThanJCBCard = { "title": "paidByOtherMeansThanJCBCard", "help": "paidByOtherMeansThanJCBCardHelp" };
  const NonMatchingAccountNumber = { "title": "nonMatchingAccountNumber", "help": "nonMatchingAccountNumberHelp" };
  const MerchantFraudPerformanceProgram = { "title": "merchantFraudPerformanceProgram", "help": "merchantFraudPerformanceProgramHelp" };
  const Other = { "title": "other", "help": "otherHelp" };
  const ProofOfFulfillment = { "title": "proofOfFulfillment", "help": "proofShowingTrackingInformation" };
  const ProofOfRefund = { "title": "proofOfRefund", "help": "uploadListOfRefundIds" };
  const MerchandiseNotAsDescribedReason = { "title": "merchandiseNotAsDescribed", "help": "documentCanBetUrlReturnPolicy" };
  const CancelledRecurringBillingReason = { "title": "cancelledRecurringBilling", "help": "documentCanBeSubscriptionAgreement" };
  const IncorrectAmountReason = { "title": "incorrectAmount", "help": "provideRefundId" };
  const ProofOfRefundForAmountDifference = { "title": "incorrectAmount", "help": "provideRefundId" };
  const UnauthorisedReason = { "title": "unauthorisedReason", "help": "documentCanBeProofOfDelivery" };
  const CreditNotProcessedReason = { "title": "creditNotProcessedReason", "help": "documentCanBeCreditReasonDue" };
  const defenseDocumentConfig = {
    AcquirerMemberMessageText,
    AcquirerRecurringTransactionDetails,
    AcquirerRepresentmentForm,
    AcquirerRetrievalFulfilmentForm,
    AcquirerRFItransactionDetails,
    AddendumDocumentation,
    AdditionalInformation: AdditionalInformation$1,
    AdditionalTransactions,
    AlternativeDefenseMaterial,
    AmexFaxCover,
    ARDnotProvided,
    AuthorisedTransaction: AuthorisedTransaction$1,
    CancellationNeverAccepted,
    CardholderIdentification,
    CardholderRenewedMembership: CardholderRenewedMembership$1,
    CardPresent,
    ChargebackCodeNotApplicable,
    ChipLiabilityShift: ChipLiabilityShift$1,
    ChipTransactionReportedToSAFE: ChipTransactionReportedToSAFE$1,
    CopyOfSalesDraft,
    CompellingEvidence: CompellingEvidence$1,
    CorrectTransactionCurrency: CorrectTransactionCurrency$1,
    CreditPreviouslyIssued: CreditPreviouslyIssued$1,
    DateMerchandiseShipped,
    DefenseMaterial,
    DisclosureAtPointOfInteraction,
    DuplicateChargeback: DuplicateChargeback$1,
    EvidenceOfCardholderParticipation,
    FlightManifest,
    FlightTicket,
    FlightTicketAtBillingAddress,
    FlightTicketUsed,
    FligthTookPlace,
    FrequentFlyer,
    GoodsNotReturned: GoodsNotReturned$1,
    GoodsRepairedOrReplaced: GoodsRepairedOrReplaced$1,
    GoodsWereAsDescribed: GoodsWereAsDescribed$1,
    IncreasedTransactionAmount: IncreasedTransactionAmount$1,
    InvalidCancellationCode: InvalidCancellationCode$1,
    InvalidChargeback: InvalidChargeback$1,
    LiabilityShiftFullUCAF: LiabilityShiftFullUCAF$1,
    LiabilityShiftMerchantUCAF: LiabilityShiftMerchantUCAF$1,
    MerchandiseDescription,
    MerchandiseNotCounterfeit: MerchandiseNotCounterfeit$1,
    MerchantProofOfRecurringTransaction,
    MPIdata,
    NotCancelled: NotCancelled$1,
    NotChargebacked: NotChargebacked$1,
    NotChargebackedAuto: NotChargebackedAuto$1,
    NotNotified: NotNotified$1,
    OriginalAmount,
    PaperAirlineTicket,
    PassengerIdentification,
    PastChargebackTimeLimit: PastChargebackTimeLimit$1,
    PaymentByOtherMeans: PaymentByOtherMeans$1,
    PINTransaction: PINTransaction$1,
    PositiveAVS,
    PresentmentWithinTimeLimit: PresentmentWithinTimeLimit$1,
    PrintedSignedTerminalReceipt,
    ProofOfAbilityToProvideServices,
    ProofOfAccountTakeover,
    ProofOfAttendedPOSTerminal,
    ProofOfCardPresenceAndSignatureChipNoPIN: ProofOfCardPresenceAndSignatureChipNoPIN$1,
    ProofOfCardPresenceAndSignatureWithTerminalReceipt: ProofOfCardPresenceAndSignatureWithTerminalReceipt$1,
    ProofOfCardPresenceSignatureOrChipPIN,
    ProofOfGoodsOrServicesProvided,
    ProofOfNoShow,
    ProofOfRecurringTransaction,
    ProofOfRetailSaleRatherThanCredit,
    ReasonForReturn,
    RetrievalRequestFulfilled: RetrievalRequestFulfilled$1,
    ReturnedMerchandiseNotReceived,
    SaleTermsNotMisrepresented: SaleTermsNotMisrepresented$1,
    ShippedToAVS: ShippedToAVS$1,
    ShipToAddress,
    SupplementalDocuments,
    TEDocument,
    TIDorInvoice,
    TransactionNotPOS: TransactionNotPOS$1,
    TwoDifferentTIDs: TwoDifferentTIDs$1,
    TwoPINTransactions: TwoPINTransactions$1,
    TwoPriorFraudChargebacks: TwoPriorFraudChargebacks$1,
    UnreasonableAmount: UnreasonableAmount$1,
    DuplicateProcessing,
    ChargeToWrongAccountNumber,
    SplitSales,
    MissingSignature,
    ProcessingError,
    ExpiredCard,
    LatePresentment,
    FalseTransaction,
    AuthorizationNotObtained,
    TransactionNotRecognizedContactlessAndCardNotPresented,
    TransactionNotRecognizedChipLiabilityShift,
    DeffectiveMerchandise,
    MerchandiseNotReceived,
    ServiceNotRendered,
    CardRecoveryBulletinOrExceptionFile,
    TransactionAfterReservationCancelled,
    DifferentSignature,
    RetrievalRequestNotHonored,
    CreditNotProcessed,
    PaidByOtherMeansThanJCBCard,
    NonMatchingAccountNumber,
    MerchantFraudPerformanceProgram,
    Other,
    ProofOfFulfillment,
    ProofOfRefund,
    MerchandiseNotAsDescribedReason,
    CancelledRecurringBillingReason,
    IncorrectAmountReason,
    ProofOfRefundForAmountDifference,
    UnauthorisedReason,
    CreditNotProcessedReason
  };
  const ATMDispute = { "title": "atmDispute", "help": "invalidChargebackReasonCode" };
  const AccountTakeover = { "title": "accountTakeover", "help": "transactionFromAccountTakeover" };
  const AdditionalInformation = { "title": "additionalInformation", "help": "merchantCanProvideAdditionalInformation" };
  const AirlineCompellingEvidence = { "title": "airlineCompellingEvidence", "help": "evidenceCardholderAuthorizedTransaction" };
  const AirlineFlightProvided = { "title": "airlineFlightProvided", "help": "shopperUsedAirlineTicket" };
  const AirlineRFIresponse = { "title": "responseToRfiAirlines", "help": "provideTransactionalInfoTravelDetails" };
  const AuthorisedTransaction = { "title": "transactionWasAuthorised", "help": "authorisationReceivedForAmount" };
  const AutomaticRFIresponse = { "title": "autoResponseToRfi", "help": "autoResponseSentToIssuer" };
  const CVC2ValidationProgram = { "title": "cvc2ValidationProgram", "help": "transactionFallsCvc2ValidationProgram" };
  const CancellationOrReturns = { "title": "cancellationOrReturns", "help": "useThisDefenseReasonIfApplicable", "helpitems": ["noCreditSlip", "returnNotAccepted", "merchandiseNotReturned"] };
  const CancellationTermsFailed = { "title": "cancellationContractFailed", "help": "cardholderDidNotMeetCancellationTerms" };
  const CarRentalRFIresponse = { "title": "responseToRfiCarRental", "help": "provideTransactionalInfoTravelDetails" };
  const CardNotOnExceptionFile = { "title": "accountNumberNotListedInExceptions", "help": "accountNumberNotListedInExceptionsFor60Days" };
  const CardNotPresentRFIresponse = { "title": "reponseToRfi", "help": "provideTransactionalInformation" };
  const CardPresentFraud = { "title": "fraudEvidence" };
  const CardPresentNotApplicable = { "title": "cbCodeNotApplicable", "help": "firstChargebackCodeNotApplicable" };
  const CardPresentRFIresponse = { "title": "reponseToRfiCardPresent", "help": "provideTransactionalInformation" };
  const CardholderNotReplied = { "title": "cardholderNotifiedButNoReply", "help": "cardholderNotifiedBeforeRecurringTransaction" };
  const CardholderParticipated = { "title": "cardholderParticipated", "help": "evidenceThatCardholderParticipated" };
  const CardholderRenewedMembership = { "title": "membershipRenewedAfterCancellation", "help": "cardholderCancelledRecurringServiceButRenewedLater" };
  const ChipLiabilityShift = { "title": "chipLiabilityShift", "help": "transactionBetweenChipLiabilityShiftProgramCustomers" };
  const ChipTransactionReportedToSAFE = { "title": "chipTransactionReportedSAFE", "help": "intraregionalTransactionReportedSAFE" };
  const CieloRFIresponse = { "title": "reponseToRfi", "help": "provideTransactionalInformation" };
  const CompellingEvidence = { "title": "compellingEvidence", "help": "evidenceCardholderAuthorizedTransaction" };
  const CompellingEvidenceRecurringTransactions = { "title": "compellingEvidenceRecurringTransactions", "help": "evidenceServicesProvidedAndReceivedWrittenCorrespondence" };
  const CorrectTransactionAmount = { "title": "correctTransactionAmount", "help": "transactionInformationDocument" };
  const CorrectTransactionCurrency = { "title": "correctTransactionCurrency", "help": "chargebackInvalidCorrectAmountAndCurrencyProvided" };
  const CorrectTransactionDate = { "title": "correctTransactionDateProvided", "help": "acquirerProvidesCorrectDateWithinTimeLimit" };
  const CreditOrCancellationPolicyProperlyDisclosed = { "title": "creditOrCancellationPolicyDisclosed", "help": "creditOrCancellationPolicyDisclosedToCardholder" };
  const CreditPreviouslyIssued = { "title": "creditPreviouslyIssued", "help": "transactionAmountAlreadyRefunded" };
  const DeficiencyCorrected = { "title": "deficiencyCorrected", "help": "proofDeficiencyCorrected" };
  const DisputedSurcharge = { "title": "disputedSurcharge", "help": "surchargeCorrectlyProcessed" };
  const DisputedSurchargeIncorrectProratedCalculation = { "title": "disputedSurchargeIncorrectCalculation", "help": "surchargeIncorrectlyCalculatedByIssuer" };
  const DuplicateChargeback = { "title": "duplicateChargeback", "help": "issuerProcessedChargebackMoreThanOnce" };
  const EMVLiabilityShift = { "title": "emvLiabilityShift", "help": "emvDeviceNonEmvCard" };
  const EmergencyPaymentAuthorizationService = { "title": "emergencyPaymentAuthorizationService", "help": "transactioAuthorisedEmergencyPaymentAuthorizationService" };
  const FaceToFace = { "title": "faceToFaceTransactionNoConflictingInformation", "help": "transactionWasInFaceToFaceEnvironment" };
  const FaceToFaceConflictingMessages = { "title": "faceToFaceTransactionWithConflictingInformation", "help": "de22DontMatchInFaceToFaceTransaction" };
  const GoodsNotReturned = { "title": "goodsNotReturned", "help": "cardholderShouldHaveReturnedGoods" };
  const GoodsOrServicesProvided = { "title": "goodsOrServicesProvided", "help": "proofCardholderReceivedMerchandise", "helpitems": ["signedImprintedSalesSlipInvoicePosReceipt", "parcelServiceReceipt", "waiverFormAbsolvingMerchantResponsibility"] };
  const GoodsRepairedOrReplaced = { "title": "goodsRepairedOrReplaced", "help": "goodsWereRepairedOrReplaced" };
  const GoodsWereAsDescribed = { "title": "goodsWereAsDescribed", "help": "evidenceGoodsNotDamaged" };
  const IdentifiedAddendum = { "title": "identifiedAddendum", "help": ["cardholderResponsibleForAddendumTransaction", "cardholderResponsibleForDisputedAmount", "cardholderBilledForSeparateAdditionalAmount"] };
  const IllegibleDocumentationReceived = { "title": "documentationReceivedWasIllegible", "help": "firstChargebackInvalid" };
  const IncreasedTransactionAmount = { "title": "increasedTransactionAmount", "help": "documentationIncreasedDebitCardholderAccount" };
  const InvalidARD = { "title": "invalidAcquirerReferenceData", "help": "invalidReferenceDataDocumentationNotRequired" };
  const InvalidCancellationCode = { "title": "invalidCancellationCode", "help": "cancellationCodeWasInvalidAsShownByExplanationProvided" };
  const InvalidChargeback = { "title": "invalidChargeback", "help": ["firstChargebackDoesNotMeetPrerequisites", "thisReasonIsTechnical"] };
  const InvalidChargebackAllocation = { "title": "invalidChargeback", "help": ["firstChargebackDoesNotMeetPrerequisites", "thisReasonIsTechnical"] };
  const InvalidChargebackBundling = { "title": "chargebackBundlingInvalid", "help": "chargebackBundlingInvalid" };
  const InvalidDE72CB = { "title": "invalidMessageText", "help": "formatCbmmddyyArdXxxExpected" };
  const InvalidDE72MultipleTransactions = { "title": "invalidMessageText", "help": "formatMultipleTransactionsNnnExpected" };
  const InvalidDE72RPCS = { "title": "invalidMessageText", "help": "formatRpcsMmddyyExpected" };
  const InvalidReasonCodeForMCC = { "title": "invalidChargebackBasedOnMcc", "help": "merchantCantReceiveThisChargebackBasedOnTheirMcc" };
  const JCBRFIResponse = { "title": "reponseToRfi", "help": "provideTransactionalInformation" };
  const JustifiedDelayedPresentment = { "title": "justifiedDelayedPresentment", "help": "delayInSubmittingTransaction" };
  const LiabilityShiftFullAuthenticated = { "title": "liabilityShiftFullAuthenticated", "help": "transactionIssuerApproved3dSecureAuthenticated" };
  const LiabilityShiftFullUCAF = { "title": "3dSecureFullyAuthenticatedTransaction", "help": "transactionApproved3dSecureAuthenticated" };
  const LiabilityShiftMerchantUCAF = { "title": "3dSecureLiabilityShiftNotFullyAuthenticated", "help": "transactionNotFully3dSecureAuthenticated" };
  const MerchandiseNotCounterfeit = { "title": "merchandiseWasNotCounterfeit" };
  const MerchandiseReceived = { "title": "merchandiseWasReceivedByShopper", "help": "proofCardholderReceivedMerchandise", "helpitems": ["signedImprintedSalesSlipInvoicePosReceipt", "parcelServiceReceipt", "waiverFormAbsolvingMerchantResponsibility"] };
  const MissingInformation = { "title": "provideMissingInformation", "help": "merchantProvideMissingDocuments" };
  const NoARDprovidedInMessageText = { "title": "invalidMessageText", "help": "issuerDidNotIncludeTwoSetsOfArns" };
  const NoShowTransaction = { "title": "noShowTransaction", "help": "transactionWasResultOfGuaranteedReservation" };
  const NonReceiptOfRequiredDocuments = { "title": "requiredDocumentationNotReceived", "help": "issuerDidNotProvideRequiredDocumentation" };
  const NonReceiptOfRequiredDocumentsAutoDefense = { "title": "requiredDocumentationNotReceived", "help": "issuerDidNotProvideRequiredDocumentation" };
  const Not3DSecure = { "title": "not3dSecureTransaction", "help": "chargebackCodeNA3dSecureNotOffered" };
  const NotCancelled = { "title": "serviceNotCancelled", "help": "serviceNotCancelledEvidence" };
  const NotChargebacked = { "title": "noPriorChargebackReceived", "help": "claimNotJustifiedSinceTransactionNotChargebacked" };
  const NotChargebackedAuto = { "title": "noPriorChargebackReceived", "help": "transactionNotChargebackedAutoDefense" };
  const NotNotified = { "title": "merchantNotNotifiedOfCancellation", "help": "serviceCancelledButMerchantNotNotified" };
  const NotPaidByOtherMeans = { "title": "additionalInformation", "help": "docToProveNoPaymentByOtherMean" };
  const NotRecurring = { "title": "transactionNotRecurring", "help": "transactionNotRecurringTransactionInstallment" };
  const PINTransaction = { "title": "pinTransaction", "help": "pinUsedToVerifyCardholder" };
  const PastChargebackTimeLimit = { "title": "pastChargebackTimeLimit", "help": "chargebackReceivedAfterMastercardTimeLimit" };
  const PayPassTransaction = { "title": "paypassTransaction", "help": "paypassAmountBelowProtectionAmount" };
  const PaymentByOtherMeans = { "title": "paymentByOtherMeans", "help": "validityOfTransactionChargedExplanation" };
  const PresentmentWithinTimeLimit = { "title": "transactionSettledWithinTimeLimit", "help": "timeBetweenAuthorisationAndSettlementWithinTimeLimits" };
  const PreviousTransactionNotChargebacked = { "title": "noPriorChargebackReceived", "help": "previousChargebackCancellingRecurringContract" };
  const ProofOfCardPresenceAndSignatureChipNoPIN = { "title": "chipTransaction", "help": "cardPresentAndChipUsedNoPinProvided" };
  const ProofOfCardPresenceAndSignatureLossTheftOrDamage = { "title": "transactionsInitiatedDueToLossTheftOrDamages", "help": "receiptWithItemsBilledBecauseOfLossTheftDamages" };
  const ProofOfCardPresenceAndSignatureMasterCardCorporateFleetCard = { "title": "proofOfCardPresenceMastercardCorporateFleet", "help": "cardAndSignatureForCorporateFleetCardTransaction" };
  const ProofOfCardPresenceAndSignatureNotMasterCardWorldWideNetwork = { "title": "proofOfCardPresenceAvailableNotAuthorisedMastercardNetwork", "help": "cardWithSignatureNotProcessedMastercardNetwork" };
  const ProofOfCardPresenceAndSignatureWithTerminalReceipt = { "title": "signedTerminalReceiptAvailable", "help": "posTransactionAndSignedTerminalReceiptAvailable" };
  const ProofOfCardPresenceAndSignatureWithoutTerminalReceipt = { "title": "cardPresenceProof", "help": "posTransactionCardholderWasPresentProof" };
  const ProvideInformation = { "title": "provideInformationForCollectionOrFraudCase" };
  const PurchaseProperlyPosted = { "title": "purchaseProperlyPosted", "help": "transactionWasProperlyIdentifiedAsInstallmentTransaction" };
  const QPSTransaction = { "title": "qpsTransaction", "help": "qpsTransactionWithAmountLessThanChargebackProtectionAmount" };
  const RecurringTransactionsCompellingEvidence = { "title": "recurringTransactionCompellingEvidence", "help": "autoGeneratedRecurringTransactionDetails" };
  const RecurringTransactionsCompellingMerchantEvidence = { "title": "recurringTransactionCompellingMerchantEvidence", "help": "merchantCanProvideAdditionalCompellingEvidence" };
  const RefundNotAgreed = { "title": "notAgreeWithRefund", "help": "shopperClaimsRefundWasPromisedButNotExecuted" };
  const RetrievalRequestFulfilled = { "title": "retrievalRequestFulfilled", "help": "documentsSentToFulfillRetrievalRequest" };
  const ReturnPeriodExpired = { "title": "buyerExceededWindowToFileReturn", "help": "uploadReturnPolicyDocument" };
  const SaleTermsNotMisrepresented = { "title": "termsOfSaleWereNotMisrepresented" };
  const ScanningError = { "title": "scanningError", "help": "defenseReasonIfProblemsWithScans" };
  const ServicesProvided = { "title": "goodsOrServicesProvided", "help": "merchantProvidedServicesToCardholderProof" };
  const ServicesProvidedAfterCancellation = { "title": "servicesProvidedAfterCancellation", "help": "servicesProvidedAndUsedAfterCancellation" };
  const ShippedToAVS = { "title": "addressVerificationService", "help": "addressMerchandiseSentAvsConfirmed" };
  const ShippedToAVSAdditionalInformation = { "title": "addressVerificationServiceAdditionalInformation", "help": "addressMerchandiseSentAvsConfirmed" };
  const SupplyDefenseDocument = { "title": "supplyDefenseMaterial", "help": "fallbackDefenseReasonCode" };
  const SupplyDefenseMaterial = { "title": "supplyDefenseMaterial", "help": "fallbackDefenseReasonCode" };
  const TooManyFraudulentChargebacks = { "title": "manyFraudulentChargebacks", "help": "issuerHasInitiatedTooManyFraudulentDisputes" };
  const TransactionAuthorisedOnline = { "title": "authorisedOnline", "help": "transactionWasAuthorisedOnline" };
  const TransactionNotPOS = { "title": "notPosTransaction", "help": "transactionWasECommerceGivenChargebackReasonNotApplicable" };
  const TwoDifferentTIDs = { "title": "twoDifferentTransactions", "help": "twoSeparateTransactions" };
  const TwoDifferentTIDsPOS = { "title": "twoDifferentTidsNonAtm", "help": "twoDifferentTidsWithSameCardholderAccount" };
  const TwoPINTransactions = { "title": "pinTransaction", "help": "pinForOneOrBothTransactions" };
  const TwoPriorFraudChargebacks = { "title": "twoPreviousFraudRelatedChargebacks", "help": "prevChargedbackTwoTransactionsWithSameAccount" };
  const UnfoundedCardholderDispute = { "title": "unfoundedCardholderDispute", "help": "acquirerDefendChargebackIfIssuerRequested" };
  const UnreasonableAmount = { "title": "unreasonableAmount", "help": "cardholderAgreedToAmountAsReasonable" };
  const defenseReasonConfig = {
    ATMDispute,
    AccountTakeover,
    AdditionalInformation,
    AirlineCompellingEvidence,
    AirlineFlightProvided,
    AirlineRFIresponse,
    AuthorisedTransaction,
    AutomaticRFIresponse,
    CVC2ValidationProgram,
    CancellationOrReturns,
    CancellationTermsFailed,
    CarRentalRFIresponse,
    CardNotOnExceptionFile,
    CardNotPresentRFIresponse,
    CardPresentFraud,
    CardPresentNotApplicable,
    CardPresentRFIresponse,
    CardholderNotReplied,
    CardholderParticipated,
    CardholderRenewedMembership,
    ChipLiabilityShift,
    ChipTransactionReportedToSAFE,
    CieloRFIresponse,
    CompellingEvidence,
    CompellingEvidenceRecurringTransactions,
    CorrectTransactionAmount,
    CorrectTransactionCurrency,
    CorrectTransactionDate,
    CreditOrCancellationPolicyProperlyDisclosed,
    CreditPreviouslyIssued,
    DeficiencyCorrected,
    DisputedSurcharge,
    DisputedSurchargeIncorrectProratedCalculation,
    DuplicateChargeback,
    EMVLiabilityShift,
    EmergencyPaymentAuthorizationService,
    FaceToFace,
    FaceToFaceConflictingMessages,
    GoodsNotReturned,
    GoodsOrServicesProvided,
    GoodsRepairedOrReplaced,
    GoodsWereAsDescribed,
    IdentifiedAddendum,
    IllegibleDocumentationReceived,
    IncreasedTransactionAmount,
    InvalidARD,
    InvalidCancellationCode,
    InvalidChargeback,
    InvalidChargebackAllocation,
    InvalidChargebackBundling,
    InvalidDE72CB,
    InvalidDE72MultipleTransactions,
    InvalidDE72RPCS,
    InvalidReasonCodeForMCC,
    JCBRFIResponse,
    JustifiedDelayedPresentment,
    LiabilityShiftFullAuthenticated,
    LiabilityShiftFullUCAF,
    LiabilityShiftMerchantUCAF,
    MerchandiseNotCounterfeit,
    MerchandiseReceived,
    MissingInformation,
    NoARDprovidedInMessageText,
    NoShowTransaction,
    NonReceiptOfRequiredDocuments,
    NonReceiptOfRequiredDocumentsAutoDefense,
    Not3DSecure,
    NotCancelled,
    NotChargebacked,
    NotChargebackedAuto,
    NotNotified,
    NotPaidByOtherMeans,
    NotRecurring,
    PINTransaction,
    PastChargebackTimeLimit,
    PayPassTransaction,
    PaymentByOtherMeans,
    PresentmentWithinTimeLimit,
    PreviousTransactionNotChargebacked,
    ProofOfCardPresenceAndSignatureChipNoPIN,
    ProofOfCardPresenceAndSignatureLossTheftOrDamage,
    ProofOfCardPresenceAndSignatureMasterCardCorporateFleetCard,
    ProofOfCardPresenceAndSignatureNotMasterCardWorldWideNetwork,
    ProofOfCardPresenceAndSignatureWithTerminalReceipt,
    ProofOfCardPresenceAndSignatureWithoutTerminalReceipt,
    ProvideInformation,
    PurchaseProperlyPosted,
    QPSTransaction,
    RecurringTransactionsCompellingEvidence,
    RecurringTransactionsCompellingMerchantEvidence,
    RefundNotAgreed,
    RetrievalRequestFulfilled,
    ReturnPeriodExpired,
    SaleTermsNotMisrepresented,
    ScanningError,
    ServicesProvided,
    ServicesProvidedAfterCancellation,
    ShippedToAVS,
    ShippedToAVSAdditionalInformation,
    SupplyDefenseDocument,
    SupplyDefenseMaterial,
    TooManyFraudulentChargebacks,
    TransactionAuthorisedOnline,
    TransactionNotPOS,
    TwoDifferentTIDs,
    TwoDifferentTIDsPOS,
    TwoPINTransactions,
    TwoPriorFraudChargebacks,
    UnfoundedCardholderDispute,
    UnreasonableAmount
  };
  const getTranslationIfExists = (i18n, prefix, key) => {
    const prefixedKey = `${prefix}.${key}`;
    return i18n.has(prefixedKey) ? i18n.get(prefixedKey) : void 0;
  };
  const getContent = (i18n, config, configItemKey, translationPrefix) => {
    const configItem = config[configItemKey];
    if (!configItem) return void 0;
    const title = getTranslationIfExists(i18n, translationPrefix, configItem.title);
    const descriptionKeys = configItem.help ? Array.isArray(configItem.help) ? configItem.help : [configItem.help] : void 0;
    const primaryDescriptionItems = descriptionKeys == null ? void 0 : descriptionKeys.map((key) => getTranslationIfExists(i18n, translationPrefix, key)).filter((k2) => k2 !== void 0);
    const secondaryDescriptionItems = [];
    if (configItem.helpitems) {
      configItem.helpitems.forEach((item) => {
        const translation = getTranslationIfExists(i18n, translationPrefix, item);
        if (translation) secondaryDescriptionItems.push(translation);
      });
    }
    return {
      title: title || "",
      ...(primaryDescriptionItems == null ? void 0 : primaryDescriptionItems.length) ? { primaryDescriptionItems } : {},
      ...(secondaryDescriptionItems == null ? void 0 : secondaryDescriptionItems.length) ? { secondaryDescriptionItems } : {}
    };
  };
  const getDefenseDocumentContent = (i18n, defenseDocumentKey) => {
    return getContent(i18n, defenseDocumentConfig, defenseDocumentKey, "disputes.defenseDocument");
  };
  const getDefenseReasonContent = (i18n, defenseReasonKey) => {
    return getContent(i18n, defenseReasonConfig, defenseReasonKey, "disputes.defenseReason");
  };
  const UPLOAD_DOCUMENT_MAX_SIZE = {
    "2MB": 2097152,
    "10MB": 10485760
  };
  const ALLOWED_FILE_TYPES = ["application/pdf", "image/jpeg", "image/jpg", "image/tiff"];
  const DOCUMENT_MAX_SIZE = {
    "application/pdf": UPLOAD_DOCUMENT_MAX_SIZE["2MB"],
    "image/jpeg": UPLOAD_DOCUMENT_MAX_SIZE["10MB"],
    "image/jpg": UPLOAD_DOCUMENT_MAX_SIZE["10MB"],
    "image/tiff": UPLOAD_DOCUMENT_MAX_SIZE["10MB"]
  };
  const DefendDocumentUpload = ({
    document: document2,
    disabled,
    required,
    mapError
  }) => {
    const { i18n } = useCoreContext();
    const { title, primaryDescriptionItems } = T$1(() => getDefenseDocumentContent(i18n, document2), [i18n, document2]) || {};
    const { removeFieldFromDefendPayload, addFileToDefendPayload } = useDisputeFlow();
    return /* @__PURE__ */ u$1("div", { className: "adyen-pe-defend-dispute-document-upload", children: [
      /* @__PURE__ */ u$1("div", { children: [
        /* @__PURE__ */ u$1(
          Typography$1,
          {
            strongest: true,
            className: "adyen-pe-defend-dispute-document-upload__title",
            variant: TypographyVariant.BODY,
            el: TypographyElement.DIV,
            children: title || document2
          }
        ),
        primaryDescriptionItems && primaryDescriptionItems.length > 0 ? primaryDescriptionItems.map((desc, i2) => {
          return /* @__PURE__ */ u$1(
            Typography$1,
            {
              className: "adyen-pe-defend-dispute-document-upload__description",
              variant: TypographyVariant.BODY,
              children: desc
            },
            `${i2}-description`
          );
        }) : null
      ] }),
      /* @__PURE__ */ u$1(
        FileInput,
        {
          allowedFileTypes: ALLOWED_FILE_TYPES,
          maxFileSize: (type2) => {
            return DOCUMENT_MAX_SIZE[type2];
          },
          mapError,
          onDelete: () => {
            document2 && removeFieldFromDefendPayload(document2);
          },
          disabled,
          required,
          onChange: (files) => {
            files[0] ? addFileToDefendPayload(document2, files[0]) : removeFieldFromDefendPayload(document2);
          }
        },
        document2
      )
    ] });
  };
  const BASE_CLASS$1 = "adyen-pe-defend-dispute-document-upload-box";
  const classes$1 = {
    deleteButton: BASE_CLASS$1 + "__delete-button-container",
    dropdownList: BASE_CLASS$1 + "__dropdown-list",
    dropdownListMobile: BASE_CLASS$1 + "__dropdown-list--mobile",
    extraDocuments: BASE_CLASS$1 + "__extra-documents-selector",
    extraDocumentsTitle: BASE_CLASS$1 + "__extra-documents-selector-title"
  };
  const SelectAndUploadOptionalDoc = ({
    items,
    selection,
    setSelection,
    disabled,
    required,
    title,
    index,
    onRemoveOption,
    mapError
  }) => {
    var _a2, _b2;
    const { i18n } = useCoreContext();
    const { addFileToDefendPayload, moveFieldInDefendPayload, removeFieldFromDefendPayload } = useDisputeFlow();
    const getDocInfo = q$1((document2) => getDefenseDocumentContent(i18n, document2), [i18n]);
    const isMobileContainer = useResponsiveContainer(containerQueries.down.xs);
    const updateDocumentSelection = q$1(
      (documentSelection) => {
        selection && moveFieldInDefendPayload(selection, documentSelection);
        setSelection(documentSelection, index);
      },
      [index, moveFieldInDefendPayload, selection, setSelection]
    );
    y(() => {
      const activeSelectItems = items.filter(({ disabled: disabled2 }) => disabled2 !== true);
      if (activeSelectItems.length === 1 && !selection) {
        updateDocumentSelection(activeSelectItems[0].id);
      }
    }, [items, selection, updateDocumentSelection]);
    return /* @__PURE__ */ u$1("div", { className: classes$1.extraDocuments, children: [
      /* @__PURE__ */ u$1("div", { className: classes$1.deleteButton, children: [
        /* @__PURE__ */ u$1(Typography$1, { strongest: true, className: classes$1.extraDocumentsTitle, variant: TypographyVariant.BODY, el: TypographyElement.DIV, children: title }),
        onRemoveOption && /* @__PURE__ */ u$1(
          Button$1,
          {
            disabled,
            onClick: () => index !== void 0 && !disabled && onRemoveOption(index),
            variant: ButtonVariant.TERTIARY,
            fullWidth: false,
            align: "center",
            children: /* @__PURE__ */ u$1(Icon$1, { name: "trash-can" })
          }
        )
      ] }),
      /* @__PURE__ */ u$1("div", { children: [
        /* @__PURE__ */ u$1(
          Select,
          {
            onChange: (val) => {
              const documentSelection = val.target.value;
              updateDocumentSelection(documentSelection);
            },
            filterable: false,
            selected: selection,
            readonly: disabled,
            multiSelect: false,
            items,
            popoverClassNameModifiers: [cx(classes$1.dropdownList, { [classes$1.dropdownListMobile]: isMobileContainer })],
            showOverlay: false,
            placeholder: i18n.get("disputes.uploadDocuments.selectDocumentType"),
            fixedPopoverPositioning: true
          }
        ),
        selection && ((_b2 = (_a2 = getDocInfo(selection)) == null ? void 0 : _a2.primaryDescriptionItems) == null ? void 0 : _b2.map((desc) => {
          return /* @__PURE__ */ u$1(
            Typography$1,
            {
              className: "adyen-pe-defend-dispute-document-upload__description",
              variant: TypographyVariant.BODY,
              el: TypographyElement.PARAGRAPH,
              children: desc
            },
            desc
          );
        }))
      ] }),
      /* @__PURE__ */ u$1(
        FileInput,
        {
          maxFileSize: (type2) => {
            return DOCUMENT_MAX_SIZE[type2];
          },
          allowedFileTypes: ALLOWED_FILE_TYPES,
          mapError,
          onDelete: () => {
            selection && removeFieldFromDefendPayload(selection);
          },
          disabled: disabled || !selection,
          required,
          onChange: (files) => {
            if (selection) {
              files[0] ? addFileToDefendPayload(selection, files[0]) : removeFieldFromDefendPayload(selection);
            }
          }
        }
      )
    ] });
  };
  const documentRequirements = [
    "disputes.documentRequirements.mustBeInEnglish",
    "disputes.documentRequirements.recommendedSize",
    "disputes.documentRequirements.acceptableFormatAndSize"
  ];
  const DefendDisputeFileUpload = () => {
    const { i18n } = useCoreContext();
    const { defendDispute } = useConfigContext().endpoints;
    const {
      clearFiles,
      clearStates,
      dispute,
      applicableDocuments,
      goBack: goBack2,
      defendDisputePayload,
      defendResponse,
      onDefendSubmit,
      removeFieldFromDefendPayload,
      setFlowState
    } = useDisputeFlow();
    const disputePspReference = dispute == null ? void 0 : dispute.dispute.pspReference;
    const [oneOrMoreSelectedDocument, setOneOrMoreSelectedDocument] = d(void 0);
    const [optionalSelectedDocuments, setOptionalSelectedDocuments] = d([]);
    const goBackToDetails = q$1(() => {
      clearStates();
      setFlowState("details");
    }, [clearStates, setFlowState]);
    const mapError = q$1(
      (error, file2) => {
        var _a2, _b2;
        switch (error) {
          case validationErrors.DISALLOWED_FILE_TYPE:
            return i18n.get("inputError.disallowedFileType");
          case validationErrors.FILE_REQUIRED:
            return i18n.get("disputes.inputError.uploadAtLeastOneSupportingDocumentToContinue");
          case validationErrors.TOO_MANY_FILES:
            return i18n.get("inputError.tooManyFiles");
          case validationErrors.VERY_LARGE_FILE:
            return i18n.get("disputes.inputError.fileIsOverSizeLimitForTypeChooseASmallerFileAndTryAgain", {
              values: {
                size: (file2 == null ? void 0 : file2.size) === void 0 ? void 0 : getHumanReadableFileSize(file2.size),
                type: (_b2 = (_a2 = file2 == null ? void 0 : file2.type) == null ? void 0 : _a2.replace(/^([^/]+\/)*/gi, "")) == null ? void 0 : _b2.toUpperCase()
              }
            });
          default:
            return i18n.get("disputes.inputError.somethingWentWrongPleaseCheckYourDocuments");
        }
      },
      [i18n]
    );
    const { requiredDocuments, optionalDocuments, oneOrMoreDocuments } = T$1(() => {
      const docs = {
        requiredDocuments: [],
        optionalDocuments: [],
        oneOrMoreDocuments: []
      };
      (applicableDocuments ?? []).forEach(({ documentTypeCode, requirementLevel }) => {
        var _a2;
        const name = ((_a2 = getDefenseDocumentContent(i18n, documentTypeCode)) == null ? void 0 : _a2.title) || documentTypeCode;
        switch (requirementLevel) {
          case "REQUIRED":
            docs.requiredDocuments.push(documentTypeCode);
            break;
          case "OPTIONAL":
            docs.optionalDocuments.push({
              id: documentTypeCode,
              name
            });
            break;
          case "ONE_OR_MORE":
            docs.oneOrMoreDocuments.push({
              id: documentTypeCode,
              name
            });
            break;
        }
        return docs;
      });
      return docs;
    }, [applicableDocuments, i18n]);
    const requiredDocumentsUploaded = T$1(() => {
      if (!defendDisputePayload) return false;
      let requiredDocumentsPresent = requiredDocuments.every((d2) => defendDisputePayload.get(d2) instanceof File);
      if (oneOrMoreDocuments.length > 0) {
        requiredDocumentsPresent && (requiredDocumentsPresent = oneOrMoreDocuments.some((d2) => defendDisputePayload.get(d2.id) instanceof File));
      }
      return requiredDocumentsPresent;
    }, [defendDisputePayload, oneOrMoreDocuments, requiredDocuments]);
    const defendDisputeMutation = useMutation({
      queryFn: defendDispute,
      options: {
        onSuccess: q$1(() => {
          clearFiles();
          onDefendSubmit("success");
          setFlowState("defenseSubmitResponseView");
        }, [clearFiles, onDefendSubmit, setFlowState]),
        onError: q$1(() => {
          clearFiles();
          onDefendSubmit("error");
          setFlowState("defenseSubmitResponseView");
        }, [clearFiles, onDefendSubmit, setFlowState])
      }
    });
    const disputeDefended = defendResponse === "success";
    const interactionsDisabled = defendDisputeMutation.isLoading || disputeDefended;
    const canSubmitDocuments = defendDisputePayload && requiredDocumentsUploaded && !interactionsDisabled;
    const defendDisputeCallback = q$1(() => {
      if (canSubmitDocuments) {
        void defendDisputeMutation.mutate(
          { contentType: "multipart/form-data", body: defendDisputePayload },
          { path: { disputePspReference } }
        );
      }
    }, [canSubmitDocuments, disputePspReference, defendDisputeMutation, defendDisputePayload]);
    const actionButtons = T$1(() => {
      return [
        {
          title: i18n.get("disputes.defend.submit"),
          disabled: !canSubmitDocuments,
          state: defendDisputeMutation.isLoading ? "loading" : "default",
          variant: ButtonVariant.PRIMARY,
          event: defendDisputeCallback,
          classNames: disputeDefended ? ["adyen-pe-defend-dispute__defended-btn"] : void 0,
          renderTitle: (title) => {
            if (disputeDefended) {
              return /* @__PURE__ */ u$1(k$1, { children: [
                /* @__PURE__ */ u$1(Icon$1, { name: "checkmark-circle-fill", className: "adyen-pe-defend-dispute__defended-icon" }),
                i18n.get("disputes.defend.defended")
              ] });
            }
            return title;
          }
        },
        {
          title: i18n.get("disputes.goBack"),
          disabled: defendDisputeMutation.isLoading,
          variant: ButtonVariant.SECONDARY,
          event: disputeDefended ? goBackToDetails : goBack2
        }
      ];
    }, [i18n, defendDisputeCallback, defendDisputeMutation.isLoading, disputeDefended, goBack2]);
    const addOptionalDocument = q$1((documentType, index) => {
      if (documentType === void 0) {
        setOptionalSelectedDocuments((prev) => [...prev, documentType]);
      } else if (index !== void 0) {
        setOptionalSelectedDocuments((prev) => {
          if (prev[index] === documentType) {
            return prev;
          }
          const newDocs = [...prev];
          newDocs[index] = documentType;
          return newDocs;
        });
      }
    }, []);
    const canAddOptionalDocument = T$1(() => {
      if (interactionsDisabled) return false;
      const optionalDocumentsCount = optionalDocuments.length + Math.max(0, oneOrMoreDocuments.length - 1);
      return Boolean(optionalDocumentsCount && optionalDocumentsCount !== optionalSelectedDocuments.length);
    }, [interactionsDisabled, oneOrMoreDocuments, optionalDocuments, optionalSelectedDocuments]);
    const addEmptyOptionalDocument = q$1(() => {
      if (canAddOptionalDocument) addOptionalDocument();
    }, [canAddOptionalDocument, addOptionalDocument]);
    const availableOptionalDocuments = T$1(() => {
      const additionalOptionalDocs = oneOrMoreDocuments.filter((doc) => doc.id !== oneOrMoreSelectedDocument);
      return [...additionalOptionalDocs, ...optionalDocuments].map((doc) => {
        return { ...doc, disabled: optionalSelectedDocuments.includes(doc.id) };
      });
    }, [oneOrMoreDocuments, oneOrMoreSelectedDocument, optionalDocuments, optionalSelectedDocuments]);
    const removeSelectedOptionalDocument = q$1(
      (indexToRemove) => {
        setOptionalSelectedDocuments((prevDocs) => {
          if (indexToRemove < 0 || indexToRemove >= prevDocs.length) {
            return prevDocs;
          }
          const docToRemove = prevDocs[indexToRemove];
          if (docToRemove) {
            removeFieldFromDefendPayload(docToRemove);
          }
          return prevDocs.filter((_2, index) => index !== indexToRemove);
        });
      },
      [removeFieldFromDefendPayload]
    );
    return /* @__PURE__ */ u$1(k$1, { children: /* @__PURE__ */ u$1(k$1, { children: [
      /* @__PURE__ */ u$1(Typography$1, { className: "adyen-pe-defend-dispute-file-uploader__subtitle", variant: TypographyVariant.BODY, children: i18n.get("disputes.defend.uploadDocumentsInformation") }),
      /* @__PURE__ */ u$1(
        Card,
        {
          renderHeader: /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.BODY, stronger: true, className: "adyen-pe-defend-dispute-document-requirements", children: i18n.get("disputes.documentRequirements") }),
          filled: true,
          expandable: true,
          compact: true,
          children: /* @__PURE__ */ u$1("ul", { className: "adyen-pe-defend-dispute-document-requirements--list", children: documentRequirements.map((item, index) => /* @__PURE__ */ u$1("li", { className: "adyen-pe-defend-dispute-document-requirements--item", children: /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.BODY, children: i18n.get(item) }) }, `${item}-${index}`)) })
        }
      ),
      /* @__PURE__ */ u$1("div", { className: "adyen-pe-defend-dispute-file-uploader__container", children: [
        requiredDocuments.length || oneOrMoreDocuments.length ? /* @__PURE__ */ u$1("div", { className: "adyen-pe-defend-dispute-document-upload-box", children: [
          requiredDocuments.length ? /* @__PURE__ */ u$1("div", { className: "adyen-pe-defend-dispute-document-upload-box__required-documents", children: requiredDocuments == null ? void 0 : requiredDocuments.map((document2) => {
            return /* @__PURE__ */ u$1(
              DefendDocumentUpload,
              {
                mapError,
                disabled: interactionsDisabled,
                document: document2,
                required: true
              },
              document2
            );
          }) }) : null,
          oneOrMoreDocuments.length ? /* @__PURE__ */ u$1(
            SelectAndUploadOptionalDoc,
            {
              mapError,
              disabled: interactionsDisabled,
              selection: oneOrMoreSelectedDocument,
              setSelection: (val) => setOneOrMoreSelectedDocument(val),
              items: oneOrMoreDocuments,
              title: i18n.get("disputes.uploadDocuments.extraRequiredDocument"),
              required: true
            }
          ) : null
        ] }) : null,
        optionalSelectedDocuments.length ? optionalSelectedDocuments.map((doc, index) => {
          return /* @__PURE__ */ u$1("div", { className: "adyen-pe-defend-dispute-document-upload-box", children: /* @__PURE__ */ u$1(
            SelectAndUploadOptionalDoc,
            {
              mapError,
              disabled: interactionsDisabled,
              onRemoveOption: removeSelectedOptionalDocument,
              selection: doc,
              setSelection: addOptionalDocument,
              index,
              items: availableOptionalDocuments,
              title: i18n.get("disputes.uploadDocuments.optionalDocument"),
              required: true
            }
          ) }, `optional-doc-${index}`);
        }) : null,
        canAddOptionalDocument && /* @__PURE__ */ u$1(Button$1, { align: "center", onClick: addEmptyOptionalDocument, variant: ButtonVariant.SECONDARY, fullWidth: true, children: [
          /* @__PURE__ */ u$1(Icon$1, { name: "plus" }),
          i18n.get("disputes.uploadDocuments.addOptionalDocument")
        ] })
      ] }),
      /* @__PURE__ */ u$1("div", { className: "adyen-pe-defend-file-uploader__actions", children: /* @__PURE__ */ u$1(ButtonActions$1, { actions: actionButtons }) })
    ] }) });
  };
  const BASE_CLASS = "adyen-pe-defend-dispute-reason";
  const classes = {
    selector: BASE_CLASS + "__selector",
    description: BASE_CLASS + "__description",
    dropdownList: BASE_CLASS + "__dropdown-list",
    dropdownListMobile: BASE_CLASS + "__dropdown-list--mobile"
  };
  const DefendDisputeReason = () => {
    var _a2, _b2, _c2, _d2;
    const { i18n } = useCoreContext();
    const { applicableDocuments, dispute, goBack: goBack2, setFlowState, setSelectedDefenseReason, selectedDefenseReason, setApplicableDocuments } = useDisputeFlow();
    const allowedDefenseReasons = (_a2 = dispute == null ? void 0 : dispute.dispute) == null ? void 0 : _a2.allowedDefenseReasons;
    const disputePspReference = (_b2 = dispute == null ? void 0 : dispute.dispute) == null ? void 0 : _b2.pspReference;
    const [isReasonSubmitted, setIsReasonSubmitted] = d(false);
    const isMobileContainer = useResponsiveContainer(containerQueries.down.xs);
    const defenseReasons = T$1(
      () => Object.freeze(
        allowedDefenseReasons == null ? void 0 : allowedDefenseReasons.map((reason) => {
          var _a3;
          return {
            id: reason,
            disabled: allowedDefenseReasons.length === 1,
            name: ((_a3 = getDefenseReasonContent(i18n, reason)) == null ? void 0 : _a3.title) ?? reason
          };
        })
      ) ?? [],
      [i18n, allowedDefenseReasons]
    );
    const selected = T$1(
      () => {
        var _a3, _b3;
        return selectedDefenseReason ? (_a3 = defenseReasons.find((reason) => reason.id === selectedDefenseReason)) == null ? void 0 : _a3.id : ((_b3 = defenseReasons == null ? void 0 : defenseReasons[0]) == null ? void 0 : _b3.id) ?? null;
      },
      [selectedDefenseReason, defenseReasons]
    );
    const { getApplicableDefenseDocuments } = useConfigContext().endpoints;
    const fetchCallback = q$1(async () => {
      return getApplicableDefenseDocuments == null ? void 0 : getApplicableDefenseDocuments(EMPTY_OBJECT, {
        query: {
          defenseReason: selectedDefenseReason
        },
        path: {
          disputePspReference
        }
      });
    }, [selectedDefenseReason, disputePspReference, getApplicableDefenseDocuments]);
    const { error, isFetching } = useFetch({
      queryFn: fetchCallback,
      fetchOptions: {
        enabled: isReasonSubmitted,
        onSuccess: q$1(
          (response) => {
            setIsReasonSubmitted(false);
            setApplicableDocuments((response == null ? void 0 : response.data) ?? null);
            if ((response == null ? void 0 : response.data) && (response == null ? void 0 : response.data.length) > 0) setFlowState("uploadDefenseFilesView");
          },
          [setApplicableDocuments, setIsReasonSubmitted, setFlowState]
        )
      }
    });
    y(() => {
      setIsReasonSubmitted(false);
    }, [error]);
    const onDefenseReasonSubmit = q$1(() => {
      if (applicableDocuments == null ? void 0 : applicableDocuments.length) return setFlowState("uploadDefenseFilesView");
      setIsReasonSubmitted(true);
    }, [applicableDocuments, setFlowState]);
    const onChange = q$1(
      (param) => {
        var _a3;
        if (selectedDefenseReason !== param.target.value && (applicableDocuments == null ? void 0 : applicableDocuments.length)) setApplicableDocuments([]);
        if ((_a3 = param == null ? void 0 : param.target) == null ? void 0 : _a3.value) setSelectedDefenseReason(param.target.value);
      },
      [applicableDocuments, selectedDefenseReason, setApplicableDocuments, setSelectedDefenseReason]
    );
    const actionButtons = T$1(() => {
      return [
        {
          title: i18n.get("disputes.defend.continue"),
          disabled: isReasonSubmitted || isFetching,
          event: onDefenseReasonSubmit
        },
        {
          title: i18n.get("disputes.goBack"),
          disabled: isReasonSubmitted || isFetching,
          event: goBack2
        }
      ];
    }, [isFetching, isReasonSubmitted, i18n, goBack2, onDefenseReasonSubmit]);
    const [showAlert, setShowAlert] = d(true);
    const closeAlert = q$1(() => {
      setShowAlert(false);
    }, []);
    const defenseReasonContent = T$1(() => selected ? getDefenseReasonContent(i18n, selected) : void 0, [i18n, selected]);
    if (!defenseReasons || !selected) {
      return null;
    }
    return /* @__PURE__ */ u$1(k$1, { children: [
      /* @__PURE__ */ u$1("div", { className: classes.selector, children: [
        /* @__PURE__ */ u$1(Typography$1, { className: "adyen-pe-defend-dispute__reason-description", variant: TypographyVariant.BODY, children: i18n.get("disputes.defend.selectDefenseReason") }),
        /* @__PURE__ */ u$1(
          Select,
          {
            items: defenseReasons,
            onChange,
            selected,
            popoverClassNameModifiers: [cx(classes.dropdownList, { [classes.dropdownListMobile]: isMobileContainer })],
            fixedPopoverPositioning: true
          }
        ),
        (_c2 = defenseReasonContent == null ? void 0 : defenseReasonContent.primaryDescriptionItems) == null ? void 0 : _c2.map((description2, i2) => /* @__PURE__ */ u$1(
          Typography$1,
          {
            el: TypographyElement.PARAGRAPH,
            className: classes.description,
            variant: TypographyVariant.BODY,
            children: description2
          },
          `description-${i2}`
        )),
        ((_d2 = defenseReasonContent == null ? void 0 : defenseReasonContent.secondaryDescriptionItems) == null ? void 0 : _d2.length) && /* @__PURE__ */ u$1("ul", { className: "adyen-pe-defend-dispute-reason__secondary-description-items-container", children: defenseReasonContent.secondaryDescriptionItems.map((description2, i2) => /* @__PURE__ */ u$1("li", { className: "adyen-pe-defend-dispute-reason__secondary-description-item", children: /* @__PURE__ */ u$1(
          Typography$1,
          {
            el: TypographyElement.PARAGRAPH,
            className: "adyen-pe-defend-dispute-reason__description",
            variant: TypographyVariant.BODY,
            children: description2
          }
        ) }, `description-item-${i2}`)) })
      ] }),
      showAlert && /* @__PURE__ */ u$1(Alert, { onClose: closeAlert, type: AlertTypeOption.HIGHLIGHT, variant: AlertVariantOption.DEFAULT, children: /* @__PURE__ */ u$1(Typography$1, { className: "adyen-pe-alert__description", el: TypographyElement.DIV, variant: TypographyVariant.BODY, wide: true, children: i18n.get("disputes.defend.chargebackFeeInformation") }) }),
      /* @__PURE__ */ u$1("div", { className: "adyen-pe-defend-dispute__actions", children: /* @__PURE__ */ u$1(ButtonActions$1, { actions: actionButtons }) })
    ] });
  };
  const DefendDisputeResponse = ({ onDisputeDefend }) => {
    const { i18n } = useCoreContext();
    const { clearFiles, clearStates, dispute, setFlowState, defendResponse } = useDisputeFlow();
    const goBackToDetails = q$1(() => {
      clearStates();
      setFlowState("details");
    }, [clearStates, setFlowState]);
    const goBackToFileUploadView = q$1(() => {
      clearFiles();
      setFlowState("uploadDefenseFilesView");
    }, [clearFiles, setFlowState]);
    const defendCallbackHasBeenCalled = A$1(false);
    y(() => {
      if (defendCallbackHasBeenCalled.current) return;
      if (defendResponse === "success" && isFunction(onDisputeDefend)) {
        const disputePspReference = dispute == null ? void 0 : dispute.dispute.pspReference;
        if (disputePspReference) {
          defendCallbackHasBeenCalled.current = true;
          onDisputeDefend({ id: disputePspReference });
        }
      }
    }, [defendResponse, dispute, onDisputeDefend]);
    return /* @__PURE__ */ u$1("div", { className: "adyen-pe-defend-dispute__response", children: defendResponse === "success" ? /* @__PURE__ */ u$1("div", { className: "adyen-pe-defend-dispute__success", children: [
      /* @__PURE__ */ u$1(Icon$1, { name: "checkmark-circle-fill", className: "adyen-pe-defend-dispute__success-icon" }),
      /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.TITLE, children: i18n.get("disputes.defend.evidenceSubmitted") }),
      /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.BODY, className: "adyen-pe-defend-dispute__success-description", children: i18n.get("disputes.defend.submitSuccessfulInformation") }),
      /* @__PURE__ */ u$1("div", { className: "adyen-pe-defend-dispute__success-buttons", children: /* @__PURE__ */ u$1(Button$1, { variant: ButtonVariant.SECONDARY, onClick: goBackToDetails, children: i18n.get("disputes.showDisputeDetails") }) })
    ] }) : /* @__PURE__ */ u$1("div", { className: "adyen-pe-defend-dispute__error", children: [
      /* @__PURE__ */ u$1(Icon$1, { name: "cross-circle-fill", className: "adyen-pe-defend-dispute__error-icon" }),
      /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.TITLE, medium: true, children: i18n.get("disputes.defend.somethingWentWrong") }),
      /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.BODY, children: i18n.get("disputes.error.weCouldNotProcessTheDisputePleaseTryAgainOrContactSupport") }),
      /* @__PURE__ */ u$1(Button$1, { variant: ButtonVariant.SECONDARY, onClick: goBackToFileUploadView, children: i18n.get("disputes.goBack") })
    ] }) });
  };
  const DefendDisputeFlow = ({ onDisputeDefend }) => {
    const { i18n } = useCoreContext();
    const { applicableDocuments, flowState } = useDisputeFlow();
    return /* @__PURE__ */ u$1("div", { className: "adyen-pe-defend-dispute__container", children: [
      flowState !== "defenseSubmitResponseView" && /* @__PURE__ */ u$1(Typography$1, { className: "adyen-pe-defend-dispute__title", variant: TypographyVariant.TITLE, medium: true, children: i18n.get("disputes.defend.chargeback") }),
      flowState === "defendReasonSelectionView" && /* @__PURE__ */ u$1(DefendDisputeReason, {}),
      flowState === "uploadDefenseFilesView" && !!(applicableDocuments == null ? void 0 : applicableDocuments.length) && /* @__PURE__ */ u$1(DefendDisputeFileUpload, {}),
      flowState === "defenseSubmitResponseView" && /* @__PURE__ */ u$1(DefendDisputeResponse, { onDisputeDefend })
    ] });
  };
  const DISPUTE_DATA_CLASS = "adyen-pe-dispute-data";
  const DISPUTE_DATA_MOBILE_CLASS = "adyen-pe-dispute-data--mobile";
  const DISPUTE_STATUS_BOX = `${DISPUTE_DATA_CLASS}__status-box`;
  const DISPUTE_DATA_ACTION_BAR = `${DISPUTE_DATA_CLASS}__action-bar`;
  const DISPUTE_DATA_LABEL = `${DISPUTE_DATA_CLASS}__label`;
  const DISPUTE_DATA_LIST = `${DISPUTE_DATA_CLASS}__list`;
  const DISPUTE_DATA_LIST_EVIDENCE = `${DISPUTE_DATA_CLASS}__list--evidence`;
  const DISPUTE_DATA_LIST_EVIDENCE_ERROR_MESSAGE = `${DISPUTE_DATA_CLASS}__list-evidence-error-message`;
  const DISPUTE_DATA_ISSUER_COMMENT = `${DISPUTE_DATA_CLASS}__issuer-comment`;
  const DISPUTE_DATA_ISSUER_COMMENTS = `${DISPUTE_DATA_CLASS}__issuer-comments`;
  const DISPUTE_DATA_ISSUER_COMMENTS_EXPANDED = `${DISPUTE_DATA_ISSUER_COMMENTS}--expanded`;
  const DISPUTE_DATA_ISSUER_COMMENTS_TRUNCATED = `${DISPUTE_DATA_ISSUER_COMMENTS}--truncated`;
  const DISPUTE_DATA_ISSUER_COMMENTS_ALERT = `${DISPUTE_DATA_CLASS}__issuer-comments-alert`;
  const DISPUTE_DATA_ISSUER_COMMENTS_GROUP = `${DISPUTE_DATA_CLASS}__issuer-comments-group`;
  const DISPUTE_DATA_ERROR_CONTAINER = "adyen-pe-dispute-data__error-container";
  const DISPUTE_DATA_STATUS_BOX_SKELETON = "adyen-pe-dispute-data__status-box-skeleton";
  const DISPUTE_DATA_PROPERTIES_SKELETON = "adyen-pe-dispute-data__properties-skeleton";
  const DISPUTE_DATA_PROPERTIES_SKELETON_ELEMENT = "adyen-pe-dispute-data__properties-skeleton-element";
  const DISPUTE_DATA_PROPERTIES_SKELETON_CONTAINER = "adyen-pe-dispute-data__properties-skeleton-container";
  const DISPUTE_DATA_STATUS_BOX_STATUS_CONTAINER = "adyen-pe-dispute-data__status-box-status-container";
  const DISPUTE_DATA_STATUS_BOX_STATUS = "adyen-pe-dispute-data__status-box-status";
  const DISPUTE_DATA_STATUS_BOX_AMOUNT = "adyen-pe-dispute-data__status-box-amount";
  const DISPUTE_DATA_STATUS_BOX_PAYMENT_METHOD = "adyen-pe-dispute-data__status-box-payment-method";
  const DISPUTE_DATA_SKELETON_CONTAINER = "adyen-pe-dispute-data__skeleton-container";
  const DISPUTE_DATA_STATUS_BOX_PAYMENT_METHOD_CONTAINER = "adyen-pe-dispute-data__status-box-payment-method-container";
  const DISPUTE_DETAILS_RESERVED_FIELDS_SET = /* @__PURE__ */ new Set([
    "allowedDefenseReasons",
    "balanceAccount",
    "amount",
    "createdAt",
    "defensibility",
    "dueDate",
    "id",
    "latestDefense",
    "paymentMerchantReference",
    "paymentMethod",
    "paymentPspReference",
    "reasonCode",
    "reasonGroup",
    "status"
  ]);
  const DisputeIssuerComments = ({ issuerComments }) => {
    const { i18n } = useCoreContext();
    const [minimumHeight, setMinimumHeight] = d(0);
    const [maximumHeight, setMaximumHeight] = d(0);
    const [isTruncated, setIsTruncated] = d(false);
    const [isExpanded, setIsExpanded] = d(false);
    const commentsGroupRef = A$1(null);
    const onButtonClick = (evt) => {
      var _a2;
      evt.preventDefault();
      setIsExpanded(!isExpanded);
      (_a2 = commentsGroupRef.current) == null ? void 0 : _a2.style.setProperty("max-height", `${isExpanded ? minimumHeight : maximumHeight}px`);
    };
    _(() => {
      var _a2;
      if (commentsGroupRef.current) {
        const commentsGroup = commentsGroupRef.current;
        const firstComment = commentsGroup.querySelector(`.${DISPUTE_DATA_ISSUER_COMMENT}`);
        const lineHeight = firstComment ? parseInt(getComputedStyle(firstComment).getPropertyValue("line-height")) : 0;
        const minimumHeight2 = Math.min((firstComment == null ? void 0 : firstComment.clientHeight) || Infinity, lineHeight * 3);
        const maximumHeight2 = commentsGroup.scrollHeight;
        setMinimumHeight(minimumHeight2);
        setMaximumHeight(maximumHeight2);
        setIsTruncated(maximumHeight2 > minimumHeight2);
        (_a2 = commentsGroupRef.current) == null ? void 0 : _a2.style.setProperty("max-height", `${minimumHeight2}px`);
      }
    }, []);
    return /* @__PURE__ */ u$1(
      Alert,
      {
        type: AlertTypeOption.HIGHLIGHT,
        variant: AlertVariantOption.TIP,
        description: /* @__PURE__ */ u$1("div", { className: DISPUTE_DATA_ISSUER_COMMENTS_ALERT, children: [
          /* @__PURE__ */ u$1(Typography$1, { el: TypographyElement.DIV, variant: TypographyVariant.BODY, strongest: true, children: i18n.get("disputes.issuerComment.title") }),
          /* @__PURE__ */ u$1(
            "div",
            {
              className: cx(DISPUTE_DATA_ISSUER_COMMENTS, {
                [DISPUTE_DATA_ISSUER_COMMENTS_EXPANDED]: isExpanded,
                [DISPUTE_DATA_ISSUER_COMMENTS_TRUNCATED]: isTruncated
              }),
              children: /* @__PURE__ */ u$1("ul", { ref: commentsGroupRef, className: DISPUTE_DATA_ISSUER_COMMENTS_GROUP, children: issuerComments.map((issuerComment, index) => /* @__PURE__ */ u$1("li", { children: /* @__PURE__ */ u$1(
                Typography$1,
                {
                  className: DISPUTE_DATA_ISSUER_COMMENT,
                  el: TypographyElement.PARAGRAPH,
                  variant: TypographyVariant.BODY,
                  children: issuerComment
                }
              ) }, index)) })
            }
          ),
          isTruncated && /* @__PURE__ */ u$1(Button$1, { variant: ButtonVariant.TERTIARY, onClick: onButtonClick, children: i18n.get(isExpanded ? "disputes.issuerComment.showLess" : "disputes.issuerComment.showMore") })
        ] })
      }
    );
  };
  const disputeDataKeys = {
    acceptedOn: "disputes.acceptedOn",
    account: "disputes.account",
    defendedOn: "disputes.defendedOn",
    defenseReason: "disputes.defenseReason",
    disputeEvidence: "disputes.evidence",
    disputeReason: "disputes.disputeReason",
    disputeReference: "disputes.disputeReference",
    expiredOn: "disputes.expiredOn",
    merchantReference: "disputes.merchantReference",
    openedOn: "disputes.openedOn",
    paymentReference: "disputes.paymentReference",
    reasonCode: "disputes.reasonCode",
    respondBy: "disputes.respondBy"
  };
  const DISPUTE_STATUSES_WITH_ACCEPTED_DATE = ["ACCEPTED", "EXPIRED"];
  const DisputeDataProperties = ({ dispute, dataCustomization }) => {
    var _a2;
    const { i18n } = useCoreContext();
    const { dateFormat } = useTimezoneAwareDateFormatting(dispute.payment.balanceAccount.timeZone);
    const [extraFields, setExtraFields] = d();
    const getExtraFields = q$1(async () => {
      var _a3, _b2, _c2;
      if (dispute) {
        const detailsData = await ((_b2 = (_a3 = dataCustomization == null ? void 0 : dataCustomization.details) == null ? void 0 : _a3.onDataRetrieve) == null ? void 0 : _b2.call(_a3, dispute));
        setExtraFields(
          (_c2 = dataCustomization == null ? void 0 : dataCustomization.details) == null ? void 0 : _c2.fields.reduce((acc, field) => {
            return DISPUTE_DETAILS_RESERVED_FIELDS_SET.has(field.key) || PAYOUT_TABLE_FIELDS.includes(field.key) || (field == null ? void 0 : field.visibility) === "hidden" ? acc : { ...acc, ...(detailsData == null ? void 0 : detailsData[field.key]) ? { [field.key]: detailsData[field.key] } : {} };
          }, {})
        );
      }
    }, [dispute, dataCustomization]);
    y(() => {
      void getExtraFields();
    }, [getExtraFields]);
    return T$1(() => {
      var _a3;
      const { pspReference: disputeReference, reason: disputeReason, acceptedDate, createdAt, dueDate, status: status2, type: type2 } = dispute.dispute;
      const { pspReference: paymentReference, merchantReference, balanceAccount: balanceAccount2 } = dispute.payment;
      const { reason: defenseReason, defendedOn, suppliedDocuments } = dispute.defense || {};
      const isFraudNotification = type2 === "NOTIFICATION_OF_FRAUD";
      const isExpiredDispute = status2 === "EXPIRED" || status2 === "LOST" && !isFraudNotification && !defendedOn;
      const isActionableDispute = isDisputeActionNeeded(dispute.dispute) && dispute.dispute.defensibility !== "NOT_ACTIONABLE";
      const SKIP_ITEM = null;
      const listItems = [
        // dispute reason
        {
          key: disputeDataKeys.disputeReason,
          value: `${i18n.get(DISPUTE_REASON_CATEGORIES[disputeReason.category])} - ${disputeReason.title}`,
          // [NOTE]: Not translated at the moment (maybe in the future)
          id: "disputeReason"
        },
        // reason code
        !isFraudNotification ? {
          key: disputeDataKeys.reasonCode,
          value: disputeReason.code,
          id: "reasonCode"
        } : SKIP_ITEM,
        // created at
        {
          key: disputeDataKeys.openedOn,
          value: dateFormat(createdAt, DATE_FORMAT_DISPUTE_DETAILS),
          id: "openedOn"
        },
        // respond by
        dueDate && isActionableDispute ? {
          key: disputeDataKeys.respondBy,
          value: dateFormat(dueDate, DATE_FORMAT_DISPUTE_DETAILS),
          id: "respondBy"
        } : SKIP_ITEM,
        // dispute reference
        {
          key: disputeDataKeys.disputeReference,
          value: /* @__PURE__ */ u$1(CopyText, { type: "Default", textToCopy: disputeReference, showCopyTextTooltip: false }),
          id: "disputeId"
        },
        // balance account
        {
          key: disputeDataKeys.account,
          value: balanceAccount2.description,
          id: "account"
        },
        // psp reference
        {
          key: disputeDataKeys.paymentReference,
          value: /* @__PURE__ */ u$1(CopyText, { type: "Default", textToCopy: paymentReference, showCopyTextTooltip: false }),
          id: "paymentPspReference"
        },
        // merchant reference
        merchantReference ? {
          key: disputeDataKeys.merchantReference,
          value: /* @__PURE__ */ u$1(CopyText, { type: "Default", textToCopy: merchantReference, showCopyTextTooltip: false }),
          id: "paymentMerchantReference"
        } : SKIP_ITEM,
        // defense reason
        defenseReason ? {
          key: disputeDataKeys.defenseReason,
          value: ((_a3 = getDefenseReasonContent(i18n, defenseReason)) == null ? void 0 : _a3.title) ?? defenseReason,
          id: "defenseReason"
        } : SKIP_ITEM,
        // defended on
        defendedOn ? {
          key: disputeDataKeys.defendedOn,
          value: dateFormat(defendedOn, DATE_FORMAT_DISPUTE_DETAILS),
          id: "defendedOn"
        } : SKIP_ITEM,
        // evidence
        suppliedDocuments && suppliedDocuments.length > 0 ? {
          key: disputeDataKeys.disputeEvidence,
          value: /* @__PURE__ */ u$1(k$1, { children: suppliedDocuments.map((document2, index) => {
            var _a4;
            const queryParam = {
              path: { disputePspReference: disputeReference },
              query: { documentType: document2 }
            };
            return /* @__PURE__ */ u$1("div", { className: DISPUTE_DATA_LIST_EVIDENCE, children: [
              /* @__PURE__ */ u$1(Tag, { label: ((_a4 = getDefenseDocumentContent(i18n, document2)) == null ? void 0 : _a4.title) ?? document2 }),
              /* @__PURE__ */ u$1(
                DownloadButton,
                {
                  className: "adyen-pe-dispute-document-download",
                  endpointName: "downloadDefenseDocument",
                  disabled: false,
                  requestParams: queryParam,
                  iconButton: true,
                  errorMessage: () => {
                    return /* @__PURE__ */ u$1("div", { className: DISPUTE_DATA_LIST_EVIDENCE_ERROR_MESSAGE, children: [
                      /* @__PURE__ */ u$1(Icon$1, { name: "info-filled" }),
                      /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.CAPTION, el: TypographyElement.SPAN, children: i18n.get("disputes.error.failedRetry") })
                    ] });
                  },
                  onDownloadRequested: () => console.warn("Download failed for", document2)
                }
              )
            ] }, `${document2}-${index}`);
          }) }),
          id: "disputeEvidence"
        } : SKIP_ITEM,
        // accepted on
        acceptedDate && DISPUTE_STATUSES_WITH_ACCEPTED_DATE.includes(status2) ? {
          key: disputeDataKeys.acceptedOn,
          value: dateFormat(acceptedDate, DATE_FORMAT_DISPUTE_DETAILS),
          id: "acceptedOn"
        } : SKIP_ITEM,
        // expired on
        dueDate && isExpiredDispute ? {
          key: disputeDataKeys.expiredOn,
          value: dateFormat(dueDate, DATE_FORMAT_DISPUTE_DETAILS),
          id: "expiredOn"
        } : SKIP_ITEM
      ].filter(Boolean).filter((val) => {
        var _a4, _b2;
        return !((_b2 = (_a4 = dataCustomization == null ? void 0 : dataCustomization.details) == null ? void 0 : _a4.fields) == null ? void 0 : _b2.some((field) => field.key === val.id && field.visibility === "hidden"));
      });
      const itemsWithExtraFields = [
        ...listItems,
        ...Object.entries(extraFields || {}).filter(
          ([key, value2]) => !DISPUTE_DETAILS_RESERVED_FIELDS_SET.has(key) && value2.type !== "button" && value2.visibility !== "hidden"
        ).map(([key, value2]) => ({
          key,
          value: isCustomDataObject(value2) ? value2.value : value2,
          type: isCustomDataObject(value2) ? value2.type : "text",
          config: isCustomDataObject(value2) ? value2.config : void 0
        })) || {}
      ];
      return /* @__PURE__ */ u$1(
        StructuredList,
        {
          classNames: DISPUTE_DATA_LIST,
          items: itemsWithExtraFields,
          layout: "4-8",
          align: "start",
          renderLabel: (label) => /* @__PURE__ */ u$1("div", { className: DISPUTE_DATA_LABEL, children: label }),
          renderValue: (val, key, type22, config) => {
            if (type22 === "link" && config) {
              return /* @__PURE__ */ u$1(Link, { classNames: [cx(config == null ? void 0 : config.className)], href: config.href, target: config.target || "_blank", children: val });
            }
            if (type22 === "icon" && config) {
              const icon = { url: config == null ? void 0 : config.src, alt: config.alt || val };
              return /* @__PURE__ */ u$1("div", { className: cx("adyen-pe-dispute-data__list-icon-value", config == null ? void 0 : config.className), children: [
                /* @__PURE__ */ u$1(Icon, { ...icon }),
                /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.BODY, children: val })
              ] });
            }
            return /* @__PURE__ */ u$1(Typography$1, { className: cx(config == null ? void 0 : config.className), variant: TypographyVariant.BODY, children: val });
          }
        }
      );
    }, [dispute, i18n, dateFormat, extraFields, (_a2 = dataCustomization == null ? void 0 : dataCustomization.details) == null ? void 0 : _a2.fields]);
  };
  const getDisputesErrorMessage = (error, errorMessage, onContactSupport) => {
    if (!error) return UNDEFINED_ERROR;
    switch (error.errorCode) {
      case void 0:
        return {
          title: "somethingWentWrong",
          message: [errorMessage, "tryRefreshingThePageOrComeBackLater"],
          refreshComponent: true
        };
      case "00_500": {
        const secondaryErrorMessage = onContactSupport ? "theErrorCodeIs" : "contactSupportForHelpAndShareErrorCode";
        return {
          title: "somethingWentWrong",
          message: [errorMessage, secondaryErrorMessage],
          translationValues: {
            [secondaryErrorMessage]: error.requestId ? /* @__PURE__ */ u$1(CopyText, { textToCopy: error.requestId }) : null
          },
          onContactSupport
        };
      }
      case "30_112":
        return {
          title: "disputes.error.entityWasNotFound",
          message: ["disputes.error.entityWasNotFoundDetail"],
          onContactSupport
        };
      default:
        return UNDEFINED_ERROR;
    }
  };
  const _isButtonType = (item) => {
    return !!item && typeof item === "object" && item.type === "button";
  };
  const DisputeDataAlert = ({
    alertMode,
    dispute,
    timeZone
  }) => {
    const { i18n } = useCoreContext();
    const { dateFormat } = useTimezoneAwareDateFormatting(timeZone);
    switch (alertMode) {
      case "contactSupport": {
        const { dueDate, type: type2 } = dispute;
        const translationKey = type2 === "REQUEST_FOR_INFORMATION" ? "disputes.contactSupport.toDefendRequestForInformation" : type2 === "NOTIFICATION_OF_FRAUD" ? "disputes.contactSupport.toResolveNotificationOfFraud" : "disputes.contactSupport.toDefendDispute";
        return /* @__PURE__ */ u$1(
          Alert,
          {
            type: AlertTypeOption.WARNING,
            variant: AlertVariantOption.TIP,
            description: /* @__PURE__ */ u$1(k$1, { children: [
              i18n.get(translationKey),
              type2 !== "NOTIFICATION_OF_FRAUD" && !!dueDate && /* @__PURE__ */ u$1(k$1, { children: [
                " ",
                /* @__PURE__ */ u$1(
                  Translation,
                  {
                    translationKey: "disputes.alert.responseDeadline",
                    fills: {
                      date: /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.BODY, el: TypographyElement.SPAN, stronger: true, children: dateFormat(dueDate, DATE_FORMAT_RESPONSE_DEADLINE) })
                    }
                  }
                )
              ] })
            ] })
          }
        );
      }
      case "autoDefended":
        return /* @__PURE__ */ u$1(Alert, { type: AlertTypeOption.HIGHLIGHT, variant: AlertVariantOption.TIP, description: i18n.get("disputes.alert.autoDefended") });
      case "notDefended": {
        const translationKey = dispute.status === "EXPIRED" ? "disputes.alert.notDefendedExpired" : "disputes.alert.notDefendedLost";
        return /* @__PURE__ */ u$1(Alert, { type: AlertTypeOption.HIGHLIGHT, variant: AlertVariantOption.TIP, description: i18n.get(translationKey) });
      }
      case "notDefendable":
        return /* @__PURE__ */ u$1(Alert, { type: AlertTypeOption.HIGHLIGHT, variant: AlertVariantOption.TIP, description: i18n.get("disputes.alert.notDefendable") });
    }
    return null;
  };
  const DisputeData = ({
    disputeId,
    dataCustomization,
    onContactSupport,
    onDismiss
  }) => {
    var _a2, _b2, _c2;
    const { i18n } = useCoreContext();
    const { dispute: storedDispute, setDispute, setFlowState } = useDisputeFlow();
    const { getDisputeDetail, getApplicableDefenseDocuments, acceptDispute } = useConfigContext().endpoints;
    const acceptAuthorization = isFunction(acceptDispute);
    const defendAuthorization = isFunction(getApplicableDefenseDocuments);
    const isSmAndUpContainer = useResponsiveContainer(containerQueries.up.sm);
    const { data, isFetching, error } = useFetch(
      T$1(
        () => ({
          fetchOptions: {
            enabled: !!disputeId && !!getDisputeDetail && !storedDispute,
            onSuccess: (dispute2) => {
              setDispute(dispute2);
            }
          },
          queryFn: async () => {
            return getDisputeDetail(EMPTY_OBJECT, {
              path: {
                disputePspReference: disputeId
              }
            });
          }
        }),
        [storedDispute, disputeId, getDisputeDetail, setDispute]
      )
    );
    const dispute = storedDispute || data;
    const defensibility = (_a2 = dispute == null ? void 0 : dispute.dispute) == null ? void 0 : _a2.defensibility;
    const statusBoxOptions = useStatusBoxData({
      amountData: dispute == null ? void 0 : dispute.dispute.amount,
      paymentMethodData: dispute == null ? void 0 : dispute.payment.paymentMethod
    });
    const issuerComments = T$1(() => {
      const { chargeback: chargeback2, preArbitration } = (dispute == null ? void 0 : dispute.dispute.issuerExtraData) ?? {};
      const comments = [];
      [preArbitration, chargeback2].forEach((commentGroup) => {
        if (!commentGroup) return;
        ["LIABILITY_NOT_ACCEPTED_FULLY", "PRE_ARB_REASON", "NOTE"].forEach((commentKey) => {
          const raw = commentGroup[commentKey];
          const trimmed = raw == null ? void 0 : raw.trim();
          if (trimmed) comments.push(trimmed);
        });
      });
      return comments.filter(Boolean);
    }, [dispute]);
    const disputeType = T$1(() => {
      const type2 = dispute == null ? void 0 : dispute.dispute.type;
      return type2 && i18n.get(DISPUTE_TYPES[type2]);
    }, [i18n, dispute]);
    const showContactSupport = !!defensibility && ["ACCEPTABLE", "DEFENDABLE_EXTERNALLY"].includes(defensibility) || (dispute == null ? void 0 : dispute.dispute.type) === "NOTIFICATION_OF_FRAUD";
    const isDefendable = !!defensibility && defensibility === "DEFENDABLE" && defendAuthorization;
    const isAcceptable = !!defensibility && ["ACCEPTABLE", "DEFENDABLE"].includes(defensibility) && acceptAuthorization;
    const onAcceptClick = q$1(() => {
      setFlowState("accept");
    }, [setFlowState]);
    const onDefendClick = q$1(() => {
      setFlowState("defendReasonSelectionView");
    }, [setFlowState]);
    const [extraButtons, setExtraButtons] = d([]);
    const getCustomButtons = q$1(async () => {
      var _a3, _b3;
      const customData = data && await ((_b3 = (_a3 = dataCustomization == null ? void 0 : dataCustomization.details) == null ? void 0 : _a3.onDataRetrieve) == null ? void 0 : _b3.call(_a3, data));
      if (customData) {
        return setExtraButtons(
          Object.values(customData).filter((config) => {
            return _isButtonType(config);
          })
        );
      }
    }, [data, dataCustomization == null ? void 0 : dataCustomization.details]);
    y(() => {
      void getCustomButtons();
    }, [getCustomButtons]);
    const actionButtons = T$1(() => {
      const ctaButtons = [];
      if (isDefendable)
        ctaButtons.push({
          title: i18n.get("disputes.defend.chargeback"),
          event: onDefendClick
        });
      if (isAcceptable) {
        ctaButtons.push({
          title: i18n.get("disputes.accept"),
          event: onAcceptClick,
          variant: ButtonVariant.SECONDARY
        });
      }
      if (showContactSupport && isFunction(onContactSupport)) {
        ctaButtons.push({
          title: i18n.get("contactSupport"),
          event: onContactSupport,
          variant: ButtonVariant.SECONDARY
        });
      }
      if (extraButtons && extraButtons.length) {
        extraButtons.forEach((config) => {
          var _a3;
          ctaButtons.push({
            title: config == null ? void 0 : config.value,
            event: (_a3 = config == null ? void 0 : config.config) == null ? void 0 : _a3.action,
            variant: ButtonVariant.SECONDARY
          });
        });
      }
      return ctaButtons;
    }, [isDefendable, i18n, onDefendClick, isAcceptable, showContactSupport, onContactSupport, extraButtons, onAcceptClick]);
    const actionNeeded = T$1(() => !!dispute && isDisputeActionNeeded(dispute.dispute), [dispute]);
    const renderBackButton = q$1(() => {
      return /* @__PURE__ */ u$1(Button$1, { variant: ButtonVariant.SECONDARY, onClick: onDismiss, children: i18n.get("disputes.goBack") });
    }, [i18n, onDismiss]);
    if (!dispute && !error || isFetching) {
      const skeletonRows = Array.from({ length: 5 });
      return /* @__PURE__ */ u$1("div", { className: cx(DISPUTE_DATA_CLASS, { [DISPUTE_DATA_MOBILE_CLASS]: !isSmAndUpContainer }), children: /* @__PURE__ */ u$1("div", { className: DISPUTE_DATA_SKELETON_CONTAINER, children: [
        /* @__PURE__ */ u$1("div", { className: DISPUTE_DATA_STATUS_BOX_SKELETON, children: [
          /* @__PURE__ */ u$1("div", { className: DISPUTE_DATA_STATUS_BOX_STATUS_CONTAINER, children: [
            /* @__PURE__ */ u$1("span", { className: DISPUTE_DATA_STATUS_BOX_STATUS }),
            /* @__PURE__ */ u$1("span", { className: DISPUTE_DATA_STATUS_BOX_STATUS })
          ] }),
          /* @__PURE__ */ u$1("span", { className: DISPUTE_DATA_STATUS_BOX_AMOUNT }),
          /* @__PURE__ */ u$1("div", { className: DISPUTE_DATA_STATUS_BOX_PAYMENT_METHOD_CONTAINER, children: [
            /* @__PURE__ */ u$1("span", { className: DISPUTE_DATA_STATUS_BOX_PAYMENT_METHOD }),
            /* @__PURE__ */ u$1("span", { className: DISPUTE_DATA_STATUS_BOX_PAYMENT_METHOD })
          ] })
        ] }),
        /* @__PURE__ */ u$1("div", { className: DISPUTE_DATA_PROPERTIES_SKELETON_CONTAINER, children: skeletonRows.map((_2, index) => /* @__PURE__ */ u$1("div", { className: DISPUTE_DATA_PROPERTIES_SKELETON, children: [
          /* @__PURE__ */ u$1("span", { className: DISPUTE_DATA_PROPERTIES_SKELETON_ELEMENT }),
          /* @__PURE__ */ u$1("span", { className: DISPUTE_DATA_PROPERTIES_SKELETON_ELEMENT })
        ] }, `skeleton-${index}`)) })
      ] }) });
    }
    const isFraudNotification = (dispute == null ? void 0 : dispute.dispute.type) === "NOTIFICATION_OF_FRAUD";
    const isDefended = !!((dispute == null ? void 0 : dispute.defense) && dispute.defense.defendedOn);
    let disputeAlertMode = void 0;
    if (((_b2 = dispute == null ? void 0 : dispute.defense) == null ? void 0 : _b2.autodefended) === true) {
      disputeAlertMode = "autoDefended";
    } else if (actionNeeded && defensibility === "NOT_ACTIONABLE") {
      disputeAlertMode = "notDefendable";
    } else if (actionNeeded && showContactSupport || showContactSupport && isFraudNotification) {
      disputeAlertMode = "contactSupport";
    } else if ((dispute == null ? void 0 : dispute.dispute.status) === "EXPIRED") {
      disputeAlertMode = "notDefended";
    } else if ((dispute == null ? void 0 : dispute.dispute.status) === "LOST" && !(isFraudNotification || isDefended)) {
      disputeAlertMode = "notDefended";
    }
    const errorProps = getDisputesErrorMessage(error, "disputes.error.weCouldNotLoadYourDispute", onContactSupport);
    return /* @__PURE__ */ u$1("div", { className: cx(DISPUTE_DATA_CLASS, { [DISPUTE_DATA_MOBILE_CLASS]: !isSmAndUpContainer }), children: error ? /* @__PURE__ */ u$1("div", { className: DISPUTE_DATA_ERROR_CONTAINER, children: /* @__PURE__ */ u$1(
      ErrorMessageDisplay,
      {
        renderSecondaryButton: onDismiss ? renderBackButton : void 0,
        withImage: true,
        outlined: false,
        absolutePosition: false,
        withBackground: false,
        ...errorProps
      }
    ) }) : dispute ? /* @__PURE__ */ u$1(k$1, { children: [
      /* @__PURE__ */ u$1("div", { className: DISPUTE_STATUS_BOX, children: /* @__PURE__ */ u$1(
        StatusBox$1,
        {
          ...statusBoxOptions,
          tag: /* @__PURE__ */ u$1(k$1, { children: [
            disputeType && /* @__PURE__ */ u$1(Tag, { label: disputeType }),
            !isFraudNotification && /* @__PURE__ */ u$1(DisputeStatusTag, { dispute: dispute.dispute })
          ] })
        }
      ) }),
      issuerComments.length > 0 && /* @__PURE__ */ u$1(DisputeIssuerComments, { issuerComments }),
      disputeAlertMode && /* @__PURE__ */ u$1(
        DisputeDataAlert,
        {
          alertMode: disputeAlertMode,
          dispute: dispute.dispute,
          timeZone: (_c2 = dispute.payment.balanceAccount) == null ? void 0 : _c2.timeZone
        }
      ),
      /* @__PURE__ */ u$1(DisputeDataProperties, { dispute, dataCustomization }),
      actionButtons.length > 0 ? /* @__PURE__ */ u$1("div", { className: DISPUTE_DATA_ACTION_BAR, children: /* @__PURE__ */ u$1(ButtonActions$1, { actions: actionButtons }) }) : null
    ] }) : null });
  };
  const DisputeDetails = ({
    id: id2,
    hideTitle,
    dataCustomization,
    onContactSupport,
    onDisputeAccept,
    onDisputeDefend,
    onDismiss
  }) => {
    const { flowState } = useDisputeFlow();
    const { i18n } = useCoreContext();
    switch (flowState) {
      case "details":
        return /* @__PURE__ */ u$1(k$1, { children: [
          !hideTitle && /* @__PURE__ */ u$1(Typography$1, { variant: TypographyVariant.TITLE, medium: true, children: i18n.get("disputes.disputeManagementTitle") }),
          /* @__PURE__ */ u$1(DisputeData, { disputeId: id2, dataCustomization, onContactSupport, onDismiss })
        ] });
      case "accept":
        return /* @__PURE__ */ u$1(AcceptDisputeFlow, { onDisputeAccept });
      case "defendReasonSelectionView":
      case "defenseSubmitResponseView":
      case "uploadDefenseFilesView":
        return /* @__PURE__ */ u$1(DefendDisputeFlow, { onDisputeDefend });
      default:
        return null;
    }
  };
  const DisputeDetailsContainer = (props) => {
    const [dispute, setDispute] = d();
    const setDisputeCallback = q$1((dispute2) => {
      setDispute(dispute2);
    }, []);
    return /* @__PURE__ */ u$1(DisputeContextProvider, { dispute, setDispute: setDisputeCallback, children: /* @__PURE__ */ u$1("div", { className: "adyen-pe-dispute__container", children: /* @__PURE__ */ u$1(DisputeDetails, { ...props }) }) });
  };
  const DisputeManagementModal = ({
    children,
    selectedDetail,
    resetDetails,
    dataCustomization,
    onContactSupport,
    refreshDisputesList,
    setModalVisible
  }) => {
    const { i18n } = useCoreContext();
    const [disputeManagementSuccessful, setDisputeManagementSuccessful] = d(false);
    const isModalOpen = !!selectedDetail;
    const onCloseCallback = q$1(() => {
      if (disputeManagementSuccessful) {
        setDisputeManagementSuccessful(false);
        refreshDisputesList("CHARGEBACKS");
      }
      setModalVisible(false);
      resetDetails();
    }, [disputeManagementSuccessful, refreshDisputesList, resetDetails, setModalVisible]);
    const onDisputeManagementSuccessful = q$1(() => {
      setDisputeManagementSuccessful(true);
    }, []);
    y(() => {
      if (isModalOpen) {
        setModalVisible(true);
        popoverUtil.closeAll();
      }
    }, [isModalOpen, setModalVisible]);
    return /* @__PURE__ */ u$1("div", { children: [
      children,
      selectedDetail && /* @__PURE__ */ u$1(
        Modal,
        {
          isOpen: isModalOpen,
          "aria-label": i18n.get("disputes.disputeManagementTitle"),
          onClose: onCloseCallback,
          isDismissible: true,
          headerWithBorder: false,
          size: selectedDetail.modalSize || "large",
          children: /* @__PURE__ */ u$1("div", { className: "adyen-pe-dispute-management-modal-content", children: /* @__PURE__ */ u$1(
            DisputeDetailsContainer,
            {
              id: selectedDetail.selection.data,
              dataCustomization,
              onDisputeAccept: onDisputeManagementSuccessful,
              onDisputeDefend: onDisputeManagementSuccessful,
              onContactSupport,
              onDismiss: resetDetails,
              hideTitle: true
            }
          ) })
        }
      )
    ] });
  };
  function Tabs({ activeTab, tabs: tabs2, onChange }) {
    const { activeIndex, onClick, onKeyDown, refs, uniqueId: uniqueId2 } = useTabbedControl({ onChange, options: tabs2, activeOption: activeTab });
    const { i18n } = useCoreContext();
    return /* @__PURE__ */ u$1("section", { "aria-label": i18n.get("tabs"), children: [
      /* @__PURE__ */ u$1("div", { className: "adyen-pe-tabs", role: "tablist", "aria-orientation": "horizontal", children: tabs2.map((tab, index) => {
        const isActive = activeIndex === index;
        return /* @__PURE__ */ u$1(
          "button",
          {
            role: "tab",
            name: tab.id,
            ref: refs[index],
            id: `tab:${uniqueId2}-${tab.id}`,
            className: "adyen-pe-tabs__tab",
            "aria-controls": `panel:${uniqueId2}-${tab.id}`,
            "aria-selected": isActive,
            onClick: isActive ? void 0 : onClick,
            onKeyDown,
            disabled: tab.disabled,
            tabIndex: isActive ? 0 : -1,
            children: /* @__PURE__ */ u$1(Typography$1, { el: TypographyElement.SPAN, variant: TypographyVariant.BODY, className: "adyen-pe-tabs__tab-label", stronger: true, children: i18n.get(tab.label) })
          },
          `tab:${uniqueId2}-${tab.id}`
        );
      }) }),
      /* @__PURE__ */ u$1("div", { className: "adyen-pe-tabpanels", children: tabs2.map((tab, index) => /* @__PURE__ */ u$1(
        "section",
        {
          role: "tabpanel",
          id: `panel:${uniqueId2}-${tab.id}`,
          className: "adyen-pe-tabpanels__panel",
          "aria-labelledby": `tab:${uniqueId2}-${tab.id}`,
          hidden: activeIndex !== index,
          children: tab.content
        },
        `panel:${uniqueId2}-${tab.id}`
      )) })
    ] });
  }
  const DEFAULT_DISPUTE_STATUS_GROUP = "CHARGEBACKS";
  const DISPUTE_SCHEMES_FILTER_PARAM = "schemeCodes";
  const DISPUTE_REASONS_FILTER_PARAM = "reasonCategories";
  const LAST_REFRESH_TIMESTAMP_PARAM = "_t";
  const DISPUTE_SCHEMES_FILTER_VALUES = Object.keys(DISPUTE_PAYMENT_SCHEMES);
  const DISPUTE_REASONS_FILTER_VALUES = Object.keys(DISPUTE_REASON_CATEGORIES);
  const DISPUTE_STATUS_GROUPS_VALUES = Object.keys(DISPUTE_STATUS_GROUPS);
  const DISPUTE_STATUS_GROUPS_TABS = Object.entries(DISPUTE_STATUS_GROUPS).map(([statusGroup, labelTranslationKey]) => ({
    id: statusGroup,
    label: labelTranslationKey,
    content: null
  }));
  const DisputesOverviewTabsDropdown = ({
    activeTab,
    onChange
  }) => {
    const { i18n } = useCoreContext();
    const [statusGroup, setStatusGroup] = d(activeTab);
    const selectItems = T$1(() => {
      return Object.entries(DISPUTE_STATUS_GROUPS).map(([statusGroup2, labelTranslationKey]) => ({
        id: statusGroup2,
        name: i18n.get(labelTranslationKey)
      }));
    }, [i18n]);
    y(() => {
      const currentTab = DISPUTE_STATUS_GROUPS_TABS.find((tab) => tab.id === statusGroup);
      currentTab && onChange(currentTab);
    }, [onChange, statusGroup]);
    y(() => setStatusGroup(activeTab), [activeTab]);
    return /* @__PURE__ */ u$1(
      Select,
      {
        items: selectItems,
        selected: statusGroup,
        onChange: ({ target }) => setStatusGroup(target.value),
        showOverlay: true,
        multiSelect: false,
        filterable: false
      }
    );
  };
  const DisputesOverview = ({
    onFiltersChanged,
    balanceAccounts,
    allowLimitSelection = true,
    preferredLimit = DEFAULT_PAGE_LIMIT,
    isLoadingBalanceAccount,
    onContactSupport,
    hideTitle,
    onRecordSelection,
    showDetails,
    dataCustomization
  }) => {
    const { i18n } = useCoreContext();
    const { getDisputeList: getDisputesCall } = useConfigContext().endpoints;
    const { activeBalanceAccount, balanceAccountSelectionOptions, onBalanceAccountSelection } = useBalanceAccountSelection(balanceAccounts, true);
    const { defaultParams, nowTimestamp: nowTimestamp2, refreshNowTimestamp } = useDefaultOverviewFilterParams("disputes", activeBalanceAccount);
    const [modalVisible, setModalVisible] = d(false);
    const [mobileStyleOverrides, setMobileStyleOverrides] = d();
    const [statusGroup, setStatusGroup] = d(DEFAULT_DISPUTE_STATUS_GROUP);
    const [statusGroupFetchPending, setStatusGroupFetchPending] = d(false);
    const [statusGroupActiveTab, setStatusGroupActiveTab] = d(statusGroup);
    const disputeDetails = T$1(
      () => ({
        showDetails: showDetails ?? true,
        callback: onRecordSelection
      }),
      [showDetails, onRecordSelection]
    );
    const modalOptions = T$1(() => ({ dispute: disputeDetails }), [disputeDetails]);
    const getDisputes = q$1(
      async ({ [LAST_REFRESH_TIMESTAMP_PARAM]: _2, ...pageRequestParams }, signal) => {
        const requestOptions = { signal, errorLevel: "error" };
        return getDisputesCall(requestOptions, {
          query: {
            ...pageRequestParams,
            ...(activeBalanceAccount == null ? void 0 : activeBalanceAccount.id) !== ALL_BALANCE_ACCOUNTS_SELECTION_ID && {
              balanceAccountId: (activeBalanceAccount == null ? void 0 : activeBalanceAccount.id) ?? ""
            },
            reasonCategories: listFrom(pageRequestParams[DISPUTE_REASONS_FILTER_PARAM]),
            schemeCodes: listFrom(pageRequestParams[DISPUTE_SCHEMES_FILTER_PARAM]),
            createdSince: pageRequestParams[FilterParam.CREATED_SINCE] ?? defaultParams.current.defaultFilterParams[FilterParam.CREATED_SINCE],
            createdUntil: pageRequestParams[FilterParam.CREATED_UNTIL] ?? defaultParams.current.defaultFilterParams[FilterParam.CREATED_UNTIL]
          }
        });
      },
      [activeBalanceAccount == null ? void 0 : activeBalanceAccount.id, defaultParams, getDisputesCall]
    );
    const filterBarState = useFilterBarState();
    const _onFiltersChanged = T$1(() => isFunction(onFiltersChanged) ? onFiltersChanged : void 0, [onFiltersChanged]);
    const preferredLimitOptions = T$1(() => allowLimitSelection ? LIMIT_OPTIONS : void 0, [allowLimitSelection]);
    const defaultFilters = Object.assign(defaultParams.current.defaultFilterParams, {
      [DISPUTE_REASONS_FILTER_PARAM]: void 0,
      [DISPUTE_SCHEMES_FILTER_PARAM]: void 0,
      [LAST_REFRESH_TIMESTAMP_PARAM]: performance.now(),
      statusGroup: DEFAULT_DISPUTE_STATUS_GROUP
    });
    const { canResetFilters, error, fetching, filters, limit, limitOptions, records, resetFilters, updateFilters, updateLimit, ...paginationProps } = useCursorPaginatedRecords({
      fetchRecords: getDisputes,
      dataField: "data",
      filterParams: defaultFilters,
      initialFiltersSameAsDefault: true,
      onFiltersChanged: _onFiltersChanged,
      preferredLimit,
      preferredLimitOptions,
      enabled: !!(activeBalanceAccount == null ? void 0 : activeBalanceAccount.id) && !!getDisputesCall
    });
    const cachedDisputeReasonsFilter = A$1(void 0);
    const disputeReasonsFilter = useMultiSelectionFilter({
      mapFilterOptionName: q$1((reason) => i18n.get(DISPUTE_REASON_CATEGORIES[reason]), [i18n]),
      filterParam: DISPUTE_REASONS_FILTER_PARAM,
      filterValues: DISPUTE_REASONS_FILTER_VALUES,
      defaultFilters: { ...defaultFilters, [DISPUTE_REASONS_FILTER_PARAM]: cachedDisputeReasonsFilter.current },
      updateFilters,
      filters
    });
    const disputeSchemesFilter = useMultiSelectionFilter({
      mapFilterOptionName: q$1((scheme) => DISPUTE_PAYMENT_SCHEMES[scheme], []),
      filterParam: DISPUTE_SCHEMES_FILTER_PARAM,
      filterValues: DISPUTE_SCHEMES_FILTER_VALUES,
      defaultFilters,
      updateFilters,
      filters
    });
    const { updateDetails, resetDetails, selectedDetail } = useModalDetails(modalOptions);
    const onRowClick = q$1(
      ({ disputePspReference }) => {
        updateDetails({
          selection: {
            type: "dispute",
            data: disputePspReference
          },
          modalSize: "small"
        }).callback({ id: disputePspReference });
      },
      [updateDetails]
    );
    const sinceDate = T$1(() => {
      const date2 = new Date(nowTimestamp2);
      const oneYearUntilNow = date2.setFullYear(date2.getFullYear() - 1);
      const earliestTimestamp = new Date(EARLIEST_DISPUTES_SINCE_DATE).getTime();
      return new Date(Math.max(earliestTimestamp, oneYearUntilNow)).toString();
    }, [nowTimestamp2]);
    const debounceTimeoutIdRef = A$1(null);
    const onStatusGroupChange = q$1(
      ({ id: statusGroup2 }) => {
        debounceTimeoutIdRef.current && clearTimeout(debounceTimeoutIdRef.current);
        debounceTimeoutIdRef.current = setTimeout(() => {
          requestAnimationFrame(() => setStatusGroupFetchPending(false));
          const reasonsFilterParam = DISPUTE_REASONS_FILTER_PARAM;
          const filterUpdates = { statusGroup: statusGroup2, [reasonsFilterParam]: void 0 };
          if (statusGroup2 !== "FRAUD_ALERTS") {
            filterUpdates[reasonsFilterParam] = cachedDisputeReasonsFilter.current;
          }
          updateFilters(filterUpdates);
          debounceTimeoutIdRef.current = null;
        }, 500);
        setStatusGroup(statusGroup2);
        setStatusGroupFetchPending(true);
        setStatusGroupActiveTab(void 0);
      },
      [updateFilters]
    );
    const refreshDisputesList = q$1(
      (gotoStatusGroup) => {
        gotoStatusGroup && DISPUTE_STATUS_GROUPS_VALUES.includes(gotoStatusGroup) && gotoStatusGroup !== statusGroup ? setStatusGroupActiveTab(gotoStatusGroup) : (
          // Refresh the current disputes list status group,
          // by updating the last refresh timestamp filter parameter
          updateFilters({ [LAST_REFRESH_TIMESTAMP_PARAM]: performance.now() })
        );
      },
      [statusGroup, updateFilters]
    );
    const isMobileContainer = useResponsiveContainer(containerQueries.down.xs);
    y(() => {
      setMobileStyleOverrides(isMobileContainer && modalVisible ? { maxHeight: 0, overflowY: "hidden" } : void 0);
    }, [isMobileContainer, modalVisible]);
    y(() => {
      refreshNowTimestamp();
      if (filters["statusGroup"] !== "FRAUD_ALERTS") {
        cachedDisputeReasonsFilter.current = filters[DISPUTE_REASONS_FILTER_PARAM];
      }
    }, [filters, refreshNowTimestamp]);
    return /* @__PURE__ */ u$1("div", { style: mobileStyleOverrides, className: cx(BASE_CLASS$4, { [BASE_XS_CLASS]: isMobileContainer }), children: [
      /* @__PURE__ */ u$1(Header, { hideTitle, titleKey: "disputes.title", children: /* @__PURE__ */ u$1(FilterBarMobileSwitch, { ...filterBarState }) }),
      /* @__PURE__ */ u$1("div", { children: [
        /* @__PURE__ */ u$1("div", { className: TABS_CONTAINER_CLASS, children: isMobileContainer ? /* @__PURE__ */ u$1(DisputesOverviewTabsDropdown, { activeTab: statusGroupActiveTab ?? statusGroup, onChange: onStatusGroupChange }) : /* @__PURE__ */ u$1(Tabs, { tabs: DISPUTE_STATUS_GROUPS_TABS, activeTab: statusGroupActiveTab, onChange: onStatusGroupChange }) }),
        /* @__PURE__ */ u$1(FilterBar, { ...filterBarState, children: [
          /* @__PURE__ */ u$1(
            BalanceAccountSelector,
            {
              activeBalanceAccount,
              balanceAccountSelectionOptions,
              onBalanceAccountSelection
            }
          ),
          /* @__PURE__ */ u$1(
            DateFilter,
            {
              canResetFilters,
              defaultParams,
              filters,
              nowTimestamp: nowTimestamp2,
              refreshNowTimestamp,
              sinceDate,
              timezone: activeBalanceAccount == null ? void 0 : activeBalanceAccount.timeZone,
              updateFilters
            }
          ),
          /* @__PURE__ */ u$1(MultiSelectionFilter, { ...disputeSchemesFilter, placeholder: i18n.get("disputes.paymentMethod") }),
          statusGroup !== "FRAUD_ALERTS" && /* @__PURE__ */ u$1(MultiSelectionFilter, { ...disputeReasonsFilter, placeholder: i18n.get("disputes.disputeReason") })
        ] })
      ] }),
      /* @__PURE__ */ u$1(
        DisputeManagementModal,
        {
          dataCustomization: (dataCustomization == null ? void 0 : dataCustomization.details) && { details: dataCustomization == null ? void 0 : dataCustomization.details },
          selectedDetail,
          resetDetails,
          onContactSupport,
          refreshDisputesList,
          setModalVisible,
          children: /* @__PURE__ */ u$1(
            DisputesTable,
            {
              activeBalanceAccount,
              balanceAccountId: activeBalanceAccount == null ? void 0 : activeBalanceAccount.id,
              loading: statusGroupFetchPending || fetching || isLoadingBalanceAccount || !balanceAccounts || !activeBalanceAccount,
              data: records,
              showPagination: true,
              limit,
              limitOptions,
              onContactSupport,
              onLimitSelection: updateLimit,
              error,
              onRowClick,
              statusGroup,
              ...paginationProps
            }
          )
        }
      )
    ] });
  };
  function DisputesOverviewContainer({ ...props }) {
    const { balanceAccounts, isBalanceAccountIdWrong, isFetching, error } = useBalanceAccounts(props.balanceAccountId);
    return /* @__PURE__ */ u$1(
      DataOverviewContainer,
      {
        balanceAccountsError: error,
        className: "adyen-pe-disputes-overview-container",
        errorMessage: "disputes.error.couldNotLoadDisputesOverview",
        isBalanceAccountIdWrong,
        onContactSupport: props.onContactSupport,
        children: /* @__PURE__ */ u$1(DisputesOverview, { ...props, balanceAccounts, isLoadingBalanceAccount: isFetching })
      }
    );
  }
  class DisputesOverviewElement extends UIElement {
    constructor(props) {
      super(props);
      __publicField(this, "componentToRender", () => {
        return /* @__PURE__ */ u$1(
          DisputesOverviewContainer,
          {
            ...this.props,
            balanceAccountId: this.props.balanceAccountId,
            ref: (ref) => void (this.componentRef = ref)
          }
        );
      });
      this.componentToRender = this.componentToRender.bind(this);
    }
  }
  __publicField(DisputesOverviewElement, "type", "disputes");
  class DisputeManagementElement extends UIElement {
    constructor(props) {
      super(props);
      __publicField(this, "componentToRender", () => {
        return /* @__PURE__ */ u$1(DisputeDetailsContainer, { ...this.props, ref: (ref) => void (this.componentRef = ref) });
      });
      this.componentToRender = this.componentToRender.bind(this);
    }
  }
  __publicField(DisputeManagementElement, "type", "disputesManagement");
  async function AdyenPlatformExperience(props) {
    const core = new Core(props);
    return await core.initialize();
  }
  const SvgAngleRight = (props) => /* @__PURE__ */ u$1("svg", { xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 16 16", ...props, children: /* @__PURE__ */ u$1("path", { d: "M3.75 7.5V3.25h-1.5V7.5c0 1.24 1 2.25 2.25 2.25h6.69L8.94 12 10 13.06 14.06 9 10 4.94 8.94 6l2.25 2.25H4.5a.75.75 0 0 1-.75-.75Z", fill: "currentColor" }) });
  const angleRight = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    default: SvgAngleRight
  }, Symbol.toStringTag, { value: "Module" }));
  const SvgCheckmarkCircleFill = (props) => /* @__PURE__ */ u$1("svg", { xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 16 16", ...props, children: [
    /* @__PURE__ */ u$1("g", { clipPath: "url(#checkmark-circle-fill_svg__a)", children: /* @__PURE__ */ u$1("path", { fill: "currentColor", d: "M.25 8a7.75 7.75 0 1 1 15.5 0A7.75 7.75 0 0 1 .25 8M11 4.94l-4 4-2-2L3.94 8 7 11.06 12.06 6z" }) }),
    /* @__PURE__ */ u$1("defs", { children: /* @__PURE__ */ u$1("clipPath", { id: "checkmark-circle-fill_svg__a", children: /* @__PURE__ */ u$1("path", { fill: "currentColor", d: "M0 0h16v16H0z" }) }) })
  ] });
  const checkmarkCircleFill = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    default: SvgCheckmarkCircleFill
  }, Symbol.toStringTag, { value: "Module" }));
  const SvgCheckmarkSquareFill = (props) => /* @__PURE__ */ u$1("svg", { xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 16 16", ...props, children: /* @__PURE__ */ u$1("path", { fill: "currentColor", d: "M1.25 3.5c0-1.24 1-2.25 2.25-2.25h9c1.24 0 2.25 1 2.25 2.25v9c0 1.24-1 2.25-2.25 2.25h-9c-1.24 0-2.25-1-2.25-2.25zM12.06 6 11 4.94l-4 4-2-2L3.94 8 7 11.06z" }) });
  const checkmarkSquareFill = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    default: SvgCheckmarkSquareFill
  }, Symbol.toStringTag, { value: "Module" }));
  const SvgCheckmark = (props) => /* @__PURE__ */ u$1("svg", { xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 16 16", ...props, children: /* @__PURE__ */ u$1("path", { fill: "currentColor", d: "M15.06 4 14 2.94l-8 8-4-4L.94 8 6 13.06z" }) });
  const checkmark = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    default: SvgCheckmark
  }, Symbol.toStringTag, { value: "Module" }));
  const SvgChevronDown = (props) => /* @__PURE__ */ u$1("svg", { xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 16 16", ...props, children: /* @__PURE__ */ u$1("path", { fill: "currentColor", d: "m3 4.44 5 5 5-5 1.06 1.06L8 11.56 1.94 5.5z" }) });
  const chevronDown = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    default: SvgChevronDown
  }, Symbol.toStringTag, { value: "Module" }));
  const SvgChevronLeft = (props) => /* @__PURE__ */ u$1("svg", { xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 16 16", ...props, children: /* @__PURE__ */ u$1("path", { fill: "currentColor", d: "m11.56 3-5 5 5 5-1.06 1.06L4.44 8l6.06-6.06z" }) });
  const chevronLeft = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    default: SvgChevronLeft
  }, Symbol.toStringTag, { value: "Module" }));
  const SvgChevronRight = (props) => /* @__PURE__ */ u$1("svg", { xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 16 16", ...props, children: /* @__PURE__ */ u$1("path", { fill: "currentColor", d: "m4.44 13 5-5-5-5L5.5 1.94 11.56 8 5.5 14.06z" }) });
  const chevronRight = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    default: SvgChevronRight
  }, Symbol.toStringTag, { value: "Module" }));
  const SvgChevronUp = (props) => /* @__PURE__ */ u$1("svg", { xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 16 16", ...props, children: /* @__PURE__ */ u$1("path", { fill: "currentColor", d: "m13 11.56-5-5-5 5-1.06-1.06L8 4.44l6.06 6.06z" }) });
  const chevronUp = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    default: SvgChevronUp
  }, Symbol.toStringTag, { value: "Module" }));
  const SvgCopy = (props) => /* @__PURE__ */ u$1("svg", { xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 16 16", ...props, children: /* @__PURE__ */ u$1("path", { fill: "currentColor", d: "M3.5 1.25c-1.24 0-2.25 1-2.25 2.25v5c0 1.24 1 2.25 2.25 2.25h1.75v1.75c0 1.24 1 2.25 2.25 2.25h5c1.24 0 2.25-1 2.25-2.25v-5c0-1.24-1-2.25-2.25-2.25h-1.75V3.5c0-1.24-1-2.25-2.25-2.25zm5.75 4H7.5c-1.24 0-2.25 1-2.25 2.25v1.75H3.5a.75.75 0 0 1-.75-.75v-5c0-.41.34-.75.75-.75h5c.41 0 .75.34.75.75zm-2.5 7.25v-5c0-.41.34-.75.75-.75h5c.41 0 .75.34.75.75v5c0 .41-.34.75-.75.75h-5a.75.75 0 0 1-.75-.75" }) });
  const copy = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    default: SvgCopy
  }, Symbol.toStringTag, { value: "Module" }));
  const SvgCrossCircleFill = (props) => /* @__PURE__ */ u$1("svg", { xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 16 16", ...props, children: [
    /* @__PURE__ */ u$1("g", { clipPath: "url(#cross-circle-fill_svg__a)", children: /* @__PURE__ */ u$1("path", { fill: "currentColor", d: "M.25 8a7.75 7.75 0 1 1 15.5 0A7.75 7.75 0 0 1 .25 8M6 4.94 4.94 6l2 2-2 2L6 11.06l2-2 2 2L11.06 10l-2-2 2-2L10 4.94l-2 2z" }) }),
    /* @__PURE__ */ u$1("defs", { children: /* @__PURE__ */ u$1("clipPath", { id: "cross-circle-fill_svg__a", children: /* @__PURE__ */ u$1("path", { fill: "currentColor", d: "M0 0h16v16H0z" }) }) })
  ] });
  const crossCircleFill = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    default: SvgCrossCircleFill
  }, Symbol.toStringTag, { value: "Module" }));
  const SvgCross = (props) => /* @__PURE__ */ u$1("svg", { xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 16 16", ...props, children: /* @__PURE__ */ u$1("path", { fill: "currentColor", d: "m8 9.06 4 4L13.06 12l-4-4 4-4L12 2.94l-4 4-4-4L2.94 4l4 4-4 4L4 13.06z" }) });
  const cross = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    default: SvgCross
  }, Symbol.toStringTag, { value: "Module" }));
  const SvgDownload = (props) => /* @__PURE__ */ u$1("svg", { xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 16 16", ...props, children: [
    /* @__PURE__ */ u$1("path", { fill: "currentColor", d: "M8.75 1.25v7.94L11 6.94 12.06 8 8 12.06 3.94 8 5 6.94l2.25 2.25V1.25z" }),
    /* @__PURE__ */ u$1("path", { fill: "currentColor", d: "M2.75 12.5v-2.25h-1.5v2.25a2.25 2.25 0 0 0 2.25 2.25h9a2.25 2.25 0 0 0 2.25-2.25v-2.25h-1.5v2.25a.75.75 0 0 1-.75.75h-9a.75.75 0 0 1-.75-.75" })
  ] });
  const download = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    default: SvgDownload
  }, Symbol.toStringTag, { value: "Module" }));
  const SvgExternalLink = (props) => /* @__PURE__ */ u$1("svg", { width: 11, height: 11, viewBox: "0 0 11 11", fill: "none", xmlns: "http://www.w3.org/2000/svg", ...props, children: /* @__PURE__ */ u$1("path", { d: "M0.939453 9L8.18945 1.75H3.25011V0.25H10.7501V7.75H9.25011V2.81066L2.00011 10.0607L0.939453 9Z", fill: "#00112C" }) });
  const externalLink = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    default: SvgExternalLink
  }, Symbol.toStringTag, { value: "Module" }));
  const SvgFilter = (props) => /* @__PURE__ */ u$1("svg", { xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 16 16", ...props, children: /* @__PURE__ */ u$1("path", { fill: "currentColor", d: "M1.25 1.25h13.5v2.8c0 .6-.24 1.17-.66 1.59l-4.01 4.01v1.97l-2.74 3.14H5.92v-5.1L1.91 5.63a2.3 2.3 0 0 1-.66-1.59zm1.5 1.5v1.3q0 .31.22.53l4.45 4.45v3.36l1.16-1.33V9.03l4.45-4.45a.8.8 0 0 0 .22-.53v-1.3z" }) });
  const filter = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    default: SvgFilter
  }, Symbol.toStringTag, { value: "Module" }));
  const SvgInfoFilled = (props) => /* @__PURE__ */ u$1("svg", { xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 16 16", ...props, children: [
    /* @__PURE__ */ u$1("g", { clipPath: "url(#info-filled_svg__a)", children: /* @__PURE__ */ u$1("path", { fill: "currentColor", d: "M5.03.84a7.75 7.75 0 1 1 5.94 14.32A7.75 7.75 0 0 1 5.03.84M8.75 4.5a1 1 0 1 0-2 0 1 1 0 0 0 2 0m0 1.75h-2.5v1.5h1v2.5h-1v1.5h3.5v-1.5h-1z" }) }),
    /* @__PURE__ */ u$1("defs", { children: /* @__PURE__ */ u$1("clipPath", { id: "info-filled_svg__a", children: /* @__PURE__ */ u$1("path", { fill: "currentColor", d: "M0 0h16v16H0z" }) }) })
  ] });
  const infoFilled = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    default: SvgInfoFilled
  }, Symbol.toStringTag, { value: "Module" }));
  const SvgMinusCircleOutline = (props) => /* @__PURE__ */ u$1("svg", { xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 16 16", ...props, children: [
    /* @__PURE__ */ u$1("path", { d: "M11.75 7.25h-7.5v1.5h7.5v-1.5Z", fill: "currentColor" }),
    /* @__PURE__ */ u$1("path", { d: "M8 .25a7.75 7.75 0 1 0 0 15.5A7.75 7.75 0 0 0 8 .25ZM1.75 8a6.25 6.25 0 1 1 12.5 0 6.25 6.25 0 0 1-12.5 0Z", fill: "currentColor" })
  ] });
  const minusCircleOutline = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    default: SvgMinusCircleOutline
  }, Symbol.toStringTag, { value: "Module" }));
  const SvgPlus = (props) => /* @__PURE__ */ u$1("svg", { width: 12, height: 12, viewBox: "0 0 12 12", fill: "none", xmlns: "http://www.w3.org/2000/svg", ...props, children: /* @__PURE__ */ u$1("path", { d: "M6.75 5.25V0.25H5.25V5.25H0.25V6.75H5.25V11.75H6.75V6.75H11.75V5.25H6.75Z", fill: "currentColor" }) });
  const plus = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    default: SvgPlus
  }, Symbol.toStringTag, { value: "Module" }));
  const SvgPlusCircleOutline = (props) => /* @__PURE__ */ u$1("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 16 16", fill: "none", ...props, children: [
    /* @__PURE__ */ u$1("path", { d: "M8.7 7.3h2.9v1.4H8.7v2.9H7.3V8.7H4.4V7.3h2.9V4.4h1.4v2.9Z", fill: "currentColor" }),
    /* @__PURE__ */ u$1("path", { d: "M.3 8a7.7 7.7 0 1 1 15.4 0A7.7 7.7 0 0 1 .3 8ZM8 1.7a6.3 6.3 0 1 0 0 12.6A6.3 6.3 0 0 0 8 1.7Z", fill: "currentColor" })
  ] });
  const plusCircleOutline = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    default: SvgPlusCircleOutline
  }, Symbol.toStringTag, { value: "Module" }));
  const SvgSquare = (props) => /* @__PURE__ */ u$1("svg", { xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 16 16", ...props, children: /* @__PURE__ */ u$1("path", { fill: "currentColor", fillRule: "evenodd", d: "M1.25 3.5c0-1.24 1-2.25 2.25-2.25h9c1.24 0 2.25 1 2.25 2.25v9c0 1.24-1 2.25-2.25 2.25h-9c-1.24 0-2.25-1-2.25-2.25zm2.25-.75a.75.75 0 0 0-.75.75v9c0 .41.34.75.75.75h9c.41 0 .75-.34.75-.75v-9a.75.75 0 0 0-.75-.75z", clipRule: "evenodd" }) });
  const square = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    default: SvgSquare
  }, Symbol.toStringTag, { value: "Module" }));
  const SvgTrashCan = (props) => /* @__PURE__ */ u$1("svg", { xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 16 16", ...props, children: [
    /* @__PURE__ */ u$1("path", { fill: "currentColor", d: "M7.25 6.25h-1.5v6.5h1.5v-6.5ZM8.75 6.25h1.5v6.5h-1.5v-6.5Z" }),
    /* @__PURE__ */ u$1("path", { fill: "currentColor", d: "M14.75 3.25h-2.21l-.49-1.5a2.2 2.2 0 0 0-.83-1.1c-.39-.27-.88-.4-1.3-.41H6.09c-.45 0-.92.14-1.31.41a2.2 2.2 0 0 0-.83 1.11l-.49 1.48H1.25v1.5h1.07l.82 8.96c.05.56.31 1.08.72 1.46.41.38.95.59 1.51.59h5.27c.56 0 1.1-.21 1.51-.59.42-.38.67-.9.72-1.46l.82-8.96h1.07v-1.5l-.01.01Zm-9.38-1a.75.75 0 0 1 .27-.36.7.7 0 0 1 .44-.13h3.85c.15 0 .3.05.42.13.13.09.22.21.27.35l.33 1.02H5.02l.33-1 .02-.01Zm6 11.33a.72.72 0 0 1-.24.48.73.73 0 0 1-.5.19H5.36a.76.76 0 0 1-.5-.19.76.76 0 0 1-.24-.49l-.81-8.82h8.36l-.81 8.82.01.01Z" })
  ] });
  const trashCan = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    default: SvgTrashCan
  }, Symbol.toStringTag, { value: "Module" }));
  const SvgUpload = (props) => /* @__PURE__ */ u$1("svg", { xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 16 16", ...props, children: [
    /* @__PURE__ */ u$1("path", { fill: "currentColor", d: "M8 .94 12.06 5 11 6.06 8.75 3.81v7.94h-1.5V3.81L5 6.06 3.94 5 8 .94Z" }),
    /* @__PURE__ */ u$1("path", { fill: "currentColor", d: "M2.75 12.5v-2.25h-1.5v2.25a2.25 2.25 0 0 0 2.25 2.25h9a2.25 2.25 0 0 0 2.25-2.25v-2.25h-1.5v2.25a.75.75 0 0 1-.75.75h-9a.75.75 0 0 1-.75-.75Z" })
  ] });
  const upload = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    default: SvgUpload
  }, Symbol.toStringTag, { value: "Module" }));
  const SvgWarningFilled = (props) => /* @__PURE__ */ u$1("svg", { xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 16 16", ...props, children: /* @__PURE__ */ u$1("path", { fill: "currentColor", d: "m15.35 11.53-5.4-9.32q-.3-.52-.82-.83a2.26 2.26 0 0 0-3.07.82L.65 11.53a2.2 2.2 0 0 0 0 2.25A2.2 2.2 0 0 0 2.6 14.9h10.8q.6 0 1.12-.3t.83-.82.3-1.13-.3-1.13zm-8.1-6.95h1.5v4.5h-1.5zm1.67 7.13a1 1 0 0 1-.93.62.99.99 0 0 1-.83-1.55q.17-.24.45-.37.28-.11.58-.06a1 1 0 0 1 .78.78q.06.29-.06.58z" }) });
  const warningFilled = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    default: SvgWarningFilled
  }, Symbol.toStringTag, { value: "Module" }));
  const SvgWarning = (props) => /* @__PURE__ */ u$1("svg", { xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 16 16", ...props, children: [
    /* @__PURE__ */ u$1("path", { fill: "currentColor", d: "M8.75 4.58h-1.5v4.5h1.5zm-.04 6.04a1 1 0 0 0-.51-.27 1 1 0 0 0-1.2.99q.01.41.29.71.3.29.71.29.3 0 .56-.17.24-.17.37-.45.12-.28.06-.58a1 1 0 0 0-.27-.51z" }),
    /* @__PURE__ */ u$1("path", { fill: "currentColor", d: "m9.95 2.21 5.4 9.32v-.01q.3.52.3 1.13a2.2 2.2 0 0 1-1.13 1.95q-.52.3-1.12.3H2.6a2.2 2.2 0 0 1-1.95-1.12q-.3-.5-.3-1.12 0-.61.3-1.13L6.06 2.2q.3-.52.82-.82a2.26 2.26 0 0 1 3.07.83m3.82 11.09a1 1 0 0 0 .28-.27l.01.01q.1-.18.1-.38a1 1 0 0 0-.1-.37l-5.4-9.33a1 1 0 0 0-.28-.28 1 1 0 0 0-.38-.1 1 1 0 0 0-.38.1 1 1 0 0 0-.27.27l-5.4 9.34a1 1 0 0 0-.1.37q0 .2.1.37a1 1 0 0 0 .27.27q.18.1.38.1h10.79a1 1 0 0 0 .38-.1" })
  ] });
  const warning = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    default: SvgWarning
  }, Symbol.toStringTag, { value: "Module" }));
  exports2.AdyenPlatformExperience = AdyenPlatformExperience;
  exports2.CapitalOffer = CapitalOfferElement;
  exports2.CapitalOverview = CapitalOverviewElement;
  exports2.Core = Core;
  exports2.DisputeManagement = DisputeManagementElement;
  exports2.DisputesOverview = DisputesOverviewElement;
  exports2.PayoutDetails = PayoutElement;
  exports2.PayoutsOverview = PayoutsElement;
  exports2.ReportsOverview = ReportsElement;
  exports2.TransactionDetails = TransactionElement;
  exports2.TransactionsOverview = TransactionsElement;
  exports2.all_locales = all_locales;
  exports2.da_DK = da_DK;
  exports2.de_DE = de_DE;
  exports2.en_US = en_US;
  exports2.es_ES = es_ES;
  exports2.fi_FI = fi_FI;
  exports2.fr_FR = fr_FR;
  exports2.it_IT = it_IT;
  exports2.nl_NL = nl_NL;
  exports2.no_NO = no_NO;
  exports2.pt_BR = pt_BR;
  exports2.sv_SE = sv_SE;
  Object.defineProperty(exports2, Symbol.toStringTag, { value: "Module" });
});
//# sourceMappingURL=index.js.map
